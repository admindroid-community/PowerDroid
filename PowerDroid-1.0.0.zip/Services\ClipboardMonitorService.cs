using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Interop;
using PowerDroid.Models;

namespace PowerDroid.Services
{
    /// <summary>
    /// Service that monitors the Windows clipboard for URL changes.
    /// Uses Win32 AddClipboardFormatListener for efficient clipboard monitoring.
    /// </summary>
    public class ClipboardMonitorService : IDisposable
    {
        #region Win32 Interop

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool AddClipboardFormatListener(IntPtr hwnd);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RemoveClipboardFormatListener(IntPtr hwnd);

        private const int WM_CLIPBOARDUPDATE = 0x031D;

        #endregion

        #region Singleton

        private static ClipboardMonitorService? _instance;
        private static readonly object _lock = new object();

        public static ClipboardMonitorService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new ClipboardMonitorService();
                    }
                }
                return _instance;
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// Fired when a valid URL is detected in the clipboard that matches a rule with notifications enabled.
        /// </summary>
        public event EventHandler<ClipboardUrlEventArgs>? UrlDetected;

        /// <summary>
        /// Fired for ALL clipboard text captures (used by Power Clip).
        /// </summary>
        public event EventHandler<ClipboardTextEventArgs>? ClipboardTextCaptured;

        /// <summary>
        /// Fired when an image is detected on the clipboard (used by Power Clip).
        /// </summary>
        public event EventHandler<ClipboardImageEventArgs>? ClipboardImageCaptured;

        /// <summary>
        /// Fired when a GIF is detected on the clipboard (raw bytes, preserves animation).
        /// </summary>
        public event EventHandler<ClipboardGifEventArgs>? ClipboardGifCaptured;

        #endregion

        #region Fields

        private HwndSource? _hwndSource;
        private bool _isRunning;
        private readonly ConcurrentDictionary<string, DateTime> _recentDomains = new();
        private string? _lastClipboardText;
        private DateTime _lastClipboardTime;
        private const int DEDUP_WINDOW_MS = 3000; // 3 seconds to deduplicate rapid clipboard events
        private bool _disposed;
        private int _suppressNextCapture; // int for Interlocked atomicity
        private const long MaxGifDownloadBytes = 10 * 1024 * 1024; // 10 MB max GIF download size

        private static readonly HttpClient _sharedHttpClient = new()
        {
            Timeout = TimeSpan.FromSeconds(10)
        };

        private static readonly Regex GifUrlPattern = new(
            @"<img[^>]+src=""([^""]+\.gif[^""]*)""",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        #endregion

        #region Properties

        public bool IsRunning => _isRunning;

        /// <summary>
        /// Suppresses the next clipboard capture event. Use before setting clipboard from within the app.
        /// </summary>
        public void SuppressNextCapture() => Interlocked.Exchange(ref _suppressNextCapture, 1);

        #endregion

        #region Constructor

        private ClipboardMonitorService()
        {
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Starts monitoring the clipboard for URL changes.
        /// </summary>
        public void Start()
        {
            if (_isRunning) return;

            Logger.Log("ClipboardMonitorService: Starting clipboard monitoring");

            Application.Current.Dispatcher.Invoke(() =>
            {
                // Create a hidden window to receive clipboard messages
                var parameters = new HwndSourceParameters("ClipboardMonitorWindow")
                {
                    Width = 0,
                    Height = 0,
                    PositionX = 0,
                    PositionY = 0,
                    WindowStyle = 0x800000 // WS_SYSMENU - minimal window
                };

                _hwndSource = new HwndSource(parameters);
                _hwndSource.AddHook(WndProc);

                if (AddClipboardFormatListener(_hwndSource.Handle))
                {
                    _isRunning = true;
                    Logger.Log("ClipboardMonitorService: Clipboard listener registered successfully");
                }
                else
                {
                    var error = Marshal.GetLastWin32Error();
                    Logger.Log($"ClipboardMonitorService: Failed to register clipboard listener. Error: {error}");
                }
            });
        }

        /// <summary>
        /// Stops monitoring the clipboard.
        /// </summary>
        public void Stop()
        {
            if (!_isRunning) return;

            Logger.Log("ClipboardMonitorService: Stopping clipboard monitoring");

            Application.Current.Dispatcher.Invoke(() =>
            {
                if (_hwndSource != null)
                {
                    RemoveClipboardFormatListener(_hwndSource.Handle);
                    _hwndSource.RemoveHook(WndProc);
                    _hwndSource.Dispose();
                    _hwndSource = null;
                }

                _isRunning = false;
                Logger.Log("ClipboardMonitorService: Clipboard monitoring stopped");
            });
        }

        /// <summary>
        /// Clears the cooldown cache, allowing immediate notifications.
        /// </summary>
        public void ClearCooldownCache()
        {
            _recentDomains.Clear();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Validates that a URL is safe to download (HTTPS only, no private/internal IPs).
        /// </summary>
        private static bool IsUrlSafeToDownload(string url)
        {
            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
                return false;

            if (!string.Equals(uri.Scheme, "https", StringComparison.OrdinalIgnoreCase))
                return false;

            // Reject localhost and private IP ranges
            if (uri.IsLoopback)
                return false;

            if (IPAddress.TryParse(uri.Host, out var ip))
            {
                var bytes = ip.GetAddressBytes();
                if (bytes.Length == 4)
                {
                    // 10.x.x.x, 172.16-31.x.x, 192.168.x.x
                    if (bytes[0] == 10) return false;
                    if (bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31) return false;
                    if (bytes[0] == 192 && bytes[1] == 168) return false;
                    if (bytes[0] == 127) return false;
                }
            }

            return true;
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_CLIPBOARDUPDATE)
            {
                handled = true;
                OnClipboardUpdate();
            }

            return IntPtr.Zero;
        }

        private async void OnClipboardUpdate()
        {
            try
            {
                if (Interlocked.CompareExchange(ref _suppressNextCapture, 0, 1) == 1)
                {
                    return;
                }
                // Get clipboard content with retry for transient clipboard locks
                string? text = null;
                System.Windows.Media.Imaging.BitmapSource? image = null;
                byte[]? gifBytes = null;

                for (int attempt = 0; attempt < 3; attempt++)
                {
                    try
                    {
                        (text, image, gifBytes) = await Application.Current.Dispatcher.InvokeAsync(() =>
                        {
                            if (Clipboard.ContainsText())
                                return (Clipboard.GetText(), (System.Windows.Media.Imaging.BitmapSource?)null, (byte[]?)null);

                            // Check for raw GIF data first (preserves animation)
                            var dataObj = Clipboard.GetDataObject();
                            if (dataObj != null)
                            {
                                // Log available formats for debugging
                                var formats = dataObj.GetFormats();
                                Logger.Log($"ClipboardMonitorService: Available formats: {string.Join(", ", formats)}");

                                // Try multiple GIF format names
                                foreach (var fmt in new[] { "GIF", "image/gif", "gif" })
                                {
                                    if (dataObj.GetDataPresent(fmt))
                                    {
                                        var data = dataObj.GetData(fmt);
                                        if (data is System.IO.MemoryStream ms)
                                            return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, ms.ToArray());
                                        if (data is System.IO.Stream stream)
                                        {
                                            using var reader = new System.IO.MemoryStream();
                                            stream.CopyTo(reader);
                                            return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, reader.ToArray());
                                        }
                                    }
                                }

                                // Try FileContents (some apps put GIFs as file drops)
                                if (dataObj.GetDataPresent(DataFormats.FileDrop))
                                {
                                    var files = dataObj.GetData(DataFormats.FileDrop) as string[];
                                    if (files?.Length == 1 && files[0].EndsWith(".gif", StringComparison.OrdinalIgnoreCase) && System.IO.File.Exists(files[0]))
                                    {
                                        var bytes = System.IO.File.ReadAllBytes(files[0]);
                                        return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, bytes);
                                    }
                                }

                                // Try HTML Format — extract original image URL (browsers put GIF source URL here)
                                if (dataObj.GetDataPresent("HTML Format") && Clipboard.ContainsImage())
                                {
                                    var html = dataObj.GetData("HTML Format") as string;
                                    if (!string.IsNullOrEmpty(html))
                                    {
                                        var match = GifUrlPattern.Match(html);
                                        if (match.Success)
                                        {
                                            var gifUrl = match.Groups[1].Value;
                                            if (IsUrlSafeToDownload(gifUrl))
                                            {
                                                Logger.Log($"ClipboardMonitorService: Found GIF URL in HTML Format: {Logger.SanitizeUrl(gifUrl)}");
                                                try
                                                {
                                                    var gifData = _sharedHttpClient.GetByteArrayAsync(gifUrl).GetAwaiter().GetResult();
                                                    if (gifData.Length > 0 && gifData.Length <= MaxGifDownloadBytes)
                                                        return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, gifData);
                                                }
                                                catch (Exception dlEx)
                                                {
                                                    Logger.Log($"ClipboardMonitorService: Failed to download GIF: {dlEx.Message}");
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (Clipboard.ContainsImage())
                                return ((string?)null, Clipboard.GetImage(), (byte[]?)null);

                            return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, (byte[]?)null);
                        });
                        break; // Success
                    }
                    catch (System.Runtime.InteropServices.COMException) when (attempt < 2)
                    {
                        // Clipboard locked by another app — wait and retry without blocking UI
                        await System.Threading.Tasks.Task.Delay(100);
                    }
                }

                // Detect source application once, early — before any event firing
                var sourceApp = SourceAppDetector.GetCurrentSourceApp();

                // Handle GIF capture (raw bytes, preserves animation)
                if (gifBytes != null && gifBytes.Length > 0)
                {
                    ClipboardGifCaptured?.Invoke(this, new ClipboardGifEventArgs(gifBytes, sourceApp));
                    return;
                }

                // Handle image capture (static BitmapSource → PNG)
                if (image != null)
                {
                    if (!image.IsFrozen) image.Freeze();
                    ClipboardImageCaptured?.Invoke(this, new ClipboardImageEventArgs(image, sourceApp));
                    return;
                }

                if (string.IsNullOrWhiteSpace(text))
                    return;

                // Deduplicate rapid clipboard events (e.g. browsers fire multiple events per copy)
                // but allow re-copying the same URL after the dedup window expires
                var now = DateTime.Now;
                if (text == _lastClipboardText && (now - _lastClipboardTime).TotalMilliseconds < DEDUP_WINDOW_MS)
                    return;

                _lastClipboardText = text;
                _lastClipboardTime = now;

                // Fire event for Power Clip (captures ALL text, not just URLs)
                ClipboardTextCaptured?.Invoke(this, new ClipboardTextEventArgs(text, sourceApp));

                // Check if it's a valid URL
                var url = NormalizeUrl(text.Trim());
                if (url == null)
                    return;

                Logger.Log($"ClipboardMonitorService: Valid URL detected: {Logger.SanitizeUrl(url)}");

                // Get settings
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;

                // Check if paused
                if (settings.IsPaused)
                {
                    Logger.Log("ClipboardMonitorService: Monitoring is paused, ignoring URL");
                    return;
                }

                // Extract domain
                string domain;
                try
                {
                    domain = new Uri(url).Host.ToLowerInvariant();
                }
                catch
                {
                    return;
                }

                // Check cooldown
                if (!ShouldNotify(domain, settings.CooldownSeconds))
                {
                    Logger.Log($"ClipboardMonitorService: Domain '{domain}' is in cooldown period");
                    return;
                }

                // Check if URL matches a rule (single pass for both enabled and disabled matches)
                var fullMatch = UrlRuleManager.FindMatchWithDisabledCheck(url, sourceApp?.ProcessName);
                var match = fullMatch.Match;
                if (match.Type == MatchType.NoMatch)
                {
                    if (fullMatch.HasDisabledMatch)
                    {
                        Logger.Log($"ClipboardMonitorService: Disabled rule/group exists for URL, suppressing notification");
                    }
                    else
                    {
                        Logger.Log($"ClipboardMonitorService: URL doesn't match any rule, ignoring");
                    }
                    return;
                }

                // Check if the matched rule has clipboard notifications enabled
                bool clipboardEnabled = match.Type switch
                {
                    MatchType.IndividualRule => match.Rule?.ClipboardNotificationsEnabled ?? true,
                    MatchType.UrlGroup => match.Group?.ClipboardNotificationsEnabled ?? true,
                    MatchType.GroupOverride => match.Group?.ClipboardNotificationsEnabled ?? true,
                    _ => false
                };

                if (!clipboardEnabled)
                {
                    Logger.Log($"ClipboardMonitorService: Rule has clipboard notifications disabled");
                    return;
                }

                // Fire event
                UrlDetected?.Invoke(this, new ClipboardUrlEventArgs(url, domain, sourceApp));
            }
            catch (Exception ex)
            {
                Logger.Log($"ClipboardMonitorService: Error processing clipboard: {ex.Message}");
            }
        }

        private string? NormalizeUrl(string text)
        {
            // Skip if text is too long (likely not a URL)
            if (text.Length > 2000)
                return null;

            // Skip if text contains newlines (likely multi-line text)
            if (text.Contains('\n') || text.Contains('\r'))
                return null;

            // Check for common URL patterns
            string url = text;

            // Handle www. prefix without protocol
            if (url.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                url = "https://" + url;
            }

            // Must start with http:// or https://
            if (!url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
                !url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }

            // Validate as URI
            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
                return null;

            // Must be HTTP or HTTPS
            if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)
                return null;

            // Must have a valid host
            if (string.IsNullOrWhiteSpace(uri.Host))
                return null;

            // Host must contain a dot (filter out localhost, etc. if desired)
            // But allow localhost for development
            if (!uri.Host.Contains('.') && uri.Host != "localhost")
                return null;

            return url;
        }

        private bool ShouldNotify(string domain, int cooldownSeconds)
        {
            var now = DateTime.Now;

            // Clean up old entries
            var cutoff = now.AddMinutes(-5);
            foreach (var key in _recentDomains.Keys.ToList())
            {
                if (_recentDomains.TryGetValue(key, out var time) && time < cutoff)
                {
                    _recentDomains.TryRemove(key, out _);
                }
            }

            // Check cooldown
            if (_recentDomains.TryGetValue(domain, out var lastNotified))
            {
                if ((now - lastNotified).TotalSeconds < cooldownSeconds)
                {
                    return false;
                }
            }

            // Update last notified time
            _recentDomains[domain] = now;
            return true;
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            if (_disposed) return;

            Stop();
            _disposed = true;
        }

        #endregion
    }

    /// <summary>
    /// Event args for clipboard text capture events (used by Power Clip).
    /// </summary>
    public class ClipboardTextEventArgs : EventArgs
    {
        public string Text { get; }
        public SourceAppInfo? SourceApp { get; }

        public ClipboardTextEventArgs(string text, SourceAppInfo? sourceApp)
        {
            Text = text;
            SourceApp = sourceApp;
        }
    }

    /// <summary>
    /// Event args for clipboard URL detection events.
    /// </summary>
    public class ClipboardUrlEventArgs : EventArgs
    {
        public string Url { get; }
        public string Domain { get; }
        public SourceAppInfo? SourceApp { get; }

        public ClipboardUrlEventArgs(string url, string domain, SourceAppInfo? sourceApp = null)
        {
            Url = url;
            Domain = domain;
            SourceApp = sourceApp;
        }
    }

    /// <summary>
    /// Event args for clipboard image capture events.
    /// </summary>
    public class ClipboardImageEventArgs : EventArgs
    {
        public System.Windows.Media.Imaging.BitmapSource Image { get; }
        public SourceAppInfo? SourceApp { get; }

        public ClipboardImageEventArgs(System.Windows.Media.Imaging.BitmapSource image, SourceAppInfo? sourceApp)
        {
            Image = image;
            SourceApp = sourceApp;
        }
    }

    /// <summary>
    /// Event args for clipboard GIF capture events.
    /// </summary>
    public class ClipboardGifEventArgs : EventArgs
    {
        public byte[] GifBytes { get; }
        public SourceAppInfo? SourceApp { get; }

        public ClipboardGifEventArgs(byte[] gifBytes, SourceAppInfo? sourceApp)
        {
            GifBytes = gifBytes;
            SourceApp = sourceApp;
        }
    }
}
