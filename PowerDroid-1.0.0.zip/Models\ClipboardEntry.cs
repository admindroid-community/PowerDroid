using System;
using System.Text.Json.Serialization;

namespace PowerDroid.Models
{
    public enum ClipboardEntryType
    {
        Text,
        Url,
        FilePath,
        Image
    }

    /// <summary>
    /// A single clipboard history entry captured by Power Clip.
    /// </summary>
    public class ClipboardEntry
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Content { get; set; } = string.Empty;
        public ClipboardEntryType Type { get; set; } = ClipboardEntryType.Text;
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public bool IsPinned { get; set; }

        /// <summary>User-friendly source app name (e.g., "Google Chrome", "VS Code").</summary>
        public string? SourceApp { get; set; }

        /// <summary>Stable process name for matching (e.g., "chrome", "msedge", "Code").</summary>
        public string? SourceAppId { get; set; }

        /// <summary>Additional detail such as browser profile name (e.g., "Work").</summary>
        public string? SourceDetail { get; set; }

        /// <summary>Cached OCR text extracted from image. Not persisted to JSON.</summary>
        [JsonIgnore]
        public string? CachedOcrText { get; set; }
    }
}
