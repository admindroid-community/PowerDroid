using System;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid.Pages
{
    public partial class SettingsPage : UserControl
    {

        public SettingsPage()
        {
            InitializeComponent();
            Loaded += SettingsPage_Loaded;
            Unloaded += SettingsPage_Unloaded;
        }

        private void SettingsPage_Loaded(object sender, RoutedEventArgs e)
        {
            ThemeManager.ThemeChanged += OnThemeChanged;
            TrayIconService.Instance.StateChanged += TrayIconService_StateChanged;
            Services.UpdateCheckService.Instance.UpdateAvailable += OnUpdateAvailable;
            LoadData();
            RefreshUpdateStatus();
        }

        private void SettingsPage_Unloaded(object sender, RoutedEventArgs e)
        {
            ThemeManager.ThemeChanged -= OnThemeChanged;
            TrayIconService.Instance.StateChanged -= TrayIconService_StateChanged;
            Services.UpdateCheckService.Instance.UpdateAvailable -= OnUpdateAvailable;
        }

        private void OnUpdateAvailable(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(RefreshUpdateStatus);
        }

        private void OnThemeChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                UpdatePauseResumeState(settings);
            });
        }

        private void TrayIconService_StateChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;

                ClipboardMonitoringToggle.Checked -= ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.Unchecked -= ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.IsChecked = settings.IsEnabled;
                ClipboardMonitoringToggle.Checked += ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.Unchecked += ClipboardMonitoringToggle_Changed;

                UpdatePauseResumeState(settings);
            });
        }

        public void LoadData()
        {
            InitializeThemeCombo();
            InitializeHotkeyBoxes();

            InitializeClipboardSettings();

            if (!BrandConfig.PowerClipEnabled)
            {
                ClipHotkeyCard.Visibility = Visibility.Collapsed;
            }
        }

        private void InitializeThemeCombo()
        {
            try
            {
                var settings = SettingsManager.LoadSettings();
                ThemeComboBox.SelectionChanged -= ThemeComboBox_SelectionChanged;
                for (int i = 0; i < ThemeComboBox.Items.Count; i++)
                {
                    if (ThemeComboBox.Items[i] is ComboBoxItem item &&
                        item.Tag is string tag &&
                        tag.Equals(settings.Theme, StringComparison.OrdinalIgnoreCase))
                    {
                        ThemeComboBox.SelectedIndex = i;
                        break;
                    }
                }
                ThemeComboBox.SelectionChanged += ThemeComboBox_SelectionChanged;
            }
            catch (Exception ex)
            {
                Logger.Log($"InitializeThemeCombo ERROR: {ex.Message}");
            }
        }

        private void ThemeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (ThemeComboBox.SelectedItem is ComboBoxItem item && item.Tag is string theme)
                {
                    var settings = SettingsManager.LoadSettings();
                    settings.Theme = theme;
                    SettingsManager.SaveSettings(settings);
                    ThemeManager.ApplyTheme(Enum.Parse<AppTheme>(theme));
                    Logger.Log($"Theme changed to: {theme}");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"ThemeComboBox_SelectionChanged ERROR: {ex.Message}");
            }
        }

        #region Keyboard Shortcuts

        private void InitializeHotkeyBoxes()
        {
            var hk = SettingsManager.LoadSettings().Hotkeys;
            RulesHotkeyBox.Text = HotkeyService.FormatHotkey(hk.RulesModifiers, hk.RulesKey);
            ClipHotkeyBox.Text = HotkeyService.FormatHotkey(hk.ClipModifiers, hk.ClipKey);
        }

        private void HotkeyBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox box)
                box.Text = "Press a shortcut...";
        }

        private void HotkeyBox_LostFocus(object sender, RoutedEventArgs e)
        {
            // Restore current value if user clicks away without pressing a key
            if (sender is TextBox box && box.Text == "Press a shortcut...")
                InitializeHotkeyBoxes();
        }

        private void HotkeyBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;

            var key = e.Key == Key.System ? e.SystemKey : e.Key;

            // Ignore lone modifier keys
            if (key == Key.LeftCtrl || key == Key.RightCtrl ||
                key == Key.LeftShift || key == Key.RightShift ||
                key == Key.LeftAlt || key == Key.RightAlt ||
                key == Key.LWin || key == Key.RWin)
                return;

            // Build modifiers
            uint modifiers = 0;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) modifiers |= HotkeyService.MOD_CTRL;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Alt)) modifiers |= HotkeyService.MOD_ALT;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) modifiers |= HotkeyService.MOD_SHIFT;

            // Require at least one modifier
            if (modifiers == 0) return;

            // Convert WPF Key to Win32 VK
            uint vk = (uint)KeyInterop.VirtualKeyFromKey(key);
            if (vk == 0) return;

            var box = sender as TextBox;
            var tag = box?.Tag?.ToString();

            // Save to settings
            var settings = SettingsManager.LoadSettings();
            if (tag == "Rules")
            {
                settings.Hotkeys.RulesModifiers = modifiers;
                settings.Hotkeys.RulesKey = vk;
            }
            else if (tag == "Clip")
            {
                settings.Hotkeys.ClipModifiers = modifiers;
                settings.Hotkeys.ClipKey = vk;
            }

            SettingsManager.SaveSettings(settings);

            // Update display
            if (box != null)
                box.Text = HotkeyService.FormatHotkey(modifiers, vk);

            // Re-register hotkeys
            HotkeyService.Instance.Reload();

            // Move focus away
            Keyboard.ClearFocus();

            Logger.Log($"Hotkey changed: {tag} → {HotkeyService.FormatHotkey(modifiers, vk)}");
        }

        #endregion

        #region Clipboard Monitoring

        private void InitializeClipboardSettings()
        {
            try
            {
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                var serviceRunning = ClipboardMonitorService.Instance.IsRunning;

                bool shouldBeEnabled = settings.IsEnabled;

                ClipboardMonitoringToggle.Checked -= ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.Unchecked -= ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.IsChecked = shouldBeEnabled;
                ClipboardMonitoringToggle.Checked += ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.Unchecked += ClipboardMonitoringToggle_Changed;

                if (shouldBeEnabled && !serviceRunning)
                {
                    Logger.Log("SettingsPage: Service not running but should be - starting now");
                    ClipboardMonitorService.Instance.Start();
                    TrayIconService.Instance.Show();
                    TrayIconService.Instance.UpdateState();
                }

                UpdatePauseResumeState(settings);

                Logger.Log($"SettingsPage.InitializeClipboardSettings: Toggle={shouldBeEnabled}, ServiceRunning={serviceRunning}");
            }
            catch (Exception ex)
            {
                Logger.Log($"SettingsPage.InitializeClipboardSettings ERROR: {ex.Message}");
            }
        }

        private void ClipboardMonitoringToggle_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                var isEnabled = ClipboardMonitoringToggle.IsChecked == true;

                var settings = SettingsManager.LoadSettings();
                settings.ClipboardMonitoring.IsEnabled = isEnabled;
                SettingsManager.SaveSettings(settings);

                if (isEnabled)
                {
                    ClipboardMonitorService.Instance.Start();
                    TrayIconService.Instance.Show();
                    TrayIconService.Instance.UpdateState();

                    RegistryHelper.AddToStartup();
                }
                else
                {
                    ClipboardMonitorService.Instance.Stop();
                    TrayIconService.Instance.Show();
                    TrayIconService.Instance.UpdateState();
                }

                UpdatePauseResumeState(settings.ClipboardMonitoring);

                Logger.Log($"Clipboard monitoring {(isEnabled ? "enabled" : "disabled")}");
            }
            catch (Exception ex)
            {
                Logger.Log($"SettingsPage.ClipboardMonitoringToggle_Changed ERROR: {ex.Message}");
            }
        }

        private void UpdatePauseResumeState(ClipboardSettings monitorSettings)
        {
            if (!monitorSettings.IsEnabled)
            {
                PauseMonitoringCard.IsEnabled = false;
                PauseStatusText.Text = "Disabled";
                ResumeButton.Visibility = Visibility.Collapsed;
                PauseDropdown.Tag = "Pause for...";
                StatusIndicatorDot.Fill = (System.Windows.Media.Brush)FindResource("StatusDisabledFgBrush");
            }
            else if (monitorSettings.IsPaused)
            {
                PauseMonitoringCard.IsEnabled = true;
                var remaining = monitorSettings.RemainingPauseTime;
                PauseStatusText.Text = remaining.HasValue
                    ? $"Paused for {FormatRemainingTime(remaining.Value)}"
                    : "Paused";
                ResumeButton.Visibility = Visibility.Visible;
                PauseDropdown.Tag = "Extend Time";
                StatusIndicatorDot.Fill = (System.Windows.Media.Brush)FindResource("StatusPausedFgBrush");
            }
            else
            {
                PauseMonitoringCard.IsEnabled = true;
                PauseStatusText.Text = "Active";
                ResumeButton.Visibility = Visibility.Collapsed;
                PauseDropdown.Tag = "Pause for...";
                StatusIndicatorDot.Fill = (System.Windows.Media.Brush)FindResource("StatusActiveFgBrush");
            }
        }

        private void ResumeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TrayIconService.Instance.Resume();

                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                UpdatePauseResumeState(settings);

                Logger.Log("SettingsPage: Monitoring resumed");
            }
            catch (Exception ex)
            {
                Logger.Log($"SettingsPage.ResumeButton_Click ERROR: {ex.Message}");
            }
        }

        private void PauseDropdown_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (sender is ComboBox comboBox && comboBox.SelectedItem is ComboBoxItem item
                    && item.Tag is string minutesStr && int.TryParse(minutesStr, out int minutes))
                {
                    TrayIconService.Instance.PauseFor(TimeSpan.FromMinutes(minutes));

                    var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                    UpdatePauseResumeState(settings);

                    Logger.Log($"SettingsPage: Monitoring paused for {minutes} minutes");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"SettingsPage.PauseDropdown_SelectionChanged ERROR: {ex.Message}");
            }
            finally
            {
                if (sender is ComboBox cb) cb.SelectedIndex = -1;
            }
        }

        private string FormatRemainingTime(TimeSpan remaining)
        {
            if (remaining.TotalMinutes < 1)
                return $"{remaining.Seconds}s";
            else if (remaining.TotalHours < 1)
                return $"{(int)remaining.TotalMinutes}m";
            else
                return $"{(int)remaining.TotalHours}h {remaining.Minutes}m";
        }

        #endregion

        private void AppVersionText_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is TextBlock textBlock)
            {
                var version = Assembly.GetExecutingAssembly().GetName().Version;
                textBlock.Text = version != null ? $"v{version.Major}.{version.Minor}.{version.Build}" : "v1.0.0";
            }
        }

        private void Hyperlink_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true });
            }
            catch (Exception ex) { Logger.Log($"Hyperlink navigation failed: {ex.Message}"); }
            e.Handled = true;
        }

        #region Update Check

        /// <summary>
        /// Refreshes the update available card based on the current state.
        /// </summary>
        public void RefreshUpdateStatus()
        {
            var service = Services.UpdateCheckService.Instance;
            if (service.IsUpdateAvailable)
            {
                // Update available — show info directly, hide check button
                UpdateStatusText.Text = $"Update available \u2014 v{service.LatestVersion}";
                UpdateIcon.Text = "\uE896";
                UpdateIcon.SetResourceReference(TextBlock.ForegroundProperty, "StatusSuccessFgBrush");

                UpdateVersionText.Text = !string.IsNullOrWhiteSpace(service.ReleaseTitle)
                    ? $"{service.ReleaseTitle} (v{service.LatestVersion})"
                    : $"PowerDroid v{service.LatestVersion}";
                UpdateCurrentVersionText.Text = $"Currently installed: v{BrandConfig.Version}";
                UpdateSizeText.Text = service.InstallerSizeBytes > 0
                    ? $"\u00B7 {Services.UpdateCheckService.FormatSize(service.InstallerSizeBytes)}"
                    : "";
                UpdateVersionBadge.Text = $"v{service.LatestVersion}";
                UpdateVersionBadge.Visibility = Visibility.Visible;
                UpdateCheckRow.Visibility = Visibility.Collapsed;
                UpdateNotesText.Text = !string.IsNullOrWhiteSpace(service.ReleaseNotes)
                    ? service.ReleaseNotes
                    : "Visit the releases page for details.";
                // Set view release link
                if (!string.IsNullOrEmpty(service.ReleaseUrl))
                    ViewReleaseHyperlink.NavigateUri = new Uri(service.ReleaseUrl);
                UpdateAvailableCard.Visibility = Visibility.Visible;
            }
            else
            {
                // Up to date — show check button
                UpdateIcon.Text = "\uE895";
                UpdateIcon.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
                UpdateVersionBadge.Visibility = Visibility.Collapsed;
                UpdateCheckRow.Visibility = Visibility.Visible;
                UpdateAvailableCard.Visibility = Visibility.Collapsed;

                var settings = SettingsManager.LoadSettings();
                UpdateStatusText.Text = settings.LastUpdateCheckTime > DateTime.MinValue
                    ? "You're up to date"
                    : "Check for new versions";
            }
        }

        private async void CheckForUpdates_Click(object sender, RoutedEventArgs e)
        {
            CheckForUpdatesButton.IsEnabled = false;
            CheckForUpdatesButton.Content = "Checking...";
            UpdateStatusText.Text = "Checking for updates...";

            try
            {
                // Force a fresh check by resetting the cache time
                var settings = SettingsManager.LoadSettings();
                settings.LastUpdateCheckTime = DateTime.MinValue;
                SettingsManager.SaveSettings(settings);

                await Services.UpdateCheckService.Instance.CheckForUpdatesAsync();
                RefreshUpdateStatus();

                // Update the dot in the parent window
                var settingsWindow = Window.GetWindow(this) as SettingsWindow;
                if (Services.UpdateCheckService.Instance.IsUpdateAvailable)
                    settingsWindow?.ShowUpdateNotification();
                else
                    settingsWindow?.HideUpdateDot();
            }
            catch (Exception ex)
            {
                UpdateStatusText.Text = "Could not check for updates";
                Logger.Log($"CheckForUpdates_Click: {ex.Message}");
            }
            finally
            {
                CheckForUpdatesButton.IsEnabled = true;
                CheckForUpdatesButton.Content = "Check Now";
            }
        }

        /// <summary>
        /// Public entry point to start the download & install flow (called from overlay).
        /// </summary>
        public void StartDownloadAndInstall()
        {
            DownloadUpdate_Click(DownloadInstallButton, new RoutedEventArgs());
        }

        private async void DownloadUpdate_Click(object sender, RoutedEventArgs e)
        {
            // Confirmation
            var service = Services.UpdateCheckService.Instance;
            var size = service.InstallerSizeBytes;
            var sizeText = size > 0 ? $" ({Services.UpdateCheckService.FormatSize(size)})" : "";
            var confirmed = ConfirmationDialog.Show(
                Window.GetWindow(this),
                "Download & Install Update",
                $"This will download PowerDroid v{service.LatestVersion}{sizeText} and restart the application to install the update.\n\nContinue?",
                "Download & Install",
                "Cancel");

            if (!confirmed) return;

            DownloadInstallButton.IsEnabled = false;
            DownloadInstallButton.Content = "Downloading...";
            DownloadProgressPanel.Visibility = Visibility.Visible;
            DownloadProgressBar.Value = 0;
            DownloadProgressText.Text = "0%";

            try
            {
                var progress = new Progress<int>(percent =>
                {
                    DownloadProgressBar.Value = percent;
                    DownloadProgressText.Text = $"{percent}%";
                    DownloadInstallButton.Content = $"Downloading... {percent}%";
                });

                await Services.UpdateCheckService.Instance.DownloadAndInstallAsync(progress);

                // Show installing state briefly before shutdown
                DownloadInstallButton.Content = "Installing...";
                DownloadProgressText.Text = "Restarting...";
            }
            catch (Exception ex)
            {
                Logger.Log($"DownloadUpdate_Click: {ex.Message}");
                DownloadInstallButton.Content = "Download & Install";
                DownloadInstallButton.IsEnabled = true;
                DownloadProgressPanel.Visibility = Visibility.Collapsed;
                UpdateStatusText.Text = "Download failed — try again";
            }
        }

        private void SkipUpdate_Click(object sender, RoutedEventArgs e)
        {
            Services.UpdateCheckService.Instance.SkipCurrentVersion();
            UpdateAvailableCard.Visibility = Visibility.Collapsed;
            UpdateStatusText.Text = "Update skipped";
            var settingsWindow = Window.GetWindow(this) as SettingsWindow;
            settingsWindow?.HideUpdateDot();
        }

        #endregion

    }
}
