using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Media.Imaging;
using PowerDroid.Models;

namespace PowerDroid.Services
{
    /// <summary>
    /// Singleton service for the Power Clip feature.
    /// Captures and persists all clipboard text with auto-detection, deduplication, and retention.
    /// </summary>
    public class PowerClipService
    {
        #region Singleton

        private static PowerClipService? _instance;
        private static readonly object _lock = new object();

        public static PowerClipService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new PowerClipService();
                    }
                }
                return _instance;
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// Fired after any mutation to the clipboard history (add, pin, unpin, delete, clear).
        /// </summary>
        public event EventHandler? HistoryChanged;

        #endregion

        #region Fields

        private readonly string _settingsPath;
        private readonly string _historyPath;
        private readonly string _imageFolder;
        private PowerClipSettings _settings;
        private List<ClipboardEntry> _entries;
        private Dictionary<string, string> _sourceAppCache = new(StringComparer.OrdinalIgnoreCase);
        private string? _lastContent;
        private DateTime _lastCaptureTime;
        private string? _lastImageHash;
        private const int DEDUP_WINDOW_SECONDS = 3;
        private const long MAX_IMAGE_BYTES = 4 * 1024 * 1024; // 4 MB per image

        #endregion

        #region Constructor

        private PowerClipService()
        {
            _settingsPath = Path.Combine(AppConfig.AppDataFolder, "powerclip-settings.json");
            _historyPath = Path.Combine(AppConfig.AppDataFolder, "powerclip-history.json");
            _imageFolder = Path.Combine(AppConfig.AppDataFolder, "clip-images");
            _settings = new PowerClipSettings();
            _entries = new List<ClipboardEntry>();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Loads settings and history from disk, performs retention cleanup, and subscribes to clipboard events.
        /// </summary>
        public void Initialize()
        {
            Logger.Log($"{BrandConfig.PowerClipName}: Initializing");

            _settings = JsonStorageService.Load<PowerClipSettings>(_settingsPath);
            _entries = JsonStorageService.Load<List<ClipboardEntry>>(_historyPath);

            // Retention cleanup: remove non-pinned entries older than RetentionDays (skip if 0)
            if (_settings.RetentionDays > 0)
            {
                var cutoff = DateTime.Now.AddDays(-_settings.RetentionDays);
                var before = _entries.Count;
                var expiredEntries = _entries.Where(e => !e.IsPinned && e.Timestamp < cutoff).ToList();
                foreach (var entry in expiredEntries)
                {
                    DeleteEntryFile(entry);
                    _entries.Remove(entry);
                }

                var removed = before - _entries.Count;
                if (removed > 0)
                {
                    Logger.Log($"{BrandConfig.PowerClipName}: Retention cleanup removed {removed} entries older than {_settings.RetentionDays} days");
                    SaveHistory();
                }
            }

            // Enforce image storage cap on startup
            EnforceImageStorageCap();

            // Subscribe to clipboard events
            ClipboardMonitorService.Instance.ClipboardTextCaptured += OnClipboardTextCaptured;
            ClipboardMonitorService.Instance.ClipboardImageCaptured += OnClipboardImageCaptured;
            ClipboardMonitorService.Instance.ClipboardGifCaptured += OnClipboardGifCaptured;

            RebuildSourceAppCache();
            Logger.Log($"{BrandConfig.PowerClipName}: Initialized with {_entries.Count} entries, {_sourceAppCache.Count} source apps");
        }

        /// <summary>
        /// Searches clipboard history by content (case-insensitive substring match).
        /// </summary>
        public List<ClipboardEntry> Search(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return new List<ClipboardEntry>(_entries);

            return _entries
                .Where(e => e.Content.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();
        }

        /// <summary>
        /// Pins an entry so it is exempt from retention cleanup and MaxEntries trimming.
        /// </summary>
        public const int MaxPinnedEntries = 10;

        public void Pin(string id)
        {
            var entry = _entries.FirstOrDefault(e => e.Id == id);
            if (entry == null) return;

            if (_entries.Count(e => e.IsPinned) >= MaxPinnedEntries)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Pin limit reached ({MaxPinnedEntries})");
                return;
            }

            entry.IsPinned = true;
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Unpins an entry, making it subject to normal retention and trimming rules.
        /// </summary>
        public void Unpin(string id)
        {
            var entry = _entries.FirstOrDefault(e => e.Id == id);
            if (entry == null) return;

            entry.IsPinned = false;
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Deletes a single entry by ID.
        /// </summary>
        public void Delete(string id)
        {
            var entry = _entries.FirstOrDefault(e => e.Id == id);
            if (entry == null) return;

            DeleteEntryFile(entry);
            _entries.Remove(entry);

            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Clears all clipboard history entries.
        /// </summary>
        public void ClearAll()
        {
            foreach (var entry in _entries)
                DeleteEntryFile(entry);

            _entries.Clear();
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Clears non-pinned clipboard entries older than the specified cutoff date.
        /// </summary>
        public void ClearBefore(DateTime cutoff)
        {
            var toRemove = _entries.Where(e => !e.IsPinned && e.Timestamp < cutoff).ToList();
            if (toRemove.Count == 0) return;

            foreach (var entry in toRemove)
            {
                DeleteEntryFile(entry);
                _entries.Remove(entry);
            }

            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Adds a pre-built clipboard entry (used for testing/seeding).
        /// </summary>
        public void AddEntry(ClipboardEntry entry)
        {
            _entries.Add(entry);
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Returns a copy of all clipboard history entries (newest first).
        /// </summary>
        public List<ClipboardEntry> GetEntries()
        {
            return _entries.OrderByDescending(e => e.Timestamp).ToList();
        }

        /// <summary>
        /// Returns cached dictionary of source apps that appear in clipboard history.
        /// Key = SourceAppId (process name), Value = SourceApp (display name).
        /// </summary>
        public Dictionary<string, string> GetSourceApps() => new(_sourceAppCache);

        private void RebuildSourceAppCache()
        {
            _sourceAppCache = _entries
                .Where(e => !string.IsNullOrEmpty(e.SourceAppId))
                .GroupBy(e => e.SourceAppId!, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(
                    g => g.Key,
                    g => g.First().SourceApp ?? g.Key,
                    StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Updates and persists Power Clip settings.
        /// </summary>
        public void SaveSettings(PowerClipSettings settings)
        {
            _settings = settings;
            JsonStorageService.Save(_settingsPath, _settings);
            Logger.Log($"{BrandConfig.PowerClipName}: Settings saved");

            // Enforce max entries cap immediately
            EnforceMaxEntries();
        }

        /// <summary>
        /// Returns the current settings.
        /// </summary>
        public PowerClipSettings GetSettings()
        {
            return _settings;
        }

        #endregion

        #region Private Methods

        private void OnClipboardTextCaptured(object? sender, ClipboardTextEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(e.Text))
                    return;

                var content = e.Text.Trim();

                // Deduplicate: skip only if same as the most recent entry
                var now = DateTime.Now;
                var latest = _entries.OrderByDescending(e => e.Timestamp).FirstOrDefault();
                if (latest != null && latest.Content == content)
                    return;

                _lastContent = content;
                _lastCaptureTime = now;

                // Auto-detect entry type
                var entryType = DetectEntryType(content);

                // Check if this type is enabled in settings
                if (entryType == ClipboardEntryType.Url && !_settings.CaptureUrls)
                    return;
                if (entryType == ClipboardEntryType.Text && !_settings.CaptureText)
                    return;
                if (entryType == ClipboardEntryType.FilePath && !_settings.CaptureFilePaths)
                    return;

                // Create entry
                var entry = new ClipboardEntry
                {
                    Content = content,
                    Type = entryType,
                    Timestamp = now,
                    SourceApp = e.SourceApp?.DisplayName,
                    SourceAppId = e.SourceApp?.ProcessName,
                    SourceDetail = e.SourceApp?.BrowserProfileName
                };

                _entries.Add(entry);

                // Enforce MaxEntries cap: trim oldest non-pinned entries
                EnforceMaxEntries();

                SaveHistory();
                HistoryChanged?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Error capturing clipboard text: {ex.Message}");
            }
        }

        /// <summary>
        /// Auto-detects the type of clipboard content.
        /// </summary>
        private static ClipboardEntryType DetectEntryType(string content)
        {
            // Skip multiline content — URLs and file paths are single-line
            bool isMultiline = content.Contains('\n') || content.Contains('\r');

            if (!isMultiline)
            {
                // URL: starts with http://, https://, or www.
                if (content.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                    content.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ||
                    content.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
                {
                    return ClipboardEntryType.Url;
                }

                // File path: must start with drive letter (e.g. C:\) or UNC path (\\)
                if ((content.Length >= 3 && char.IsLetter(content[0]) && content[1] == ':' && content[2] == '\\') ||
                    content.StartsWith("\\\\"))
                {
                    return ClipboardEntryType.FilePath;
                }
            }

            return ClipboardEntryType.Text;
        }

        /// <summary>
        /// Removes oldest non-pinned entries when the total count exceeds MaxEntries.
        /// </summary>
        private void EnforceMaxEntries()
        {
            if (_settings.MaxEntries <= 0)
                return;

            while (_entries.Count > _settings.MaxEntries)
            {
                var oldest = _entries
                    .Where(e => !e.IsPinned)
                    .OrderBy(e => e.Timestamp)
                    .FirstOrDefault();

                if (oldest == null)
                    break;

                DeleteEntryFile(oldest);
                _entries.Remove(oldest);
            }
        }

        private void OnClipboardImageCaptured(object? sender, ClipboardImageEventArgs e)
        {
            try
            {
                if (!_settings.CaptureImages)
                    return;

                var image = e.Image;

                // Encode to PNG bytes
                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(image));
                byte[] imageBytes;
                using (var ms = new MemoryStream())
                {
                    encoder.Save(ms);
                    imageBytes = ms.ToArray();
                }

                // Skip if over 4 MB
                if (imageBytes.Length > MAX_IMAGE_BYTES)
                {
                    Logger.Log($"{BrandConfig.PowerClipName}: Skipping image ({imageBytes.Length / 1024} KB) — exceeds 4 MB limit");
                    return;
                }

                // Dedup: compute hash and compare to last image
                var hash = Convert.ToBase64String(SHA256.HashData(imageBytes));
                if (hash == _lastImageHash)
                    return;
                _lastImageHash = hash;

                // Also check existing image entries by filename hash prefix
                if (_entries.Any(e => e.Type == ClipboardEntryType.Image && Path.GetFileNameWithoutExtension(e.Content) == hash.Replace("/", "_").Replace("+", "-")[..16]))
                    return;

                // Ensure image folder exists
                if (!Directory.Exists(_imageFolder))
                    Directory.CreateDirectory(_imageFolder);

                // Save to file
                var safeHash = hash.Replace("/", "_").Replace("+", "-")[..16];
                var fileName = $"{safeHash}.png";
                var filePath = Path.Combine(_imageFolder, fileName);

                // Skip if file already exists (same image content)
                if (File.Exists(filePath))
                    return;

                File.WriteAllBytes(filePath, imageBytes);

                // Create entry
                var entry = new ClipboardEntry
                {
                    Content = filePath,
                    Type = ClipboardEntryType.Image,
                    Timestamp = DateTime.Now,
                    SourceApp = e.SourceApp?.DisplayName,
                    SourceAppId = e.SourceApp?.ProcessName,
                    SourceDetail = e.SourceApp?.BrowserProfileName
                };

                _entries.Add(entry);
                EnforceMaxEntries();
                EnforceImageStorageCap();
                SaveHistory();
                HistoryChanged?.Invoke(this, EventArgs.Empty);

                Logger.Log($"{BrandConfig.PowerClipName}: Captured image ({imageBytes.Length / 1024} KB, {image.PixelWidth}x{image.PixelHeight})");
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Error capturing clipboard image: {ex.Message}");
            }
        }

        private void OnClipboardGifCaptured(object? sender, ClipboardGifEventArgs e)
        {
            try
            {
                if (!_settings.CaptureImages)
                    return;

                var gifBytes = e.GifBytes;
                bool savedAsPng = false;

                // If GIF exceeds size limit, convert first frame to PNG instead of skipping
                if (gifBytes.Length > MAX_IMAGE_BYTES)
                {
                    Logger.Log($"{BrandConfig.PowerClipName}: GIF ({gifBytes.Length / 1024} KB) exceeds 4 MB — converting to PNG");
                    try
                    {
                        using var gifStream = new MemoryStream(gifBytes);
                        var decoder = new System.Windows.Media.Imaging.GifBitmapDecoder(
                            gifStream,
                            System.Windows.Media.Imaging.BitmapCreateOptions.PreservePixelFormat,
                            System.Windows.Media.Imaging.BitmapCacheOption.OnLoad);
                        var firstFrame = decoder.Frames[0];

                        var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
                        encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(firstFrame));
                        using var pngStream = new MemoryStream();
                        encoder.Save(pngStream);
                        gifBytes = pngStream.ToArray();
                        savedAsPng = true;
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"{BrandConfig.PowerClipName}: Failed to convert GIF to PNG: {ex.Message}");
                        return;
                    }
                }

                // Dedup: hash and compare
                var hash = Convert.ToBase64String(SHA256.HashData(gifBytes));
                if (hash == _lastImageHash)
                    return;
                _lastImageHash = hash;

                var safeHash = hash.Replace("/", "_").Replace("+", "-")[..16];
                if (_entries.Any(e => e.Type == ClipboardEntryType.Image && Path.GetFileNameWithoutExtension(e.Content) == safeHash))
                    return;

                if (!Directory.Exists(_imageFolder))
                    Directory.CreateDirectory(_imageFolder);

                var fileName = savedAsPng ? $"{safeHash}.png" : $"{safeHash}.gif";
                var filePath = Path.Combine(_imageFolder, fileName);

                if (File.Exists(filePath))
                    return;

                File.WriteAllBytes(filePath, gifBytes);

                var entry = new ClipboardEntry
                {
                    Content = filePath,
                    Type = ClipboardEntryType.Image,
                    Timestamp = DateTime.Now,
                    SourceApp = e.SourceApp?.DisplayName,
                    SourceAppId = e.SourceApp?.ProcessName,
                    SourceDetail = e.SourceApp?.BrowserProfileName
                };

                _entries.Add(entry);
                EnforceMaxEntries();
                EnforceImageStorageCap();
                SaveHistory();
                HistoryChanged?.Invoke(this, EventArgs.Empty);

                Logger.Log($"{BrandConfig.PowerClipName}: Captured {(savedAsPng ? "GIF as PNG" : "GIF")} ({gifBytes.Length / 1024} KB)");
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Error capturing clipboard GIF: {ex.Message}");
            }
        }

        /// <summary>
        /// Validates that a file path is within the image folder to prevent path traversal attacks.
        /// </summary>
        private bool IsPathWithinImageFolder(string path)
        {
            try
            {
                var fullPath = Path.GetFullPath(path);
                var folderPath = Path.GetFullPath(_imageFolder + Path.DirectorySeparatorChar);
                return fullPath.StartsWith(folderPath, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Deletes the image file associated with an entry if it's an Image type.
        /// </summary>
        private void DeleteEntryFile(ClipboardEntry entry)
        {
            if (entry.Type != ClipboardEntryType.Image) return;

            try
            {
                if (IsPathWithinImageFolder(entry.Content) && File.Exists(entry.Content))
                {
                    File.Delete(entry.Content);
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Failed to delete image file: {ex.Message}");
            }
        }

        /// <summary>
        /// Enforces the image storage size cap by removing oldest non-pinned image entries.
        /// </summary>
        private void EnforceImageStorageCap()
        {
            if (_settings.MaxImageStorageMB <= 0 || !Directory.Exists(_imageFolder))
                return;

            var maxBytes = _settings.MaxImageStorageMB * 1024 * 1024;
            var dirInfo = new DirectoryInfo(_imageFolder);
            var totalSize = dirInfo.GetFiles("*.png").Concat(dirInfo.GetFiles("*.gif"))
                .Sum(f => f.Length);

            if (totalSize <= maxBytes) return;

            // Remove oldest non-pinned image entries until under cap
            var imageEntries = _entries
                .Where(e => e.Type == ClipboardEntryType.Image && !e.IsPinned)
                .OrderBy(e => e.Timestamp)
                .ToList();

            foreach (var entry in imageEntries)
            {
                if (totalSize <= maxBytes) break;

                try
                {
                    if (IsPathWithinImageFolder(entry.Content) && File.Exists(entry.Content))
                    {
                        var fileSize = new FileInfo(entry.Content).Length;
                        File.Delete(entry.Content);
                        totalSize -= fileSize;
                    }
                }
                catch { }

                _entries.Remove(entry);
            }

            SaveHistory();
            Logger.Log($"{BrandConfig.PowerClipName}: Image storage cap enforced, now {totalSize / 1024 / 1024} MB");
        }

        private void SaveHistory()
        {
            RebuildSourceAppCache();
            try
            {
                JsonStorageService.Save(_historyPath, _entries);
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Failed to save history: {ex.Message}");
            }
        }

        #endregion
    }
}
