﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid
{
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            // Catch unhandled exceptions to prevent silent crashes
            DispatcherUnhandledException += (s, args) =>
            {
                Logger.Log($"UNHANDLED EXCEPTION: {args.Exception.Message}\n{args.Exception.StackTrace}");
                args.Handled = true;
            };
            AppDomain.CurrentDomain.UnhandledException += (s, args) =>
            {
                if (args.ExceptionObject is Exception ex)
                    Logger.Log($"FATAL UNHANDLED EXCEPTION: {ex.Message}\n{ex.StackTrace}");
            };

            Logger.Log("========== APPLICATION STARTUP ==========");
            Logger.Log($"Arguments count: {e.Args.Length}");
            for (int i = 0; i < e.Args.Length; i++)
            {
                Logger.Log($"  Arg[{i}]: {e.Args[i]}");
            }

            // Migrate data from legacy LinkRouter folder if needed
            DataMigrationService.MigrateIfNeeded();

            // Initialize theme before any window is created
            ThemeManager.Initialize();

            // --- SINGLE INSTANCE CHECK (must be first) ---
            if (!SingleInstanceManager.Instance.TryAcquireLock())
            {
                // Another instance exists - forward args and exit
                Logger.Log("Forwarding arguments to existing instance");

                if (e.Args.Length > 0)
                {
                    SingleInstanceManager.SendArgumentsToExistingInstance(e.Args);
                }
                else
                {
                    // No args = user wants to open settings
                    SingleInstanceManager.SendArgumentsToExistingInstance(new[] { "--manage" });
                }

                // Exit immediately (don't initialize anything)
                Shutdown(0);
                return;
            }

            // This is the first instance - start pipe server to receive args from future instances
            SingleInstanceManager.Instance.ArgumentsReceived += OnArgumentsReceived;
            SingleInstanceManager.Instance.StartPipeServer();

            // Suppress the taskbar jump list's automatic "Recent" / "Frequent" categories.
            // Because the app is registered as a URL/file handler, Windows otherwise records
            // every URL it opens and shows them as raw entries in the taskbar right-click menu.
            ConfigureJumpList();

            // Pre-load profile avatars in background for better UX
            ProfileAvatarService.LoadAllAvatarsAtStartup();

            // Initialize built-in templates and apply any updates
            try
            {
                UrlGroupManager.EnsureBuiltInGroupsExist();
            }
            catch (Exception ex)
            {
                Logger.Log($"Warning: Failed to initialize built-in templates: {ex.Message}");
            }

            // Auto-register if not already registered
            if (!RegistryHelper.IsRegistered())
            {
                Logger.Log("App not registered - auto-registering...");
                try
                {
                    RegistryHelper.RegisterAsDefaultBrowser();
                    Logger.Log("Auto-registration completed successfully");
                }
                catch (Exception ex)
                {
                    Logger.Log($"Auto-registration failed: {ex.Message}");
                }
            }

            // Auto-detect fallback browser if not configured
            var settings = SettingsManager.LoadSettings();
            if (string.IsNullOrEmpty(settings.DefaultBrowserPath))
            {
                var browsers = BrowserDetector.GetInstalledBrowsers();
                var fallback = browsers.FirstOrDefault();
                if (fallback != null)
                {
                    settings.DefaultBrowserName = fallback.Name;
                    settings.DefaultBrowserPath = fallback.ExecutablePath;
                    settings.DefaultBrowserType = fallback.Type;
                    SettingsManager.SaveSettings(settings);
                    Logger.Log($"Auto-configured fallback browser: {fallback.Name} ({fallback.ExecutablePath})");
                }
            }

            // Always set up clipboard monitoring event handlers
            // This ensures notifications work whether enabled from Settings or via --startup
            SetupClipboardEventHandlers();

            // Initialize Power Clip (subscribes to clipboard events)
            if (BrandConfig.PowerClipEnabled)
                PowerClipService.Instance.Initialize();

            // Clean up old installer downloads from temp
            Services.UpdateCheckService.CleanupOldInstallers();

            // Show notification dot + overlay when an update is found
            Services.UpdateCheckService.Instance.UpdateAvailable += (s, args) =>
            {
                Dispatcher.BeginInvoke(() =>
                {
                    var settingsWindow = Windows.OfType<SettingsWindow>().FirstOrDefault();
                    settingsWindow?.ShowUpdateNotification();
                });
            };

            // Show cached update info if available (no API call)
            Services.UpdateCheckService.Instance.ApplyCachedIfAvailable();

            // Schedule update checks at 8am and 8pm
            ScheduleUpdateChecks();

            if (e.Args.Length > 0)
            {
                var url = e.Args[0];
                Logger.Log($"Processing argument: {Logger.SanitizeUrl(url)}");

                // Handle startup parameter (silent start or background monitoring)
                if (url.Equals("--startup", StringComparison.OrdinalIgnoreCase))
                {
                    // Verify registration keys still exist (may have been lost during update/browser install)
                    bool repaired = RegistryHelper.VerifyAndRepairRegistration();
                    if (repaired)
                    {
                        Logger.Log("Startup: Registration keys were missing — auto-repaired");
                    }

                    var clipboardSettings = SettingsManager.LoadSettings().ClipboardMonitoring;

                    if (clipboardSettings.IsEnabled)
                    {
                        Logger.Log("Command: --startup - Starting clipboard monitoring in background");
                        StartBackgroundMonitoring();

                        // Check if we're still the system default browser
                        if (!RegistryHelper.IsSystemDefaultBrowser())
                        {
                            Logger.Log($"Startup: {BrandConfig.AppDisplayName} is not the default browser — showing balloon");
                            TrayIconService.Instance.ShowBalloon(
                                $"{BrandConfig.AppDisplayName} Smart Browse is not your default browser",
                                "Another app may have changed your default. Click the tray icon to fix.");
                        }

                        return; // Keep app running in background
                    }
                    else
                    {
                        Logger.Log("Command: --startup (silent start) - clipboard monitoring disabled, exiting silently");
                        AppLifecycleService.RequestShutdown("--startup with monitoring disabled");
                        return;
                    }
                }

                // Handle background monitoring command
                if (url.Equals("--background", StringComparison.OrdinalIgnoreCase))
                {
                    Logger.Log("Command: --background - Starting clipboard monitoring");
                    StartBackgroundMonitoring();
                    return;
                }

                // Handle automated test runner (headless - no UI)
                if (url.Equals("--run-tests", StringComparison.OrdinalIgnoreCase) ||
                    url.StartsWith("--run-tests:", StringComparison.OrdinalIgnoreCase))
                {
                    string? category = url.Contains(':') ? url.Split(':')[1] : null;
                    Logger.Log($"Command: --run-tests - Running tests{(category != null ? $" (category: {category})" : " (all)")}");

                    try
                    {
                        var results = category != null
                            ? TestRunnerService.RunCategory(category)
                            : TestRunnerService.RunAllTests();

                        // Write JSON results file
                        var resultsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "test-results.json");
                        TestRunnerService.WriteResultsToFile(results, resultsPath);

                        // Print summary to stdout
                        var summary = TestRunnerService.FormatSummary(results);
                        Console.WriteLine(summary);
                        Logger.Log(summary);

                        // Exit with appropriate code
                        int exitCode = results.All(r => r.Status == "Passed") ? 0 : 1;
                        Logger.Log($"Tests completed. Exit code: {exitCode}");
                        Shutdown(exitCode);
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"Test runner error: {ex}");
                        Console.Error.WriteLine($"Test runner error: {ex.Message}");
                        Shutdown(2);
                    }
                    return;
                }

                // Handle post-update launch — open settings window on Home page with What's New overlay
                if (url.Equals("--updated", StringComparison.OrdinalIgnoreCase))
                {
                    Logger.Log("Command: --updated - opening SettingsWindow after update");
                    try
                    {
                        var settingsWindow = new SettingsWindow();

                        // Show welcome overlay on first install, What's New on upgrades
                        var appSettings = SettingsManager.LoadSettings();
                        if (!appSettings.HasSeenWelcome)
                        {
                            Logger.Log("First install via --updated - showing welcome overlay");
                            settingsWindow.ShowWelcomeOverlay();
                        }

                        settingsWindow.ShowDialog();
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"FATAL: Failed to create SettingsWindow after update: {ex}");
                    }
                    AppLifecycleService.ShutdownOrStayInBackground("--updated completed");
                    return;
                }

                // Handle manage rules command
                if (url.Equals("--manage", StringComparison.OrdinalIgnoreCase))
                {
                    Logger.Log("Command: --manage - opening SettingsWindow");
                    try
                    {
                        var settingsWindow = new SettingsWindow();
                        Logger.Log("SettingsWindow created, showing dialog...");
                        settingsWindow.ShowDialog();
                        Logger.Log("SettingsWindow closed");
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"FATAL: Failed to create SettingsWindow: {ex}");
                        MessageBox.Show($"Error starting application:\n\n{ex.Message}\n\nCheck log at D:\\BrowserSelector\\log.txt",
                            $"{BrandConfig.AppDisplayName} Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    AppLifecycleService.ShutdownOrStayInBackground("--manage completed");
                    return;
                }

                // Handle register command - register and show settings with App tab
                if (url.Equals("--register", StringComparison.OrdinalIgnoreCase))
                {
                    Logger.Log("Command: --register - registering as default browser");
                    try
                    {
                        Logger.Log("Calling RegistryHelper.RegisterAsDefaultBrowser()...");
                        RegistryHelper.RegisterAsDefaultBrowser();
                        Logger.Log("Registration complete, opening SettingsWindow");
                        var settingsWindow = new SettingsWindow();
                        settingsWindow.SelectAppTab();
                        Logger.Log("SettingsWindow created, showing dialog...");
                        settingsWindow.ShowDialog();
                        Logger.Log("SettingsWindow closed");
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"FATAL: Failed to create SettingsWindow: {ex}");
                        MessageBox.Show($"Error starting application:\n\n{ex.Message}\n\nCheck log at D:\\BrowserSelector\\log.txt",
                            $"{BrandConfig.AppDisplayName} Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    AppLifecycleService.ShutdownOrStayInBackground("--register completed");
                    return;
                }
                else if (url.Equals("--unregister", StringComparison.OrdinalIgnoreCase))
                {
                    Logger.Log("Command: --unregister - unregistering as default browser");
                    RegistryHelper.UnregisterAsDefaultBrowser();
                    Logger.Log("Unregistration complete, shutting down");
                    AppLifecycleService.RequestShutdown("--unregister complete");
                    return;
                }

                // Normal operation - process URL and open browser
                else
                {
                    Logger.Log("Normal operation - processing URL");

                    // Validate URL - treat empty/whitespace as no URL
                    if (string.IsNullOrWhiteSpace(url))
                    {
                        Logger.Log("URL is empty/whitespace - treating as no URL, showing SettingsWindow");
                        try
                        {
                            var settingsWindow = new SettingsWindow();
                            settingsWindow.ShowDialog();
                        }
                        catch (Exception ex)
                        {
                            Logger.Log($"FATAL: Failed to create SettingsWindow: {ex}");
                            MessageBox.Show($"Error starting application:\n\n{ex.Message}",
                                $"{BrandConfig.AppDisplayName} Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                        AppLifecycleService.ShutdownOrStayInBackground("Empty URL - settings closed");
                        return;
                    }

                    Logger.Log($"Valid URL received: {Logger.SanitizeUrl(url)}");
                    Logger.Log("Creating MainWindow...");

                    MainWindow? mainWindow = null;
                    try
                    {
                        mainWindow = new MainWindow();
                        Logger.Log("MainWindow created successfully");
                        Logger.Log("Calling mainWindow.SetUrl()...");
                        mainWindow.SetUrl(url);
                        Logger.Log("SetUrl() completed - flow continues in MainWindow");
                        // Note: If SetUrl() finds a match and auto-opens, it calls Shutdown()
                        // If no match, HandleNoMatch() calls Show() on the window
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"Error processing URL: {ex}");

                        // Try to show the window as fallback for manual selection
                        Logger.Log("Attempting fallback - showing window for manual selection");
                        try
                        {
                            if (mainWindow != null)
                            {
                                Logger.Log("MainWindow exists - showing it");
                                mainWindow.Show();
                                mainWindow.Activate();
                            }
                            else
                            {
                                // MainWindow creation failed - show error and shutdown
                                Logger.Log("MainWindow is null - showing error and shutting down");
                                MessageBox.Show($"Error processing URL:\n\n{ex.Message}",
                                    $"{BrandConfig.AppDisplayName} Error", MessageBoxButton.OK, MessageBoxImage.Error);
                                AppLifecycleService.RequestShutdown("MainWindow creation failed");
                            }
                        }
                        catch (Exception fallbackEx)
                        {
                            // Complete failure - shutdown
                            Logger.Log($"Fallback also failed: {fallbackEx}");
                            MessageBox.Show($"Error starting application:\n\n{ex.Message}",
                                $"{BrandConfig.AppDisplayName} Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            AppLifecycleService.RequestShutdown("Fallback failed");
                        }
                    }
                }
            }
            else
            {
                // No URL argument - show SettingsWindow directly
                Logger.Log("No arguments provided - showing SettingsWindow");
                try
                {
                    var settingsWindow = new SettingsWindow();

                    // Show welcome overlay on first run
                    var appSettings = SettingsManager.LoadSettings();
                    if (!appSettings.HasSeenWelcome)
                    {
                        Logger.Log("First run - showing welcome overlay");
                        settingsWindow.ShowWelcomeOverlay();
                    }

                    Logger.Log("SettingsWindow created, showing dialog...");
                    settingsWindow.ShowDialog();
                    Logger.Log("SettingsWindow closed");
                }
                catch (Exception ex)
                {
                    Logger.Log($"FATAL: Failed to create SettingsWindow: {ex}");
                    MessageBox.Show($"Error starting application:\n\n{ex.Message}\n\nCheck log at D:\\BrowserSelector\\log.txt",
                        $"{BrandConfig.AppDisplayName} Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                AppLifecycleService.ShutdownOrStayInBackground("No arguments - settings closed");
            }
        }

        /// <summary>
        /// Applies an explicit, empty jump list with the Recent and Frequent categories
        /// disabled. This overrides Windows' automatic destination tracking, which would
        /// otherwise expose every opened URL in the taskbar jump list.
        /// </summary>
        private void ConfigureJumpList()
        {
            try
            {
                var jumpList = new System.Windows.Shell.JumpList
                {
                    ShowRecentCategory = false,
                    ShowFrequentCategory = false
                };
                System.Windows.Shell.JumpList.SetJumpList(this, jumpList);
                jumpList.Apply();
                Logger.Log("ConfigureJumpList: Recent/Frequent categories disabled");
            }
            catch (Exception ex)
            {
                Logger.Log($"ConfigureJumpList failed: {ex.Message}");
            }
        }

        private bool _clipboardHandlersSetup = false;

        private void SetupClipboardEventHandlers()
        {
            if (_clipboardHandlersSetup) return;

            // Set up clipboard monitoring events (once)
            ClipboardMonitorService.Instance.UrlDetected += OnClipboardUrlDetected;

            // Set up tray icon events
            TrayIconService.Instance.SettingsRequested += OnTraySettingsRequested;
            TrayIconService.Instance.SettingsPageRequested += OnTraySettingsPageRequested;
            TrayIconService.Instance.ExitRequested += OnTrayExitRequested;

            // Set up global hotkey events and register hotkeys immediately
            HotkeyService.Instance.HotkeyPressed += OnHotkeyPressed;
            HotkeyService.Instance.Start();

            _clipboardHandlersSetup = true;
            Logger.Log("SetupClipboardEventHandlers: Event handlers registered");
        }

        private void StartBackgroundMonitoring()
        {
            Logger.Log("StartBackgroundMonitoring: Initializing services");

            // Event handlers are already set up in Application_Startup via SetupClipboardEventHandlers()

            // Start services
            ClipboardMonitorService.Instance.Start();
            TrayIconService.Instance.Show();
            TrayIconService.Instance.UpdateState();

            // Initialize Power Clip
            if (BrandConfig.PowerClipEnabled)
                PowerClipService.Instance.Initialize();

            // Start global hotkeys
            HotkeyService.Instance.Start();

            Logger.Log("StartBackgroundMonitoring: Services started, app running in background");
        }

        private void OnClipboardUrlDetected(object? sender, ClipboardUrlEventArgs e)
        {
            Logger.Log($"OnClipboardUrlDetected: {e.Url}");

            Dispatcher.Invoke(() =>
            {
                // Get match result
                var matchResult = UrlRuleManager.FindMatch(e.Url);

                // Show notification
                var sourceDisplay = e.SourceApp?.FormattedDisplay;
                var notification = new ClipboardNotificationWindow(e.Url, e.Domain, matchResult, sourceDisplay);
                notification.NotificationClosed += OnNotificationClosed;
                notification.Show();
            });
        }

        private void OnNotificationClosed(object? sender, ClipboardNotificationResult result)
        {
            Logger.Log($"OnNotificationClosed: Action={result.Action}, URL={Logger.SanitizeUrl(result.Url)}");

            switch (result.Action)
            {
                case ClipboardNotificationAction.Open:
                    OpenUrlWithMatch(result.Url, result.MatchResult);
                    break;

                case ClipboardNotificationAction.DontShowAgain:
                    // Disable clipboard notifications for this rule
                    DisableClipboardForRule(result.MatchResult);
                    Logger.Log($"Disabled clipboard notifications for matched rule");
                    break;

                case ClipboardNotificationAction.Dismissed:
                case ClipboardNotificationAction.Timeout:
                    // No action needed
                    break;
            }
        }

        private void DisableClipboardForRule(MatchResult match)
        {
            if (match.Type == MatchType.IndividualRule && match.Rule != null)
            {
                match.Rule.ClipboardNotificationsEnabled = false;
                UrlRuleManager.UpdateRule(match.Rule);
                Logger.Log($"Disabled clipboard for rule: {match.Rule.Pattern}");
            }
            else if ((match.Type == MatchType.UrlGroup || match.Type == MatchType.GroupOverride) && match.Group != null)
            {
                match.Group.ClipboardNotificationsEnabled = false;
                UrlGroupManager.UpdateGroup(match.Group);
                Logger.Log($"Disabled clipboard for group: {match.Group.Name}");
            }
        }

        /// <summary>
        /// Validates that a string is a safe HTTP/HTTPS URL for browser launching.
        /// Rejects URLs containing unescaped quotes or non-HTTP schemes.
        /// </summary>
        internal static bool IsValidBrowseUrl(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return false;
            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return false;
            if (uri.Scheme != "http" && uri.Scheme != "https") return false;
            if (string.IsNullOrEmpty(uri.Host)) return false;
            if (url.Contains('"')) return false;
            return true;
        }

        /// <summary>
        /// Escapes double quotes in a URL to prevent argument injection.
        /// </summary>
        internal static string SanitizeUrlForArgument(string url) => url.Replace("\"", "%22");

        /// <summary>
        /// Launches a browser and forcibly brings its window to the foreground.
        /// </summary>
        private static void LaunchBrowser(string exePath, string arguments)
        {
            Services.BrowserFocusHelper.LaunchAndFocus(exePath, arguments);
        }

        private void OpenUrlWithMatch(string url, MatchResult matchResult)
        {
            try
            {
                // Multi-profile rule — show picker instead of auto-opening first profile
                if (matchResult.Type == MatchType.IndividualRule && matchResult.Rule?.HasMultipleProfiles == true)
                {
                    var picker = new RuleProfilePickerWindow(url, matchResult.Rule);
                    picker.ShowDialog();
                    return;
                }

                // Multi-profile group or ShowProfilePicker behavior — show group picker
                if (matchResult.Type == MatchType.UrlGroup && matchResult.Group != null &&
                    (matchResult.Group.HasMultipleProfiles || matchResult.Group.Behavior == UrlGroupBehavior.ShowProfilePicker))
                {
                    var picker = new RuleProfilePickerWindow(url, matchResult.Group);
                    picker.ShowDialog();
                    return;
                }

                var browserPath = matchResult.GetBrowserPath();
                var profileArgs = matchResult.GetProfileArguments();

                var safeUrl = SanitizeUrlForArgument(url);

                if (matchResult.Type != MatchType.NoMatch && !string.IsNullOrEmpty(browserPath))
                {
                    var args = string.IsNullOrEmpty(profileArgs)
                        ? $"\"{safeUrl}\""
                        : $"{profileArgs} \"{safeUrl}\"";

                    Logger.Log($"Opening URL with profile: {browserPath} {args}");
                    LaunchBrowser(browserPath, args);
                }
                else
                {
                    // Use default browser
                    var settings = SettingsManager.LoadSettings();
                    if (!string.IsNullOrEmpty(settings.DefaultBrowserPath))
                    {
                        Logger.Log($"Opening URL with default browser: {settings.DefaultBrowserPath}");
                        LaunchBrowser(settings.DefaultBrowserPath, $"\"{safeUrl}\"");
                    }
                    else if (IsValidBrowseUrl(url))
                    {
                        // Fallback to system default — only allow valid HTTP/HTTPS URLs
                        Logger.Log("Opening URL with system default browser");
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = url,
                            UseShellExecute = true
                        });
                    }
                    else
                    {
                        Logger.Log($"Rejected invalid URL from shell execution: {Logger.SanitizeUrl(url)}");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"OpenUrlWithMatch error: {ex}");
            }
        }

        private void OnTraySettingsRequested(object? sender, EventArgs e)
        {
            Logger.Log("OnTraySettingsRequested: Opening settings window");
            ShowOrActivateSettingsWindow();
        }

        private void OnTraySettingsPageRequested(object? sender, EventArgs e)
        {
            Logger.Log("OnTraySettingsPageRequested: Opening settings page");
            ShowOrActivateSettingsWindow(selectAppTab: true);
        }

        private System.Windows.Threading.DispatcherTimer? _updateCheckTimer;

        private void ScheduleUpdateChecks()
        {
            // Calculate delay to next 8am or 8pm
            var now = DateTime.Now;
            var next1 = now.Date.AddHours(8);  // 8:00 AM
            var next2 = now.Date.AddHours(20); // 8:00 PM

            if (next1 <= now) next1 = next1.AddDays(1);
            if (next2 <= now) next2 = next2.AddDays(1);

            var nextCheck = next1 < next2 ? next1 : next2;
            var delay = nextCheck - now;

            Logger.Log($"UpdateCheck: Next scheduled check at {nextCheck:HH:mm} (in {delay.TotalMinutes:F0}m)");

            _updateCheckTimer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = delay
            };
            _updateCheckTimer.Tick += async (s, e) =>
            {
                _updateCheckTimer.Stop();

                try
                {
                    // Force fresh check
                    var settings = SettingsManager.LoadSettings();
                    settings.LastUpdateCheckTime = DateTime.MinValue;
                    SettingsManager.SaveSettings(settings);

                    await Services.UpdateCheckService.Instance.CheckForUpdatesAsync();
                }
                catch (Exception ex)
                {
                    Logger.Log($"Scheduled update check failed: {ex.Message}");
                }

                // Schedule next check (12 hours later)
                _updateCheckTimer.Interval = TimeSpan.FromHours(12);
                _updateCheckTimer.Start();
            };
            _updateCheckTimer.Start();
        }

        private void OnTrayExitRequested(object? sender, EventArgs e)
        {
            Logger.Log("OnTrayExitRequested: Shutting down");

            // Clean up services
            ClipboardMonitorService.Instance.Stop();
            ClipboardMonitorService.Instance.Dispose();
            TrayIconService.Instance.Hide();
            TrayIconService.Instance.Dispose();

            AppLifecycleService.RequestShutdown("Tray exit requested");
        }

        #region Single Instance Support

        private void OnArgumentsReceived(object? sender, string[] args)
        {
            Logger.Log($"OnArgumentsReceived: {string.Join(", ", args)}");
            ProcessReceivedArguments(args);
        }

        private void ProcessReceivedArguments(string[] args)
        {
            if (args.Length == 0)
            {
                // No args - show/activate settings window
                ShowOrActivateSettingsWindow();
                return;
            }

            var arg = args[0];

            if (arg.Equals("--manage", StringComparison.OrdinalIgnoreCase))
            {
                ShowOrActivateSettingsWindow();
            }
            else if (arg.Equals("--startup", StringComparison.OrdinalIgnoreCase))
            {
                // Already running - just ensure background services
                var settings = SettingsManager.LoadSettings();
                if (settings.ClipboardMonitoring.IsEnabled)
                {
                    AppLifecycleService.EnsureBackgroundServicesRunning();
                }
            }
            else if (arg.Equals("--background", StringComparison.OrdinalIgnoreCase))
            {
                AppLifecycleService.EnsureBackgroundServicesRunning();
            }
            else if (arg.Equals("--register", StringComparison.OrdinalIgnoreCase))
            {
                RegistryHelper.RegisterAsDefaultBrowser();
                ShowOrActivateSettingsWindow(selectAppTab: true);
            }
            else if (arg.Equals("--unregister", StringComparison.OrdinalIgnoreCase))
            {
                // Probably shouldn't process from second instance
                Logger.Log("Ignoring --unregister from second instance");
            }
            else if (arg.StartsWith("--page:", StringComparison.OrdinalIgnoreCase))
            {
                var pageName = arg.Substring("--page:".Length);
                OnHotkeyPressed(null, pageName);
            }
            else if (!string.IsNullOrWhiteSpace(arg))
            {
                // It's a URL - process it
                ProcessUrlFromSecondInstance(arg);
            }
        }

        private void ShowOrActivateSettingsWindow(bool selectAppTab = false)
        {
            Dispatcher.Invoke(() =>
            {
                // Check for existing settings window
                var existingWindow = Windows
                    .OfType<SettingsWindow>()
                    .FirstOrDefault();

                if (existingWindow != null)
                {
                    Logger.Log("Activating existing SettingsWindow");
                    existingWindow.WindowState = WindowState.Normal;
                    existingWindow.Activate();
                    existingWindow.Focus();

                    if (selectAppTab)
                    {
                        existingWindow.SelectAppTab();
                    }
                }
                else
                {
                    Logger.Log("Creating new SettingsWindow");
                    var settingsWindow = new SettingsWindow();

                    if (selectAppTab)
                    {
                        settingsWindow.SelectAppTab();
                    }

                    settingsWindow.Show();
                    settingsWindow.Activate();
                }
            });
        }

        private CompactClipboardWindow? _compactClipboard;

        private void OnHotkeyPressed(object? sender, string pageName)
        {
            Dispatcher.BeginInvoke(() =>
            {
                try
                {
                    Logger.Log($"OnHotkeyPressed: Handling {pageName}");

                    // Power Clip hotkey → compact popup
                    if (pageName == "PowerClip" && BrandConfig.PowerClipEnabled)
                    {
                        ToggleCompactClipboard();
                        return;
                    }

                    // Rules hotkey → open full app
                    var existingWindow = Windows
                        .OfType<SettingsWindow>()
                        .FirstOrDefault();

                    if (existingWindow != null)
                    {
                        existingWindow.WindowState = WindowState.Normal;
                        existingWindow.Show();
                        existingWindow.Activate();
                        existingWindow.NavigateToPage(pageName);
                    }
                    else
                    {
                        var settingsWindow = new SettingsWindow();
                        settingsWindow.NavigateToPage(pageName);
                        settingsWindow.Show();
                        settingsWindow.Activate();
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"OnHotkeyPressed ERROR: {ex}");
                }
            });
        }

        private void ToggleCompactClipboard()
        {
            if (_compactClipboard != null && _compactClipboard.IsVisible)
            {
                _compactClipboard.Close();
                _compactClipboard = null;
                return;
            }

            _compactClipboard = new CompactClipboardWindow();
            _compactClipboard.Closed += (s, e) => _compactClipboard = null;
            _compactClipboard.Show();
            _compactClipboard.Activate();
        }

        private void ProcessUrlFromSecondInstance(string url)
        {
            Logger.Log($"ProcessUrlFromSecondInstance: {Logger.SanitizeUrl(url)}");

            Dispatcher.Invoke(() =>
            {
                try
                {
                    // Reuse existing MainWindow if one is already open (prevents window pileup)
                    // Don't call Show/Activate here — SetUrl will show the window only if manual selection is needed
                    var existingWindow = Windows.OfType<MainWindow>().FirstOrDefault();
                    if (existingWindow != null)
                    {
                        Logger.Log("Reusing existing MainWindow");
                        existingWindow.SetUrl(url);
                        return;
                    }

                    var mainWindow = new MainWindow();
                    mainWindow.SetUrl(url);
                }
                catch (Exception ex)
                {
                    Logger.Log($"ProcessUrlFromSecondInstance error: {ex}");
                }
            });
        }

        protected override void OnExit(ExitEventArgs e)
        {
            Logger.Log("Application.OnExit: Cleaning up");
            HotkeyService.Instance.Stop();
            ThemeManager.Cleanup();
            SingleInstanceManager.Instance.Dispose();
            base.OnExit(e);
        }

        #endregion

    }

    public static class Logger
    {
        private static readonly string LogDirectory = AppConfig.AppDataFolder;
        private static readonly string LogFilePath = Path.Combine(LogDirectory, "log.txt");
        private static readonly string OldLogFilePath = Path.Combine(LogDirectory, "log.old.txt");
        private const long MaxLogSize = 1 * 1024 * 1024; // 1 MB

        /// <summary>
        /// Strips query string and fragment from a URL to avoid logging sensitive parameters.
        /// </summary>
        public static string SanitizeUrl(string url)
        {
            try
            {
                if (Uri.TryCreate(url, UriKind.Absolute, out var uri))
                    return $"{uri.Scheme}://{uri.Host}{uri.AbsolutePath}";
            }
            catch { }
            // Fallback: strip everything after ? or #
            var idx = url.IndexOfAny(new[] { '?', '#' });
            return idx >= 0 ? url[..idx] : url;
        }

        public static void Log(string message)
        {
            try
            {
                if (!Directory.Exists(LogDirectory))
                    Directory.CreateDirectory(LogDirectory);

                // Rotate log if it exceeds max size
                if (File.Exists(LogFilePath))
                {
                    var fileInfo = new FileInfo(LogFilePath);
                    if (fileInfo.Length > MaxLogSize)
                    {
                        if (File.Exists(OldLogFilePath))
                            File.Delete(OldLogFilePath);
                        File.Move(LogFilePath, OldLogFilePath);
                    }
                }

                File.AppendAllText(
                    LogFilePath,
                    $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} | {message}{Environment.NewLine}"
                );
            }
            catch
            {
                // Never crash the app because of logging
            }
        }
    }
}