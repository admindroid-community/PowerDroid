using System.Windows.Controls;

namespace PowerDroid.Pages
{
    public partial class DocsPage : UserControl
    {
        public DocsPage()
        {
            InitializeComponent();
        }
    }
}
