using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using PowerDroid.Models;
using Hardcodet.Wpf.TaskbarNotification;

namespace PowerDroid.Services
{
    /// <summary>
    /// Service that manages the system tray icon for background clipboard monitoring.
    /// Uses Hardcodet.NotifyIcon.Wpf (WPF-native, no WinForms dependency).
    /// </summary>
    public class TrayIconService : IDisposable
    {
        #region Singleton

        private static TrayIconService? _instance;
        private static readonly object _lock = new object();

        public static TrayIconService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new TrayIconService();
                    }
                }
                return _instance;
            }
        }

        #endregion

        #region Fields

        private TaskbarIcon? _taskbarIcon;
        private MenuItem? _statusMenuItem;
        private MenuItem? _resumeMenuItem;
        private MenuItem? _pauseMenuItem;
        private DispatcherTimer? _pauseTimer;
        private bool _disposed;
        private bool _isVisible;

        #endregion

        #region Events

        public event EventHandler? SettingsRequested;
        public event EventHandler? SettingsPageRequested;
        public event EventHandler? ExitRequested;
        public event EventHandler? StateChanged;

        #endregion

        #region Properties

        public bool IsVisible => _isVisible;

        #endregion

        #region Constructor

        private TrayIconService()
        {
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Shows the tray icon.
        /// </summary>
        public void Show()
        {
            Logger.Log($"TrayIconService.Show() called. Already visible: {_isVisible}");

            if (_isVisible) return;

            try
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    // Only create once — reuse existing instance
                    if (_taskbarIcon == null)
                        CreateTaskbarIcon();

                    if (_taskbarIcon != null)
                    {
                        _taskbarIcon.Visibility = Visibility.Visible;
                        _isVisible = true;
                        Logger.Log("TrayIconService: Tray icon shown");
                    }
                    else
                    {
                        Logger.Log("TrayIconService: TaskbarIcon is null after creation!");
                    }
                });
            }
            catch (Exception ex)
            {
                Logger.Log($"TrayIconService.Show() ERROR: {ex.Message}");
            }
        }

        /// <summary>
        /// Hides the tray icon.
        /// </summary>
        public void Hide()
        {
            if (!_isVisible) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                if (_taskbarIcon != null)
                {
                    _taskbarIcon.Visibility = Visibility.Collapsed;
                    _isVisible = false;
                    Logger.Log("TrayIconService: Tray icon hidden");
                }
            });
        }

        /// <summary>
        /// Updates the tray icon state based on current settings.
        /// </summary>
        public void UpdateState()
        {
            if (_taskbarIcon == null || _statusMenuItem == null) return;

            var settings = SettingsManager.LoadSettings().ClipboardMonitoring;

            Application.Current.Dispatcher.Invoke(() =>
            {
                if (!settings.IsEnabled)
                {
                    _statusMenuItem.Header = "Disabled";
                    _statusMenuItem.IsChecked = false;
                    _statusMenuItem.IsEnabled = true;
                    _statusMenuItem.IsCheckable = true;
                    _taskbarIcon.ToolTipText = $"{BrandConfig.AppDisplayName}\nClipboard monitoring is off";
                    if (_resumeMenuItem != null) _resumeMenuItem.Visibility = Visibility.Collapsed;
                    if (_pauseMenuItem != null) { _pauseMenuItem.Header = "Pause for..."; _pauseMenuItem.IsEnabled = false; }
                }
                else if (settings.IsPaused)
                {
                    var remaining = settings.RemainingPauseTime;
                    _statusMenuItem.Header = remaining.HasValue
                        ? $"Paused for {FormatRemainingTime(remaining)}"
                        : "Paused";
                    _statusMenuItem.IsChecked = false;
                    _statusMenuItem.IsEnabled = false;
                    _statusMenuItem.IsCheckable = false;
                    _taskbarIcon.ToolTipText = remaining.HasValue
                        ? $"{BrandConfig.AppDisplayName}\nMonitoring paused for {FormatRemainingTime(remaining)}"
                        : $"{BrandConfig.AppDisplayName}\nMonitoring paused";
                    if (_resumeMenuItem != null) _resumeMenuItem.Visibility = Visibility.Visible;
                    if (_pauseMenuItem != null) { _pauseMenuItem.Header = "Extend Time"; _pauseMenuItem.IsEnabled = true; }
                }
                else
                {
                    _statusMenuItem.Header = "Active";
                    _statusMenuItem.IsChecked = true;
                    _statusMenuItem.IsEnabled = true;
                    _statusMenuItem.IsCheckable = true;
                    _taskbarIcon.ToolTipText = $"{BrandConfig.AppDisplayName}\nClipboard monitoring is active";
                    if (_resumeMenuItem != null) _resumeMenuItem.Visibility = Visibility.Collapsed;
                    if (_pauseMenuItem != null) { _pauseMenuItem.Header = "Pause for..."; _pauseMenuItem.IsEnabled = true; }
                }

                StateChanged?.Invoke(this, EventArgs.Empty);
            });
        }

        /// <summary>
        /// Shows a brief balloon notification.
        /// </summary>
        public void ShowBalloon(string title, string text, BalloonIcon icon = BalloonIcon.Info, int timeout = 2000)
        {
            if (_taskbarIcon == null) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                _taskbarIcon.ShowBalloonTip(title, text, icon);
            });
        }

        /// <summary>
        /// Pauses clipboard monitoring for the specified duration.
        /// If already paused, extends from the current pause end time.
        /// </summary>
        public void PauseFor(TimeSpan duration)
        {
            var settings = SettingsManager.LoadSettings();

            var baseTime = settings.ClipboardMonitoring.IsPaused && settings.ClipboardMonitoring.PauseEndTime.HasValue
                ? settings.ClipboardMonitoring.PauseEndTime.Value
                : DateTime.Now;
            settings.ClipboardMonitoring.PauseEndTime = baseTime.Add(duration);
            SettingsManager.SaveSettings(settings);

            var totalRemaining = settings.ClipboardMonitoring.PauseEndTime.Value - DateTime.Now;
            Logger.Log($"TrayIconService: Monitoring paused/extended by {duration.TotalMinutes} minutes (total remaining: {totalRemaining.TotalMinutes:F0} minutes)");

            StartPauseTimer(totalRemaining);
            UpdateState();
        }

        /// <summary>
        /// Resumes clipboard monitoring.
        /// </summary>
        public void Resume()
        {
            var settings = SettingsManager.LoadSettings();
            settings.ClipboardMonitoring.PauseEndTime = null;
            SettingsManager.SaveSettings(settings);

            StopPauseTimer();
            UpdateState();

            Logger.Log("TrayIconService: Monitoring resumed");
        }

        #endregion

        #region Private Methods

        private void CreateTaskbarIcon()
        {
            var contextMenu = CreateContextMenu();

            _taskbarIcon = new TaskbarIcon
            {
                IconSource = LoadIcon(),
                ToolTipText = BrandConfig.AppDisplayName,
                ContextMenu = contextMenu,
                MenuActivation = PopupActivationMode.RightClick,
                Visibility = Visibility.Collapsed
            };

            // Single left-click opens settings
            _taskbarIcon.TrayLeftMouseUp += (s, e) =>
            {
                SettingsRequested?.Invoke(this, EventArgs.Empty);
            };
        }

        private ImageSource? LoadIcon()
        {
            // Try to load from WPF application resources using BitmapDecoder (handles .ico multi-frame)
            try
            {
                var resourceUri = new Uri("pack://application:,,,/Assets/Icons/app.ico", UriKind.Absolute);
                var decoder = BitmapDecoder.Create(resourceUri, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                if (decoder.Frames.Count > 0)
                {
                    // Pick the best frame for tray icon (prefer 16x16, then 32x32 for crisp scaling)
                    var frame = decoder.Frames
                        .OrderBy(f => f.PixelWidth == 16 ? 0 : f.PixelWidth == 32 ? 1 : Math.Abs(f.PixelWidth - 16) + 10)
                        .First();
                    Logger.Log($"TrayIconService: Loaded icon from WPF resource ({frame.PixelWidth}x{frame.PixelHeight})");
                    return frame;
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"TrayIconService: WPF resource load failed: {ex.Message}");
            }

            // Fallback: try to load from file
            try
            {
                var iconPaths = new[]
                {
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Icons", "app.ico"),
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"{BrandConfig.ExeName}.ico")
                };

                foreach (var iconPath in iconPaths)
                {
                    if (File.Exists(iconPath))
                    {
                        var decoder = BitmapDecoder.Create(
                            new Uri(iconPath), BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                        if (decoder.Frames.Count > 0)
                        {
                            var frame = decoder.Frames.OrderBy(f => Math.Abs(f.PixelWidth - 32)).First();
                            Logger.Log($"TrayIconService: Loaded icon from file: {iconPath}");
                            return frame;
                        }
                    }
                }

                Logger.Log("TrayIconService: No icon file found");
            }
            catch (Exception ex)
            {
                Logger.Log($"TrayIconService: File load failed: {ex.Message}");
            }

            return null;
        }

        private ContextMenu CreateContextMenu()
        {
            var contextMenu = new ContextMenu();

            // Clipboard Monitoring submenu (shared by Smart Browse and Power Clip)
            var clipboardMonitoringMenuItem = new MenuItem { Header = "Clipboard Monitoring" };

            _statusMenuItem = new MenuItem
            {
                Header = "Enabled",
                IsCheckable = true,
                IsChecked = true
            };
            _statusMenuItem.Click += StatusMenuItem_Click;
            clipboardMonitoringMenuItem.Items.Add(_statusMenuItem);

            clipboardMonitoringMenuItem.Items.Add(new Separator());

            _resumeMenuItem = new MenuItem { Header = "Resume Monitoring", Visibility = Visibility.Collapsed };
            _resumeMenuItem.Click += (s, e) => Resume();
            clipboardMonitoringMenuItem.Items.Add(_resumeMenuItem);

            _pauseMenuItem = new MenuItem { Header = "Pause for..." };
            _pauseMenuItem.Items.Add(CreatePauseItem("5 minutes", TimeSpan.FromMinutes(5)));
            _pauseMenuItem.Items.Add(CreatePauseItem("15 minutes", TimeSpan.FromMinutes(15)));
            _pauseMenuItem.Items.Add(CreatePauseItem("30 minutes", TimeSpan.FromMinutes(30)));
            _pauseMenuItem.Items.Add(CreatePauseItem("1 hour", TimeSpan.FromHours(1)));
            clipboardMonitoringMenuItem.Items.Add(_pauseMenuItem);

            contextMenu.Items.Add(clipboardMonitoringMenuItem);
            contextMenu.Items.Add(new Separator());

            // Settings
            var settingsItem = new MenuItem { Header = "Settings..." };
            settingsItem.Click += (s, e) => SettingsPageRequested?.Invoke(this, EventArgs.Empty);
            contextMenu.Items.Add(settingsItem);

            contextMenu.Items.Add(new Separator());

            // Quit
            var quitItem = new MenuItem { Header = "Quit" };
            quitItem.Click += (s, e) => ExitRequested?.Invoke(this, EventArgs.Empty);
            contextMenu.Items.Add(quitItem);

            return contextMenu;
        }

        private MenuItem CreatePauseItem(string text, TimeSpan duration)
        {
            var item = new MenuItem { Header = text };
            item.Click += (s, e) => PauseFor(duration);
            return item;
        }

        private void StatusMenuItem_Click(object sender, RoutedEventArgs e)
        {
            var settings = SettingsManager.LoadSettings();

            if (settings.ClipboardMonitoring.IsPaused)
            {
                Resume();
            }
            else
            {
                settings.ClipboardMonitoring.IsEnabled = !settings.ClipboardMonitoring.IsEnabled;
                SettingsManager.SaveSettings(settings);

                if (settings.ClipboardMonitoring.IsEnabled)
                {
                    ClipboardMonitorService.Instance.Start();
                }
                else
                {
                    ClipboardMonitorService.Instance.Stop();
                }

                UpdateState();
            }
        }

        private void StartPauseTimer(TimeSpan duration)
        {
            StopPauseTimer();

            _pauseTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(30)
            };
            _pauseTimer.Tick += (s, e) =>
            {
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                if (!settings.IsPaused)
                {
                    StopPauseTimer();
                    Resume();
                }
                else
                {
                    UpdateState();
                }
            };
            _pauseTimer.Start();
        }

        private void StopPauseTimer()
        {
            if (_pauseTimer != null)
            {
                _pauseTimer.Stop();
                _pauseTimer = null;
            }
        }

        private string FormatRemainingTime(TimeSpan? remaining)
        {
            if (!remaining.HasValue) return "";

            if (remaining.Value.TotalMinutes < 1)
                return $"{remaining.Value.Seconds}s";
            else if (remaining.Value.TotalHours < 1)
                return $"{(int)remaining.Value.TotalMinutes}m";
            else
                return $"{(int)remaining.Value.TotalHours}h {remaining.Value.Minutes}m";
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            if (_disposed) return;

            StopPauseTimer();

            if (_taskbarIcon != null)
            {
                _taskbarIcon.Visibility = Visibility.Collapsed;
                _taskbarIcon.Dispose();
                _taskbarIcon = null;
            }

            _disposed = true;
        }

        #endregion
    }
}
