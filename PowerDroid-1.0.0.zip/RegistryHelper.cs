﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace PowerDroid
{
    public static class RegistryHelper
    {
        public const string AppName = BrandConfig.RegistryAppId;
        private static readonly string AppDescription = $"{BrandConfig.AppDisplayName} - {BrandConfig.PowerBrowserDescription}";

        [DllImport("shell32.dll")]
        private static extern void SHChangeNotify(uint wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);

        private const uint SHCNE_ASSOCCHANGED = 0x08000000;
        private const uint SHCNF_IDLIST = 0x0000;

        public static string? GetRegisteredAppName()
        {
            const string regPath = @"SOFTWARE\RegisteredApplications";

            using var key = Registry.LocalMachine.OpenSubKey(regPath);
            if (key == null) return null;

            foreach (var name in key.GetValueNames())
            {
                var value = key.GetValue(name)?.ToString();
                if (value != null && value.Contains(AppName, StringComparison.OrdinalIgnoreCase))
                {
                    return name; // This is the registeredApp name
                }
            }

            return null;
        }

        public static void RegisterAsDefaultBrowser()
        {
            Logger.Log($"SECURITY: Browser registration initiated by user {Environment.UserName}");
            var exePath = Path.ChangeExtension(Assembly.GetExecutingAssembly().Location, ".exe");

            if (!File.Exists(exePath))
                exePath = Path.Combine(AppContext.BaseDirectory, $"{BrandConfig.ExeName}.exe");

            if (!File.Exists(exePath))
            {
                throw new FileNotFoundException("Executable not found", exePath);
            }

            try
            {
                // Register capabilities
                using (var key = Registry.CurrentUser.CreateSubKey($@"Software\Clients\StartMenuInternet\{AppName}"))
                {
                    if (key != null)
                    {
                        key.SetValue("", AppDescription);

                        using (var defaultIconKey = key.CreateSubKey("DefaultIcon"))
                        {
                            if (defaultIconKey != null)
                            {
                                defaultIconKey.SetValue("", $"{exePath},0");
                            }
                        }

                        using (var shellKey = key.CreateSubKey(@"shell\open\command"))
                        {
                            if (shellKey != null)
                            {
                                shellKey.SetValue("", $"\"{exePath}\" \"%1\"");
                            }
                        }
                    }
                }

                // Register application
                using (var key = Registry.CurrentUser.CreateSubKey($@"Software\{AppName}"))
                {
                    if (key != null)
                    {
                        key.SetValue("", AppDescription);
                    }
                }

                // Register URL associations
                using (var capabilitiesKey = Registry.CurrentUser.CreateSubKey($@"Software\{AppName}\Capabilities"))
                {
                    if (capabilitiesKey != null)
                    {
                        capabilitiesKey.SetValue("ApplicationName", BrandConfig.AppDisplayName);
                        capabilitiesKey.SetValue("ApplicationDescription", AppDescription);
                        capabilitiesKey.SetValue("ApplicationIcon", $"{exePath},0");

                        using (var urlAssocKey = capabilitiesKey.CreateSubKey("URLAssociations"))
                        {
                            if (urlAssocKey != null)
                            {
                                urlAssocKey.SetValue("http", $"{AppName}");
                                urlAssocKey.SetValue("https", $"{AppName}");
                            }
                        }

                        // Clean up legacy FileAssociations if present from previous versions
                        capabilitiesKey.DeleteSubKeyTree("FileAssociations", false);

                        using (var startMenuKey = capabilitiesKey.CreateSubKey("Startmenu"))
                        {
                            if (startMenuKey != null)
                            {
                                startMenuKey.SetValue("StartMenuInternet", AppName);
                            }
                        }
                    }
                }

                // Register in RegisteredApplications
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\RegisteredApplications", true))
                {
                    if (key != null)
                    {
                        key.SetValue(AppName, $@"Software\{AppName}\Capabilities");
                    }
                }

                // Register URL handler
                RegisterUrlProtocol("http", exePath);
                RegisterUrlProtocol("https", exePath);

                // Add to startup
                AddToStartup(exePath);

                // Notify Windows shell that associations changed (flushes cached handler data)
                SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, IntPtr.Zero, IntPtr.Zero);
                Logger.Log("SHChangeNotify called - shell association cache flushed");
                Logger.Log($"SECURITY: Browser registration completed for path: {exePath}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to register: {ex.Message}", ex);
            }
        }

        private static void AddToStartup(string exePath)
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (key != null)
                    {
                        // Add startup entry that runs in background (no window)
                        key.SetValue(AppName, $"\"{exePath}\" --startup");
                    }
                }
            }
            catch
            {
                // Startup registration is optional, don't fail the whole registration
            }
        }

        /// <summary>
        /// Adds the application to Windows startup (public method for clipboard monitoring)
        /// </summary>
        public static void AddToStartup()
        {
            try
            {
                var exePath = Path.ChangeExtension(Assembly.GetExecutingAssembly().Location, ".exe");
                if (!File.Exists(exePath))
                    exePath = Path.Combine(AppContext.BaseDirectory, $"{BrandConfig.ExeName}.exe");
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (key != null)
                    {
                        key.SetValue(AppName, $"\"{exePath}\" --startup");
                        Logger.Log("Added to startup");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"AddToStartup error: {ex.Message}");
            }
        }

        /// <summary>
        /// Removes the application from Windows startup
        /// </summary>
        public static void RemoveFromStartup()
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (key != null)
                    {
                        key.DeleteValue(AppName, false);
                        Logger.Log("Removed from startup");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"RemoveFromStartup error: {ex.Message}");
            }
        }

        /// <summary>
        /// Checks if the application is registered in Windows startup
        /// </summary>
        public static bool IsInStartup()
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
                {
                    return key?.GetValue(AppName) != null;
                }
            }
            catch
            {
                return false;
            }
        }

        private static void RegisterUrlProtocol(string protocol, string exePath)
        {
            using (var key = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{AppName}"))
            {
                if (key != null)
                {
                    key.SetValue("", $"{BrandConfig.AppDisplayName} URL Handler");
                    key.SetValue("URL Protocol", "");

                    using (var defaultIconKey = key.CreateSubKey("DefaultIcon"))
                    {
                        if (defaultIconKey != null)
                        {
                            defaultIconKey.SetValue("", $"{exePath},0");
                        }
                    }

                    using (var commandKey = key.CreateSubKey(@"shell\open\command"))
                    {
                        if (commandKey != null)
                        {
                            commandKey.SetValue("", $"\"{exePath}\" \"%1\"");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Check if the app is the system default browser (UserChoice points to us)
        /// </summary>
        public static bool IsSystemDefaultBrowser()
        {
            try
            {
                // Windows 11 2025+ uses UserChoiceLatest, fall back to UserChoice for older versions
                string? progId = null;

                // Try UserChoiceLatest\ProgId first (Windows 11 2025+ stores ProgId as a subkey)
                using (var key = Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoiceLatest\ProgId"))
                {
                    progId = key?.GetValue("ProgId")?.ToString();
                    if (!string.IsNullOrEmpty(progId))
                    {
                        Logger.Log($"IsSystemDefaultBrowser check (UserChoiceLatest\\ProgId) - ProgId: '{progId}', AppName: '{AppName}'");
                    }
                }

                // Fall back to UserChoice if UserChoiceLatest not found
                if (string.IsNullOrEmpty(progId))
                {
                    using var key = Registry.CurrentUser.OpenSubKey(
                        @"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice");
                    progId = key?.GetValue("ProgId")?.ToString();
                    Logger.Log($"IsSystemDefaultBrowser check (UserChoice) - ProgId: '{progId}', AppName: '{AppName}'");
                }

                var isDefault = string.Equals(progId, AppName, StringComparison.OrdinalIgnoreCase);
                Logger.Log($"IsSystemDefaultBrowser result: {isDefault}");

                return isDefault;
            }
            catch (Exception ex)
            {
                Logger.Log($"IsSystemDefaultBrowser ERROR: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Check if the application is registered as a browser handler
        /// </summary>
        public static bool IsRegistered()
        {
            try
            {
                // Check both old name and new name for compatibility
                using (RegistryKey? key = Registry.CurrentUser.OpenSubKey($@"Software\Clients\StartMenuInternet\{AppName}"))
                {
                    if (key != null)
                    {
                        using (RegistryKey? commandKey = key.OpenSubKey(@"shell\open\command"))
                        {
                            if (commandKey != null)
                            {
                                string? registeredPath = commandKey.GetValue("")?.ToString();
                                if (!string.IsNullOrEmpty(registeredPath) &&
                                    registeredPath.Contains($"{BrandConfig.ExeName}.exe", StringComparison.OrdinalIgnoreCase))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }

                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Verifies that all registration keys exist and point to the current exe.
        /// If any are missing or broken, re-registers automatically.
        /// Returns true if repair was needed.
        /// </summary>
        public static bool VerifyAndRepairRegistration()
        {
            try
            {
                var exePath = Path.ChangeExtension(Assembly.GetExecutingAssembly().Location, ".exe");
                if (!File.Exists(exePath))
                {
                    exePath = Path.Combine(AppContext.BaseDirectory, $"{BrandConfig.ExeName}.exe");
                }

                bool needsRepair = false;

                // Check ProgId: Software\Classes\{AppName}\shell\open\command
                using (var key = Registry.CurrentUser.OpenSubKey($@"Software\Classes\{AppName}\shell\open\command"))
                {
                    if (key == null)
                    {
                        Logger.Log($"VerifyRegistration: Missing Software\\Classes\\{AppName}\\shell\\open\\command");
                        needsRepair = true;
                    }
                    else
                    {
                        var command = key.GetValue("")?.ToString() ?? "";
                        if (!command.Contains($"{BrandConfig.ExeName}.exe", StringComparison.OrdinalIgnoreCase))
                        {
                            Logger.Log($"VerifyRegistration: ProgId command doesn't point to {BrandConfig.ExeName}: {command}");
                            needsRepair = true;
                        }
                    }
                }

                // Check Capabilities: Software\{AppName}\Capabilities
                if (!needsRepair)
                {
                    using var key = Registry.CurrentUser.OpenSubKey($@"Software\{AppName}\Capabilities");
                    if (key == null)
                    {
                        Logger.Log($"VerifyRegistration: Missing Software\\{AppName}\\Capabilities");
                        needsRepair = true;
                    }
                }

                // Check StartMenuInternet: Software\Clients\StartMenuInternet\{AppName}
                if (!needsRepair)
                {
                    using var key = Registry.CurrentUser.OpenSubKey($@"Software\Clients\StartMenuInternet\{AppName}");
                    if (key == null)
                    {
                        Logger.Log($"VerifyRegistration: Missing Software\\Clients\\StartMenuInternet\\{AppName}");
                        needsRepair = true;
                    }
                }

                if (needsRepair)
                {
                    Logger.Log("VerifyRegistration: Repairing registration...");
                    RegisterAsDefaultBrowser();
                    Logger.Log("VerifyRegistration: Registration repaired successfully");
                }
                else
                {
                    Logger.Log("VerifyRegistration: All registration keys intact");
                }

                return needsRepair;
            }
            catch (Exception ex)
            {
                Logger.Log($"VerifyRegistration ERROR: {ex.Message}");
                return false;
            }
        }

        public static void UnregisterAsDefaultBrowser()
        {
            try
            {
                Registry.CurrentUser.DeleteSubKeyTree($@"Software\Clients\StartMenuInternet\{AppName}", false);
                Registry.CurrentUser.DeleteSubKeyTree($@"Software\{AppName}", false);
                Registry.CurrentUser.DeleteSubKeyTree($@"Software\Classes\{AppName}", false);

                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\RegisteredApplications", true))
                {
                    if (key != null)
                    {
                        key.DeleteValue(AppName, false);
                    }
                }

                RemoveFromStartup();

                // Notify Windows shell that associations changed
                SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, IntPtr.Zero, IntPtr.Zero);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to unregister: {ex.Message}", ex);
            }
        }
    }
    public static class SystemDefaultBrowserDetector
    {
        public static BrowserInfo Get()
        {
            try
            {
                return BrowserDetector.MatchBrowserByPath(GetSystemDefaultBrowser().ExecutablePath);
            }
            catch
            {
                return null;
            }
        }
        public static BrowserInfo GetSystemDefaultBrowser()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice");

                var progId = key?.GetValue("ProgId")?.ToString();

                Logger.Log($"System default browser ProgId: {progId}");

                if (string.IsNullOrEmpty(progId))
                    return null;

                return ResolveProgIdToExe(progId);
            }
            catch (Exception ex)
            {
                Logger.Log($"Default browser detection failed: {ex}");
                return null;
            }
        }

        private static BrowserInfo ResolveProgIdToExe(string progId)
        {
            using var key = Registry.ClassesRoot.OpenSubKey(
                $@"{progId}\shell\open\command");

            var command = key?.GetValue(null)?.ToString();

            if (string.IsNullOrEmpty(command))
                return null;

            var exePath = ExtractExePath(command);

            if (!File.Exists(exePath))
                return null;

            return new BrowserInfo
            {
                Name = progId,
                ExecutablePath = exePath
            };
        }

        private static string ExtractExePath(string command)
        {
            command = command.Trim();

            if (command.StartsWith("\""))
            {
                return command.Substring(1, command.IndexOf("\"", 1) - 1);
            }

            return command.Split(' ')[0];
        }
    }
}