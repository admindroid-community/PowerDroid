# LinkRouter v2.0.0 — Testing Checklist

## Scenario 1: Fresh Install (No prior version)

- [ ] Install on clean Windows 11 (no .NET 8 runtime) — verify runtime auto-download
- [ ] Verify runtime download failure blocks installation (no internet)
- [ ] Install on Windows 11 with .NET 8 already present — no download prompt
- [ ] App launches after install
- [ ] Welcome overlay appears on first run
- [ ] Browser registration works (appears in Windows Default Apps)
- [ ] Start Menu shortcut created
- [ ] Desktop shortcut created only if checkbox was checked
- [ ] About section shows "v2.0.0" and "by AdminDroid"
- [ ] Files created in `%APPDATA%\LinkRouter\` (settings, rules, urlgroups)

## Scenario 2: Upgrade from v1.0.0 to v2.0.0

- [ ] Install v1.0.0 first, create rules and URL groups
- [ ] Install v2.0.0 over existing installation
- [ ] Existing rules and URL groups preserved
- [ ] Settings preserved (default browser, toggles)
- [ ] About section updates to v2.0.0
- [ ] No duplicate Start Menu shortcuts
- [ ] Registry publisher shows AdminDroid

## Scenario 3: Upgrade from v1.1.0 to v2.0.0

- [ ] Install v1.1.0 first, configure dark theme
- [ ] Install v2.0.0 over existing
- [ ] Theme preference preserved
- [ ] All data intact

## Scenario 4: Uninstall v2.0.0

- [ ] Run uninstaller
- [ ] `C:\Program Files\LinkRouter\` removed
- [ ] `%APPDATA%\LinkRouter\` removed
- [ ] All registry keys cleaned up
- [ ] Start Menu shortcuts removed
- [ ] Desktop shortcut removed (if existed)
- [ ] LinkRouter no longer in Windows Default Apps
- [ ] No leftover startup entry in Task Manager

## Scenario 5: Reinstall after uninstall

- [ ] Uninstall v2.0.0 completely
- [ ] Run `cleanup-linkrouter.ps1`
- [ ] Install v2.0.0 fresh
- [ ] Behaves like Scenario 1 (welcome overlay, fresh state)

## Scenario 6: Functional Validation

- [ ] Set as default browser → status shows green "Active"
- [ ] Change default to Chrome → status shows orange "Not Default"
- [ ] URL routing works when set as default
- [ ] Clipboard monitoring works
- [ ] System tray icon appears with `--startup` flag
- [ ] Import/Export preserves data correctly
- [ ] Dark/Light/System theme switching works

---

## Cleanup Script

Reset system to fresh state between tests:

```powershell
# Full cleanup
powershell -ExecutionPolicy Bypass -File cleanup-linkrouter.ps1

# Keep rules/settings, only remove registry + install
powershell -ExecutionPolicy Bypass -File cleanup-linkrouter.ps1 -KeepAppData
```
