using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PowerDroid.Services
{
    /// <summary>
    /// Service for extracting and caching browser icons from executable files.
    /// Uses Win32 SHGetFileInfo to avoid System.Drawing dependency.
    /// </summary>
    public static class BrowserIconService
    {
        private static readonly Dictionary<string, ImageSource> _iconCache = new Dictionary<string, ImageSource>();
        private static readonly object _cacheLock = new object();

        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SHGetFileInfo(string pszPath, uint dwFileAttributes,
            ref SHFILEINFO psfi, uint cbSizeFileInfo, uint uFlags);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool DestroyIcon(IntPtr hIcon);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct SHFILEINFO
        {
            public IntPtr hIcon;
            public int iIcon;
            public uint dwAttributes;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string szDisplayName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
            public string szTypeName;
        }

        private const uint SHGFI_ICON = 0x000000100;
        private const uint SHGFI_LARGEICON = 0x000000000;

        /// <summary>
        /// Gets the icon for a browser executable, using cache when available.
        /// </summary>
        public static ImageSource? GetBrowserIcon(string? executablePath)
        {
            if (string.IsNullOrEmpty(executablePath))
                return null;

            lock (_cacheLock)
            {
                if (_iconCache.TryGetValue(executablePath, out var cached))
                    return cached;
            }

            try
            {
                if (!File.Exists(executablePath))
                    return null;

                var shinfo = new SHFILEINFO();
                var result = SHGetFileInfo(executablePath, 0, ref shinfo, (uint)Marshal.SizeOf(shinfo),
                    SHGFI_ICON | SHGFI_LARGEICON);

                if (result == IntPtr.Zero || shinfo.hIcon == IntPtr.Zero)
                    return null;

                try
                {
                    var bitmapSource = Imaging.CreateBitmapSourceFromHIcon(
                        shinfo.hIcon,
                        Int32Rect.Empty,
                        BitmapSizeOptions.FromEmptyOptions());

                    bitmapSource.Freeze();

                    lock (_cacheLock)
                    {
                        _iconCache[executablePath] = bitmapSource;
                    }

                    return bitmapSource;
                }
                finally
                {
                    DestroyIcon(shinfo.hIcon);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Clears the icon cache (useful if browser installations change)
        /// </summary>
        public static void ClearCache()
        {
            lock (_cacheLock)
            {
                _iconCache.Clear();
            }
        }
    }
}
