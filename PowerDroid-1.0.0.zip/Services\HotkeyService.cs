using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace PowerDroid.Services
{
    /// <summary>
    /// Singleton service for global keyboard shortcuts.
    /// Uses Win32 RegisterHotKey for system-wide hotkey registration.
    /// Hotkey combinations are loaded from AppSettings.Hotkeys.
    /// </summary>
    public class HotkeyService : IDisposable
    {
        #region Win32 Interop

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private const int WM_HOTKEY = 0x0312;

        // Hotkey IDs
        private const int HOTKEY_RULES = 1;
        private const int HOTKEY_POWERCLIP = 2;

        // Modifier constants (for UI display)
        public const uint MOD_ALT = 0x0001;
        public const uint MOD_CTRL = 0x0002;
        public const uint MOD_SHIFT = 0x0004;

        #endregion

        #region Singleton

        private static HotkeyService? _instance;
        private static readonly object _lock = new object();

        public static HotkeyService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new HotkeyService();
                    }
                }
                return _instance;
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// Fired when a registered hotkey is pressed. Parameter is the page name ("Rules" or "PowerClip").
        /// </summary>
        public event EventHandler<string>? HotkeyPressed;

        #endregion

        #region Fields

        private HwndSource? _hwndSource;
        private bool _isRunning;
        private bool _disposed;

        #endregion

        #region Constructor

        private HotkeyService()
        {
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Registers global hotkeys from settings and starts listening.
        /// </summary>
        public void Start()
        {
            if (_isRunning) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                var parameters = new HwndSourceParameters("HotkeyListenerWindow")
                {
                    Width = 0,
                    Height = 0,
                    PositionX = 0,
                    PositionY = 0,
                    WindowStyle = 0x800000 // WS_SYSMENU
                };

                _hwndSource = new HwndSource(parameters);
                _hwndSource.AddHook(WndProc);

                RegisterFromSettings();
                _isRunning = true;
            });
        }

        /// <summary>
        /// Unregisters hotkeys and stops listening.
        /// </summary>
        public void Stop()
        {
            if (!_isRunning) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                if (_hwndSource != null)
                {
                    UnregisterHotKey(_hwndSource.Handle, HOTKEY_RULES);
                    UnregisterHotKey(_hwndSource.Handle, HOTKEY_POWERCLIP);
                    _hwndSource.RemoveHook(WndProc);
                    _hwndSource.Dispose();
                    _hwndSource = null;
                }

                _isRunning = false;
                Logger.Log("HotkeyService: Global hotkeys unregistered");
            });
        }

        /// <summary>
        /// Re-reads settings and re-registers hotkeys. Call after user changes shortcuts.
        /// </summary>
        public void Reload()
        {
            if (!_isRunning || _hwndSource == null) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                UnregisterHotKey(_hwndSource.Handle, HOTKEY_RULES);
                UnregisterHotKey(_hwndSource.Handle, HOTKEY_POWERCLIP);
                RegisterFromSettings();
            });
        }

        /// <summary>
        /// Formats a modifier+key combination as a display string (e.g., "Ctrl+Shift+R").
        /// </summary>
        public static string FormatHotkey(uint modifiers, uint vk)
        {
            var parts = new System.Collections.Generic.List<string>();
            if ((modifiers & MOD_CTRL) != 0) parts.Add("Ctrl");
            if ((modifiers & MOD_ALT) != 0) parts.Add("Alt");
            if ((modifiers & MOD_SHIFT) != 0) parts.Add("Shift");
            parts.Add(KeyName(vk));
            return string.Join("+", parts);
        }

        #endregion

        #region Private Methods

        private void RegisterFromSettings()
        {
            var settings = SettingsManager.LoadSettings().Hotkeys;

            if (settings.RulesKey != 0 && _hwndSource != null)
            {
                if (!RegisterHotKey(_hwndSource.Handle, HOTKEY_RULES, settings.RulesModifiers, settings.RulesKey))
                    Logger.Log($"HotkeyService: Failed to register Rules hotkey {FormatHotkey(settings.RulesModifiers, settings.RulesKey)} (error {Marshal.GetLastWin32Error()})");
            }

            if (BrandConfig.PowerClipEnabled && settings.ClipKey != 0 && _hwndSource != null)
            {
                if (!RegisterHotKey(_hwndSource.Handle, HOTKEY_POWERCLIP, settings.ClipModifiers, settings.ClipKey))
                    Logger.Log($"HotkeyService: Failed to register Clip hotkey {FormatHotkey(settings.ClipModifiers, settings.ClipKey)} (error {Marshal.GetLastWin32Error()})");
            }

            Logger.Log($"HotkeyService: Registered — Rules: {FormatHotkey(settings.RulesModifiers, settings.RulesKey)}, Clip: {FormatHotkey(settings.ClipModifiers, settings.ClipKey)}");
        }

        private static string KeyName(uint vk)
        {
            if (vk >= 0x30 && vk <= 0x39) return ((char)vk).ToString(); // 0-9
            if (vk >= 0x41 && vk <= 0x5A) return ((char)vk).ToString(); // A-Z
            if (vk >= 0x70 && vk <= 0x7B) return $"F{vk - 0x6F}";      // F1-F12
            return $"0x{vk:X2}";
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_HOTKEY)
            {
                handled = true;
                int id = wParam.ToInt32();

                string? pageName = id switch
                {
                    HOTKEY_RULES => "Rules",
                    HOTKEY_POWERCLIP => "PowerClip",
                    _ => null
                };

                if (pageName != null)
                {
                    Logger.Log($"HotkeyService: Hotkey pressed for {pageName}");
                    HotkeyPressed?.Invoke(this, pageName);
                }
            }

            return IntPtr.Zero;
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            if (_disposed) return;

            Stop();
            _disposed = true;
        }

        #endregion
    }
}
