using System;
using System.IO;

namespace PowerDroid.Services
{
    /// <summary>
    /// One-time migration service that copies user data from the legacy
    /// LinkRouter folder to the new PowerDroid folder.
    /// </summary>
    public static class DataMigrationService
    {
        /// <summary>
        /// Migrates data from %APPDATA%\LinkRouter to %APPDATA%\PowerDroid if needed.
        /// Call this at startup before any settings are loaded.
        /// </summary>
        public static void MigrateIfNeeded()
        {
            var legacyFolder = BrandConfig.LegacyAppDataFolder;
            var newFolder = BrandConfig.AppDataFolder;

            // Only migrate if legacy folder exists and new folder does not
            if (!Directory.Exists(legacyFolder) || Directory.Exists(newFolder))
                return;

            try
            {
                Logger.Log($"DataMigration: Migrating data from '{legacyFolder}' to '{newFolder}'");

                // Create the new folder
                Directory.CreateDirectory(newFolder);

                // Copy all files
                foreach (var file in Directory.GetFiles(legacyFolder))
                {
                    var fileName = Path.GetFileName(file);
                    var destFile = Path.Combine(newFolder, fileName);
                    File.Copy(file, destFile, overwrite: false);
                    Logger.Log($"DataMigration: Copied '{fileName}'");
                }

                // Rename old folder as safety backup (don't delete)
                var migratedFolder = legacyFolder + ".migrated";
                if (!Directory.Exists(migratedFolder))
                {
                    Directory.Move(legacyFolder, migratedFolder);
                    Logger.Log($"DataMigration: Renamed legacy folder to '{migratedFolder}'");
                }

                Logger.Log("DataMigration: Migration completed successfully");
            }
            catch (Exception ex)
            {
                Logger.Log($"DataMigration: Error during migration: {ex.Message}");
                // Non-fatal — app can still run, settings will be recreated
            }
        }
    }
}
