# Development Guide

This document covers how to set up, build, debug, and work on the PowerDroid codebase.

## Overview

PowerDroid is a single-project .NET 8 WPF desktop application that registers as a Windows browser and routes URLs to the correct browser and profile based on user-defined rules.

- **Solution:** `PowerDroid.sln`
- **Project:** `PowerDroid.csproj`
- **Target Framework:** `net8.0-windows10.0.19041.0`
- **Output:** Single-file, framework-dependent executable
- **Installer:** Inno Setup 6 (`Installer/PowerDroidSetup.iss`)

## Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) (8.0.x)
- [Visual Studio 2022](https://visualstudio.microsoft.com/) (17.8+) with the **.NET desktop development** workload, or [VS Code](https://code.visualstudio.com/) with the [C# Dev Kit](https://marketplace.visualstudio.com/items?itemName=ms-dotnettools.csdevkit) extension
- Windows 10 (1607+) or Windows 11
- (Optional) [Inno Setup 6](https://jrsoftware.org/isdl.php) for building the installer
- (Optional) Git

## Quick Start

```bash
git clone https://github.com/admindroid-community/PowerDroid.git
cd PowerDroid
dotnet build PowerDroid.csproj
dotnet run --project PowerDroid.csproj
```

Or open `PowerDroid.sln` in Visual Studio and press **F5**.

## Project Structure

```
PowerDroid/
├── App.xaml / App.xaml.cs          # Application entry point
├── MainWindow.xaml / .cs           # Main navigation shell
├── BrandConfig.cs                  # Centralized branding (names, IDs, paths)
├── AppConfig.cs                    # Runtime configuration
├── SettingsManager.cs              # User settings persistence
├── RegistryHelper.cs               # Windows browser registration
│
├── Models/                         # Data classes
│   ├── BrowserProfile.cs           # Browser/profile metadata
│   ├── UrlRule.cs                  # Individual URL rule
│   ├── UrlGroup.cs                 # URL group with multiple patterns
│   └── ...
│
├── Services/                       # Business logic (19 services)
│   ├── BrowserService.cs           # Browser detection and launching
│   ├── JsonStorageService.cs       # Atomic JSON file persistence
│   ├── ClipboardMonitorService.cs  # Clipboard URL monitoring
│   ├── UpdateCheckService.cs       # GitHub Releases update check
│   ├── DataMigrationService.cs     # LinkRouter → PowerDroid migration
│   ├── SingleInstanceManager.cs    # Mutex + named pipe single instance
│   ├── ValidationService.cs        # URL pattern validation
│   └── ...
│
├── Pages/                          # WPF pages
│   ├── HomePage.xaml               # Dashboard
│   ├── RulesPage.xaml              # URL rules management
│   ├── BrowserSettingsPage.xaml    # Browser settings
│   ├── SettingsPage.xaml           # Application settings
│   ├── PowerClipPage.xaml          # Clipboard manager (v2.0)
│   └── DocsPage.xaml               # Documentation
│
├── Controls/                       # Reusable custom controls
├── Converters/                     # XAML value converters
├── Dialogs/                        # Modal dialogs (AddRule, EditGroup, etc.)
├── Themes/                         # WPF resource dictionaries
│   ├── Generic.xaml                # Base styles
│   ├── Windows11Theme.xaml         # Modern theme
│   ├── DarkColors.xaml             # Dark theme colors
│   └── LightColors.xaml            # Light theme colors
│
├── Assets/                         # Icons and images
├── Resources/                      # Embedded resources (builtin-templates.json)
├── Installer/                      # Inno Setup script
│   └── PowerDroidSetup.iss
└── docs/                           # Screenshots for README
```

## Building

**Debug build:**

```bash
dotnet build PowerDroid.csproj
```

**Release build (single-file executable):**

```bash
dotnet publish PowerDroid.csproj -c Release -r win-x64 --self-contained false
```

Output: `bin\Release\net8.0-windows10.0.19041.0\win-x64\publish\PowerDroid.exe`

**Installer build** (requires Inno Setup 6):

```bash
"C:\Program Files (x86)\Inno Setup 6\ISCC.exe" Installer\PowerDroidSetup.iss
```

## Debugging

- **Visual Studio:** Set `PowerDroid.csproj` as startup project, press F5.
- **VS Code:** Use C# Dev Kit launch configuration.
- **Logging:** `Logger.Log()` writes to `log.txt` in the app directory. Check `%APPDATA%\PowerDroid\` for runtime data files.
- **Testing URL routing:** Set PowerDroid as your default browser in Windows Settings, then click links from other apps (Teams, Outlook, etc.).
- **Command-line testing:** `PowerDroid.exe "https://github.com"` to test routing for a specific URL.

## Architecture

### Branding

All product names, identifiers, and paths are centralized in `BrandConfig.cs`. Never hardcode these values elsewhere.

### Stable Identifiers

These values must **never change** after release:

| Identifier | Value | Purpose |
|-----------|-------|---------|
| `RegistryAppId` | `PowerDroidSmartBrowse` | Windows browser registration key |
| Installer `AppId` | `{B2F3A1C4-A9CA-4611-8635-E7756F3CFE0D}` | Windows Apps & Features identity |

### Profile Matching

Always match browser profiles by `ProfilePath` (stable), never by display `Name` (can change):

```csharp
// Correct
var profile = profiles.FirstOrDefault(p => p.Path == profilePath);

// Wrong — name can change
var profile = profiles.FirstOrDefault(p => p.Name == profileName);
```

### Data Storage

All user data is stored as JSON files under `%APPDATA%\PowerDroid\`:

| File | Contents |
|------|----------|
| `settings.json` | Default browser, preferences |
| `rules.json` | Individual URL rules with ProfilePath |
| `urlgroups.json` | URL groups |
| `profilegroups.json` | Profile groups |

`JsonStorageService` handles atomic read/write operations. Legacy data from `%APPDATA%\LinkRouter\` is auto-migrated on first launch via `DataMigrationService`.

### Registry Keys

All registry writes are under `HKCU` (current user only). Key paths:

```
HKCU\Software\Clients\StartMenuInternet\PowerDroidSmartBrowse
HKCU\Software\PowerDroidSmartBrowse\Capabilities
HKCU\Software\RegisteredApplications  (value: PowerDroidSmartBrowse)
HKCU\Software\Classes\PowerDroidSmartBrowse
```

See `RegistryHelper.cs` for the full registration logic.

### Theme System

WPF resource dictionaries in `Themes/` provide Light, Dark, and System theme modes. `ThemeManager` handles runtime switching without restart.

### Single Instance

`SingleInstanceManager` uses a mutex (`PowerDroid_{user}_SingleInstance_Mutex`) and named pipe to ensure only one instance runs. Subsequent launches forward URLs to the running instance.

## Common Tasks

| Task | Where to Look |
|------|---------------|
| Add a new URL rule feature | `Models/UrlRule.cs`, `ValidationService`, `RulesPage.xaml` |
| Add a new page | Create XAML + codebehind in `Pages/`, register navigation in `MainWindow` |
| Change branding | Edit `BrandConfig.cs` only |
| Add a theme color | Update `DarkColors.xaml` and `LightColors.xaml` |
| Add a new service | Create in `Services/`, inject where needed |

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Build errors about WinRT APIs | Ensure TFM is `net8.0-windows10.0.19041.0` |
| App not in Default Apps | Run `PowerDroid.exe --register`, sign out/in |
| Data not persisting | Verify `%APPDATA%\PowerDroid\` exists and is writable |
| Multiple instances running | Check for stale `PowerDroid.exe` in Task Manager |
| Theme not applying | Ensure `ThemeManager` is called before window loads |

## References

- [TESTING.md](TESTING.md) — Testing checklist
- [TRANSPARENCY.md](TRANSPARENCY.md) — Privacy and data access
- [CHANGELOG.md](CHANGELOG.md) — Version history
