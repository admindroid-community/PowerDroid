using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using PowerDroid.Models;

namespace PowerDroid.Services
{
    /// <summary>
    /// Detects the foreground application at the time of a clipboard event.
    /// Used to tag clipboard entries with their source app and browser profile.
    /// </summary>
    public static class SourceAppDetector
    {
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string? lpszClass, string? lpszWindow);

        /// <summary>
        /// Gets information about the currently focused application.
        /// Returns null if detection fails (e.g., process exited between calls).
        /// </summary>
        public static SourceAppInfo? GetCurrentSourceApp()
        {
            try
            {
                var hwnd = GetForegroundWindow();
                if (hwnd == IntPtr.Zero)
                    return null;

                GetWindowThreadProcessId(hwnd, out uint pid);
                if (pid == 0)
                    return null;

                using var process = Process.GetProcessById((int)pid);
                var processName = process.ProcessName;
                var windowTitle = process.MainWindowTitle ?? string.Empty;

                // Resolve UWP apps behind ApplicationFrameHost
                if (processName.Equals("ApplicationFrameHost", StringComparison.OrdinalIgnoreCase))
                {
                    var resolved = ResolveUwpApp(hwnd);
                    if (resolved != null)
                        return resolved;
                }

                // Get display name from executable's FileDescription (same as Task Manager)
                var displayName = processName;
                try
                {
                    var mainModule = process.MainModule;
                    if (mainModule != null)
                    {
                        var desc = FileVersionInfo.GetVersionInfo(mainModule.FileName).FileDescription;
                        if (!string.IsNullOrWhiteSpace(desc))
                            displayName = desc;
                    }
                }
                catch { }

                var browserProfile = ParseBrowserProfile(processName, windowTitle);

                return new SourceAppInfo
                {
                    ProcessName = processName,
                    DisplayName = displayName,
                    WindowTitle = windowTitle,
                    BrowserProfileName = browserProfile
                };
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Resolves the actual UWP app behind an ApplicationFrameHost window.
        /// UWP apps are hosted inside ApplicationFrameHost.exe — the real app runs as a
        /// child CoreWindow. We find it via FindWindowEx and get its process.
        /// </summary>
        private static SourceAppInfo? ResolveUwpApp(IntPtr frameHwnd)
        {
            try
            {
                // Look for the CoreWindow child inside the ApplicationFrameHost window
                var coreWindow = FindWindowEx(frameHwnd, IntPtr.Zero, "Windows.UI.Core.CoreWindow", null);
                if (coreWindow == IntPtr.Zero)
                    return null;

                GetWindowThreadProcessId(coreWindow, out uint realPid);
                if (realPid == 0)
                    return null;

                using var realProcess = Process.GetProcessById((int)realPid);
                var processName = realProcess.ProcessName;
                var windowTitle = realProcess.MainWindowTitle ?? string.Empty;

                // If MainWindowTitle is empty, use the frame window's title
                if (string.IsNullOrEmpty(windowTitle))
                {
                    try
                    {
                        foreach (var p in Process.GetProcesses())
                        {
                            using (p)
                            {
                                try
                                {
                                    if (p.MainWindowHandle == frameHwnd)
                                    {
                                        windowTitle = p.MainWindowTitle ?? string.Empty;
                                        break;
                                    }
                                }
                                catch { }
                            }
                        }
                    }
                    catch { }
                }

                var displayName = processName;
                try
                {
                    var mainModule = realProcess.MainModule;
                    if (mainModule != null)
                    {
                        var desc = FileVersionInfo.GetVersionInfo(mainModule.FileName).FileDescription;
                        if (!string.IsNullOrWhiteSpace(desc))
                            displayName = desc;
                    }
                }
                catch { }

                return new SourceAppInfo
                {
                    ProcessName = processName,
                    DisplayName = displayName,
                    WindowTitle = windowTitle,
                    BrowserProfileName = null
                };
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Returns a deduplicated, sorted list of source apps for UI dropdowns.
        /// Combines currently running processes (with visible windows) and clipboard history.
        /// </summary>
        public static List<SourceAppInfo> GetAvailableSourceApps()
        {
            var apps = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            // Source 1: Running processes with visible windows
            try
            {
                var ownPid = Environment.ProcessId;
                foreach (var proc in Process.GetProcesses())
                {
                    try
                    {
                        if (proc.Id == ownPid) continue;
                        if (proc.MainWindowHandle == IntPtr.Zero) continue;
                        var name = proc.ProcessName;
                        if (!apps.ContainsKey(name))
                        {
                            // Get display name from executable's FileDescription (same as Task Manager)
                            string friendly = name;
                            try
                            {
                                var mainModule = proc.MainModule;
                                if (mainModule != null)
                                {
                                    var desc = FileVersionInfo.GetVersionInfo(mainModule.FileName).FileDescription;
                                    if (!string.IsNullOrWhiteSpace(desc))
                                        friendly = desc;
                                }
                            }
                            catch { }
                            apps[name] = friendly;
                        }
                    }
                    catch { }
                    finally { proc.Dispose(); }
                }
            }
            catch { }

            // Source 2: Clipboard history (apps not currently running)
            try
            {
                foreach (var entry in PowerClipService.Instance.GetEntries())
                {
                    if (!string.IsNullOrEmpty(entry.SourceAppId) && !apps.ContainsKey(entry.SourceAppId))
                        apps[entry.SourceAppId] = entry.SourceApp ?? GetFriendlyAppName(entry.SourceAppId);
                }
            }
            catch { }

            return apps
                .Select(kv => new SourceAppInfo { ProcessName = kv.Key, DisplayName = kv.Value })
                .OrderBy(a => a.DisplayName, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        /// <summary>
        /// Maps browser process names to their display names for profile matching.
        /// Returns the process name as-is if not a known browser.
        /// </summary>
        public static string GetFriendlyAppName(string processName)
        {
            return processName.ToLowerInvariant() switch
            {
                "chrome" => "Google Chrome",
                "msedge" => "Microsoft Edge",
                "firefox" => "Firefox",
                "brave" => "Brave",
                "opera" => "Opera",
                "vivaldi" => "Vivaldi",
                "arc" => "Arc",
                _ => processName
            };
        }

        /// <summary>
        /// Attempts to parse the browser profile name from the window title.
        /// Chromium browsers show profile in title when multiple profiles exist:
        ///   "Page Title - Profile Name - Google Chrome"
        /// Single profile just shows: "Page Title - Google Chrome"
        /// </summary>
        private static string? ParseBrowserProfile(string processName, string windowTitle)
        {
            if (string.IsNullOrEmpty(windowTitle))
                return null;

            // Map process names to their known title suffixes
            var suffix = processName.ToLowerInvariant() switch
            {
                "chrome" => " - Google Chrome",
                "msedge" => " - Microsoft Edge",
                "brave" => " - Brave",
                "opera" => " - Opera",
                "vivaldi" => " - Vivaldi",
                _ => null
            };

            if (suffix == null)
                return null;

            // Strip the browser suffix from end of title
            var idx = windowTitle.LastIndexOf(suffix, StringComparison.OrdinalIgnoreCase);
            if (idx < 0)
                return null;

            var titleWithoutBrowser = windowTitle.Substring(0, idx);

            // Now check if there's a profile segment: "Page Title - Profile Name"
            // The profile name is the last " - " delimited segment
            var lastDash = titleWithoutBrowser.LastIndexOf(" - ", StringComparison.Ordinal);
            if (lastDash < 0)
                return null; // Single profile — no profile segment in title

            var candidate = titleWithoutBrowser.Substring(lastDash + 3).Trim();

            // Validate: profile names are typically short and don't look like page titles
            // Cross-reference with known profiles from BrowserDetector
            var browsers = BrowserDetector.GetInstalledBrowsers();
            foreach (var browser in browsers)
            {
                if (!browser.Name.Equals(GetFriendlyAppName(processName), StringComparison.OrdinalIgnoreCase))
                    continue;

                var profiles = BrowserDetector.GetBrowserProfiles(browser);
                foreach (var profile in profiles)
                {
                    if (profile.Name.Equals(candidate, StringComparison.OrdinalIgnoreCase))
                        return profile.Name;
                }
            }

            // No match in known profiles — could be a page title segment, not a profile
            return null;
        }
    }

    /// <summary>
    /// Information about the source application of a clipboard event.
    /// </summary>
    public class SourceAppInfo
    {
        /// <summary>Raw process name (e.g., "chrome", "msedge", "Code").</summary>
        public string ProcessName { get; set; } = string.Empty;

        /// <summary>User-friendly name (e.g., "Google Chrome", "VS Code").</summary>
        public string DisplayName { get; set; } = string.Empty;

        /// <summary>Window title at time of capture.</summary>
        public string WindowTitle { get; set; } = string.Empty;

        /// <summary>Browser profile name if detected (e.g., "Work", "Personal"), null otherwise.</summary>
        public string? BrowserProfileName { get; set; }

        /// <summary>
        /// Formatted display string: "Google Chrome · Work" or "VS Code".
        /// </summary>
        public string FormattedDisplay =>
            string.IsNullOrEmpty(BrowserProfileName)
                ? DisplayName
                : $"{DisplayName} · {BrowserProfileName}";
    }
}
