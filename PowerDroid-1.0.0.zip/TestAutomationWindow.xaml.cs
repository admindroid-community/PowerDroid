using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid
{
    /// <summary>
    /// Test automation window for running automated tests.
    /// Thin UI wrapper around TestRunnerService.
    /// </summary>
    public partial class TestAutomationWindow : Window
    {
        private ObservableCollection<TestResult> _testResults;
        private List<TestDefinition> _allTests;
        private bool _isRunning = false;

        public TestAutomationWindow()
        {
            InitializeComponent();
            SourceInitialized += (s, e) => ThemeManager.ApplyTitleBarTheme(this);
            _testResults = new ObservableCollection<TestResult>();
            _allTests = TestRunnerService.GetAllTests();
            TestResultsControl.ItemsSource = _testResults;
            InitializeTests(null); // Show all tests initially
            UpdateSummary();
        }

        /// <summary>
        /// Initializes the test list, optionally filtering by category
        /// </summary>
        private void InitializeTests(string? category)
        {
            _testResults.Clear();
            var tests = category == null
                ? _allTests
                : _allTests.Where(t => t.Category.Equals(category, StringComparison.OrdinalIgnoreCase)).ToList();

            foreach (var test in tests)
            {
                _testResults.Add(new TestResult
                {
                    Name = test.Name,
                    Category = test.Category,
                    Status = TestStatus.Pending
                });
            }
        }

        private async void RunTests_Click(object sender, RoutedEventArgs e)
        {
            if (_isRunning) return;

            // Determine which category to run based on selected tab
            string? selectedCategory = GetSelectedCategory();

            _isRunning = true;
            RunTestsButton.Content = "Running...";
            RunTestsButton.IsEnabled = false;
            InitializeTests(selectedCategory);

            var totalStopwatch = Stopwatch.StartNew();

            var testsToRun = selectedCategory == null
                ? _allTests
                : _allTests.Where(t => t.Category.Equals(selectedCategory, StringComparison.OrdinalIgnoreCase)).ToList();

            try
            {
                for (int i = 0; i < testsToRun.Count; i++)
                {
                    await RunTest(i, testsToRun[i].Action);
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"Test automation error: {ex.Message}");
            }

            totalStopwatch.Stop();
            TotalTime.Text = $"Total: {totalStopwatch.ElapsedMilliseconds}ms";

            _isRunning = false;
            RunTestsButton.Content = "Run Tests";
            RunTestsButton.IsEnabled = true;
            UpdateSummary();
        }

        private string? GetSelectedCategory()
        {
            if (CategoryTabs == null) return null;
            var selectedTab = CategoryTabs.SelectedItem as TabItem;
            if (selectedTab == null) return null;
            var tag = selectedTab.Tag as string;
            return tag == "All" ? null : tag;
        }

        private void CategoryTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isRunning) return;

            string? category = GetSelectedCategory();
            InitializeTests(category);
            UpdateSummary();
            TotalTime.Text = string.Empty;
        }

        private async Task RunTest(int index, Func<string> testAction)
        {
            if (index < 0 || index >= _testResults.Count) return;

            var result = _testResults[index];
            result.Status = TestStatus.Running;
            result.Message = "Running...";
            RefreshList();

            var stopwatch = Stopwatch.StartNew();

            await Task.Run(() =>
            {
                try
                {
                    string message = testAction();
                    stopwatch.Stop();

                    Dispatcher.Invoke(() =>
                    {
                        result.Status = TestStatus.Passed;
                        result.Message = message;
                        result.Duration = stopwatch.ElapsedMilliseconds;
                        RefreshList();
                    });
                }
                catch (Exception ex)
                {
                    stopwatch.Stop();

                    Dispatcher.Invoke(() =>
                    {
                        result.Status = TestStatus.Failed;
                        result.Message = ex.Message;
                        result.Duration = stopwatch.ElapsedMilliseconds;
                        RefreshList();
                    });
                }
            });

            // Small delay for UI visibility
            await Task.Delay(100);
        }

        private void RefreshList()
        {
            TestResultsControl.ItemsSource = null;
            TestResultsControl.ItemsSource = _testResults;
            UpdateSummary();
        }

        private void UpdateSummary()
        {
            int passed = _testResults.Count(t => t.Status == TestStatus.Passed);
            int failed = _testResults.Count(t => t.Status == TestStatus.Failed);
            int total = _testResults.Count;

            SummaryText.Text = $"{passed + failed}/{total} tests completed";
            PassedCount.Text = $"Passed: {passed}";
            FailedCount.Text = $"Failed: {failed}";

            if (passed + failed == total && total > 0)
            {
                SummaryText.Foreground = failed == 0
                    ? System.Windows.Media.Brushes.Green
                    : System.Windows.Media.Brushes.Red;
            }
            else
            {
                SummaryText.Foreground = System.Windows.Media.Brushes.Black;
            }
        }

        private void SimulateUpdate_Click(object sender, RoutedEventArgs e)
        {
            var service = Services.UpdateCheckService.Instance;
            if (service.IsUpdateAvailable)
            {
                service.ClearSimulatedUpdate();
                SimulateUpdateButton.Content = "Simulate Update";

                // Refresh settings page if open
                var settingsWindow = Owner as SettingsWindow;
                settingsWindow?.HideUpdateDot();
                var settingsPage = settingsWindow?.FindName("SettingsPageControl") as Pages.SettingsPage;
                settingsPage?.RefreshUpdateStatus();
            }
            else
            {
                service.SimulateUpdate();
                SimulateUpdateButton.Content = "Clear Update";
            }
        }

        private void SeedClipData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var now = DateTime.Now;
                var seed = new List<(string Content, ClipboardEntryType Type, int DaysAgo, bool Pinned)>
                {
                    // Today
                    ("[TEST] Today — Meeting notes from standup", ClipboardEntryType.Text, 0, false),
                    ("[TEST] Today — https://github.com/pulls", ClipboardEntryType.Url, 0, false),
                    // 1 day ago
                    ("[TEST] 1d ago — Code review feedback for PR #42", ClipboardEntryType.Text, 1, false),
                    ("[TEST] 1d ago — C:\\Projects\\AdminDesk\\src\\main.cs", ClipboardEntryType.FilePath, 1, false),
                    // 2 days ago (within 3-day window)
                    ("[TEST] 2d ago — SELECT * FROM Users WHERE Active = 1", ClipboardEntryType.Text, 2, false),
                    ("[TEST] 2d ago — https://stackoverflow.com/questions/12345", ClipboardEntryType.Url, 2, false),
                    // 5 days ago (outside 3-day, inside 10-day)
                    ("[TEST] 5d ago — Bug fix: null reference in TrayIconService", ClipboardEntryType.Text, 5, false),
                    ("[TEST] 5d ago — https://learn.microsoft.com/wpf/overview", ClipboardEntryType.Url, 5, false),
                    ("[TEST] 5d ago — D:\\BrowserSelector\\Services\\PowerClipService.cs", ClipboardEntryType.FilePath, 5, false),
                    // 8 days ago
                    ("[TEST] 8d ago — Discussed migration strategy with team", ClipboardEntryType.Text, 8, false),
                    ("[TEST] 8d ago — https://jira.atlassian.com/browse/PROJ-100", ClipboardEntryType.Url, 8, false),
                    // 12 days ago (outside 10-day, inside 20-day)
                    ("[TEST] 12d ago — Updated installer version to 2.1.0", ClipboardEntryType.Text, 12, false),
                    ("[TEST] 12d ago — https://git.admindroid.com/issues/35", ClipboardEntryType.Url, 12, false),
                    // 15 days ago
                    ("[TEST] 15d ago — Refactored RegistryHelper for new branding", ClipboardEntryType.Text, 15, false),
                    ("[TEST] 15d ago — C:\\Users\\Documents\\design-spec.pdf", ClipboardEntryType.FilePath, 15, false),
                    // 18 days ago (PINNED — should survive date-based clears)
                    ("[TEST] 18d ago PINNED — Important: API key for staging env", ClipboardEntryType.Text, 18, true),
                    // 22 days ago (outside 20-day)
                    ("[TEST] 22d ago — Old deployment checklist v1", ClipboardEntryType.Text, 22, false),
                    ("[TEST] 22d ago — https://docs.google.com/spreadsheets/old-tracker", ClipboardEntryType.Url, 22, false),
                    // 25 days ago
                    ("[TEST] 25d ago — Sprint retrospective notes from May", ClipboardEntryType.Text, 25, false),
                    ("[TEST] 25d ago — D:\\Archive\\old-project\\readme.md", ClipboardEntryType.FilePath, 25, false),
                    // 30 days ago
                    ("[TEST] 30d ago — Initial PowerDroid feature brainstorm", ClipboardEntryType.Text, 30, false),
                };

                foreach (var (content, type, daysAgo, pinned) in seed)
                {
                    var entry = new ClipboardEntry
                    {
                        Id = Guid.NewGuid().ToString(),
                        Content = content,
                        Type = type,
                        Timestamp = now.AddDays(-daysAgo).AddHours(-2),
                        IsPinned = pinned
                    };
                    PowerClipService.Instance.AddEntry(entry);
                }

                Logger.Log($"Seeded {seed.Count} test clipboard entries");
                MessageBox.Show(
                    $"Added {seed.Count} test entries to clipboard history.\n\n" +
                    "Entries span from today to 30 days ago,\nincluding 1 pinned entry at 18 days.\n\n" +
                    "Go to Power Clip page and use the\nClear History dropdown to test.",
                    "Seed Complete", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                Logger.Log($"SeedClipData ERROR: {ex.Message}");
                MessageBox.Show($"Error seeding data: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void RunSingleTest_Click(object sender, RoutedEventArgs e)
        {
            if (_isRunning) return;
            if (sender is not Button button || button.Tag is not string testName) return;

            var testDef = _allTests.FirstOrDefault(t => t.Name == testName);
            if (testDef == null) return;

            var resultItem = _testResults.FirstOrDefault(r => r.Name == testName);
            if (resultItem == null) return;

            _isRunning = true;

            try
            {
                resultItem.Status = TestStatus.Running;
                resultItem.Message = "";

                await Task.Run(() =>
                {
                    var sw = Stopwatch.StartNew();
                    try
                    {
                        var msg = testDef.Action();
                        sw.Stop();
                        Dispatcher.Invoke(() =>
                        {
                            resultItem.Status = TestStatus.Passed;
                            resultItem.Message = msg;
                            resultItem.Duration = sw.ElapsedMilliseconds;
                        });
                    }
                    catch (Exception ex)
                    {
                        sw.Stop();
                        Dispatcher.Invoke(() =>
                        {
                            resultItem.Status = TestStatus.Failed;
                            resultItem.Message = ex.Message;
                            resultItem.Duration = sw.ElapsedMilliseconds;
                        });
                    }
                });
            }
            finally
            {
                _isRunning = false;
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            // Safety net: clean up any leftover test data
            TestRunnerService.CleanupAllTestData();
            base.OnClosing(e);
        }
    }

    #region Test Result Model

    public enum TestStatus
    {
        Pending,
        Running,
        Passed,
        Failed
    }

    public class TestResult : INotifyPropertyChanged
    {
        private string _name = string.Empty;
        private TestStatus _status;
        private string _message = string.Empty;
        private long _duration;
        private string _category = string.Empty;

        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(nameof(Name)); }
        }

        public string Category
        {
            get => _category;
            set { _category = value; OnPropertyChanged(nameof(Category)); }
        }

        public TestStatus Status
        {
            get => _status;
            set { _status = value; OnPropertyChanged(nameof(Status)); }
        }

        public string Message
        {
            get => _message;
            set { _message = value; OnPropertyChanged(nameof(Message)); OnPropertyChanged(nameof(HasMessage)); }
        }

        public long Duration
        {
            get => _duration;
            set { _duration = value; OnPropertyChanged(nameof(Duration)); OnPropertyChanged(nameof(HasDuration)); }
        }

        public bool HasMessage => !string.IsNullOrEmpty(Message);
        public bool HasDuration => Duration > 0;

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    #endregion
}
