using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace PowerDroid
{
    /// <summary>
    /// Toast notification window for clipboard URL detection.
    /// Shows options to Open or Don't show again for the matched rule.
    /// </summary>
    public partial class ClipboardNotificationWindow : Window
    {
        private readonly string _url;
        private readonly string _domain;
        private readonly MatchResult _matchResult;
        private readonly string? _sourceAppName;
        private readonly DispatcherTimer _autoCloseTimer;
        private const int NOTIFICATION_TIMEOUT = 8000; // 8 seconds
        private DateTime _animationStartTime;
        private double _remainingTime;

        public event EventHandler<ClipboardNotificationResult>? NotificationClosed;

        public ClipboardNotificationWindow(string url, string domain, MatchResult matchResult, string? sourceAppName = null)
        {
            InitializeComponent();

            _url = url;
            _domain = domain;
            _matchResult = matchResult;
            _sourceAppName = sourceAppName;
            _remainingTime = NOTIFICATION_TIMEOUT;

            // Apply theme colors
            ApplyThemeColors();

            // Set UI content
            UrlText.Text = domain;
            StatusText.Text = string.IsNullOrEmpty(_sourceAppName)
                ? "URL copied to clipboard"
                : $"URL copied from {_sourceAppName}";
            SetMatchInfo();

            // Setup auto-close timer
            _autoCloseTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(NOTIFICATION_TIMEOUT)
            };
            _autoCloseTimer.Tick += (s, e) => CloseWithAction(ClipboardNotificationAction.Timeout);

            Loaded += OnLoaded;
            MouseEnter += OnMouseEnter;
            MouseLeave += OnMouseLeave;
        }

        private void ApplyThemeColors()
        {
            bool isLight = !ThemeManager.IsDarkTheme;

            // Main border — Win11 notification card style
            MainBorder.Background = new SolidColorBrush(isLight
                ? Color.FromRgb(252, 252, 252)          // Light: Win11 white card
                : Color.FromArgb(230, 28, 28, 32));    // Dark: frosted dark
            MainBorder.BorderBrush = new SolidColorBrush(isLight
                ? Color.FromArgb(30, 0, 0, 0)           // Light: barely visible border
                : Color.FromArgb(50, 255, 255, 255));   // Dark: subtle white glow
            MainBorder.BorderThickness = new Thickness(1);
            MainShadow.Opacity = isLight ? 0.08 : 0.5;
            MainShadow.BlurRadius = isLight ? 20 : 16;
            MainShadow.ShadowDepth = isLight ? 2 : 2;

            // Title
            TitleText.Foreground = new SolidColorBrush(isLight ? Color.FromRgb(51, 51, 51) : Color.FromRgb(255, 255, 255));

            // Status icon and text
            var statusColor = new SolidColorBrush(isLight ? Color.FromRgb(0, 120, 212) : Color.FromRgb(100, 181, 246));
            StatusIcon.Foreground = statusColor;
            StatusText.Foreground = statusColor;

            // URL text
            UrlText.Foreground = new SolidColorBrush(isLight ? Color.FromRgb(0, 120, 212) : Color.FromRgb(100, 181, 246));

            // Info text
            var infoColor = new SolidColorBrush(isLight ? Color.FromRgb(102, 102, 102) : Color.FromRgb(180, 180, 180));
            var linkColor = new SolidColorBrush(isLight ? Color.FromRgb(0, 120, 212) : Color.FromRgb(100, 181, 246));
            MatchInfoPrefix.Foreground = infoColor;
            MatchInfoLink.Foreground = linkColor;
            MatchInfoSuffix.Foreground = infoColor;
            BrowserInfoText.Foreground = infoColor;

            // Progress bar container
            ProgressContainer.Background = new SolidColorBrush(isLight ? Color.FromArgb(40, 0, 0, 0) : Color.FromArgb(40, 255, 255, 255));

            // Close button - build template from code for theme support
            ApplyCloseButtonStyle(isLight);

            // Don't show again button (secondary)
            ApplySecondaryButtonStyle(DontShowAgainButton, isLight);

            // Open button (primary) - stays blue in both themes
            ApplyPrimaryButtonStyle(OpenButton);
        }

        private void ApplyCloseButtonStyle(bool isLight)
        {
            var template = new ControlTemplate(typeof(Button));
            var borderFactory = new FrameworkElementFactory(typeof(Border));
            borderFactory.Name = "border";
            borderFactory.SetValue(Border.BackgroundProperty, Brushes.Transparent);
            borderFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(4));
            var cp = new FrameworkElementFactory(typeof(ContentPresenter));
            cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            cp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            borderFactory.AppendChild(cp);
            template.VisualTree = borderFactory;

            var hover = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
            hover.Setters.Add(new Setter(Border.BackgroundProperty,
                new SolidColorBrush(isLight ? Color.FromArgb(26, 0, 0, 0) : Color.FromArgb(60, 255, 255, 255)), "border"));
            template.Triggers.Add(hover);

            var pressed = new Trigger { Property = Button.IsPressedProperty, Value = true };
            pressed.Setters.Add(new Setter(Border.BackgroundProperty,
                new SolidColorBrush(isLight ? Color.FromArgb(50, 0, 0, 0) : Color.FromArgb(100, 255, 255, 255)), "border"));
            template.Triggers.Add(pressed);

            CloseButton.Template = template;
            CloseButton.Foreground = new SolidColorBrush(isLight ? Color.FromRgb(102, 102, 102) : Color.FromRgb(160, 160, 160));
        }

        private void ApplySecondaryButtonStyle(Button button, bool isLight)
        {
            var template = new ControlTemplate(typeof(Button));
            var borderFactory = new FrameworkElementFactory(typeof(Border));
            borderFactory.Name = "border";
            borderFactory.SetValue(Border.BackgroundProperty,
                new SolidColorBrush(isLight ? Color.FromArgb(15, 0, 0, 0) : Colors.Transparent));
            borderFactory.SetValue(Border.BorderBrushProperty,
                new SolidColorBrush(isLight ? Color.FromArgb(40, 0, 0, 0) : Color.FromRgb(128, 128, 128)));
            borderFactory.SetValue(Border.BorderThicknessProperty, new Thickness(1));
            borderFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(4));
            borderFactory.SetValue(Border.PaddingProperty, new Thickness(12, 6, 12, 6));
            var cp = new FrameworkElementFactory(typeof(ContentPresenter));
            cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            cp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            borderFactory.AppendChild(cp);
            template.VisualTree = borderFactory;

            var hover = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
            hover.Setters.Add(new Setter(Border.BackgroundProperty,
                new SolidColorBrush(isLight ? Color.FromArgb(30, 0, 0, 0) : Color.FromArgb(32, 255, 255, 255)), "border"));
            template.Triggers.Add(hover);

            var pressed = new Trigger { Property = Button.IsPressedProperty, Value = true };
            pressed.Setters.Add(new Setter(Border.BackgroundProperty,
                new SolidColorBrush(isLight ? Color.FromArgb(45, 0, 0, 0) : Color.FromArgb(64, 255, 255, 255)), "border"));
            template.Triggers.Add(pressed);

            button.Template = template;
            button.Foreground = new SolidColorBrush(isLight ? Color.FromRgb(51, 51, 51) : Color.FromRgb(180, 180, 180));
        }

        private void ApplyPrimaryButtonStyle(Button button)
        {
            var template = new ControlTemplate(typeof(Button));
            var borderFactory = new FrameworkElementFactory(typeof(Border));
            borderFactory.Name = "border";
            borderFactory.SetValue(Border.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0, 120, 212)));
            borderFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(4));
            borderFactory.SetValue(Border.PaddingProperty, new Thickness(16, 6, 16, 6));
            var cp = new FrameworkElementFactory(typeof(ContentPresenter));
            cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            cp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            borderFactory.AppendChild(cp);
            template.VisualTree = borderFactory;

            var hover = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
            hover.Setters.Add(new Setter(Border.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0, 103, 184)), "border"));
            template.Triggers.Add(hover);

            var pressed = new Trigger { Property = Button.IsPressedProperty, Value = true };
            pressed.Setters.Add(new Setter(Border.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0, 90, 158)), "border"));
            template.Triggers.Add(pressed);

            button.Template = template;
            button.Foreground = Brushes.White;
        }

        private void MatchInfoLink_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            try
            {
                if (_matchResult.Type == MatchType.IndividualRule && _matchResult.Rule != null)
                {
                    var dialog = new AddRuleWindow(_matchResult.Rule);
                    dialog.ShowDialog();
                }
                else if ((_matchResult.Type == MatchType.UrlGroup || _matchResult.Type == MatchType.GroupOverride) && _matchResult.Group != null)
                {
                    var dialog = new EditUrlGroupWindow(_matchResult.Group);
                    dialog.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"ClipboardNotification: Error opening rule editor: {ex.Message}");
            }
        }

        private void SetMatchInfo()
        {
            if (_matchResult.Type == MatchType.NoMatch)
            {
                MatchInfoPrefix.Text = "";
                MatchInfoLink.Text = "";
                MatchInfoSuffix.Text = "No matching rule found";
                BrowserInfoText.Text = "Will open in default browser";
            }
            else
            {
                string matchSource = _matchResult.Type == MatchType.IndividualRule ? "rule" : "group";
                var ruleName = _matchResult.GetRuleName();
                MatchInfoPrefix.Text = "Matches: \"";
                MatchInfoLink.Text = ruleName;
                MatchInfoSuffix.Text = $"\" {matchSource}";
                if (ruleName.Length > 40)
                    MatchInfoText.ToolTip = ruleName;

                // Check for multi-profile: individual rules or groups with multiple profiles/picker behavior
                bool isMultiProfile = (_matchResult.Type == MatchType.IndividualRule && _matchResult.Rule?.Profiles?.Count > 1)
                    || (_matchResult.Type == MatchType.UrlGroup && _matchResult.Group != null
                        && (_matchResult.Group.HasMultipleProfiles || _matchResult.Group.Behavior == UrlGroupBehavior.ShowProfilePicker));

                if (isMultiProfile)
                {
                    var count = _matchResult.Type == MatchType.IndividualRule
                        ? _matchResult.Rule!.Profiles.Count
                        : _matchResult.Group!.Profiles?.Count ?? 0;
                    BrowserInfoText.Text = $"Choose from {count} saved profiles";
                    OpenButton.Content = "Choose";
                }
                else
                {
                    var browserName = _matchResult.GetBrowserName();
                    var profileName = _matchResult.GetProfileName();

                    if (!string.IsNullOrEmpty(browserName))
                    {
                        BrowserInfoText.Text = string.IsNullOrEmpty(profileName)
                            ? $"Opens in: {browserName}"
                            : $"Opens in: {browserName} - {profileName}";
                    }
                    else
                    {
                        BrowserInfoText.Text = "Will open in default browser";
                    }
                }
            }
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            // Position at bottom-right of screen
            var workingArea = SystemParameters.WorkArea;
            Left = workingArea.Right - Width - 20;
            Top = workingArea.Bottom - ActualHeight - 20;

            AnimateIn();
            _autoCloseTimer.Start();
            _animationStartTime = DateTime.Now;
        }

        private void OnMouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            _autoCloseTimer.Stop();
            _remainingTime -= (DateTime.Now - _animationStartTime).TotalMilliseconds;
            if (_remainingTime < 0) _remainingTime = 0;
        }

        private void OnMouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (_remainingTime > 0)
            {
                _autoCloseTimer.Interval = TimeSpan.FromMilliseconds(_remainingTime);
                _autoCloseTimer.Start();
                _animationStartTime = DateTime.Now;
            }
        }

        private void AnimateIn()
        {
            var workingArea = SystemParameters.WorkArea;
            var targetLeft = workingArea.Right - Width - 20;

            // Slide in from right
            var slideIn = new DoubleAnimation
            {
                From = workingArea.Right,
                To = targetLeft,
                Duration = TimeSpan.FromMilliseconds(350),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };

            var fadeIn = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = TimeSpan.FromMilliseconds(250)
            };

            BeginAnimation(LeftProperty, slideIn);
            BeginAnimation(OpacityProperty, fadeIn);
        }

        private void CloseWithAnimation(Action? onComplete = null)
        {
            _autoCloseTimer.Stop();

            // Slide out to right
            var slideOut = new DoubleAnimation
            {
                To = SystemParameters.WorkArea.Right,
                Duration = TimeSpan.FromMilliseconds(300),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
            };

            var fadeOut = new DoubleAnimation
            {
                From = 1,
                To = 0,
                Duration = TimeSpan.FromMilliseconds(250)
            };

            fadeOut.Completed += (s, e) =>
            {
                onComplete?.Invoke();
                Close();
            };

            BeginAnimation(LeftProperty, slideOut);
            BeginAnimation(OpacityProperty, fadeOut);
        }

        private void CloseWithAction(ClipboardNotificationAction action)
        {
            CloseWithAnimation(() =>
            {
                NotificationClosed?.Invoke(this, new ClipboardNotificationResult
                {
                    Action = action,
                    Url = _url,
                    Domain = _domain,
                    MatchResult = _matchResult
                });
            });
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            CloseWithAction(ClipboardNotificationAction.Dismissed);
        }

        private void OpenButton_Click(object sender, RoutedEventArgs e)
        {
            CloseWithAction(ClipboardNotificationAction.Open);
        }

        private void DontShowAgainButton_Click(object sender, RoutedEventArgs e)
        {
            CloseWithAction(ClipboardNotificationAction.DontShowAgain);
        }
    }

    public enum ClipboardNotificationAction
    {
        Open,
        DontShowAgain,
        Dismissed,
        Timeout
    }

    public class ClipboardNotificationResult
    {
        public ClipboardNotificationAction Action { get; set; }
        public string Url { get; set; } = string.Empty;
        public string Domain { get; set; } = string.Empty;
        public MatchResult MatchResult { get; set; } = new();
    }
}
