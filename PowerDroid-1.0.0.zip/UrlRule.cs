﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows.Media;
using PowerDroid.Services;

namespace PowerDroid
{
    /// <summary>
    /// Represents a browser/profile combination within a rule
    /// </summary>
    public class RuleProfile
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string BrowserName { get; set; } = string.Empty;
        public string BrowserPath { get; set; } = string.Empty;
        public string BrowserType { get; set; } = string.Empty;
        public string ProfileName { get; set; } = string.Empty;
        public string ProfilePath { get; set; } = string.Empty;
        public string ProfileArguments { get; set; } = string.Empty;
        public int DisplayOrder { get; set; }

        /// <summary>
        /// Custom display name for this profile (scoped to this rule only).
        /// If set, this name is shown in the picker instead of the default browser/profile name.
        /// </summary>
        public string CustomDisplayName { get; set; } = string.Empty;

        /// <summary>
        /// Gets the display name - uses CustomDisplayName if set, otherwise defaults to "BrowserName - ProfileName"
        /// </summary>
        public string DisplayName => !string.IsNullOrEmpty(CustomDisplayName)
            ? CustomDisplayName
            : (string.IsNullOrEmpty(ProfileName) ? BrowserName : $"{BrowserName} - {ProfileName}");

        /// <summary>
        /// Gets the default browser/profile description (always shows "BrowserName - ProfileName")
        /// </summary>
        public string BrowserProfileDescription => string.IsNullOrEmpty(ProfileName)
            ? BrowserName
            : $"{BrowserName} - {ProfileName}";

        /// <summary>
        /// Gets the browser icon extracted from the executable path (not serialized)
        /// </summary>
        [JsonIgnore]
        public ImageSource? BrowserIcon => BrowserIconService.GetBrowserIcon(BrowserPath);
    }

    public class UrlRule
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Pattern { get; set; } = string.Empty;

        /// <summary>
        /// Whether this rule is enabled and should be used for URL matching.
        /// </summary>
        public bool IsEnabled { get; set; } = true;

        /// <summary>
        /// Whether clipboard monitoring shows notifications for URLs matching this rule.
        /// Default is true for new rules.
        /// </summary>
        public bool ClipboardNotificationsEnabled { get; set; } = true;

        /// <summary>
        /// Optional source app filter (process name, e.g., "chrome", "slack").
        /// When set, this rule only matches URLs copied from this app during clipboard monitoring.
        /// Null/empty = match from any app.
        /// </summary>
        public string? SourceAppFilter { get; set; }

        /// <summary>
        /// List of browser/profile combinations for this rule.
        /// If count is 1, auto-opens. If count > 1, shows picker.
        /// </summary>
        public List<RuleProfile> Profiles { get; set; } = new List<RuleProfile>();

        /// <summary>
        /// Returns true if this rule has multiple profiles (should show picker)
        /// </summary>
        public bool HasMultipleProfiles => Profiles?.Count > 1;

        // Legacy properties for backward compatibility during migration
        // These are used when loading old rules that don't have Profiles list
        public string BrowserName { get; set; } = string.Empty;
        public string BrowserPath { get; set; } = string.Empty;
        public string BrowserType { get; set; } = string.Empty;
        public string ProfileName { get; set; } = string.Empty;
        public string ProfilePath { get; set; } = string.Empty;
        public string ProfileArguments { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; } = DateTime.Now;

        /// <summary>
        /// When this rule was last modified. Null if never modified after creation.
        /// </summary>
        public DateTime? ModifiedDate { get; set; }

        /// <summary>
        /// Display-friendly date showing when this rule was last modified
        /// </summary>
        [System.Text.Json.Serialization.JsonIgnore]
        public string ModifiedDateDisplay => ModifiedDate.HasValue
            ? ModifiedDate.Value.ToString("MMM d, yyyy")
            : CreatedDate.ToString("MMM d, yyyy");

        /// <summary>
        /// Full date and time for tooltip display
        /// </summary>
        [System.Text.Json.Serialization.JsonIgnore]
        public string ModifiedDateTooltip => ModifiedDate.HasValue
            ? ModifiedDate.Value.ToString("MMMM d, yyyy 'at' h:mm tt")
            : CreatedDate.ToString("MMMM d, yyyy 'at' h:mm tt");

        /// <summary>
        /// Gets the first profile for display purposes
        /// </summary>
        public RuleProfile? FirstProfile => Profiles?.FirstOrDefault();

        /// <summary>
        /// Gets a display string showing profile count or single profile name
        /// </summary>
        public string ProfilesDisplay
        {
            get
            {
                if (Profiles == null || Profiles.Count == 0)
                    return ProfileName; // Legacy fallback
                if (Profiles.Count == 1)
                    return Profiles[0].ProfileName;
                return $"{Profiles.Count} profiles";
            }
        }

        /// <summary>
        /// Gets the browser name for display (from first profile or legacy)
        /// </summary>
        public string DisplayBrowserName
        {
            get
            {
                if (Profiles != null && Profiles.Count > 0)
                    return Profiles[0].BrowserName;
                return BrowserName;
            }
        }
    }

    public static class UrlRuleManager
    {
        private static readonly string ConfigPath = Path.Combine(
            AppConfig.AppDataFolder,
            "rules.json"
        );

        private static List<UrlRule> _cachedRules = null;

        public static List<UrlRule> LoadRules()
        {
            if (_cachedRules != null)
                return _cachedRules;

            _cachedRules = JsonStorageService.Load<List<UrlRule>>(ConfigPath);

            // Check if migration is needed BEFORE modifying any data
            bool needsMigration = _cachedRules.Any(r =>
                (r.Profiles == null || r.Profiles.Count == 0) &&
                !string.IsNullOrEmpty(r.BrowserName));

            // CRITICAL: Create safety backup BEFORE migration
            if (needsMigration)
            {
                JsonStorageService.CreatePreMigrationBackup(ConfigPath, "single-to-multi-profile");
            }

            // Migrate old single-profile rules to new Profiles list format
            bool needsSave = false;
            foreach (var rule in _cachedRules)
            {
                if ((rule.Profiles == null || rule.Profiles.Count == 0) &&
                    !string.IsNullOrEmpty(rule.BrowserName))
                {
                    rule.Profiles = new List<RuleProfile>
                    {
                        new RuleProfile
                        {
                            BrowserName = rule.BrowserName,
                            BrowserPath = rule.BrowserPath,
                            BrowserType = rule.BrowserType,
                            ProfileName = rule.ProfileName,
                            ProfilePath = rule.ProfilePath,
                            ProfileArguments = rule.ProfileArguments,
                            DisplayOrder = 0
                        }
                    };
                    needsSave = true;
                }
            }

            // Save migrated rules
            if (needsSave)
            {
                SaveRules(_cachedRules);
                Logger.Log("Migrated rules from single-profile to multi-profile format");
            }

            return _cachedRules;
        }

        public static void SaveRules(List<UrlRule> rules)
        {
            JsonStorageService.Save(ConfigPath, rules);
            _cachedRules = rules;
        }

        public static void AddRule(UrlRule rule)
        {
            var rules = LoadRules();
            rules.Add(rule);
            SaveRules(rules);
        }

        public static void UpdateRule(UrlRule rule)
        {
            var rules = LoadRules();
            var index = rules.FindIndex(r => r.Id == rule.Id);
            if (index >= 0)
            {
                rule.ModifiedDate = DateTime.Now; // Track modification time
                rules[index] = rule; // Replace at same position to preserve order
                SaveRules(rules);
            }
        }

        public static void DeleteRule(string ruleId)
        {
            var rules = LoadRules();
            rules.RemoveAll(r => r.Id == ruleId);
            SaveRules(rules);
        }

        public static UrlRule FindMatchingRule(string url, string? sourceProcessName = null)
        {
            var enabledRules = LoadRules().Where(r => r.IsEnabled);
            UrlRule? bestSubstring = null;
            UrlRule? bestDomain = null;

            // Strip query string/fragment to prevent false matches against query parameter values
            string urlWithoutQuery = UrlGroupManager.StripQueryAndFragment(url);

            // Extract domain once upfront
            string? domain = null;
            try { domain = new Uri(url).Host; } catch { }

            // Single pass: track both substring and domain matches
            foreach (var rule in enabledRules)
            {
                // Source app filter: skip if rule requires specific app and it doesn't match
                if (!string.IsNullOrEmpty(rule.SourceAppFilter) &&
                    !rule.SourceAppFilter.Equals(sourceProcessName, StringComparison.OrdinalIgnoreCase))
                    continue;

                // Substring match (higher priority) — match against host+path only
                if (urlWithoutQuery.IndexOf(rule.Pattern, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    if (bestSubstring == null || rule.Pattern.Length > bestSubstring.Pattern.Length)
                        bestSubstring = rule;
                }
                // Domain match (fallback)
                else if (domain != null)
                {
                    if (domain.Contains(rule.Pattern, StringComparison.OrdinalIgnoreCase))
                    {
                        if (bestDomain == null || rule.Pattern.Length > bestDomain.Pattern.Length)
                            bestDomain = rule;
                    }
                }
            }

            // Substring match takes priority over domain match
            return bestSubstring ?? bestDomain;
        }

        /// <summary>
        /// Checks if a disabled rule would have matched the given URL.
        /// Used to suppress "Create Rule" notifications when a rule exists but is disabled.
        /// </summary>
        public static bool HasDisabledMatchingRule(string url, string? sourceProcessName = null)
        {
            return FindDisabledMatchingRule(url, sourceProcessName) != null;
        }

        /// <summary>
        /// Finds and returns the most specific disabled rule that would match the given URL.
        /// Returns null if no disabled rule matches.
        /// </summary>
        public static UrlRule? FindDisabledMatchingRule(string url, string? sourceProcessName = null)
        {
            var disabledRules = LoadRules().Where(r => !r.IsEnabled).ToList();

            if (disabledRules.Count == 0)
                return null;

            // Strip query string/fragment to prevent false matches against query parameter values
            string urlWithoutQuery = UrlGroupManager.StripQueryAndFragment(url);

            var matches = new List<UrlRule>();

            // Collect all substring matches — match against host+path only
            foreach (var rule in disabledRules)
            {
                // Source app filter: skip if rule requires specific app and it doesn't match
                if (!string.IsNullOrEmpty(rule.SourceAppFilter) &&
                    !rule.SourceAppFilter.Equals(sourceProcessName, StringComparison.OrdinalIgnoreCase))
                    continue;

                if (urlWithoutQuery.IndexOf(rule.Pattern, StringComparison.OrdinalIgnoreCase) >= 0)
                    matches.Add(rule);
            }

            // If no substring matches, try domain matching
            if (matches.Count == 0)
            {
                try
                {
                    var uri = new Uri(url);
                    var domain = uri.Host.ToLowerInvariant();

                    foreach (var rule in disabledRules)
                    {
                        // Source app filter check
                        if (!string.IsNullOrEmpty(rule.SourceAppFilter) &&
                            !rule.SourceAppFilter.Equals(sourceProcessName, StringComparison.OrdinalIgnoreCase))
                            continue;

                        var pattern = rule.Pattern.ToLowerInvariant();
                        if (domain.EndsWith(pattern) || domain.Equals(pattern) || domain.Contains(pattern))
                            matches.Add(rule);
                    }
                }
                catch
                {
                    return null;
                }
            }

            // Longest pattern wins (most specific match)
            return matches.OrderByDescending(r => r.Pattern.Length).FirstOrDefault();
        }

        public static void ClearCache()
        {
            _cachedRules = null;
        }

        /// <summary>
        /// Enhanced URL matching — most specific (longest) pattern wins:
        /// 1. Check both Individual Rules and URL Groups
        /// 2. Compare matched pattern lengths — longest wins
        /// 3. On tie, Individual Rule takes precedence
        /// 4. No Match → use default browser or show picker
        /// </summary>
        public static MatchResult FindMatch(string url, string? sourceProcessName = null)
        {
            // Check both individual rules and URL groups
            var rule = FindMatchingRule(url, sourceProcessName);
            var (group, groupOverride, groupPatternLength) = UrlGroupManager.FindMatchingGroupWithLength(url, sourceProcessName);

            int rulePatternLength = rule?.Pattern.Length ?? 0;

            // Compare pattern lengths — longest (most specific) wins; on tie, individual rule wins
            if (rule != null && rulePatternLength >= groupPatternLength)
            {
                Logger.Log($"URL matched individual rule: {rule.Pattern}");
                return new MatchResult
                {
                    Type = MatchType.IndividualRule,
                    Rule = rule
                };
            }

            if (group != null)
            {
                if (groupOverride != null)
                {
                    Logger.Log($"URL matched group override: {group.Name} -> {groupOverride.UrlPattern}");
                    return new MatchResult
                    {
                        Type = MatchType.GroupOverride,
                        Group = group,
                        Override = groupOverride
                    };
                }

                Logger.Log($"URL matched URL group: {group.Name}");
                return new MatchResult
                {
                    Type = MatchType.UrlGroup,
                    Group = group
                };
            }

            // Individual rule matched but no group — return the rule
            if (rule != null)
            {
                Logger.Log($"URL matched individual rule: {rule.Pattern}");
                return new MatchResult
                {
                    Type = MatchType.IndividualRule,
                    Rule = rule
                };
            }

            // No match found
            Logger.Log($"No match found for URL: {Logger.SanitizeUrl(url)}");
            return new MatchResult { Type = MatchType.NoMatch };
        }

        /// <summary>
        /// Finds the best match for a URL. If no active match is found,
        /// also checks whether any disabled rule/group would have matched.
        /// This avoids redundant iteration over rules and groups compared to
        /// calling FindMatch + HasDisabledMatchingRule + HasDisabledMatchingGroup separately.
        /// </summary>
        public static FullMatchResult FindMatchWithDisabledCheck(string url, string? sourceProcessName = null)
        {
            var result = new FullMatchResult();
            var allRules = LoadRules();

            UrlRule? bestEnabledSubstring = null;
            UrlRule? bestEnabledDomain = null;
            bool hasDisabledMatch = false;

            // Strip query string/fragment to prevent false matches against query parameter values
            string urlWithoutQuery = UrlGroupManager.StripQueryAndFragment(url);

            // Extract domain once upfront
            string? domain = null;
            try { domain = new Uri(url).Host; } catch { }

            // Single pass over all rules: track enabled matches AND disabled matches
            foreach (var rule in allRules)
            {
                // Source app filter: skip if rule requires specific app and it doesn't match
                if (!string.IsNullOrEmpty(rule.SourceAppFilter) &&
                    !rule.SourceAppFilter.Equals(sourceProcessName, StringComparison.OrdinalIgnoreCase))
                    continue;

                bool isSubstringMatch = urlWithoutQuery.IndexOf(rule.Pattern, StringComparison.OrdinalIgnoreCase) >= 0;
                bool isDomainMatch = false;

                if (!isSubstringMatch && domain != null)
                {
                    isDomainMatch = domain.Contains(rule.Pattern, StringComparison.OrdinalIgnoreCase) ||
                                    rule.Pattern.Contains(domain, StringComparison.OrdinalIgnoreCase);
                }

                if (!isSubstringMatch && !isDomainMatch)
                    continue;

                if (rule.IsEnabled)
                {
                    if (isSubstringMatch)
                    {
                        if (bestEnabledSubstring == null || rule.Pattern.Length > bestEnabledSubstring.Pattern.Length)
                            bestEnabledSubstring = rule;
                    }
                    else
                    {
                        if (bestEnabledDomain == null || rule.Pattern.Length > bestEnabledDomain.Pattern.Length)
                            bestEnabledDomain = rule;
                    }
                }
                else
                {
                    hasDisabledMatch = true;
                }
            }

            var bestEnabledRule = bestEnabledSubstring ?? bestEnabledDomain;
            int rulePatternLength = bestEnabledRule?.Pattern.Length ?? 0;

            // Also check URL groups
            var (group, groupOverride, groupPatternLength) = UrlGroupManager.FindMatchingGroupWithLength(url, sourceProcessName);

            // Compare pattern lengths — longest (most specific) wins; on tie, individual rule wins
            if (bestEnabledRule != null && rulePatternLength >= groupPatternLength)
            {
                Logger.Log($"URL matched individual rule: {bestEnabledRule.Pattern}");
                result.Match = new MatchResult
                {
                    Type = MatchType.IndividualRule,
                    Rule = bestEnabledRule
                };
                return result;
            }

            if (group != null)
            {
                if (groupOverride != null)
                {
                    Logger.Log($"URL matched group override: {group.Name} -> {groupOverride.UrlPattern}");
                    result.Match = new MatchResult
                    {
                        Type = MatchType.GroupOverride,
                        Group = group,
                        Override = groupOverride
                    };
                }
                else
                {
                    Logger.Log($"URL matched URL group: {group.Name}");
                    result.Match = new MatchResult
                    {
                        Type = MatchType.UrlGroup,
                        Group = group
                    };
                }
                return result;
            }

            // Individual rule matched but no group — return the rule
            if (bestEnabledRule != null)
            {
                Logger.Log($"URL matched individual rule: {bestEnabledRule.Pattern}");
                result.Match = new MatchResult
                {
                    Type = MatchType.IndividualRule,
                    Rule = bestEnabledRule
                };
                return result;
            }

            // No match — report disabled status
            Logger.Log($"No match found for URL: {Logger.SanitizeUrl(url)}");
            result.Match = new MatchResult { Type = MatchType.NoMatch };
            result.HasDisabledMatch = hasDisabledMatch || UrlGroupManager.HasDisabledMatchingGroup(url, sourceProcessName);
            return result;
        }
    }

    /// <summary>
    /// Represents the type of URL match found
    /// </summary>
    public enum MatchType
    {
        /// <summary>
        /// No matching rule or group found
        /// </summary>
        NoMatch,

        /// <summary>
        /// Matched an individual URL rule
        /// </summary>
        IndividualRule,

        /// <summary>
        /// Matched a URL group's default settings
        /// </summary>
        UrlGroup,

        /// <summary>
        /// Matched a URL group override (specific URL within a group)
        /// </summary>
        GroupOverride
    }

    /// <summary>
    /// Contains the result of a URL matching operation
    /// </summary>
    public class MatchResult
    {
        public MatchType Type { get; set; } = MatchType.NoMatch;
        public UrlRule? Rule { get; set; }
        public UrlGroup? Group { get; set; }
        public UrlGroupOverride? Override { get; set; }

        /// <summary>
        /// Gets the name of the matched rule or group
        /// </summary>
        public string GetRuleName()
        {
            return Type switch
            {
                MatchType.IndividualRule => Rule?.Pattern ?? string.Empty,
                MatchType.GroupOverride => Override?.UrlPattern ?? Group?.Name ?? string.Empty,
                MatchType.UrlGroup => Group?.Name ?? string.Empty,
                _ => string.Empty
            };
        }

        /// <summary>
        /// Gets the first profile from the group's Profiles list as fallback
        /// when DefaultBrowser* fields are empty (e.g., group configured with profiles but no explicit default)
        /// </summary>
        private RuleProfile? GroupFirstProfile => Group?.Profiles?.Count > 0 ? Group.Profiles[0] : null;

        /// <summary>
        /// Gets the effective browser name based on match type
        /// </summary>
        public string GetBrowserName()
        {
            return Type switch
            {
                MatchType.IndividualRule => Rule?.DisplayBrowserName ?? string.Empty,
                MatchType.GroupOverride => Override?.BrowserName ?? string.Empty,
                MatchType.UrlGroup => !string.IsNullOrEmpty(Group?.DefaultBrowserName)
                    ? Group.DefaultBrowserName
                    : GroupFirstProfile?.BrowserName ?? string.Empty,
                _ => string.Empty
            };
        }

        /// <summary>
        /// Gets the effective browser path based on match type
        /// </summary>
        public string GetBrowserPath()
        {
            return Type switch
            {
                MatchType.IndividualRule => Rule?.FirstProfile?.BrowserPath ?? Rule?.BrowserPath ?? string.Empty,
                MatchType.GroupOverride => Override?.BrowserPath ?? string.Empty,
                MatchType.UrlGroup => !string.IsNullOrEmpty(Group?.DefaultBrowserPath)
                    ? Group.DefaultBrowserPath
                    : GroupFirstProfile?.BrowserPath ?? string.Empty,
                _ => string.Empty
            };
        }

        /// <summary>
        /// Gets the effective profile name based on match type
        /// </summary>
        public string GetProfileName()
        {
            return Type switch
            {
                MatchType.IndividualRule => Rule?.FirstProfile?.ProfileName ?? Rule?.ProfileName ?? string.Empty,
                MatchType.GroupOverride => Override?.ProfileName ?? string.Empty,
                MatchType.UrlGroup => !string.IsNullOrEmpty(Group?.DefaultProfileName)
                    ? Group.DefaultProfileName
                    : GroupFirstProfile?.ProfileName ?? string.Empty,
                _ => string.Empty
            };
        }

        /// <summary>
        /// Gets the effective profile arguments based on match type
        /// </summary>
        public string GetProfileArguments()
        {
            return Type switch
            {
                MatchType.IndividualRule => Rule?.FirstProfile?.ProfileArguments ?? Rule?.ProfileArguments ?? string.Empty,
                MatchType.GroupOverride => Override?.ProfileArguments ?? string.Empty,
                MatchType.UrlGroup => !string.IsNullOrEmpty(Group?.DefaultProfileArguments)
                    ? Group.DefaultProfileArguments
                    : GroupFirstProfile?.ProfileArguments ?? string.Empty,
                _ => string.Empty
            };
        }

        /// <summary>
        /// Gets the effective behavior (for groups/overrides)
        /// </summary>
        public UrlGroupBehavior GetBehavior()
        {
            return Type switch
            {
                MatchType.GroupOverride => Override?.Behavior ?? UrlGroupBehavior.UseDefault,
                MatchType.UrlGroup => Group?.Behavior ?? UrlGroupBehavior.UseDefault,
                _ => UrlGroupBehavior.UseDefault
            };
        }

        /// <summary>
        /// Gets the linked profile group ID (for groups/overrides with ShowProfilePicker behavior)
        /// </summary>
        public string GetLinkedProfileGroupId()
        {
            return Type switch
            {
                MatchType.GroupOverride => Override?.LinkedProfileGroupId ?? string.Empty,
                MatchType.UrlGroup => Group?.LinkedProfileGroupId ?? string.Empty,
                _ => string.Empty
            };
        }

        /// <summary>
        /// Returns true if this match should show a profile picker
        /// </summary>
        public bool ShouldShowProfilePicker()
        {
            // Individual rules with multiple profiles should show picker
            if (Type == MatchType.IndividualRule && Rule != null && Rule.HasMultipleProfiles)
            {
                return true;
            }

            return false;
        }
    }

    /// <summary>
    /// Extended match result that includes disabled match status.
    /// Used by ClipboardMonitorService to avoid redundant rule scanning.
    /// </summary>
    public class FullMatchResult
    {
        public MatchResult Match { get; set; } = new MatchResult();
        public bool HasDisabledMatch { get; set; } = false;
    }
}