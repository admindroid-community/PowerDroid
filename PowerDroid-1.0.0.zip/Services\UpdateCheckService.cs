using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;

namespace PowerDroid.Services
{
    public sealed class UpdateCheckService
    {
        private static UpdateCheckService? _instance;
        private static readonly object _lock = new();

        public static UpdateCheckService Instance
        {
            get
            {
                if (_instance == null)
                    lock (_lock)
                        _instance ??= new UpdateCheckService();
                return _instance;
            }
        }

        private static readonly HttpClient _httpClient = new()
        {
            Timeout = TimeSpan.FromSeconds(10)
        };

        static UpdateCheckService()
        {
            _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd($"PowerDroid/{BrandConfig.Version}");
        }

        public bool IsUpdateAvailable { get; private set; }
        public string LatestVersion { get; private set; } = string.Empty;
        public string ReleaseTitle { get; private set; } = string.Empty;
        public string ReleaseNotes { get; private set; } = string.Empty;
        public string ReleaseUrl { get; private set; } = string.Empty;
        public string InstallerUrl { get; private set; } = string.Empty;
        public long InstallerSizeBytes { get; private set; }
        public bool ShouldShowPopup { get; private set; }

        public event EventHandler? UpdateAvailable;

        /// <summary>
        /// Checks for updates. Uses a 24-hour cache to avoid excessive API calls.
        /// Silently fails on any error (no internet, API down, etc.).
        /// </summary>
        public async Task CheckForUpdatesAsync()
        {
            try
            {
                var settings = SettingsManager.LoadSettings();

                // Use cached result if checked within 24 hours
                if ((DateTime.UtcNow - settings.LastUpdateCheckTime).TotalHours < 24)
                {
                    ApplyCachedResult(settings);
                    return;
                }

                Logger.Log("UpdateCheck: Checking for updates...");

                if (!Version.TryParse(BrandConfig.Version, out var currentVersion))
                    return;

                // Fetch all releases (includes pre-releases)
                var apiUrl = BrandConfig.ReleasesApiUrl.Replace("/releases/latest", "/releases");
                var response = await _httpClient.GetStringAsync(apiUrl);
                using var doc = JsonDocument.Parse(response);

                // Find the newest release with a version greater than current
                Version? bestVersion = null;
                string bestVersionString = "";
                string bestTitle = "";
                string bestBody = "";
                string bestHtmlUrl = "";
                string bestInstallerUrl = "";
                long bestInstallerSize = 0;

                foreach (var release in doc.RootElement.EnumerateArray())
                {
                    var tagName = release.GetProperty("tag_name").GetString() ?? "";
                    var versionString = tagName.TrimStart('v');

                    if (!Version.TryParse(versionString, out var ver))
                    {
                        // Try parsing version from asset name (PowerDroidSetup-X.Y.Z.exe)
                        if (release.TryGetProperty("assets", out var assets))
                        {
                            foreach (var asset in assets.EnumerateArray())
                            {
                                var assetName = asset.GetProperty("name").GetString() ?? "";
                                var match = System.Text.RegularExpressions.Regex.Match(
                                    assetName, @"PowerDroidSetup-(\d+\.\d+\.\d+)\.exe");
                                if (match.Success && Version.TryParse(match.Groups[1].Value, out ver))
                                {
                                    versionString = match.Groups[1].Value;
                                    break;
                                }
                            }
                        }
                        if (ver == null) continue;
                    }

                    if (ver > currentVersion && (bestVersion == null || ver > bestVersion))
                    {
                        bestVersion = ver;
                        bestVersionString = versionString;
                        bestTitle = release.TryGetProperty("name", out var nameProp) ? nameProp.GetString() ?? "" : "";
                        bestBody = release.TryGetProperty("body", out var bodyProp) ? bodyProp.GetString() ?? "" : "";
                        bestHtmlUrl = release.TryGetProperty("html_url", out var urlProp) ? urlProp.GetString() ?? "" : "";

                        // Find the .exe installer asset
                        if (release.TryGetProperty("assets", out var releaseAssets))
                        {
                            foreach (var asset in releaseAssets.EnumerateArray())
                            {
                                var name = asset.GetProperty("name").GetString() ?? "";
                                if (name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
                                {
                                    bestInstallerUrl = asset.GetProperty("browser_download_url").GetString() ?? "";
                                    bestInstallerSize = asset.TryGetProperty("size", out var sizeProp) ? sizeProp.GetInt64() : 0;
                                    break;
                                }
                            }
                        }
                    }
                }

                // Update cache
                settings.LastUpdateCheckTime = DateTime.UtcNow;
                settings.LastKnownUpdateVersion = bestVersionString;
                settings.LastKnownReleaseTitle = bestTitle;
                settings.LastKnownReleaseNotes = bestBody;
                settings.LastKnownInstallerUrl = bestInstallerUrl;

                if (!string.IsNullOrEmpty(bestVersionString) &&
                    bestVersionString != settings.LastKnownUpdateVersion)
                    settings.HasSeenUpdatePopup = false;

                SettingsManager.SaveSettings(settings);

                if (bestVersion != null && bestVersionString != settings.SkippedUpdateVersion)
                {
                    LatestVersion = bestVersionString;
                    ReleaseTitle = bestTitle;
                    ReleaseNotes = StripMarkdown(bestBody);
                    ReleaseUrl = !string.IsNullOrEmpty(bestHtmlUrl) ? bestHtmlUrl : BrandConfig.ReleasesPageUrl;
                    InstallerUrl = bestInstallerUrl;
                    InstallerSizeBytes = bestInstallerSize;
                    IsUpdateAvailable = true;
                    ShouldShowPopup = !settings.HasSeenUpdatePopup;

                    Logger.Log($"UpdateCheck: Update available — v{bestVersionString} '{bestTitle}' (current: v{BrandConfig.Version})");
                    UpdateAvailable?.Invoke(this, EventArgs.Empty);
                }
                else
                {
                    Logger.Log($"UpdateCheck: Up to date (current: v{BrandConfig.Version})");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateCheck: Failed silently — {ex.Message}");
            }
        }

        /// <summary>
        /// Public method to apply cached update info on startup without an API call.
        /// </summary>
        public void ApplyCachedIfAvailable()
        {
            var settings = SettingsManager.LoadSettings();
            ApplyCachedResult(settings);
        }

        /// <summary>
        /// Applies cached update info without making an API call.
        /// </summary>
        private void ApplyCachedResult(AppSettings settings)
        {
            if (string.IsNullOrEmpty(settings.LastKnownUpdateVersion))
                return;

            if (!Version.TryParse(settings.LastKnownUpdateVersion, out var remoteVersion) ||
                !Version.TryParse(BrandConfig.Version, out var currentVersion))
                return;

            if (remoteVersion > currentVersion && settings.LastKnownUpdateVersion != settings.SkippedUpdateVersion)
            {
                LatestVersion = settings.LastKnownUpdateVersion;
                ReleaseTitle = settings.LastKnownReleaseTitle;
                ReleaseNotes = StripMarkdown(settings.LastKnownReleaseNotes);
                ReleaseUrl = BrandConfig.ReleasesPageUrl;
                InstallerUrl = settings.LastKnownInstallerUrl;
                IsUpdateAvailable = true;
                ShouldShowPopup = !settings.HasSeenUpdatePopup;

                Logger.Log($"UpdateCheck: Cached update available — v{LatestVersion}");
                UpdateAvailable?.Invoke(this, EventArgs.Empty);
            }
        }

        /// <summary>
        /// Marks the update popup as seen so it won't show again for this version.
        /// </summary>
        public void MarkPopupSeen()
        {
            ShouldShowPopup = false;
            var settings = SettingsManager.LoadSettings();
            settings.HasSeenUpdatePopup = true;
            SettingsManager.SaveSettings(settings);
        }

        /// <summary>
        /// Skips the current update version so it won't be shown again.
        /// </summary>
        public void SkipCurrentVersion()
        {
            IsUpdateAvailable = false;
            ShouldShowPopup = false;
            var settings = SettingsManager.LoadSettings();
            settings.SkippedUpdateVersion = LatestVersion;
            SettingsManager.SaveSettings(settings);
        }

        /// <summary>
        /// Downloads the installer to %TEMP% and launches it with /SILENT flag.
        /// The app exits and Inno Setup handles the rest.
        /// </summary>
        public async Task DownloadAndInstallAsync(IProgress<int>? progress = null)
        {
            if (string.IsNullOrEmpty(InstallerUrl))
            {
                // No direct download URL — open releases page in browser
                Logger.Log("UpdateCheck: No installer asset URL found, opening releases page");
                Process.Start(new ProcessStartInfo(BrandConfig.ReleasesPageUrl) { UseShellExecute = true });
                return;
            }

            // Save current version before update so the new version can show
            // "What's New" with correct "was vX.Y.Z" info
            var settings = SettingsManager.LoadSettings();
            settings.PreviousAppVersion = BrandConfig.Version;
            settings.HasSeenWhatsNew = false;
            settings.LastKnownReleaseNotes = ReleaseNotes;
            SettingsManager.SaveSettings(settings);

            var url = InstallerUrl;
            var fileName = $"PowerDroidSetup-{LatestVersion}.exe";
            var tempPath = Path.Combine(Path.GetTempPath(), fileName);

            // Delete any previous download
            try { if (File.Exists(tempPath)) File.Delete(tempPath); }
            catch (Exception ex) { Logger.Log($"UpdateCheck: Could not delete previous download: {ex.Message}"); }

            Logger.Log($"UpdateCheck: Downloading installer from {url}");

            // Google Drive may redirect or serve a confirmation page for large files.
            // Use a separate HttpClient with auto-redirect and cookies to handle this.
            using var handler = new HttpClientHandler
            {
                AllowAutoRedirect = true,
                UseCookies = true
            };
            using var client = new HttpClient(handler) { Timeout = TimeSpan.FromMinutes(5) };
            client.DefaultRequestHeaders.UserAgent.ParseAdd($"PowerDroid/{BrandConfig.Version}");

            // First request — may return the file or a confirmation page
            var response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();

            // Check if Google Drive returned an HTML confirmation page
            var contentType = response.Content.Headers.ContentType?.MediaType ?? "";
            if (contentType.Contains("text/html"))
            {
                // Read the HTML to find the confirm token
                var html = await response.Content.ReadAsStringAsync();
                var confirmUrl = ExtractGDriveConfirmUrl(html, url);
                if (!string.IsNullOrEmpty(confirmUrl))
                {
                    Logger.Log("UpdateCheck: Google Drive confirmation required, retrying...");
                    response.Dispose();
                    response = await client.GetAsync(confirmUrl, HttpCompletionOption.ResponseHeadersRead);
                    response.EnsureSuccessStatusCode();
                }
            }

            var totalBytes = response.Content.Headers.ContentLength ?? -1;
            long downloadedBytes = 0;

            using (var contentStream = await response.Content.ReadAsStreamAsync())
            using (var fileStream = new FileStream(tempPath, FileMode.Create, FileAccess.Write, FileShare.None, 8192, true))
            {
                var buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = await contentStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                {
                    await fileStream.WriteAsync(buffer, 0, bytesRead);
                    downloadedBytes += bytesRead;

                    if (totalBytes > 0)
                        progress?.Report((int)(downloadedBytes * 100 / totalBytes));
                }
            }
            response.Dispose();

            Logger.Log($"UpdateCheck: Downloaded {downloadedBytes / 1024} KB to {tempPath}");

            // Verify it's actually an exe (not an HTML error page)
            if (downloadedBytes < 50000)
            {
                Logger.Log("UpdateCheck: Downloaded file too small — likely not a valid installer");
                throw new Exception("Downloaded file appears invalid. Check the download URL.");
            }

            progress?.Report(100);

            // Brief pause so "Installing..." state is visible
            await Task.Delay(1500);

            // Launch installer silently and exit
            Logger.Log($"SECURITY: Launching installer from {tempPath}, size={downloadedBytes} bytes");
            Process.Start(new ProcessStartInfo
            {
                FileName = tempPath,
                Arguments = "/SILENT",
                UseShellExecute = true
            });

            // Exit the app — Inno Setup will close it anyway via CloseApplications=yes
            Application.Current.Dispatcher.Invoke(() => Application.Current.Shutdown());
        }

        /// <summary>
        /// Cleans up any leftover installer files from %TEMP% on startup.
        /// </summary>
        public static void CleanupOldInstallers()
        {
            try
            {
                var tempDir = Path.GetTempPath();
                foreach (var file in Directory.GetFiles(tempDir, "PowerDroidSetup-*.exe"))
                {
                    try
                    {
                        File.Delete(file);
                        Logger.Log($"UpdateCheck: Cleaned up {Path.GetFileName(file)}");
                    }
                    catch (Exception ex) { Logger.Log($"UpdateCheck: Could not delete {Path.GetFileName(file)}: {ex.Message}"); }
                }
            }
            catch (Exception ex) { Logger.Log($"UpdateCheck: Cleanup scan failed: {ex.Message}"); }
        }

        /// <summary>
        /// Strips common markdown syntax to produce clean plain text.
        /// </summary>
        public static string StripMarkdown(string md)
        {
            if (string.IsNullOrWhiteSpace(md)) return md;

            var text = md;
            // Remove headers (## Title → Title)
            text = System.Text.RegularExpressions.Regex.Replace(text, @"^#{1,6}\s*", "", System.Text.RegularExpressions.RegexOptions.Multiline);
            // Bold **text** or __text__
            text = System.Text.RegularExpressions.Regex.Replace(text, @"\*\*(.+?)\*\*", "$1");
            text = System.Text.RegularExpressions.Regex.Replace(text, @"__(.+?)__", "$1");
            // Italic *text* or _text_
            text = System.Text.RegularExpressions.Regex.Replace(text, @"\*(.+?)\*", "$1");
            text = System.Text.RegularExpressions.Regex.Replace(text, @"(?<!\w)_(.+?)_(?!\w)", "$1");
            // Inline code `text`
            text = System.Text.RegularExpressions.Regex.Replace(text, @"`(.+?)`", "$1");
            // Links [text](url) → text
            text = System.Text.RegularExpressions.Regex.Replace(text, @"\[(.+?)\]\(.+?\)", "$1");
            // Bullet lists - item → • item
            text = System.Text.RegularExpressions.Regex.Replace(text, @"^[-*]\s+", "\u2022 ", System.Text.RegularExpressions.RegexOptions.Multiline);
            // Collapse multiple blank lines
            text = System.Text.RegularExpressions.Regex.Replace(text, @"\n{3,}", "\n\n");

            return text.Trim();
        }

        /// <summary>
        /// Formats byte count as human-readable size.
        /// </summary>
        public static string FormatSize(long bytes)
        {
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F1} KB";
            return $"{bytes / (1024.0 * 1024.0):F1} MB";
        }

        /// <summary>
        /// Extracts the confirmation download URL from a Google Drive HTML page.
        /// Google Drive shows a "Download anyway" page for large/unscanned files.
        /// </summary>
        private static string? ExtractGDriveConfirmUrl(string html, string originalUrl)
        {
            // Look for the confirm link pattern in the HTML
            // Google Drive uses: /uc?export=download&confirm=TOKEN&id=FILE_ID
            var match = System.Text.RegularExpressions.Regex.Match(
                html, @"href=""(/uc\?export=download[^""]+)""");
            if (match.Success)
            {
                var path = match.Groups[1].Value.Replace("&amp;", "&");
                return "https://drive.google.com" + path;
            }

            // Alternative: look for action="URL" in form
            match = System.Text.RegularExpressions.Regex.Match(
                html, @"action=""(https://drive\.google\.com/uc\?[^""]+)""");
            if (match.Success)
                return match.Groups[1].Value.Replace("&amp;", "&");

            // Fallback: add confirm=t parameter
            return originalUrl + "&confirm=t";
        }

        /// <summary>
        /// Simulates an available update for testing purposes.
        /// </summary>
        public void SimulateUpdate()
        {
            LatestVersion = "99.0.0";
            ReleaseNotes = "## What's New in v99.0.0\n\n"
                + "- **Power Clip** — Persistent clipboard history with OCR text extraction\n"
                + "- **Smart Browse** improvements and bug fixes\n"
                + "- Performance and stability enhancements\n\n"
                + "This is a simulated update for testing the notification UI.";
            ReleaseUrl = BrandConfig.ReleasesPageUrl;
            IsUpdateAvailable = true;
            ShouldShowPopup = true;

            Logger.Log("UpdateCheck: Simulated update v99.0.0");
            UpdateAvailable?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Clears the simulated update state.
        /// </summary>
        public void ClearSimulatedUpdate()
        {
            IsUpdateAvailable = false;
            ShouldShowPopup = false;
            LatestVersion = string.Empty;
            ReleaseNotes = string.Empty;
            ReleaseUrl = string.Empty;
            Logger.Log("UpdateCheck: Cleared simulated update");
        }
    }
}
