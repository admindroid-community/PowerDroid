using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using PowerDroid.Models;

namespace PowerDroid.Services
{
    /// <summary>
    /// Handles export and import of all user data for backup/restore functionality.
    /// </summary>
    public static class DataExportService
    {
        private static readonly JsonSerializerOptions ExportOptions = new()
        {
            WriteIndented = true
        };

        private static readonly JsonSerializerOptions ImportOptions = new()
        {
            PropertyNameCaseInsensitive = true
        };

        /// <summary>
        /// Contains all exportable user data in a single package.
        /// </summary>
        public class ExportPackage
        {
            /// <summary>
            /// Export format version for forward compatibility.
            /// </summary>
            public int ExportVersion { get; set; } = 1;

            /// <summary>
            /// Application version that created this export.
            /// </summary>
            public string AppVersion { get; set; } = Assembly.GetExecutingAssembly().GetName().Version?.ToString() ?? "1.0.0";

            /// <summary>
            /// When this export was created.
            /// </summary>
            public DateTime ExportDate { get; set; } = DateTime.UtcNow;

            /// <summary>
            /// Machine name where export was created (for identification).
            /// </summary>
            public string MachineName { get; set; } = Environment.MachineName;

            /// <summary>
            /// Smart Browse settings only (fallback browser, rules processing, notifications).
            /// </summary>
            public SmartBrowseExportSettings? BrowseSettings { get; set; }

            /// <summary>
            /// Legacy: full app settings from older exports. Only used for import backward compatibility.
            /// </summary>
            public AppSettings? Settings { get; set; }

            /// <summary>
            /// Individual URL rules.
            /// </summary>
            public List<UrlRule>? Rules { get; set; }

            /// <summary>
            /// URL groups configuration.
            /// </summary>
            public List<UrlGroup>? UrlGroups { get; set; }

            /// <summary>
            /// URL group overrides.
            /// </summary>
            public List<UrlGroupOverride>? UrlGroupOverrides { get; set; }

            /// <summary>
            /// Power Clip settings.
            /// </summary>
            public PowerClipSettings? PowerClipSettings { get; set; }

            /// <summary>
            /// Power Clip clipboard history.
            /// </summary>
            public List<ClipboardEntry>? ClipboardHistory { get; set; }
        }

        /// <summary>
        /// Subset of app settings relevant to Smart Browse (rules, browser config).
        /// Excludes app-level settings like theme, hotkeys, update state, clipboard monitoring.
        /// </summary>
        public class SmartBrowseExportSettings
        {
            public string DefaultBrowserName { get; set; } = string.Empty;
            public string DefaultBrowserPath { get; set; } = string.Empty;
            public string DefaultBrowserType { get; set; } = string.Empty;
            public bool IsEnabled { get; set; } = true;
            public bool ShowNotifications { get; set; } = true;
            public bool UseLastActiveBrowser { get; set; } = true;
        }

        /// <summary>
        /// Result of an import operation.
        /// </summary>
        public class ImportResult
        {
            public bool Success { get; set; }
            public string Message { get; set; } = string.Empty;
            public int SettingsImported { get; set; }
            public int RulesImported { get; set; }
            public int UrlGroupsImported { get; set; }
            public int OverridesImported { get; set; }
            public int ClipboardEntriesImported { get; set; }
        }

        /// <summary>
        /// Exports all user data to a JSON file.
        /// </summary>
        public static void Export(string filePath)
        {
            try
            {
                // Clear caches to ensure fresh data
                SettingsManager.ClearCache();
                UrlRuleManager.ClearCache();
                UrlGroupManager.ClearGroupsCache();
                UrlGroupManager.ClearOverridesCache();

                var settings = SettingsManager.LoadSettings();
                var package = new ExportPackage
                {
                    BrowseSettings = new SmartBrowseExportSettings
                    {
                        DefaultBrowserName = settings.DefaultBrowserName,
                        DefaultBrowserPath = settings.DefaultBrowserPath,
                        DefaultBrowserType = settings.DefaultBrowserType,
                        IsEnabled = settings.IsEnabled,
                        ShowNotifications = settings.ShowNotifications,
                        UseLastActiveBrowser = settings.UseLastActiveBrowser
                    },
                    Rules = UrlRuleManager.LoadRules(),
                    UrlGroups = UrlGroupManager.LoadGroups(),
                    UrlGroupOverrides = UrlGroupManager.LoadOverrides()
                };

                var json = JsonSerializer.Serialize(package, ExportOptions);
                File.WriteAllText(filePath, json);

                Logger.Log($"Exported data to: {filePath}");
                Logger.Log($"  Rules: {package.Rules?.Count ?? 0}, " +
                          $"Groups: {package.UrlGroups?.Count ?? 0}, Overrides: {package.UrlGroupOverrides?.Count ?? 0}");
            }
            catch (Exception ex)
            {
                Logger.Log($"Export failed: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Imports user data from a JSON export file.
        /// Creates a backup of current data before importing.
        /// </summary>
        public static ImportResult Import(string filePath, bool replaceExisting = true)
        {
            var result = new ImportResult();

            try
            {
                // Read and parse the export file
                var json = File.ReadAllText(filePath);
                var package = JsonSerializer.Deserialize<ExportPackage>(json, ImportOptions);

                if (package == null)
                {
                    result.Message = "Invalid export file format.";
                    return result;
                }

                Logger.Log($"Importing data from: {filePath}");
                Logger.Log($"  Export version: {package.ExportVersion}, App version: {package.AppVersion}");
                Logger.Log($"  Export date: {package.ExportDate:yyyy-MM-dd HH:mm:ss}");

                // Create full backup before import
                CreatePreImportBackup();

                // Clear caches
                SettingsManager.ClearCache();
                UrlRuleManager.ClearCache();
                UrlGroupManager.ClearGroupsCache();
                UrlGroupManager.ClearOverridesCache();

                // Import Smart Browse settings only
                if (package.BrowseSettings != null)
                {
                    var currentSettings = SettingsManager.LoadSettings();
                    currentSettings.DefaultBrowserName = package.BrowseSettings.DefaultBrowserName;
                    currentSettings.DefaultBrowserPath = package.BrowseSettings.DefaultBrowserPath;
                    currentSettings.DefaultBrowserType = package.BrowseSettings.DefaultBrowserType;
                    currentSettings.IsEnabled = package.BrowseSettings.IsEnabled;
                    currentSettings.ShowNotifications = package.BrowseSettings.ShowNotifications;
                    currentSettings.UseLastActiveBrowser = package.BrowseSettings.UseLastActiveBrowser;

                    // Auto-detect fallback browser if import left it empty
                    if (string.IsNullOrEmpty(currentSettings.DefaultBrowserPath))
                    {
                        var browsers = BrowserDetector.GetInstalledBrowsers();
                        var fallback = browsers.FirstOrDefault();
                        if (fallback != null)
                        {
                            currentSettings.DefaultBrowserName = fallback.Name;
                            currentSettings.DefaultBrowserPath = fallback.ExecutablePath;
                            currentSettings.DefaultBrowserType = fallback.Type;
                            Logger.Log($"Import: Auto-configured fallback browser: {fallback.Name}");
                        }
                    }

                    SettingsManager.SaveSettings(currentSettings);
                    result.SettingsImported = 1;
                }
                // Legacy: handle old exports that used full Settings object
                else if (package.Settings != null)
                {
                    var currentSettings = SettingsManager.LoadSettings();
                    currentSettings.DefaultBrowserName = package.Settings.DefaultBrowserName;
                    currentSettings.DefaultBrowserPath = package.Settings.DefaultBrowserPath;
                    currentSettings.DefaultBrowserType = package.Settings.DefaultBrowserType;
                    currentSettings.IsEnabled = package.Settings.IsEnabled;
                    currentSettings.ShowNotifications = package.Settings.ShowNotifications;
                    currentSettings.UseLastActiveBrowser = package.Settings.UseLastActiveBrowser;

                    // Auto-detect fallback browser if import left it empty
                    if (string.IsNullOrEmpty(currentSettings.DefaultBrowserPath))
                    {
                        var browsers = BrowserDetector.GetInstalledBrowsers();
                        var fallback = browsers.FirstOrDefault();
                        if (fallback != null)
                        {
                            currentSettings.DefaultBrowserName = fallback.Name;
                            currentSettings.DefaultBrowserPath = fallback.ExecutablePath;
                            currentSettings.DefaultBrowserType = fallback.Type;
                            Logger.Log($"Import: Auto-configured fallback browser: {fallback.Name}");
                        }
                    }

                    SettingsManager.SaveSettings(currentSettings);
                    result.SettingsImported = 1;
                }

                // Import rules — always clear when replacing, even if backup has no rules
                if (replaceExisting)
                {
                    UrlRuleManager.SaveRules(package.Rules ?? new List<UrlRule>());
                }
                else if (package.Rules != null && package.Rules.Count > 0)
                {
                    var existingRules = UrlRuleManager.LoadRules();
                    foreach (var rule in package.Rules)
                    {
                        if (!existingRules.Exists(r => r.Pattern == rule.Pattern))
                        {
                            existingRules.Add(rule);
                        }
                    }
                    UrlRuleManager.SaveRules(existingRules);
                }

                // Trigger migration for imported rules (converts old single-profile format to multi-profile)
                UrlRuleManager.ClearCache();
                UrlRuleManager.LoadRules();
                result.RulesImported = package.Rules?.Count ?? 0;

                // Import URL groups — always clear when replacing, even if backup has no groups
                if (replaceExisting)
                {
                    UrlGroupManager.SaveGroups(package.UrlGroups ?? new List<UrlGroup>());
                }
                else if (package.UrlGroups != null && package.UrlGroups.Count > 0)
                {
                    var existingGroups = UrlGroupManager.LoadGroups();
                    foreach (var group in package.UrlGroups)
                    {
                        if (!existingGroups.Exists(g => g.Id == group.Id || g.Name == group.Name))
                        {
                            existingGroups.Add(group);
                        }
                    }
                    UrlGroupManager.SaveGroups(existingGroups);
                }
                result.UrlGroupsImported = package.UrlGroups?.Count ?? 0;

                // Import URL group overrides
                if (package.UrlGroupOverrides != null && package.UrlGroupOverrides.Count > 0)
                {
                    if (replaceExisting)
                    {
                        UrlGroupManager.SaveOverrides(package.UrlGroupOverrides);
                    }
                    else
                    {
                        // Merge - add overrides that don't exist
                        var existingOverrides = UrlGroupManager.LoadOverrides();
                        foreach (var over in package.UrlGroupOverrides)
                        {
                            if (!existingOverrides.Exists(o => o.Id == over.Id))
                            {
                                existingOverrides.Add(over);
                            }
                        }
                        UrlGroupManager.SaveOverrides(existingOverrides);
                    }
                    result.OverridesImported = package.UrlGroupOverrides.Count;
                }

                result.Success = true;
                var importedItems = new List<string>();
                if (result.SettingsImported > 0) importedItems.Add("Browser settings");
                if (result.RulesImported > 0) importedItems.Add($"{result.RulesImported} individual rule{(result.RulesImported != 1 ? "s" : "")}");
                if (result.UrlGroupsImported > 0) importedItems.Add($"{result.UrlGroupsImported} grouped rule{(result.UrlGroupsImported != 1 ? "s" : "")}");
                if (result.OverridesImported > 0) importedItems.Add($"{result.OverridesImported} override{(result.OverridesImported != 1 ? "s" : "")}");

                result.Message = importedItems.Count > 0
                    ? string.Join("\n", importedItems.Select(i => $"  \u2022 {i}"))
                    : "No data was found to import.";

                Logger.Log($"Import completed: {result.Message}");
            }
            catch (JsonException ex)
            {
                result.Message = $"Invalid JSON format: {ex.Message}";
                Logger.Log($"Import failed (JSON error): {ex.Message}");
            }
            catch (Exception ex)
            {
                result.Message = $"Import failed: {ex.Message}";
                Logger.Log($"Import failed: {ex.Message}");
            }

            return result;
        }

        /// <summary>
        /// Creates a backup of all current data before importing.
        /// </summary>
        private static void CreatePreImportBackup()
        {
            var configDir = AppConfig.AppDataFolder;
            var backupDir = Path.Combine(configDir, "backups");

            if (!Directory.Exists(backupDir))
                Directory.CreateDirectory(backupDir);

            var timestamp = DateTime.Now.ToString("yyyy-MM-dd_HHmmss");
            var backupPath = Path.Combine(backupDir, $"pre-import_{timestamp}.json");

            try
            {
                var backupSettings = SettingsManager.LoadSettings();
                var package = new ExportPackage
                {
                    BrowseSettings = new SmartBrowseExportSettings
                    {
                        DefaultBrowserName = backupSettings.DefaultBrowserName,
                        DefaultBrowserPath = backupSettings.DefaultBrowserPath,
                        DefaultBrowserType = backupSettings.DefaultBrowserType,
                        IsEnabled = backupSettings.IsEnabled,
                        ShowNotifications = backupSettings.ShowNotifications,
                        UseLastActiveBrowser = backupSettings.UseLastActiveBrowser
                    },
                    Rules = UrlRuleManager.LoadRules(),
                    UrlGroups = UrlGroupManager.LoadGroups(),
                    UrlGroupOverrides = UrlGroupManager.LoadOverrides()
                };

                var json = JsonSerializer.Serialize(package, ExportOptions);
                File.WriteAllText(backupPath, json);

                Logger.Log($"Created pre-import backup: {backupPath}");
            }
            catch (Exception ex)
            {
                Logger.Log($"Warning: Could not create pre-import backup: {ex.Message}");
                // Continue with import anyway
            }
        }

        /// <summary>
        /// Validates and re-maps imported rules/groups to local browsers and profiles.
        /// Called after import to ensure all rules reference browsers/profiles that exist on this machine.
        /// </summary>
        /// <param name="forceDefaults">If true (cross-machine), replace ALL assignments. If false, only replace invalid ones.</param>
        public static void ValidateAndRemapProfiles(bool forceDefaults)
        {
            try
            {
                var localBrowsers = BrowserDetector.GetInstalledBrowsers();
                if (localBrowsers.Count == 0)
                {
                    Logger.Log("ValidateAndRemapProfiles: No local browsers found, skipping");
                    return;
                }

                var defaultBrowser = localBrowsers.First();
                var defaultProfiles = BrowserDetector.GetBrowserProfiles(defaultBrowser);
                var defaultProfile = defaultProfiles.FirstOrDefault();

                // Re-map individual rules
                var rules = UrlRuleManager.LoadRules();
                int remappedRules = 0;
                foreach (var rule in rules)
                {
                    var localBrowser = localBrowsers.FirstOrDefault(b => b.Name == rule.BrowserName);
                    if (forceDefaults || localBrowser == null)
                    {
                        rule.BrowserName = defaultBrowser.Name;
                        rule.BrowserPath = defaultBrowser.ExecutablePath;
                        rule.BrowserType = defaultBrowser.Type;
                        rule.ProfileName = defaultProfile?.Name ?? "";
                        rule.ProfilePath = defaultProfile?.Path ?? "";
                        rule.ProfileArguments = defaultProfile?.Arguments ?? "";
                        foreach (var p in rule.Profiles)
                        {
                            p.BrowserName = defaultBrowser.Name;
                            p.BrowserPath = defaultBrowser.ExecutablePath;
                            p.BrowserType = defaultBrowser.Type;
                            p.ProfileName = defaultProfile?.Name ?? "";
                            p.ProfilePath = defaultProfile?.Path ?? "";
                            p.ProfileArguments = defaultProfile?.Arguments ?? "";
                        }
                        remappedRules++;
                    }
                    else
                    {
                        // Browser exists — check profiles
                        var localProfiles = BrowserDetector.GetBrowserProfiles(localBrowser);
                        foreach (var p in rule.Profiles)
                        {
                            var match = localProfiles.FirstOrDefault(lp => lp.Path == p.ProfilePath)
                                     ?? localProfiles.FirstOrDefault(lp => lp.Name == p.ProfileName);
                            if (match == null && localProfiles.Count > 0)
                            {
                                var fallback = localProfiles.First();
                                p.ProfileName = fallback.Name;
                                p.ProfilePath = fallback.Path;
                                p.ProfileArguments = fallback.Arguments;
                                remappedRules++;
                            }
                        }
                    }
                }
                if (remappedRules > 0)
                {
                    UrlRuleManager.SaveRules(rules);
                    UrlRuleManager.ClearCache();
                    Logger.Log($"ValidateAndRemapProfiles: Re-mapped {remappedRules} individual rule(s)");
                }

                // Re-map URL groups
                var groups = UrlGroupManager.LoadGroups();
                int remappedGroups = 0;
                foreach (var group in groups)
                {
                    var localBrowser = localBrowsers.FirstOrDefault(b => b.Name == group.DefaultBrowserName);
                    if (forceDefaults || localBrowser == null)
                    {
                        if (!string.IsNullOrEmpty(group.DefaultBrowserName))
                        {
                            group.DefaultBrowserName = defaultBrowser.Name;
                            group.DefaultBrowserPath = defaultBrowser.ExecutablePath;
                            group.DefaultBrowserType = defaultBrowser.Type;
                            group.DefaultProfileName = defaultProfile?.Name ?? "";
                            group.DefaultProfilePath = defaultProfile?.Path ?? "";
                            group.DefaultProfileArguments = defaultProfile?.Arguments ?? "";
                        }
                        foreach (var p in group.Profiles)
                        {
                            p.BrowserName = defaultBrowser.Name;
                            p.BrowserPath = defaultBrowser.ExecutablePath;
                            p.BrowserType = defaultBrowser.Type;
                            p.ProfileName = defaultProfile?.Name ?? "";
                            p.ProfilePath = defaultProfile?.Path ?? "";
                            p.ProfileArguments = defaultProfile?.Arguments ?? "";
                        }
                        remappedGroups++;
                    }
                    else
                    {
                        // Browser exists — check profiles
                        var localProfiles = BrowserDetector.GetBrowserProfiles(localBrowser);
                        bool groupChanged = false;
                        var defaultMatch = localProfiles.FirstOrDefault(lp => lp.Path == group.DefaultProfilePath)
                                        ?? localProfiles.FirstOrDefault(lp => lp.Name == group.DefaultProfileName);
                        if (defaultMatch == null && localProfiles.Count > 0)
                        {
                            var fallback = localProfiles.First();
                            group.DefaultProfileName = fallback.Name;
                            group.DefaultProfilePath = fallback.Path;
                            group.DefaultProfileArguments = fallback.Arguments;
                            groupChanged = true;
                        }
                        foreach (var p in group.Profiles)
                        {
                            var pBrowser = localBrowsers.FirstOrDefault(b => b.Name == p.BrowserName);
                            if (pBrowser == null)
                            {
                                p.BrowserName = defaultBrowser.Name;
                                p.BrowserPath = defaultBrowser.ExecutablePath;
                                p.BrowserType = defaultBrowser.Type;
                                p.ProfileName = defaultProfile?.Name ?? "";
                                p.ProfilePath = defaultProfile?.Path ?? "";
                                p.ProfileArguments = defaultProfile?.Arguments ?? "";
                                groupChanged = true;
                            }
                            else
                            {
                                var pProfiles = BrowserDetector.GetBrowserProfiles(pBrowser);
                                var pMatch = pProfiles.FirstOrDefault(lp => lp.Path == p.ProfilePath)
                                          ?? pProfiles.FirstOrDefault(lp => lp.Name == p.ProfileName);
                                if (pMatch == null && pProfiles.Count > 0)
                                {
                                    var fallback = pProfiles.First();
                                    p.ProfileName = fallback.Name;
                                    p.ProfilePath = fallback.Path;
                                    p.ProfileArguments = fallback.Arguments;
                                    groupChanged = true;
                                }
                            }
                        }
                        if (groupChanged) remappedGroups++;
                    }
                }
                if (remappedGroups > 0)
                {
                    UrlGroupManager.SaveGroups(groups);
                    UrlGroupManager.ClearGroupsCache();
                    Logger.Log($"ValidateAndRemapProfiles: Re-mapped {remappedGroups} URL group(s)");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"ValidateAndRemapProfiles error: {ex.Message}");
            }
        }

        /// <summary>
        /// Validates an export file without importing it.
        /// </summary>
        public static (bool valid, string message, ExportPackage? package) ValidateExportFile(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                    return (false, "File not found.", null);

                var json = File.ReadAllText(filePath);
                var package = JsonSerializer.Deserialize<ExportPackage>(json, ImportOptions);

                if (package == null)
                    return (false, "Invalid export file format.", null);

                var dataItems = new List<string>();
                if (package.BrowseSettings != null || package.Settings != null) dataItems.Add("Browser settings");
                var rulesCount = package.Rules?.Count ?? 0;
                if (rulesCount > 0) dataItems.Add($"{rulesCount} individual rule{(rulesCount != 1 ? "s" : "")}");
                var groupsCount = package.UrlGroups?.Count ?? 0;
                if (groupsCount > 0) dataItems.Add($"{groupsCount} grouped rule{(groupsCount != 1 ? "s" : "")}");
                var overridesCount = package.UrlGroupOverrides?.Count ?? 0;
                if (overridesCount > 0) dataItems.Add($"{overridesCount} override{(overridesCount != 1 ? "s" : "")}");

                // Reject files with no browser data \u2014 any JSON object deserializes into an
                // all-null package, and importing one would wipe existing rules and groups.
                if (dataItems.Count == 0)
                {
                    return (false,
                        package.PowerClipSettings != null || (package.ClipboardHistory?.Count ?? 0) > 0
                            ? "This is a Power Clip export. It doesn't contain any browser rules or settings."
                            : $"This file doesn't contain any {BrandConfig.PowerBrowserName} backup data.\n" +
                              $"Please choose a backup exported from {BrandConfig.AppDisplayName}.",
                        null);
                }

                var summary = $"Backup from {package.ExportDate:MMM dd, yyyy} ({package.MachineName})\n\n" +
                             "Includes:\n" + string.Join("\n", dataItems.Select(i => $"  \u2022 {i}"));

                return (true, summary, package);
            }
            catch (JsonException ex)
            {
                return (false, $"Invalid JSON format: {ex.Message}", null);
            }
            catch (Exception ex)
            {
                return (false, $"Error reading file: {ex.Message}", null);
            }
        }

        #region Clipboard Export/Import

        /// <summary>
        /// Exports only Power Clip data (settings + clipboard history) to a JSON file.
        /// </summary>
        public static void ExportClipboard(string filePath)
        {
            try
            {
                var package = new ExportPackage
                {
                    PowerClipSettings = PowerClipService.Instance.GetSettings(),
                    ClipboardHistory = PowerClipService.Instance.GetEntries()
                };

                var json = JsonSerializer.Serialize(package, ExportOptions);
                File.WriteAllText(filePath, json);

                Logger.Log($"Exported clipboard data to: {filePath} ({package.ClipboardHistory?.Count ?? 0} entries)");
            }
            catch (Exception ex)
            {
                Logger.Log($"Clipboard export failed: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Imports only Power Clip data (settings + clipboard history) from a JSON file.
        /// </summary>
        public static ImportResult ImportClipboard(string filePath)
        {
            var result = new ImportResult();

            try
            {
                var json = File.ReadAllText(filePath);
                var package = JsonSerializer.Deserialize<ExportPackage>(json, ImportOptions);

                if (package == null)
                {
                    result.Message = "Invalid export file format.";
                    return result;
                }

                // Import Power Clip settings
                if (package.PowerClipSettings != null)
                {
                    PowerClipService.Instance.SaveSettings(package.PowerClipSettings);
                }

                // Import clipboard history
                if (package.ClipboardHistory != null && package.ClipboardHistory.Count > 0)
                {
                    var historyPath = Path.Combine(AppConfig.AppDataFolder, "powerclip-history.json");
                    JsonStorageService.Save(historyPath, package.ClipboardHistory);
                    result.ClipboardEntriesImported = package.ClipboardHistory.Count;
                }

                result.Success = true;
                var items = new List<string>();
                if (package.PowerClipSettings != null) items.Add("Power Clip settings");
                if (result.ClipboardEntriesImported > 0) items.Add($"{result.ClipboardEntriesImported} clipboard entr{(result.ClipboardEntriesImported != 1 ? "ies" : "y")}");

                result.Message = items.Count > 0
                    ? string.Join("\n", items.Select(i => $"  \u2022 {i}"))
                    : "No clipboard data found in this file.";

                Logger.Log($"Clipboard import completed: {result.Message}");
            }
            catch (JsonException ex)
            {
                result.Message = $"Invalid JSON format: {ex.Message}";
                Logger.Log($"Clipboard import failed: {ex.Message}");
            }
            catch (Exception ex)
            {
                result.Message = $"Import failed: {ex.Message}";
                Logger.Log($"Clipboard import failed: {ex.Message}");
            }

            return result;
        }

        #endregion
    }
}
