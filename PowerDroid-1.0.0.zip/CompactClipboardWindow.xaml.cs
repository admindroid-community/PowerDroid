using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid
{
    /// <summary>
    /// Compact floating clipboard popup (like Win+V).
    /// Click an entry to paste it into the previously active app.
    /// </summary>
    public partial class CompactClipboardWindow : Window
    {
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [DllImport("user32.dll")]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc callback, IntPtr hInstance, uint threadId);

        [DllImport("user32.dll")]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool GetCursorPos(out POINT lpPoint);

        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        private const uint SWP_NOSIZE = 0x0001;
        private const uint SWP_NOZORDER = 0x0004;

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT { public int left, top, right, bottom; }

        private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int WH_MOUSE_LL = 14;
        private const int WM_LBUTTONDOWN = 0x0201;
        private const int WM_RBUTTONDOWN = 0x0204;

        private readonly IntPtr _previousWindow;
        private List<ClipboardEntry> _allEntries = new();
        private bool _isPasting;
        private IntPtr _mouseHook;
        private LowLevelMouseProc? _mouseProc;

        // Drag support
        private bool _isDragging;

        // Hover popup
        private System.Windows.Controls.Primitives.Popup? _hoverPopup;
        private System.Windows.Threading.DispatcherTimer? _hoverTimer;
        private Border? _hoveredBorder;
        private ClipboardEntry? _hoveredEntry;
        private bool _isMouseOverPopup;

        public CompactClipboardWindow()
        {
            // Capture the foreground window BEFORE our window appears
            _previousWindow = GetForegroundWindow();

            InitializeComponent();

            Loaded += OnLoaded;
            PreviewKeyDown += OnKeyDown;
            Closing += (s, e) => CloseCleanup();

            // Subscribe to history changes
            PowerClipService.Instance.HistoryChanged += OnHistoryChanged;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            // Make window non-activating so it doesn't steal focus from the target app
            var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            var exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
            SetWindowLong(hwnd, GWL_EXSTYLE, exStyle | WS_EX_NOACTIVATE);

            // Position near cursor using Win32 — all in physical pixels, no DPI conversion needed
            var cursorPos = System.Windows.Forms.Cursor.Position;
            var screen = System.Windows.Forms.Screen.FromPoint(cursorPos);
            var workArea = screen.WorkingArea;

            // Get physical window size
            GetWindowRect(hwnd, out RECT currentRect);
            int winWidth = currentRect.right - currentRect.left;
            int winHeight = currentRect.bottom - currentRect.top;

            int x = Math.Min(cursorPos.X, workArea.Right - winWidth - 10);
            int y = Math.Min(cursorPos.Y, workArea.Bottom - winHeight - 10);
            if (x < workArea.Left) x = workArea.Left + 10;
            if (y < workArea.Top) y = workArea.Top + 10;

            SetWindowPos(hwnd, IntPtr.Zero, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

            LoadEntries();

            // Install global mouse hook to detect clicks outside
            _mouseProc = MouseHookCallback;
            _mouseHook = SetWindowsHookEx(WH_MOUSE_LL, _mouseProc, IntPtr.Zero, 0);
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT { public int x, y; }

        [StructLayout(LayoutKind.Sequential)]
        private struct MSLLHOOKSTRUCT { public POINT pt; public uint mouseData, flags, time; public IntPtr dwExtraInfo; }

        private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && !_isPasting && !_isDragging &&
                (wParam == (IntPtr)WM_LBUTTONDOWN || wParam == (IntPtr)WM_RBUTTONDOWN))
            {
                // Use GetCursorPos — returns in the same DPI-virtualized coordinate system as GetWindowRect
                GetCursorPos(out POINT cursorPt);
                var clickPoint = new System.Windows.Point(cursorPt.x, cursorPt.y);

                bool insideWindow = false;
                bool insidePopup = false;
                try
                {
                    var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
                    if (hwnd != IntPtr.Zero && GetWindowRect(hwnd, out RECT wr))
                    {
                        insideWindow = clickPoint.X >= wr.left && clickPoint.X <= wr.right
                                    && clickPoint.Y >= wr.top && clickPoint.Y <= wr.bottom;
                    }
                }
                catch { }

                if (_hoverPopup?.Child is FrameworkElement popupChild && _hoverPopup.IsOpen)
                {
                    try
                    {
                        var popupSource = PresentationSource.FromVisual(popupChild) as System.Windows.Interop.HwndSource;
                        if (popupSource != null && GetWindowRect(popupSource.Handle, out RECT pr))
                        {
                            insidePopup = clickPoint.X >= pr.left && clickPoint.X <= pr.right
                                       && clickPoint.Y >= pr.top && clickPoint.Y <= pr.bottom;
                        }
                    }
                    catch { }
                }

                if (!insideWindow && !insidePopup)
                {
                    Dispatcher.BeginInvoke(() =>
                    {
                        CloseCleanup();
                        Close();
                    });
                }
            }
            return CallNextHookEx(_mouseHook, nCode, wParam, lParam);
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                CloseCleanup();
                Close();
            }
        }

        private void OnHistoryChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(LoadEntries);
        }

        private void CloseCleanup()
        {
            HidePopup();
            PowerClipService.Instance.HistoryChanged -= OnHistoryChanged;
            if (_mouseHook != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_mouseHook);
                _mouseHook = IntPtr.Zero;
            }
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _isDragging = true;
            try
            {
                DragMove();
            }
            finally
            {
                _isDragging = false;
            }
        }

        private void MonitoringOffButton_Click(object sender, RoutedEventArgs e)
        {
            var settings = SettingsManager.LoadSettings();
            if (!settings.ClipboardMonitoring.IsEnabled)
            {
                settings.ClipboardMonitoring.IsEnabled = true;
                SettingsManager.SaveSettings(settings);
                Services.ClipboardMonitorService.Instance.Start();
                Services.TrayIconService.Instance.UpdateState();
            }
            else if (settings.ClipboardMonitoring.IsPaused)
            {
                Services.TrayIconService.Instance.Resume();
            }
            LoadEntries();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            CloseCleanup();
            Close();
        }

        #region Entry Loading & Rendering

        private void LoadEntries()
        {
            _allEntries = PowerClipService.Instance.GetEntries();
            RenderEntries();
            ScrollToTop();
        }

        private void ScrollToTop()
        {
            if (EntriesListView.Items.Count > 0)
                EntriesListView.ScrollIntoView(EntriesListView.Items[0]);
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            RenderEntries();
        }

        private void ClearSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchBox.Text = string.Empty;
        }

        private void RenderEntries()
        {
            // Check monitoring status first
            var clipSettings = SettingsManager.LoadSettings().ClipboardMonitoring;
            if (!clipSettings.IsEnabled)
            {
                EntriesListView.ItemsSource = null;
                EntriesListView.Visibility = Visibility.Collapsed;
                EmptyText.Visibility = Visibility.Collapsed;
                MonitoringOffTitle.Text = "Monitoring is off";
                MonitoringOffDescription.Text = "Enable clipboard monitoring to capture history.";
                MonitoringOffButton.Content = "Enable";
                MonitoringOffState.Visibility = Visibility.Visible;
                return;
            }
            if (clipSettings.IsPaused)
            {
                var remaining = clipSettings.RemainingPauseTime;
                EntriesListView.ItemsSource = null;
                EntriesListView.Visibility = Visibility.Collapsed;
                EmptyText.Visibility = Visibility.Collapsed;
                MonitoringOffTitle.Text = "Monitoring is paused";
                MonitoringOffDescription.Text = remaining.HasValue
                    ? $"Resumes in {(int)remaining.Value.TotalMinutes}m"
                    : "Monitoring is temporarily paused.";
                MonitoringOffButton.Content = "Resume";
                MonitoringOffState.Visibility = Visibility.Visible;
                return;
            }
            MonitoringOffState.Visibility = Visibility.Collapsed;

            var entries = _allEntries.AsEnumerable();

            // Apply search filter
            var searchText = SearchBox?.Text?.Trim();
            if (!string.IsNullOrEmpty(searchText))
            {
                entries = entries.Where(e =>
                    e.Content.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0);
            }

            var all = entries.ToList();

            if (all.Count == 0)
            {
                EntriesListView.ItemsSource = null;
                EntriesListView.Visibility = Visibility.Collapsed;
                EmptyText.Visibility = Visibility.Visible;
                EmptyText.Text = _allEntries.Count == 0 ? "No clipboard entries" : "No matching entries";
                return;
            }

            EmptyText.Visibility = Visibility.Collapsed;
            EntriesListView.Visibility = Visibility.Visible;

            var items = new List<UIElement>();

            var pinned = all.Where(e => e.IsPinned).OrderByDescending(e => e.Timestamp).ToList();
            var recent = all.Where(e => !e.IsPinned).OrderByDescending(e => e.Timestamp).ToList();

            if (pinned.Count > 0)
            {
                items.Add(CreateSectionHeader("Pinned"));
                foreach (var entry in pinned)
                    items.Add(CreateEntryRow(entry));
            }

            if (recent.Count > 0)
            {
                if (pinned.Count > 0)
                    items.Add(CreateSectionHeader("Recent"));
                foreach (var entry in recent)
                    items.Add(CreateEntryRow(entry));
            }

            EntriesListView.ItemsSource = items;
        }

        private UIElement CreateSectionHeader(string text)
        {
            var header = new TextBlock
            {
                Text = text,
                FontSize = 11,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(8, 4, 0, 2)
            };
            header.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
            return header;
        }

        private void ViewAll_Click(object sender, MouseButtonEventArgs e)
        {
            CloseCleanup();
            Close();

            // Open full PowerDroid window on PowerClip page
            Dispatcher.BeginInvoke(() =>
            {
                var settingsWindow = Application.Current.Windows
                    .OfType<SettingsWindow>()
                    .FirstOrDefault();

                if (settingsWindow != null)
                {
                    settingsWindow.WindowState = WindowState.Normal;
                    settingsWindow.Show();
                    settingsWindow.Activate();
                    settingsWindow.NavigateToPage("PowerClip");
                }
                else
                {
                    settingsWindow = new SettingsWindow();
                    settingsWindow.NavigateToPage("PowerClip");
                    settingsWindow.Show();
                    settingsWindow.Activate();
                }
            });
        }

        private UIElement CreateEntryRow(ClipboardEntry entry)
        {
            var border = new Border
            {
                MinHeight = 44,
                Padding = new Thickness(12, 8, 12, 8),
                Margin = new Thickness(4, 2, 4, 2),
                CornerRadius = new CornerRadius(6),
                BorderThickness = new Thickness(1),
                Cursor = Cursors.Hand,
                Tag = entry.Id
            };
            border.SetResourceReference(Border.BackgroundProperty, "SolidBackgroundFillSecondaryBrush");
            border.SetResourceReference(Border.BorderBrushProperty, "CardStrokeBrush");

            // Hover effect + popup trigger
            border.MouseEnter += (s, e) =>
            {
                border.SetResourceReference(Border.BackgroundProperty, "NavigationItemHoverBrush");
                StartHoverPopup(border, entry);
            };
            border.MouseLeave += (s, e) =>
            {
                border.SetResourceReference(Border.BackgroundProperty, "SolidBackgroundFillSecondaryBrush");
                ScheduleHidePopup();
            };

            // Click to paste
            border.MouseLeftButtonUp += (s, e) => PasteEntry(entry);

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) }); // icon
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // content
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) }); // pin indicator
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) }); // timestamp

            // Type icon
            var icon = new TextBlock
            {
                Text = GetTypeIcon(entry.Type),
                FontSize = 13,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 10, 0)
            };
            icon.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");
            icon.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
            Grid.SetColumn(icon, 0);
            grid.Children.Add(icon);

            // Content — image thumbnail or text (consistent height)
            if (entry.Type == ClipboardEntryType.Image && File.Exists(entry.Content))
            {
                var imagePanel = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                var thumb = new Image
                {
                    Height = 48,
                    MaxWidth = 250,
                    Stretch = Stretch.Uniform,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Margin = new Thickness(0, 2, 8, 2)
                };
                try
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.DecodePixelHeight = 48;
                    bitmap.UriSource = new Uri(entry.Content);
                    bitmap.EndInit();
                    thumb.Source = bitmap;
                }
                catch { }
                imagePanel.Children.Add(thumb);
                Grid.SetColumn(imagePanel, 1);
                grid.Children.Add(imagePanel);
            }
            else
            {
                var contentPanel = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                var content = new TextBlock
                {
                    Text = TruncateContent(entry.Content, 50),
                    FontSize = 12,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    Margin = new Thickness(0, 0, 8, 0)
                };
                content.SetResourceReference(TextBlock.ForegroundProperty, "TextPrimaryBrush");
                contentPanel.Children.Add(content);
                Grid.SetColumn(contentPanel, 1);
                grid.Children.Add(contentPanel);
            }

            // Pinned indicator
            if (entry.IsPinned)
            {
                var pin = new TextBlock
                {
                    Text = "\uE840",
                    FontSize = 11,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(4, 0, 6, 0),
                    ToolTip = "Pinned"
                };
                pin.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");
                pin.Foreground = new SolidColorBrush(Color.FromRgb(255, 185, 0));
                Grid.SetColumn(pin, 2);
                grid.Children.Add(pin);
            }

            // Timestamp
            var time = new TextBlock
            {
                Text = FormatTime(entry.Timestamp),
                FontSize = 10,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(4, 0, 0, 0)
            };
            time.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
            Grid.SetColumn(time, 3);
            grid.Children.Add(time);

            border.Child = grid;
            return border;
        }

        #endregion

        #region Hover Popup

        private void StartHoverPopup(Border border, ClipboardEntry entry)
        {
            // If already showing for this entry, keep it
            if (_hoverPopup != null && _hoveredEntry?.Id == entry.Id)
                return;

            HidePopup();

            _hoveredBorder = border;
            _hoveredEntry = entry;

            // Start 1.2s delay timer
            _hoverTimer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(600)
            };
            _hoverTimer.Tick += (s, e) =>
            {
                _hoverTimer.Stop();
                ShowPopup();
            };
            _hoverTimer.Start();
        }

        private void ScheduleHidePopup()
        {
            _hoverTimer?.Stop();

            // Short delay to allow mouse to move to popup
            var hideTimer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(200)
            };
            hideTimer.Tick += (s, e) =>
            {
                hideTimer.Stop();
                if (!_isMouseOverPopup && (_hoveredBorder == null || !_hoveredBorder.IsMouseOver))
                    HidePopup();
            };
            hideTimer.Start();
        }

        private void ShowPopup()
        {
            if (_hoveredBorder == null || _hoveredEntry == null) return;

            var content = BuildPopupContent(_hoveredEntry);
            if (content == null) return;

            // Inner border with content clipping for rounded corners
            var innerBorder = new Border
            {
                Padding = new Thickness(12),
                CornerRadius = new CornerRadius(8),
                BorderThickness = new Thickness(1),
                MinWidth = 200,
                MaxWidth = 400,
                ClipToBounds = true,
            };
            innerBorder.SetResourceReference(Border.BackgroundProperty, "CardBackgroundBrush");
            innerBorder.SetResourceReference(Border.BorderBrushProperty, "CardStrokeBrush");
            innerBorder.Child = content;

            // Outer border for shadow (not clipped)
            var popupBorder = new Border
            {
                Padding = new Thickness(8),
                Background = Brushes.Transparent,
            };
            popupBorder.Effect = new System.Windows.Media.Effects.DropShadowEffect
            {
                ShadowDepth = 2, BlurRadius = 16, Opacity = 0.25, Color = Colors.Black
            };
            popupBorder.Child = innerBorder;

            // Track mouse over popup
            popupBorder.MouseEnter += (s, e) => _isMouseOverPopup = true;
            popupBorder.MouseLeave += (s, e) =>
            {
                _isMouseOverPopup = false;
                ScheduleHidePopup();
            };

            _hoverPopup = new System.Windows.Controls.Primitives.Popup
            {
                Child = popupBorder,
                PlacementTarget = _hoveredBorder,
                Placement = System.Windows.Controls.Primitives.PlacementMode.Left,
                HorizontalOffset = 0,
                AllowsTransparency = true,
                StaysOpen = true,
                IsOpen = true
            };

            // Remove WS_EX_NOACTIVATE so popup buttons are clickable
            SetNoActivate(false);
        }

        private void HidePopup()
        {
            if (_hoverPopup != null)
            {
                _hoverPopup.IsOpen = false;
                _hoverPopup = null;

                // Restore WS_EX_NOACTIVATE so clicking entries doesn't steal focus
                SetNoActivate(true);
            }
            _hoverTimer?.Stop();
            _hoveredBorder = null;
            _hoveredEntry = null;
            _isMouseOverPopup = false;
        }

        private void SetNoActivate(bool enable)
        {
            try
            {
                var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
                if (hwnd == IntPtr.Zero) return;
                var exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
                if (enable)
                    SetWindowLong(hwnd, GWL_EXSTYLE, exStyle | WS_EX_NOACTIVATE);
                else
                    SetWindowLong(hwnd, GWL_EXSTYLE, exStyle & ~WS_EX_NOACTIVATE);
            }
            catch { }
        }

        private StackPanel? BuildPopupContent(ClipboardEntry entry)
        {
            try
            {
                var panel = new StackPanel { MaxWidth = 370 };

                // Preview content
                if (entry.Type == ClipboardEntryType.Image && File.Exists(entry.Content))
                {
                    try
                    {
                        if (entry.Content.EndsWith(".gif", StringComparison.OrdinalIgnoreCase))
                        {
                            var gif = new MediaElement
                            {
                                MaxWidth = 350, MaxHeight = 250,
                                LoadedBehavior = MediaState.Play,
                                UnloadedBehavior = MediaState.Manual,
                                Stretch = Stretch.Uniform,
                            };
                            gif.MediaEnded += (s, ev) => { try { gif.Position = TimeSpan.Zero; gif.Play(); } catch { } };
                            gif.MediaFailed += (s, ev) => { };
                            gif.Source = new Uri(entry.Content);
                            var gifBorder = new Border
                            {
                                CornerRadius = new CornerRadius(4),
                                ClipToBounds = true,
                                Margin = new Thickness(0, 0, 0, 6)
                            };
                            gifBorder.Child = gif;
                            panel.Children.Add(gifBorder);
                        }
                        else
                        {
                            var preview = new BitmapImage();
                            preview.BeginInit();
                            preview.CacheOption = BitmapCacheOption.OnLoad;
                            preview.DecodePixelWidth = 350;
                            preview.UriSource = new Uri(entry.Content);
                            preview.EndInit();
                            var imgBorder = new Border
                            {
                                CornerRadius = new CornerRadius(4),
                                ClipToBounds = true,
                                Margin = new Thickness(0, 0, 0, 6)
                            };
                            imgBorder.Child = new Image
                            {
                                Source = preview, MaxWidth = 350, MaxHeight = 250,
                                Stretch = Stretch.Uniform,
                            };
                            panel.Children.Add(imgBorder);
                        }

                        var fi = new FileInfo(entry.Content);
                        var ext = Path.GetExtension(entry.Content).TrimStart('.').ToUpperInvariant();
                        var bmp = new BitmapImage();
                        bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad;
                        bmp.UriSource = new Uri(entry.Content); bmp.EndInit();
                        var detail = new TextBlock
                        {
                            Text = $"{bmp.PixelWidth}x{bmp.PixelHeight} · {fi.Length / 1024} KB · {ext}",
                            FontSize = 11, Margin = new Thickness(0, 0, 0, 6)
                        };
                        detail.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
                        panel.Children.Add(detail);
                    }
                    catch { }
                }
                else
                {
                    var text = new TextBlock
                    {
                        Text = entry.Content.Length > 500 ? entry.Content[..500] + "..." : entry.Content,
                        TextWrapping = TextWrapping.Wrap,
                        FontSize = 12, MaxWidth = 360,
                    };
                    text.SetResourceReference(TextBlock.ForegroundProperty, "TextPrimaryBrush");
                    panel.Children.Add(text);

                    var typeName = entry.Type switch
                    {
                        ClipboardEntryType.Url => "URL",
                        ClipboardEntryType.FilePath => "File Path",
                        _ => "Text"
                    };
                    var info = new TextBlock
                    {
                        Text = $"{entry.Content.Length} chars · {typeName}",
                        FontSize = 11, Margin = new Thickness(0, 4, 0, 0)
                    };
                    info.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
                    panel.Children.Add(info);
                }

                // Source app
                if (!string.IsNullOrEmpty(entry.SourceApp))
                {
                    var appName = string.IsNullOrEmpty(entry.SourceDetail)
                        ? entry.SourceApp : $"{entry.SourceApp} · {entry.SourceDetail}";
                    var src = new TextBlock { Text = $"from {appName}", FontSize = 10, Margin = new Thickness(0, 2, 0, 0) };
                    src.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
                    panel.Children.Add(src);
                }

                // Action buttons
                var actions = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(0, 8, 0, 0)
                };

                // Copy
                actions.Children.Add(CreatePopupAction("\uE8C8", "Copy", () =>
                {
                    ClipboardMonitorService.Instance.SuppressNextCapture();
                    if (entry.Type == ClipboardEntryType.Image && File.Exists(entry.Content))
                    {
                        var bmp = new BitmapImage();
                        bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad;
                        bmp.UriSource = new Uri(entry.Content); bmp.EndInit();
                        Clipboard.SetImage(bmp);
                    }
                    else
                        Clipboard.SetText(entry.Content);
                    HidePopup();
                }));

                // Extract Text (Images only — OCR)
                if (entry.Type == ClipboardEntryType.Image && File.Exists(entry.Content))
                {
                    actions.Children.Add(CreatePopupAction("\uE8AC", "Extract Text", async () =>
                    {
                        var text = entry.CachedOcrText
                            ?? await OcrService.ExtractTextAsync(entry.Content);

                        if (!string.IsNullOrEmpty(text))
                        {
                            entry.CachedOcrText = text;
                            ClipboardMonitorService.Instance.SuppressNextCapture();
                            Clipboard.SetText(text);
                        }
                        HidePopup();
                    }));
                }

                // Open Link (URLs) — only valid HTTP/HTTPS URLs
                if (entry.Type == ClipboardEntryType.Url && App.IsValidBrowseUrl(entry.Content))
                {
                    actions.Children.Add(CreatePopupAction("\uE71B", "Open Link", () =>
                    {
                        try { Process.Start(new ProcessStartInfo(entry.Content) { UseShellExecute = true }); }
                        catch (Exception ex) { Logger.Log($"Failed to open clipboard URL: {ex.Message}"); }
                        HidePopup();
                    }));
                }

                // Open Path (file paths) — block UNC paths, use explorer.exe
                if (entry.Type == ClipboardEntryType.FilePath)
                {
                    var folder = Path.GetDirectoryName(entry.Content) ?? entry.Content;
                    if (!folder.StartsWith(@"\\") && Directory.Exists(folder))
                    {
                        actions.Children.Add(CreatePopupAction("\uE838", "Open Path", () =>
                        {
                            try { Process.Start(new ProcessStartInfo("explorer.exe") { Arguments = $"\"{folder}\"", UseShellExecute = false }); }
                            catch (Exception ex) { Logger.Log($"Failed to open clipboard path: {ex.Message}"); }
                            HidePopup();
                        }));
                    }
                }

                // Pin / Unpin
                actions.Children.Add(CreatePopupAction(
                    entry.IsPinned ? "\uE841" : "\uE840",
                    entry.IsPinned ? "Unpin" : "Pin", () =>
                {
                    if (entry.IsPinned) PowerClipService.Instance.Unpin(entry.Id);
                    else PowerClipService.Instance.Pin(entry.Id);
                    HidePopup();
                }, "IconButtonOrangeStyle"));

                // Delete
                actions.Children.Add(CreatePopupAction("\uE74D", "Delete", () =>
                {
                    PowerClipService.Instance.Delete(entry.Id);
                    HidePopup();
                }, "IconButtonRedStyle"));

                panel.Children.Add(actions);
                return panel;
            }
            catch { return null; }
        }

        private Button CreatePopupAction(string icon, string tooltip, Action onClick, string styleName = "IconButtonBlueStyle")
        {
            var iconBlock = new TextBlock
            {
                Text = icon,
                FontSize = 14,
            };
            iconBlock.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");

            var binding = new System.Windows.Data.Binding("Foreground")
            {
                RelativeSource = new System.Windows.Data.RelativeSource(
                    System.Windows.Data.RelativeSourceMode.FindAncestor, typeof(Button), 1)
            };
            iconBlock.SetBinding(TextBlock.ForegroundProperty, binding);

            var button = new Button
            {
                ToolTip = tooltip,
                Margin = new Thickness(0, 0, 2, 0),
                Cursor = Cursors.Hand,
                Content = iconBlock,
            };
            button.SetResourceReference(Button.StyleProperty, styleName);
            button.Click += (s, e) => onClick();

            return button;
        }

        #endregion

        #region Paste Logic

        private void PasteEntry(ClipboardEntry entry)
        {
            try
            {
                _isPasting = true;

                // Set clipboard content
                ClipboardMonitorService.Instance.SuppressNextCapture();

                if (entry.Type == ClipboardEntryType.Image && File.Exists(entry.Content))
                {
                    if (entry.Content.EndsWith(".gif", StringComparison.OrdinalIgnoreCase))
                    {
                        var data = new DataObject();
                        data.SetFileDropList(new System.Collections.Specialized.StringCollection { entry.Content });
                        data.SetData("GIF", new MemoryStream(File.ReadAllBytes(entry.Content)));
                        var bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.CacheOption = BitmapCacheOption.OnLoad;
                        bitmap.UriSource = new Uri(entry.Content);
                        bitmap.EndInit();
                        data.SetImage(bitmap);
                        Clipboard.SetDataObject(data);
                    }
                    else
                    {
                        var bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.CacheOption = BitmapCacheOption.OnLoad;
                        bitmap.UriSource = new Uri(entry.Content);
                        bitmap.EndInit();
                        Clipboard.SetImage(bitmap);
                    }
                }
                else
                {
                    Clipboard.SetText(entry.Content);
                }

                Logger.Log($"CompactClipboard: Pasting entry {entry.Id} ({entry.Type})");

                // Hide popup then paste into the still-focused target app
                CloseCleanup();
                Hide();

                var timer = new System.Windows.Threading.DispatcherTimer
                {
                    Interval = TimeSpan.FromMilliseconds(100)
                };
                timer.Tick += (s, args) =>
                {
                    timer.Stop();
                    try
                    {
                        // Target app still has focus — just send Ctrl+V
                        System.Windows.Forms.SendKeys.SendWait("^v");
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"CompactClipboard: SendKeys error: {ex.Message}");
                    }
                    finally
                    {
                        Close();
                    }
                };
                timer.Start();
            }
            catch (Exception ex)
            {
                Logger.Log($"CompactClipboard: Paste error: {ex.Message}");
                _isPasting = false;
                Close();
            }
        }

        #endregion

        #region Helpers

        private static TextBlock CreateSourceLabel(ClipboardEntry entry)
        {
            var appName = string.IsNullOrEmpty(entry.SourceDetail)
                ? entry.SourceApp!
                : $"{entry.SourceApp} · {entry.SourceDetail}";

            var label = new TextBlock
            {
                Text = $"from {appName}",
                FontSize = 9,
                Margin = new Thickness(0, 1, 0, 0),
            };
            label.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
            return label;
        }

        private static string TruncateContent(string content, int maxLength)
        {
            if (string.IsNullOrEmpty(content)) return string.Empty;
            var singleLine = content.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");
            if (singleLine.Length <= maxLength) return singleLine;
            return singleLine.Substring(0, maxLength) + "...";
        }

        private static string FormatTime(DateTime timestamp)
        {
            var diff = DateTime.Now - timestamp;
            if (diff.TotalSeconds < 60) return "now";
            if (diff.TotalMinutes < 60) return $"{(int)diff.TotalMinutes}m";
            if (diff.TotalHours < 24) return $"{(int)diff.TotalHours}h";
            if (diff.TotalDays < 7) return $"{(int)diff.TotalDays}d";
            return timestamp.ToString("MMM d");
        }

        private static string GetTypeIcon(ClipboardEntryType type)
        {
            return type switch
            {
                ClipboardEntryType.Url => "\uE71B",
                ClipboardEntryType.FilePath => "\uE8B7",
                ClipboardEntryType.Image => "\uEB9F",
                ClipboardEntryType.Text => "\uE8C1",
                _ => "\uE8C1"
            };
        }

        #endregion
    }
}
