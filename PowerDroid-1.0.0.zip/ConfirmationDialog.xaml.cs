using System.Windows;
using System.Windows.Input;

namespace PowerDroid
{
    public partial class ConfirmationDialog : Window
    {
        public ConfirmationDialog(string title, string message, string yesText = "Yes", string noText = "No", string? warningText = null)
        {
            InitializeComponent();
            TitleText.Text = title;
            MessageText.Text = message;
            YesButton.Content = yesText;
            NoButton.Content = noText;

            if (!string.IsNullOrEmpty(warningText))
            {
                WarningText.Text = warningText;
                WarningText.Visibility = Visibility.Visible;
            }

            // Use danger style for destructive actions
            if (yesText.Contains("Delete") || yesText.Contains("Clear") || yesText.Contains("Remove"))
            {
                YesButton.Style = (Style)FindResource("DangerButtonStyle");
            }
        }

        private void Yes_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void No_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void Backdrop_Click(object sender, MouseButtonEventArgs e)
        {
            // Clicking backdrop cancels the dialog
            DialogResult = false;
            Close();
        }

        /// <summary>
        /// Shows a confirmation dialog and returns true if user clicks Yes
        /// </summary>
        public static bool Show(Window owner, string title, string message, string yesText = "Yes", string noText = "No", string? warningText = null)
        {
            var dialog = new ConfirmationDialog(title, message, yesText, noText, warningText);
            dialog.Owner = owner;
            return dialog.ShowDialog() == true;
        }

        /// <summary>
        /// Shows a confirmation dialog with default Yes/No buttons
        /// </summary>
        public static bool Confirm(Window owner, string message, string title = "Confirm")
        {
            return Show(owner, title, message);
        }

        /// <summary>
        /// Shows a warning confirmation dialog
        /// </summary>
        public static bool ConfirmWarning(Window owner, string message, string title = "Warning")
        {
            return Show(owner, title, message, "Delete", "Cancel");
        }

        /// <summary>
        /// Shows an informational dialog with a single OK button (no cancel)
        /// </summary>
        public static void ShowInfo(Window owner, string title, string message, string buttonText = "OK")
        {
            var dialog = new ConfirmationDialog(title, message, buttonText, "");
            dialog.Owner = owner;
            dialog.NoButton.Visibility = Visibility.Collapsed;
            dialog.ShowDialog();
        }
    }
}
