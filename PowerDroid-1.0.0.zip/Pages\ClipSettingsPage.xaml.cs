using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using PowerDroid.Services;

namespace PowerDroid.Pages
{
    public partial class ClipSettingsPage : UserControl
    {
        private bool _isLoading;

        public ClipSettingsPage()
        {
            InitializeComponent();
            Loaded += ClipSettingsPage_Loaded;
        }

        private void ClipSettingsPage_Loaded(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            _isLoading = true;
            try
            {
                var settings = PowerClipService.Instance.GetSettings();

                // Max Entries combo
                MaxEntriesCombo.SelectionChanged -= MaxEntriesCombo_SelectionChanged;
                SelectComboByTag(MaxEntriesCombo, settings.MaxEntries.ToString());
                MaxEntriesCombo.SelectionChanged += MaxEntriesCombo_SelectionChanged;

                // Capture type checkboxes
                CaptureUrlsCheckBox.Checked -= CaptureType_Changed;
                CaptureUrlsCheckBox.Unchecked -= CaptureType_Changed;
                CaptureTextCheckBox.Checked -= CaptureType_Changed;
                CaptureTextCheckBox.Unchecked -= CaptureType_Changed;
                CaptureFilePathsCheckBox.Checked -= CaptureType_Changed;
                CaptureFilePathsCheckBox.Unchecked -= CaptureType_Changed;
                CaptureImagesCheckBox.Checked -= CaptureType_Changed;
                CaptureImagesCheckBox.Unchecked -= CaptureType_Changed;

                CaptureUrlsCheckBox.IsChecked = settings.CaptureUrls;
                CaptureTextCheckBox.IsChecked = settings.CaptureText;
                CaptureFilePathsCheckBox.IsChecked = settings.CaptureFilePaths;
                CaptureImagesCheckBox.IsChecked = settings.CaptureImages;

                CaptureUrlsCheckBox.Checked += CaptureType_Changed;
                CaptureUrlsCheckBox.Unchecked += CaptureType_Changed;
                CaptureTextCheckBox.Checked += CaptureType_Changed;
                CaptureTextCheckBox.Unchecked += CaptureType_Changed;
                CaptureFilePathsCheckBox.Checked += CaptureType_Changed;
                CaptureFilePathsCheckBox.Unchecked += CaptureType_Changed;
                CaptureImagesCheckBox.Checked += CaptureType_Changed;
                CaptureImagesCheckBox.Unchecked += CaptureType_Changed;
            }
            catch (Exception ex)
            {
                Logger.Log($"ClipSettingsPage.LoadData ERROR: {ex.Message}");
            }
            finally
            {
                _isLoading = false;
            }
        }

        private void SelectComboByTag(ComboBox comboBox, string tagValue)
        {
            for (int i = 0; i < comboBox.Items.Count; i++)
            {
                if (comboBox.Items[i] is ComboBoxItem item &&
                    item.Tag is string tag &&
                    tag == tagValue)
                {
                    comboBox.SelectedIndex = i;
                    return;
                }
            }
        }

        private void MaxEntriesCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isLoading) return;
            try
            {
                if (MaxEntriesCombo.SelectedItem is ComboBoxItem item &&
                    item.Tag is string tag && int.TryParse(tag, out int maxEntries))
                {
                    var currentSettings = PowerClipService.Instance.GetSettings();
                    var currentCount = PowerClipService.Instance.GetEntries().Count;

                    // If reducing below current count, confirm
                    if (maxEntries < currentCount)
                    {
                        var toRemove = currentCount - maxEntries;
                        var confirmed = ConfirmationDialog.Show(
                            Window.GetWindow(this),
                            "Change Max Entries",
                            $"Reducing to {maxEntries} will remove {toRemove} oldest entries.\nPinned entries will be kept.",
                            "Change & Clear", "Cancel");

                        if (!confirmed)
                        {
                            MaxEntriesCombo.SelectionChanged -= MaxEntriesCombo_SelectionChanged;
                            SelectComboByTag(MaxEntriesCombo, currentSettings.MaxEntries.ToString());
                            MaxEntriesCombo.SelectionChanged += MaxEntriesCombo_SelectionChanged;
                            return;
                        }
                    }

                    currentSettings.MaxEntries = maxEntries;
                    PowerClipService.Instance.SaveSettings(currentSettings);
                    Logger.Log($"Clip max entries set to: {maxEntries}");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"MaxEntriesCombo_SelectionChanged ERROR: {ex.Message}");
            }
        }

        private void CaptureType_Changed(object sender, RoutedEventArgs e)
        {
            if (_isLoading) return;
            try
            {
                var settings = PowerClipService.Instance.GetSettings();
                settings.CaptureUrls = CaptureUrlsCheckBox.IsChecked == true;
                settings.CaptureText = CaptureTextCheckBox.IsChecked == true;
                settings.CaptureFilePaths = CaptureFilePathsCheckBox.IsChecked == true;
                settings.CaptureImages = CaptureImagesCheckBox.IsChecked == true;
                PowerClipService.Instance.SaveSettings(settings);
                Logger.Log($"Capture types updated — URLs:{settings.CaptureUrls}, Text:{settings.CaptureText}, FilePaths:{settings.CaptureFilePaths}, Images:{settings.CaptureImages}");
            }
            catch (Exception ex)
            {
                Logger.Log($"CaptureType_Changed ERROR: {ex.Message}");
            }
        }

    }
}
