using System;
using System.IO;

namespace PowerDroid
{
    /// <summary>
    /// Application configuration constants.
    /// </summary>
    public static class AppConfig
    {
        /// <summary>
        /// Registry identity for browser registration. Uses BrandConfig.RegistryAppId.
        /// </summary>
        public const string AppName = BrandConfig.RegistryAppId;

        /// <summary>
        /// Path to the user data folder (%APPDATA%\PowerDroid)
        /// </summary>
        public static readonly string AppDataFolder = BrandConfig.AppDataFolder;

        /// <summary>
        /// When true, shows development-only UI elements:
        /// - Documentation navigation item
        /// - Test All Rules buttons
        /// Set automatically based on build configuration.
        /// </summary>
#if DEBUG
        public const bool DevMode = true;
#else
        public const bool DevMode = false;
#endif
    }
}
