using System;
using System.Runtime.InteropServices;

namespace PowerDroid.Services
{
    /// <summary>
    /// Controls the Windows "press Shift 5 times" Sticky Keys activation shortcut for the current
    /// user. Power Clip's Shift-based trigger and multi-select can otherwise accidentally trip it,
    /// so users may opt to disable just that shortcut (Sticky Keys itself is left untouched).
    ///
    /// Uses SystemParametersInfo, which writes to the logged-in user's profile — the correct place
    /// for this per-user accessibility setting (an elevated installer would hit the wrong hive).
    /// </summary>
    public static class StickyKeysService
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct STICKYKEYS
        {
            public uint cbSize;
            public uint dwFlags;
        }

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SystemParametersInfo(uint uiAction, uint uiParam, ref STICKYKEYS pvParam, uint fWinIni);

        private const uint SPI_GETSTICKYKEYS = 0x003A;
        private const uint SPI_SETSTICKYKEYS = 0x003B;
        private const uint SPIF_UPDATEINIFILE = 0x01;
        private const uint SPIF_SENDCHANGE = 0x02;

        private const uint SKF_STICKYKEYSON = 0x00000001;   // Sticky Keys feature currently on
        private const uint SKF_HOTKEYACTIVE = 0x00000004;   // the "press Shift 5 times" activation
        private const uint SKF_CONFIRMHOTKEY = 0x00000008;  // the activation confirmation dialog/sound
        private const uint HotkeyBits = SKF_HOTKEYACTIVE | SKF_CONFIRMHOTKEY;

        private static bool TryGetFlags(out uint flags)
        {
            var sk = new STICKYKEYS { cbSize = (uint)Marshal.SizeOf<STICKYKEYS>() };
            if (SystemParametersInfo(SPI_GETSTICKYKEYS, sk.cbSize, ref sk, 0))
            {
                flags = sk.dwFlags;
                return true;
            }
            flags = 0;
            return false;
        }

        /// <summary>True if the "press Shift 5 times" activation shortcut is currently enabled.</summary>
        public static bool IsShortcutEnabled()
            => !TryGetFlags(out uint f) || (f & SKF_HOTKEYACTIVE) != 0;

        /// <summary>True if the Sticky Keys feature is currently turned on (the user relies on it).</summary>
        public static bool IsStickyKeysOn()
            => TryGetFlags(out uint f) && (f & SKF_STICKYKEYSON) != 0;

        /// <summary>
        /// Enables/disables the "press Shift 5 times" activation shortcut (and its confirmation
        /// prompt) for the current user. Does NOT turn Sticky Keys itself on or off.
        /// </summary>
        public static void SetShortcutEnabled(bool enabled)
        {
            try
            {
                var sk = new STICKYKEYS { cbSize = (uint)Marshal.SizeOf<STICKYKEYS>() };
                if (!SystemParametersInfo(SPI_GETSTICKYKEYS, sk.cbSize, ref sk, 0))
                {
                    Logger.Log("StickyKeysService: SPI_GETSTICKYKEYS failed");
                    return;
                }

                uint flags = enabled ? (sk.dwFlags | HotkeyBits) : (sk.dwFlags & ~HotkeyBits);
                if (flags == sk.dwFlags) return; // already in the desired state

                sk.dwFlags = flags;
                if (!SystemParametersInfo(SPI_SETSTICKYKEYS, sk.cbSize, ref sk, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE))
                    Logger.Log("StickyKeysService: SPI_SETSTICKYKEYS failed");
                else
                    Logger.Log($"StickyKeysService: Shift-x5 shortcut {(enabled ? "enabled" : "disabled")}");
            }
            catch (Exception ex)
            {
                Logger.Log($"StickyKeysService error: {ex.Message}");
            }
        }

        /// <summary>
        /// One-time startup default (first launch only): if the user does NOT use Sticky Keys (the
        /// feature is off) and the Shift-x5 shortcut is on, disable that shortcut so it can't be
        /// tripped by the Shift-based Power Clip trigger. Users who have Sticky Keys ON are left
        /// completely untouched. This is a single action, never a per-startup enforcement — Windows
        /// persists the shortcut state itself, and thereafter only the Settings toggle changes it.
        /// </summary>
        public static void ApplyStartupPolicy()
        {
            try
            {
                var settings = SettingsManager.LoadSettings();
                var hk = settings.Hotkeys;

                if (hk.StickyKeysDefaultApplied) return; // one-time default already decided
                hk.StickyKeysDefaultApplied = true;
                SettingsManager.SaveSettings(settings);

                // Only for users who don't use Sticky Keys, and only if the shortcut is actually on.
                if (TryGetFlags(out uint flags)
                    && (flags & SKF_STICKYKEYSON) == 0
                    && (flags & SKF_HOTKEYACTIVE) != 0)
                {
                    SetShortcutEnabled(false);
                    Logger.Log("StickyKeysService: auto-disabled Shift-x5 shortcut (Sticky Keys is off)");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"StickyKeysService.ApplyStartupPolicy error: {ex.Message}");
            }
        }
    }
}
