using System.Windows;

namespace PowerDroid.Services
{
    /// <summary>
    /// Centralized service for controlling application lifecycle (shutdown).
    /// All shutdown calls should go through this service for easier control and debugging.
    /// </summary>
    public static class AppLifecycleService
    {
        /// <summary>
        /// Request application shutdown. Centralized control point.
        /// </summary>
        public static void RequestShutdown(string reason)
        {
            Logger.Log($"AppLifecycleService.RequestShutdown: {reason}");

            var app = Application.Current;
            if (app == null) return;

            app.Dispatcher.Invoke(() =>
            {
                app.Shutdown();
            });
        }

        /// <summary>
        /// Keep the app resident in the background. Global shortcuts (Rules / Power Clip / launcher)
        /// require the process to stay alive, so the app no longer exits when clipboard monitoring is
        /// off — it stays in the tray. Clipboard capture itself is gated separately on its setting.
        /// Full exit happens only via the tray "Quit" (RequestShutdown).
        /// </summary>
        public static void ShutdownOrStayInBackground(string reason)
        {
            Logger.Log($"Staying in background ({reason})");
            EnsureBackgroundServicesRunning();
        }

        /// <summary>
        /// Ensure the background agent is running: tray icon, global hotkeys, and Power Clip are
        /// always active so shortcuts work. Clipboard capture starts only when monitoring is enabled.
        /// </summary>
        public static void EnsureBackgroundServicesRunning()
        {
            var settings = SettingsManager.LoadSettings();

            // Clipboard capture is opt-in; tray + shortcuts run regardless.
            if (settings.ClipboardMonitoring.IsEnabled && !ClipboardMonitorService.Instance.IsRunning)
            {
                Logger.Log("AppLifecycleService: Starting clipboard monitor service");
                ClipboardMonitorService.Instance.Start();
            }

            if (!TrayIconService.Instance.IsVisible)
            {
                Logger.Log("AppLifecycleService: Showing tray icon");
                TrayIconService.Instance.Show();
            }
            // Always reflect the current monitoring state in the tray (incl. "Disabled").
            TrayIconService.Instance.UpdateState();

            // Ensure global hotkeys are registered
            HotkeyService.Instance.Start();

            // Initialize Power Clip so history/shortcuts are ready (idempotent).
            if (BrandConfig.PowerClipEnabled)
                PowerClipService.Instance.Initialize();
        }
    }
}
