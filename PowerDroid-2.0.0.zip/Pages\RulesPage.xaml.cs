using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PowerDroid.Services;

namespace PowerDroid.Pages
{
    public partial class RulesPage : UserControl
    {
        public event EventHandler? DataChanged;
        private UrlRule? _ruleBeingMoved = null;
        private List<UrlRule> _allRules = new List<UrlRule>();
        private List<UrlGroup> _allGroups = new List<UrlGroup>();

        public RulesPage()
        {
            InitializeComponent();
            Loaded += RulesPage_Loaded;
        }

        private void RulesPage_Loaded(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            LoadRules();
            LoadUrlGroups();
            UpdateCounts();
            UpdateDefaultBrowserWarning();

            var hk = SettingsManager.LoadSettings().Hotkeys;
            ShortcutBadgeText.Text = Services.HotkeyService.FormatHotkey(hk.RulesModifiers, hk.RulesKey);
        }

        private void UpdateDefaultBrowserWarning()
        {
            try
            {
                bool isDefault = RegistryHelper.IsSystemDefaultBrowser();
                DefaultBrowserWarning.Visibility = isDefault ? Visibility.Collapsed : Visibility.Visible;
            }
            catch
            {
                DefaultBrowserWarning.Visibility = Visibility.Collapsed;
            }
        }

        private void GoToSettings_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!RegistryHelper.IsRegistered())
                {
                    Logger.Log("Browser not registered — registering before opening Windows Settings");
                    RegistryHelper.RegisterAsDefaultBrowser();
                }

                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = $"ms-settings:defaultapps?registeredAppUser={BrandConfig.RegistryAppId}",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                Logger.Log($"GoToSettings_Click ERROR: {ex.Message}");
            }
        }

        private void UpdateCounts()
        {
            try
            {
                var rulesCount = _allRules?.Count ?? 0;
                var groupsCount = _allGroups?.Count ?? 0;

                RulesCountBadge.Text = rulesCount.ToString();
                GroupsCountBadge.Text = groupsCount.ToString();
            }
            catch { }
        }

        private void LoadRules()
        {
            try
            {
                _allRules = UrlRuleManager.LoadRules();
                RulesDataGrid.ItemsSource = null;
                RulesDataGrid.ItemsSource = _allRules;

                // Clear search box
                if (RulesSearchBox != null)
                    RulesSearchBox.Text = "";

                // Show/hide empty state and action buttons
                var hasRules = _allRules.Count > 0;
                RulesEmptyState.Visibility = hasRules ? Visibility.Collapsed : Visibility.Visible;
                RulesDataGrid.Visibility = hasRules ? Visibility.Visible : Visibility.Collapsed;
                AddRuleButton.Visibility = hasRules ? Visibility.Visible : Visibility.Collapsed;
                ClearRulesButton.Visibility = hasRules ? Visibility.Visible : Visibility.Collapsed;

                // Restore persisted sort state
                RestoreSortState();

                UpdateCounts();
            }
            catch (Exception ex)
            {
                Logger.Log($"RulesPage LoadRules ERROR: {ex.Message}");
            }
        }

        private void LoadUrlGroups()
        {
            try
            {
                _allGroups = UrlGroupManager.LoadGroups();
                UrlGroupsItemsControl.ItemsSource = null;
                UrlGroupsItemsControl.ItemsSource = _allGroups;

                // Clear search box
                if (GroupsSearchBox != null)
                    GroupsSearchBox.Text = "";

                // Show/hide empty state
                UrlGroupsEmptyState.Visibility = _allGroups.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

                UpdateCounts();
            }
            catch (Exception ex)
            {
                Logger.Log($"RulesPage LoadUrlGroups ERROR: {ex.Message}");
            }
        }

        private void RulesDataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (RulesDataGrid.SelectedItem is UrlRule rule)
            {
                try
                {
                    var editWindow = new AddRuleWindow(rule);
                    editWindow.Owner = Window.GetWindow(this);
                    if (editWindow.ShowDialog() == true)
                    {
                        LoadRules();
                        NotifyDataChanged();
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"RulesDataGrid_MouseDoubleClick ERROR: {ex.Message}");
                }
            }
        }

        private void NotifyDataChanged()
        {
            DataChanged?.Invoke(this, EventArgs.Empty);
        }

        #region Add Actions

        private void AddRule_Click(object sender, RoutedEventArgs e)
        {
            AddUrlRule_Click();
        }

        private void AddGroup_Click(object sender, RoutedEventArgs e)
        {
            AddUrlGroup_Click();
        }

        private void AddUrlRule_Click()
        {
            try
            {
                var addWindow = new AddRuleWindow();
                addWindow.Owner = Window.GetWindow(this);
                if (addWindow.ShowDialog() == true)
                {
                    LoadRules();
                    NotifyDataChanged();
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"AddUrlRule_Click ERROR: {ex.Message}");
                MessageBox.Show($"Error opening Add Rule window: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddUrlGroup_Click()
        {
            try
            {
                var editWindow = new EditUrlGroupWindow();
                editWindow.Owner = Window.GetWindow(this);
                if (editWindow.ShowDialog() == true)
                {
                    LoadUrlGroups();
                    NotifyDataChanged();
                }
                // Refresh rules list if patterns were moved to individual rules
                if (editWindow.RulesWereModified)
                {
                    LoadRules();
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"AddUrlGroup_Click ERROR: {ex.Message}");
                MessageBox.Show($"Error opening grouped rule window: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #endregion

        #region Rule Actions

        private void EditRule_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string ruleId)
            {
                var rules = UrlRuleManager.LoadRules();
                var rule = rules.Find(r => r.Id == ruleId);

                if (rule != null)
                {
                    try
                    {
                        var editWindow = new AddRuleWindow(rule);
                        editWindow.Owner = Window.GetWindow(this);
                        if (editWindow.ShowDialog() == true)
                        {
                            LoadRules();
                            NotifyDataChanged();
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"EditRule_Click ERROR: {ex.Message}");
                        MessageBox.Show($"Error opening Edit Rule window: {ex.Message}", "Error",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void DeleteRule_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string ruleId)
            {
                if (ConfirmationDialog.Show(Window.GetWindow(this), "Delete Rule",
                    "Are you sure you want to delete this rule?", "Delete", "Cancel"))
                {
                    UrlRuleManager.DeleteRule(ruleId);
                    LoadRules();
                    NotifyDataChanged();
                }
            }
        }

        private void RuleEnabled_Click(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleButton toggle && toggle.Tag is string ruleId)
            {
                var rules = UrlRuleManager.LoadRules();
                var rule = rules.Find(r => r.Id == ruleId);
                if (rule != null)
                {
                    rule.IsEnabled = toggle.IsChecked ?? true;
                    UrlRuleManager.SaveRules(rules);
                    Logger.Log($"Rule '{rule.Pattern}' enabled: {rule.IsEnabled}");

                    // Refresh DataGrid to update row opacity
                    RulesDataGrid.Items.Refresh();
                }
            }
        }

        private void ClearIndividualRules_Click(object sender, RoutedEventArgs e)
        {
            if (ConfirmationDialog.Show(Window.GetWindow(this), "Clear Individual Rules",
                "Are you sure you want to delete all individual rules? This cannot be undone.", "Delete All", "Cancel"))
            {
                UrlRuleManager.SaveRules(new List<UrlRule>());
                LoadRules();
                NotifyDataChanged();
            }
        }

        private void ClearUrlGroups_Click(object sender, RoutedEventArgs e)
        {
            if (ConfirmationDialog.Show(Window.GetWindow(this), "Clear Grouped Rules",
                "Are you sure you want to clear all grouped rules? Built-in groups will be reset to defaults and disabled, custom groups will be deleted.", "Clear All", "Cancel"))
            {
                var groups = UrlGroupManager.LoadGroups();

                // Reset built-in groups to defaults, then disable them
                var builtInGroups = groups.Where(g => g.IsBuiltIn).ToList();
                var manifest = Services.BuiltInTemplateManager.LoadTemplateManifest();

                foreach (var group in builtInGroups)
                {
                    // Reset patterns to built-in defaults
                    var template = manifest.Templates.FirstOrDefault(t => t.Id == group.Id);
                    if (template != null)
                    {
                        group.UrlPatterns = template.Patterns.Select(p => new UrlPattern
                        {
                            Id = p.Id,
                            Pattern = p.Pattern,
                            IsBuiltIn = true,
                            VersionAdded = p.VersionAdded,
                            CreatedDate = DateTime.Now
                        }).ToList();
                    }

                    // Clear user modifications
                    group.DeletedBuiltInPatternIds.Clear();

                    // Reset browser/profile assignments
                    group.DefaultBrowserName = string.Empty;
                    group.DefaultBrowserPath = string.Empty;
                    group.DefaultBrowserType = string.Empty;
                    group.DefaultProfileName = string.Empty;
                    group.DefaultProfilePath = string.Empty;
                    group.DefaultProfileArguments = string.Empty;
                    group.LinkedProfileGroupId = string.Empty;
                    group.Profiles.Clear();
                    group.Behavior = UrlGroupBehavior.UseDefault;

                    group.IsEnabled = false;
                }

                UrlGroupManager.SaveGroups(builtInGroups);
                LoadUrlGroups();
                NotifyDataChanged();
            }
        }

        private void MoveRuleToGroup_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string ruleId)
            {
                var rule = UrlRuleManager.LoadRules().FirstOrDefault(r => r.Id == ruleId);
                if (rule == null) return;

                var allGroups = UrlGroupManager.LoadGroups();
                var groups = allGroups.Where(g => g.IsEnabled).ToList();

                if (groups.Count == 0)
                {
                    // Distinguish "no groups at all" from "groups exist but all disabled" —
                    // grouped rules are disabled by default, so the latter is the common case.
                    bool anyGroupExists = allGroups.Count > 0;
                    string title = anyGroupExists ? "No Active Groups" : "No Grouped Rules";
                    string message = anyGroupExists
                        ? "No active groups found. Enable or create one in the 'Grouped Rules' tab."
                        : "No grouped rules exist yet. Create one in the 'Grouped Rules' tab.";

                    if (ConfirmationDialog.Show(Window.GetWindow(this), title, message,
                            "Go to Grouped Rules", "Cancel"))
                    {
                        RulesTabControl.SelectedItem = UrlGroupsTab;
                    }
                    return;
                }

                _ruleBeingMoved = rule;
                GroupSelectionList.ItemsSource = groups;

                // Position popup near the button
                MoveToGroupPopup.PlacementTarget = button;
                MoveToGroupPopup.IsOpen = true;
            }
        }

        private void GroupSelectionItem_Click(object sender, RoutedEventArgs e)
        {
            MoveToGroupPopup.IsOpen = false;

            if (sender is Button button && button.Tag is string groupId && _ruleBeingMoved != null)
            {
                var group = UrlGroupManager.GetGroup(groupId);
                if (group == null) return;

                // Add pattern to group if it doesn't already exist
                if (!group.UrlPatterns.Any(p => p.Pattern.ToLower() == _ruleBeingMoved.Pattern.ToLower()))
                {
                    group.UrlPatterns.Add(new UrlPattern
                    {
                        Pattern = _ruleBeingMoved.Pattern,
                        IsBuiltIn = false,
                        CreatedDate = DateTime.Now
                    });
                    UrlGroupManager.UpdateGroup(group);
                }

                // Always delete the original individual rule (move, not copy — prevents cross-type duplicates)
                UrlRuleManager.DeleteRule(_ruleBeingMoved.Id);

                _ruleBeingMoved = null;
                LoadData();
                NotifyDataChanged();
            }
        }

        #endregion

        #region URL Group Actions

        private void UrlGroupCard_Click(object sender, MouseButtonEventArgs e)
        {
            // Don't open edit if clicking on buttons or toggle
            if (e.OriginalSource is System.Windows.Controls.Primitives.ToggleButton ||
                e.OriginalSource is Button ||
                (e.OriginalSource as FrameworkElement)?.TemplatedParent is Button ||
                (e.OriginalSource as FrameworkElement)?.TemplatedParent is System.Windows.Controls.Primitives.ToggleButton)
            {
                return;
            }

            if (sender is Border border && border.Tag is string groupId)
            {
                OpenEditUrlGroup(groupId);
            }
        }

        private void EditUrlGroup_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string groupId)
            {
                OpenEditUrlGroup(groupId);
            }
        }

        private void OpenEditUrlGroup(string groupId)
        {
            var group = UrlGroupManager.GetGroup(groupId);
            if (group != null)
            {
                try
                {
                    var editWindow = new EditUrlGroupWindow(group);
                    editWindow.Owner = Window.GetWindow(this);
                    if (editWindow.ShowDialog() == true)
                    {
                        LoadUrlGroups();
                        NotifyDataChanged();
                    }
                    // Refresh rules list if patterns were moved to individual rules
                    if (editWindow.RulesWereModified)
                    {
                        LoadRules();
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"OpenEditUrlGroup ERROR: {ex.Message}");
                    MessageBox.Show($"Error opening edit grouped rule window: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeleteUrlGroup_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string groupId)
            {
                var group = UrlGroupManager.GetGroup(groupId);
                if (group != null)
                {
                    string message = group.IsBuiltIn
                        ? $"Are you sure you want to delete the built-in group '{group.Name}'?\n\nIt will be re-added (disabled) when you restart the app."
                        : $"Are you sure you want to delete the grouped rule '{group.Name}'?\n\nThis cannot be undone.";

                    if (ConfirmationDialog.Show(Window.GetWindow(this), "Delete Grouped Rule", message, "Delete", "Cancel"))
                    {
                        UrlGroupManager.DeleteGroup(groupId);
                        LoadUrlGroups();
                        NotifyDataChanged();
                    }
                }
            }
        }

        private void UrlGroupEnabled_Click(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleButton toggle && toggle.Tag is string groupId)
            {
                var group = UrlGroupManager.GetGroup(groupId);
                if (group != null)
                {
                    group.IsEnabled = toggle.IsChecked ?? false;
                    group.HasBeenConfigured = true;  // User explicitly toggled this group

                    // Auto-assign first browser profile when enabling a group with no profiles
                    if (group.IsEnabled && !HasProfilesConfigured(group))
                    {
                        AssignFirstBrowserProfile(group);
                    }

                    UrlGroupManager.UpdateGroup(group);
                    Logger.Log($"URL Group '{group.Name}' enabled: {group.IsEnabled}");

                    // Refresh to update visual state
                    LoadUrlGroups();
                }
            }
        }

        private bool HasProfilesConfigured(UrlGroup group)
        {
            return (group.Profiles != null && group.Profiles.Count > 0) ||
                   !string.IsNullOrEmpty(group.DefaultBrowserPath);
        }

        private void AssignFirstBrowserProfile(UrlGroup group)
        {
            var browsers = BrowserService.GetBrowsersWithColors();
            if (browsers.Count == 0) return;

            var firstBrowser = browsers[0];
            var profiles = BrowserService.GetProfiles(firstBrowser);
            var firstProfile = profiles.FirstOrDefault();

            // Set legacy fields for backward compatibility
            group.DefaultBrowserName = firstBrowser.Name;
            group.DefaultBrowserPath = firstBrowser.ExecutablePath;
            group.DefaultBrowserType = firstBrowser.Type;

            if (firstProfile != null)
            {
                group.DefaultProfileName = firstProfile.Name;
                group.DefaultProfilePath = firstProfile.Path;
                group.DefaultProfileArguments = firstProfile.Arguments ?? string.Empty;
            }

            // Also add to Profiles list for modern approach
            group.Profiles = new List<RuleProfile>
            {
                new RuleProfile
                {
                    BrowserName = firstBrowser.Name,
                    BrowserPath = firstBrowser.ExecutablePath,
                    BrowserType = firstBrowser.Type,
                    ProfileName = firstProfile?.Name ?? "Default",
                    ProfilePath = firstProfile?.Path ?? "Default",
                    ProfileArguments = firstProfile?.Arguments ?? string.Empty,
                    DisplayOrder = 0
                }
            };

            group.Behavior = UrlGroupBehavior.UseDefault;
            group.ModifiedDate = DateTime.Now;

            Logger.Log($"Auto-assigned '{firstBrowser.Name}' to URL Group '{group.Name}'");
        }

        private void MovePatternToIndividualRule_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is IndexedUrlPattern patternInfo)
            {
                try
                {
                    var addWindow = new AddRuleWindow(patternInfo.Pattern);
                    addWindow.Owner = Window.GetWindow(this);

                    if (addWindow.ShowDialog() == true)
                    {
                        var group = UrlGroupManager.GetGroup(patternInfo.GroupId);
                        if (group != null)
                        {
                            // Find and remove the pattern by pattern string
                            var patternToRemove = group.UrlPatterns.FirstOrDefault(p => p.Pattern == patternInfo.Pattern);
                            if (patternToRemove != null)
                            {
                                // Track deleted built-in patterns
                                if (patternToRemove.IsBuiltIn && !string.IsNullOrEmpty(patternToRemove.Id))
                                {
                                    if (!group.DeletedBuiltInPatternIds.Contains(patternToRemove.Id))
                                    {
                                        group.DeletedBuiltInPatternIds.Add(patternToRemove.Id);
                                    }
                                }
                                group.UrlPatterns.Remove(patternToRemove);
                            }
                            UrlGroupManager.UpdateGroup(group);
                            LoadUrlGroups();
                        }

                        LoadRules();
                        NotifyDataChanged();
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"MovePatternToIndividualRule_Click ERROR: {ex.Message}");
                    MessageBox.Show($"Error creating individual rule: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        #endregion

        #region Sorting

        private void RulesDataGrid_Sorting(object sender, DataGridSortingEventArgs e)
        {
            // Let WPF handle the actual sort, then persist the state after it's applied
            Dispatcher.BeginInvoke(new Action(() =>
            {
                try
                {
                    var view = CollectionViewSource.GetDefaultView(RulesDataGrid.ItemsSource);
                    if (view == null) return;

                    var settings = SettingsManager.LoadSettings();
                    settings.RulesSortColumns = view.SortDescriptions
                        .Select(sd => new SortColumnState
                        {
                            Column = sd.PropertyName,
                            Direction = sd.Direction.ToString()
                        })
                        .ToList();
                    SettingsManager.SaveSettings(settings);

                    UpdateSortPriorityBadges();
                }
                catch (Exception ex)
                {
                    Logger.Log($"RulesDataGrid_Sorting save ERROR: {ex.Message}");
                }
            }), DispatcherPriority.Background);
        }

        private void RestoreSortState()
        {
            try
            {
                var settings = SettingsManager.LoadSettings();
                if (settings.RulesSortColumns == null || settings.RulesSortColumns.Count == 0)
                {
                    UpdateSortPriorityBadges();
                    return;
                }

                var view = CollectionViewSource.GetDefaultView(RulesDataGrid.ItemsSource);
                if (view == null) return;

                view.SortDescriptions.Clear();

                foreach (var sortCol in settings.RulesSortColumns)
                {
                    if (string.IsNullOrEmpty(sortCol.Column)) continue;

                    var direction = sortCol.Direction == "Descending"
                        ? ListSortDirection.Descending
                        : ListSortDirection.Ascending;

                    view.SortDescriptions.Add(new SortDescription(sortCol.Column, direction));
                }

                // Update column header visual sort arrows
                foreach (var column in RulesDataGrid.Columns)
                {
                    string sortPath = GetColumnSortPath(column);
                    var matchingSort = settings.RulesSortColumns
                        .FirstOrDefault(s => s.Column == sortPath);

                    if (matchingSort != null)
                    {
                        column.SortDirection = matchingSort.Direction == "Descending"
                            ? ListSortDirection.Descending
                            : ListSortDirection.Ascending;
                    }
                    else
                    {
                        column.SortDirection = null;
                    }
                }

                UpdateSortPriorityBadges();
            }
            catch (Exception ex)
            {
                Logger.Log($"RestoreSortState ERROR: {ex.Message}");
            }
        }

        private string GetColumnSortPath(DataGridColumn column)
        {
            if (column is DataGridBoundColumn boundCol &&
                boundCol.Binding is Binding binding)
            {
                return binding.Path?.Path ?? string.Empty;
            }
            if (column is DataGridTemplateColumn templateCol)
            {
                return templateCol.SortMemberPath ?? string.Empty;
            }
            return string.Empty;
        }

        private void UpdateSortPriorityBadges()
        {
            try
            {
                var view = CollectionViewSource.GetDefaultView(RulesDataGrid.ItemsSource);
                var sortCount = view?.SortDescriptions.Count ?? 0;

                // Build a map of sort column -> priority (1-based)
                var sortPriorities = new Dictionary<string, int>();
                if (view != null)
                {
                    for (int i = 0; i < view.SortDescriptions.Count; i++)
                    {
                        sortPriorities[view.SortDescriptions[i].PropertyName] = i + 1;
                    }
                }

                // Update each column's Tag for the priority badge
                foreach (var column in RulesDataGrid.Columns)
                {
                    string sortPath = GetColumnSortPath(column);

                    if (sortCount >= 2 && sortPriorities.TryGetValue(sortPath, out int priority))
                    {
                        // Multi-sort: show priority badge
                        SetColumnHeaderTag(column, priority.ToString());
                    }
                    else
                    {
                        // Single sort or unsorted: no badge
                        SetColumnHeaderTag(column, null);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateSortPriorityBadges ERROR: {ex.Message}");
            }
        }

        private void SetColumnHeaderTag(DataGridColumn column, object? tag)
        {
            // Find the DataGridColumnHeader in the visual tree
            var header = FindColumnHeader(column);
            if (header != null)
            {
                header.Tag = tag;
            }
        }

        private DataGridColumnHeader? FindColumnHeader(DataGridColumn column)
        {
            var headersPresenter = FindVisualChild<DataGridColumnHeadersPresenter>(RulesDataGrid);
            if (headersPresenter == null) return null;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(headersPresenter); i++)
            {
                var child = VisualTreeHelper.GetChild(headersPresenter, i);
                if (child is DataGridColumnHeader header && header.Column == column)
                {
                    return header;
                }
            }
            return null;
        }

        private static T? FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T result) return result;
                var found = FindVisualChild<T>(child);
                if (found != null) return found;
            }
            return null;
        }

        #endregion

        #region Search Filtering

        private void RulesSearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var filter = RulesSearchBox.Text?.Trim().ToLowerInvariant() ?? "";
            if (string.IsNullOrEmpty(filter))
            {
                RulesDataGrid.ItemsSource = _allRules;
            }
            else
            {
                RulesDataGrid.ItemsSource = _allRules
                    .Where(r => r.Pattern.ToLowerInvariant().Contains(filter) ||
                               (r.BrowserName?.ToLowerInvariant().Contains(filter) ?? false) ||
                               (r.ProfileName?.ToLowerInvariant().Contains(filter) ?? false))
                    .ToList();
            }
            RestoreSortState();
        }

        private void GroupsSearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var filter = GroupsSearchBox.Text?.Trim().ToLowerInvariant() ?? "";
            if (string.IsNullOrEmpty(filter))
            {
                UrlGroupsItemsControl.ItemsSource = _allGroups;
            }
            else
            {
                UrlGroupsItemsControl.ItemsSource = _allGroups
                    .Where(g => g.Name.ToLowerInvariant().Contains(filter) ||
                               (g.Description?.ToLowerInvariant().Contains(filter) ?? false) ||
                                g.UrlPatterns.Any(p => p.Pattern.ToLowerInvariant().Contains(filter)))
                    .ToList();
            }
        }

        private void ClearRulesSearch_Click(object sender, RoutedEventArgs e)
        {
            RulesSearchBox.Text = "";
            RulesSearchBox.Focus();
        }

        private void ClearGroupsSearch_Click(object sender, RoutedEventArgs e)
        {
            GroupsSearchBox.Text = "";
            GroupsSearchBox.Focus();
        }

        #endregion

        #region Pattern Testing

        private void TestUrlTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                TestUrl_Click(sender, e);
            }
        }

        private void TestUrl_Click(object sender, RoutedEventArgs e)
        {
            var url = TestUrlTextBox.Text?.Trim();
            if (string.IsNullOrEmpty(url))
            {
                ShowTestResult(null, "Enter a URL to test");
                return;
            }

            try
            {
                // Use the same matching logic as the actual URL handler (longest pattern wins)
                var match = UrlRuleManager.FindMatch(url);
                switch (match.Type)
                {
                    case MatchType.IndividualRule:
                        ShowTestResult(true, $"Matches rule: {match.Rule?.Pattern}");
                        break;
                    case MatchType.UrlGroup:
                        ShowTestResult(true, $"Matches group: {match.Group?.Name}");
                        break;
                    case MatchType.GroupOverride:
                        ShowTestResult(true, $"Matches group: {match.Group?.Name} (override: {match.Override?.UrlPattern})");
                        break;
                    default:
                        ShowTestResult(false, "No matching rule or group");
                        break;
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"TestUrl_Click ERROR: {ex.Message}");
                ShowTestResult(false, "Error testing URL");
            }
        }

        private void ShowTestResult(bool? isMatch, string message)
        {
            TestResultPanel.Visibility = Visibility.Visible;

            if (isMatch == null)
            {
                // Neutral state (e.g., empty input)
                TestResultIcon.Text = "\uE946"; // Info icon
                TestResultIcon.Foreground = (Brush)FindResource("TextSecondaryBrush");
                TestResultText.Foreground = (Brush)FindResource("TextSecondaryBrush");
            }
            else if (isMatch == true)
            {
                TestResultIcon.Text = "\uE73E"; // Checkmark
                TestResultIcon.Foreground = (Brush)FindResource("SuccessBrush");
                TestResultText.Foreground = (Brush)FindResource("SuccessBrush");
            }
            else
            {
                TestResultIcon.Text = "\uE711"; // X mark
                TestResultIcon.Foreground = (Brush)FindResource("DangerBrush");
                TestResultText.Foreground = (Brush)FindResource("DangerBrush");
            }

            TestResultText.Text = message;
        }

        #endregion
    }
}
