using System;
using System.Windows;
using System.Windows.Controls;
using PowerDroid.Services;
using PowerDroid; // SettingsManager, ConfirmationDialog (root namespace)

namespace PowerDroid.Controls
{
    /// <summary>
    /// Shared warning banner used across the Power Clip surfaces (Clip Settings page,
    /// Clip history page, and the compact clipboard popup). It surfaces a single warning
    /// with a fixed priority: clipboard monitoring disabled, then monitoring paused, then
    /// image storage almost full. Call <see cref="Refresh"/> whenever the host reloads.
    /// </summary>
    public partial class ClipWarningBanner : UserControl
    {
        private enum WarningKind { None, PowerClipDisabled, MonitoringDisabled, MonitoringPaused, StorageFull }

        private WarningKind _kind = WarningKind.None;

        /// <summary>
        /// When true, monitoring warnings are surfaced elsewhere (e.g. the compact window's
        /// centered "monitoring off" state), so this banner only renders the storage warning.
        /// Monitoring still takes priority: while monitoring is disabled/paused the banner
        /// stays hidden rather than dropping to a lower-priority storage warning.
        /// </summary>
        public bool HideMonitoringWarning { get; set; }

        /// <summary>Raised after the banner's action runs, so the host can refresh its data.</summary>
        public event EventHandler? Changed;

        public ClipWarningBanner()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Re-evaluates which warning (if any) to show. Priority: monitoring disabled,
        /// then monitoring paused, then image storage almost full.
        /// </summary>
        public void Refresh()
        {
            // Highest priority: the Power Clip feature itself is turned off. When off, capture
            // and the compact popup are disabled, so nothing else matters.
            if (!PowerClipService.Instance.IsEnabled)
            {
                if (HideMonitoringWarning)
                {
                    Hide();
                    return;
                }
                _kind = WarningKind.PowerClipDisabled;
                SetSeverity("CriticalBackgroundBrush", "CriticalBrush");
                TitleText.Text = "Power Clip is turned off";
                DescriptionText.Text = "Clipboard history isn't being captured and the popup shortcut is disabled.";
                ActionButton.Content = "Enable Power Clip";
                Root.Visibility = Visibility.Visible;
                return;
            }

            var monitoring = SettingsManager.LoadSettings().ClipboardMonitoring;
            bool monitoringIssue = !monitoring.IsEnabled || monitoring.IsPaused;

            if (monitoringIssue && HideMonitoringWarning)
            {
                // Monitoring has priority but is shown elsewhere; suppress the banner.
                Hide();
                return;
            }

            if (!monitoring.IsEnabled)
            {
                _kind = WarningKind.MonitoringDisabled;
                SetSeverity("CriticalBackgroundBrush", "CriticalBrush");
                TitleText.Text = "Clipboard monitoring is disabled";
                DescriptionText.Text = "Enable monitoring to start capturing clipboard history.";
                ActionButton.Content = "Enable Monitoring";
                Root.Visibility = Visibility.Visible;
                return;
            }

            if (monitoring.IsPaused)
            {
                var remaining = monitoring.RemainingPauseTime;
                _kind = WarningKind.MonitoringPaused;
                SetSeverity("CriticalBackgroundBrush", "CriticalBrush");
                TitleText.Text = "Clipboard monitoring is paused";
                DescriptionText.Text = remaining.HasValue
                    ? $"Monitoring will resume in {FormatRemainingTime(remaining.Value)}."
                    : "Monitoring is temporarily paused.";
                ActionButton.Content = "Resume Now";
                Root.Visibility = Visibility.Visible;
                return;
            }

            var storage = PowerClipService.Instance.GetImageStorageStatus();
            if (storage.NearFull)
            {
                _kind = WarningKind.StorageFull;
                SetSeverity("CautionBackgroundBrush", "CautionBrush");
                TitleText.Text = "Image storage is almost full";
                DescriptionText.Text = "New images may not be saved until you free up space.";
                ActionButton.Content = "Free up space";
                Root.Visibility = Visibility.Visible;
                return;
            }

            Hide();
        }

        private void Hide()
        {
            _kind = WarningKind.None;
            Root.Visibility = Visibility.Collapsed;
        }

        private void SetSeverity(string backgroundKey, string accentKey)
        {
            Root.SetResourceReference(Border.BackgroundProperty, backgroundKey);
            AccentStrip.SetResourceReference(Border.BackgroundProperty, accentKey);
            Icon.SetResourceReference(TextBlock.ForegroundProperty, accentKey);
        }

        private void ActionButton_Click(object sender, RoutedEventArgs e)
        {
            switch (_kind)
            {
                case WarningKind.PowerClipDisabled:
                    var pc = PowerClipService.Instance.GetSettings();
                    pc.IsEnabled = true;
                    PowerClipService.Instance.SaveSettings(pc);
                    break;

                case WarningKind.MonitoringDisabled:
                    var settings = SettingsManager.LoadSettings();
                    settings.ClipboardMonitoring.IsEnabled = true;
                    SettingsManager.SaveSettings(settings);
                    ClipboardMonitorService.Instance.Start();
                    TrayIconService.Instance.UpdateState();
                    break;

                case WarningKind.MonitoringPaused:
                    TrayIconService.Instance.Resume();
                    break;

                case WarningKind.StorageFull:
                    var confirmed = ConfirmationDialog.Show(
                        Window.GetWindow(this),
                        "Free Image Storage",
                        "This will permanently delete all clipboard images to free disk space.\nPinned images will be kept.",
                        "Clear images", "Cancel");
                    if (!confirmed) return;
                    PowerClipService.Instance.ClearAllImagesUnpinned();
                    break;

                default:
                    return;
            }

            Refresh();
            Changed?.Invoke(this, EventArgs.Empty);
        }

        private static string FormatRemainingTime(TimeSpan remaining)
        {
            if (remaining.TotalMinutes < 1) return "less than a minute";
            // Round minutes up so a fresh "5 minute" pause reads "5 minutes", not "4 minutes".
            int totalMin = (int)Math.Ceiling(remaining.TotalMinutes);
            if (totalMin < 60) return $"{totalMin} minutes";
            return $"{totalMin / 60}h {totalMin % 60}m";
        }
    }
}
