using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace PowerDroid.Services
{
    /// <summary>
    /// Launches a browser and forcibly brings it to the foreground,
    /// even when the user is in a fullscreen application.
    /// </summary>
    internal static class BrowserFocusHelper
    {
        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

        [DllImport("user32.dll")]
        private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

        [DllImport("user32.dll")]
        private static extern bool BringWindowToTop(IntPtr hWnd);

        [DllImport("kernel32.dll")]
        private static extern uint GetCurrentThreadId();

        [DllImport("user32.dll")]
        private static extern bool AllowSetForegroundWindow(int dwProcessId);

        [DllImport("user32.dll")]
        private static extern bool IsIconic(IntPtr hWnd);

        private const int SW_RESTORE = 9;
        private const int SW_SHOW = 5;

        /// <summary>
        /// Forces an already-existing window to the foreground using the AttachThreadInput trick.
        /// Used to restore the app that was active before a focus-stealing popup (e.g. the Power
        /// Clip window) so a synthesized Ctrl+V lands in the original editor's caret.
        /// </summary>
        internal static void FocusWindow(IntPtr hWnd)
        {
            if (hWnd == IntPtr.Zero) return;
            try { ForceForeground(hWnd); }
            catch (Exception ex) { Logger.Log($"BrowserFocusHelper: FocusWindow error: {ex.Message}"); }
        }

        /// <summary>
        /// Launches a browser process and aggressively focuses its window.
        /// Uses UseShellExecute=false to obtain a process handle, then
        /// applies the AttachThreadInput trick to bypass Windows foreground restrictions.
        /// </summary>
        internal static void LaunchAndFocus(string exePath, string arguments)
        {
            // Get the browser's process name to find its window later
            var processName = System.IO.Path.GetFileNameWithoutExtension(exePath);

            try
            {
                var process = Process.Start(new ProcessStartInfo
                {
                    FileName = exePath,
                    Arguments = arguments,
                    UseShellExecute = false
                });

                if (process != null)
                {
                    AllowSetForegroundWindow(process.Id);
                    Logger.Log($"BrowserFocusHelper: Launched PID {process.Id}, granted foreground permission");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserFocusHelper: UseShellExecute=false failed ({ex.Message}), falling back to shell execute");
                Process.Start(new ProcessStartInfo
                {
                    FileName = exePath,
                    Arguments = arguments,
                    UseShellExecute = true
                });
            }

            // Fire-and-forget: wait briefly for the browser window to appear, then force-focus it
            Task.Run(() => DelayedForceFocus(processName));
        }

        /// <summary>
        /// After a short delay, finds the browser's main window and forces it to the foreground.
        /// Browsers reuse existing processes, so we search by process name rather than PID.
        /// </summary>
        private static void DelayedForceFocus(string processName)
        {
            try
            {
                // Wait for the browser window to be ready
                // Two attempts: 500ms and 1200ms to handle both fast and slow scenarios
                for (int attempt = 0; attempt < 2; attempt++)
                {
                    Thread.Sleep(attempt == 0 ? 500 : 700);

                    var processes = Process.GetProcessesByName(processName);
                    foreach (var proc in processes)
                    {
                        try
                        {
                            var hWnd = proc.MainWindowHandle;
                            if (hWnd == IntPtr.Zero)
                                continue;

                            ForceForeground(hWnd);
                            Logger.Log($"BrowserFocusHelper: Focused window for {processName} (PID {proc.Id}, attempt {attempt + 1})");
                            return; // Success
                        }
                        catch
                        {
                            // Process may have exited
                        }
                    }
                }

                Logger.Log($"BrowserFocusHelper: Could not find main window for {processName} after retries");
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserFocusHelper: DelayedForceFocus error: {ex.Message}");
            }
        }

        /// <summary>
        /// Forces a window to the foreground using the AttachThreadInput trick.
        /// This bypasses Windows' restriction that only the foreground process can call SetForegroundWindow.
        /// By temporarily attaching our thread to the foreground thread's input queue,
        /// we gain the right to change the foreground window.
        /// </summary>
        private static void ForceForeground(IntPtr hWnd)
        {
            var foregroundWindow = GetForegroundWindow();
            var currentThreadId = GetCurrentThreadId();
            var foregroundThreadId = GetWindowThreadProcessId(foregroundWindow, out _);
            var targetThreadId = GetWindowThreadProcessId(hWnd, out _);

            // If the window is minimized, restore it first
            if (IsIconic(hWnd))
                ShowWindow(hWnd, SW_RESTORE);

            if (currentThreadId != foregroundThreadId)
            {
                // Attach our thread to the foreground thread's input queue
                AttachThreadInput(currentThreadId, foregroundThreadId, true);
                // Also attach to the target window's thread if different
                if (targetThreadId != foregroundThreadId)
                    AttachThreadInput(targetThreadId, foregroundThreadId, true);

                BringWindowToTop(hWnd);
                ShowWindow(hWnd, SW_SHOW);
                SetForegroundWindow(hWnd);

                // Detach
                AttachThreadInput(currentThreadId, foregroundThreadId, false);
                if (targetThreadId != foregroundThreadId)
                    AttachThreadInput(targetThreadId, foregroundThreadId, false);
            }
            else
            {
                BringWindowToTop(hWnd);
                ShowWindow(hWnd, SW_SHOW);
                SetForegroundWindow(hWnd);
            }
        }
    }
}
