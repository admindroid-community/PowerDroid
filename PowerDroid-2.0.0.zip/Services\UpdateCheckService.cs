using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;

namespace PowerDroid.Services
{
    public sealed class UpdateCheckService
    {
        private static UpdateCheckService? _instance;
        private static readonly object _lock = new();

        public static UpdateCheckService Instance
        {
            get
            {
                if (_instance == null)
                    lock (_lock)
                        _instance ??= new UpdateCheckService();
                return _instance;
            }
        }

        private static readonly HttpClient _httpClient = new()
        {
            Timeout = TimeSpan.FromSeconds(10)
        };

        static UpdateCheckService()
        {
            _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd($"PowerDroid/{BrandConfig.Version}");
        }

        public bool IsUpdateAvailable { get; private set; }
        public string LatestVersion { get; private set; } = string.Empty;
        public string ReleaseTitle { get; private set; } = string.Empty;
        public string ReleaseNotes { get; private set; } = string.Empty;
        public string ReleaseUrl { get; private set; } = string.Empty;
        public string InstallerUrl { get; private set; } = string.Empty;
        public long InstallerSizeBytes { get; private set; }
        public bool ShouldShowPopup { get; private set; }

        public event EventHandler? UpdateAvailable;

        /// <summary>
        /// Checks for updates. Uses a 24-hour cache to avoid excessive API calls.
        /// Silently fails on any error (no internet, API down, etc.).
        /// </summary>
        public async Task CheckForUpdatesAsync()
        {
            try
            {
                var settings = SettingsManager.LoadSettings();

                // Use cached result if checked within 24 hours
                if ((DateTime.UtcNow - settings.LastUpdateCheckTime).TotalHours < 24)
                {
                    ApplyCachedResult(settings);
                    return;
                }

                Logger.Log("UpdateCheck: Checking for updates...");

                if (!Version.TryParse(BrandConfig.Version, out var currentVersion))
                    return;

                // Fetch all releases (includes pre-releases)
                var apiUrl = BrandConfig.ReleasesApiUrl.Replace("/releases/latest", "/releases");
                var response = await _httpClient.GetStringAsync(apiUrl);
                using var doc = JsonDocument.Parse(response);

                // Find the newest release with a version greater than current
                Version? bestVersion = null;
                string bestVersionString = "";
                string bestTitle = "";
                string bestBody = "";
                string bestHtmlUrl = "";
                string bestInstallerUrl = "";
                long bestInstallerSize = 0;

                foreach (var release in doc.RootElement.EnumerateArray())
                {
                    var tagName = release.GetProperty("tag_name").GetString() ?? "";
                    var versionString = tagName.TrimStart('v');

                    if (!Version.TryParse(versionString, out var ver))
                    {
                        // Try parsing version from asset name (PowerDroidSetup-X.Y.Z.exe)
                        if (release.TryGetProperty("assets", out var assets))
                        {
                            foreach (var asset in assets.EnumerateArray())
                            {
                                var assetName = asset.GetProperty("name").GetString() ?? "";
                                var match = System.Text.RegularExpressions.Regex.Match(
                                    assetName, @"PowerDroidSetup-(\d+\.\d+\.\d+)\.exe");
                                if (match.Success && Version.TryParse(match.Groups[1].Value, out ver))
                                {
                                    versionString = match.Groups[1].Value;
                                    break;
                                }
                            }
                        }
                        if (ver == null) continue;
                    }

                    if (ver > currentVersion && (bestVersion == null || ver > bestVersion))
                    {
                        bestVersion = ver;
                        bestVersionString = versionString;
                        bestTitle = release.TryGetProperty("name", out var nameProp) ? nameProp.GetString() ?? "" : "";
                        bestBody = release.TryGetProperty("body", out var bodyProp) ? bodyProp.GetString() ?? "" : "";
                        bestHtmlUrl = release.TryGetProperty("html_url", out var urlProp) ? urlProp.GetString() ?? "" : "";

                        // Find the .exe installer asset
                        if (release.TryGetProperty("assets", out var releaseAssets))
                        {
                            foreach (var asset in releaseAssets.EnumerateArray())
                            {
                                var name = asset.GetProperty("name").GetString() ?? "";
                                if (name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
                                {
                                    bestInstallerUrl = asset.GetProperty("browser_download_url").GetString() ?? "";
                                    bestInstallerSize = asset.TryGetProperty("size", out var sizeProp) ? sizeProp.GetInt64() : 0;
                                    break;
                                }
                            }
                        }
                    }
                }

                // Update cache
                settings.LastUpdateCheckTime = DateTime.UtcNow;
                settings.LastKnownUpdateVersion = bestVersionString;
                settings.LastKnownReleaseTitle = bestTitle;
                settings.LastKnownReleaseNotes = bestBody;
                settings.LastKnownInstallerUrl = bestInstallerUrl;

                if (!string.IsNullOrEmpty(bestVersionString) &&
                    bestVersionString != settings.LastKnownUpdateVersion)
                    settings.HasSeenUpdatePopup = false;

                SettingsManager.SaveSettings(settings);

                if (bestVersion != null && bestVersionString != settings.SkippedUpdateVersion)
                {
                    LatestVersion = bestVersionString;
                    ReleaseTitle = bestTitle;
                    ReleaseNotes = StripMarkdown(bestBody);
                    ReleaseUrl = !string.IsNullOrEmpty(bestHtmlUrl) ? bestHtmlUrl : BrandConfig.ReleasesPageUrl;
                    InstallerUrl = bestInstallerUrl;
                    InstallerSizeBytes = bestInstallerSize;
                    IsUpdateAvailable = true;
                    ShouldShowPopup = !settings.HasSeenUpdatePopup;

                    Logger.Log($"UpdateCheck: Update available — v{bestVersionString} '{bestTitle}' (current: v{BrandConfig.Version})");
                    UpdateAvailable?.Invoke(this, EventArgs.Empty);
                }
                else
                {
                    Logger.Log($"UpdateCheck: Up to date (current: v{BrandConfig.Version})");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateCheck: Failed silently — {ex.Message}");
            }
        }

        /// <summary>
        /// Public method to apply cached update info on startup without an API call.
        /// </summary>
        public void ApplyCachedIfAvailable()
        {
            var settings = SettingsManager.LoadSettings();
            ApplyCachedResult(settings);
        }

        /// <summary>
        /// Applies cached update info without making an API call.
        /// </summary>
        private void ApplyCachedResult(AppSettings settings)
        {
            if (string.IsNullOrEmpty(settings.LastKnownUpdateVersion))
                return;

            if (!Version.TryParse(settings.LastKnownUpdateVersion, out var remoteVersion) ||
                !Version.TryParse(BrandConfig.Version, out var currentVersion))
                return;

            if (remoteVersion > currentVersion && settings.LastKnownUpdateVersion != settings.SkippedUpdateVersion)
            {
                LatestVersion = settings.LastKnownUpdateVersion;
                ReleaseTitle = settings.LastKnownReleaseTitle;
                ReleaseNotes = StripMarkdown(settings.LastKnownReleaseNotes);
                ReleaseUrl = BrandConfig.ReleasesPageUrl;
                InstallerUrl = settings.LastKnownInstallerUrl;
                IsUpdateAvailable = true;
                ShouldShowPopup = !settings.HasSeenUpdatePopup;

                Logger.Log($"UpdateCheck: Cached update available — v{LatestVersion}");
                UpdateAvailable?.Invoke(this, EventArgs.Empty);
            }
        }

        /// <summary>
        /// Marks the update popup as seen so it won't show again for this version.
        /// </summary>
        public void MarkPopupSeen()
        {
            ShouldShowPopup = false;
            var settings = SettingsManager.LoadSettings();
            settings.HasSeenUpdatePopup = true;
            SettingsManager.SaveSettings(settings);
        }

        /// <summary>
        /// Skips the current update version so it won't be shown again.
        /// </summary>
        public void SkipCurrentVersion()
        {
            IsUpdateAvailable = false;
            ShouldShowPopup = false;
            var settings = SettingsManager.LoadSettings();
            settings.SkippedUpdateVersion = LatestVersion;
            SettingsManager.SaveSettings(settings);
        }

        /// <summary>
        /// Downloads the installer to %TEMP% and launches it with /SILENT flag.
        /// The app exits and Inno Setup handles the rest.
        /// </summary>
        public async Task DownloadAndInstallAsync(IProgress<int>? progress = null)
        {
            if (string.IsNullOrEmpty(InstallerUrl))
            {
                // No direct download URL — open releases page in browser
                Logger.Log("UpdateCheck: No installer asset URL found, opening releases page");
                Process.Start(new ProcessStartInfo(BrandConfig.ReleasesPageUrl) { UseShellExecute = true });
                return;
            }

            // Save current version before update so the new version can show
            // "What's New" with correct "was vX.Y.Z" info
            var settings = SettingsManager.LoadSettings();
            settings.PreviousAppVersion = BrandConfig.Version;
            settings.HasSeenWhatsNew = false;
            settings.LastKnownReleaseNotes = ReleaseNotes;
            SettingsManager.SaveSettings(settings);

            var url = InstallerUrl;

            // Only ever download over HTTPS. GitHub release assets (and the Google Drive
            // fallback) are all HTTPS; refuse anything else outright.
            if (!Uri.TryCreate(url, UriKind.Absolute, out var installerUri) ||
                installerUri.Scheme != Uri.UriSchemeHttps)
            {
                Logger.Log($"SECURITY: Refusing non-HTTPS installer URL: {url}");
                throw new Exception("The update download link is not secure (HTTPS required).");
            }

            var fileName = $"PowerDroidSetup-{LatestVersion}.exe";
            var tempPath = Path.Combine(Path.GetTempPath(), fileName);

            // Delete any previous download
            try { if (File.Exists(tempPath)) File.Delete(tempPath); }
            catch (Exception ex) { Logger.Log($"UpdateCheck: Could not delete previous download: {ex.Message}"); }

            Logger.Log($"UpdateCheck: Downloading installer from {url}");

            // Google Drive may redirect or serve a confirmation page for large files.
            // Use a separate HttpClient with auto-redirect and cookies to handle this.
            using var handler = new HttpClientHandler
            {
                AllowAutoRedirect = true,
                UseCookies = true
            };
            using var client = new HttpClient(handler) { Timeout = TimeSpan.FromMinutes(5) };
            client.DefaultRequestHeaders.UserAgent.ParseAdd($"PowerDroid/{BrandConfig.Version}");

            // First request — may return the file or a confirmation page
            var response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();

            // Check if Google Drive returned an HTML confirmation page
            var contentType = response.Content.Headers.ContentType?.MediaType ?? "";
            if (contentType.Contains("text/html"))
            {
                // Read the HTML to find the confirm token
                var html = await response.Content.ReadAsStringAsync();
                var confirmUrl = ExtractGDriveConfirmUrl(html, url);
                if (!string.IsNullOrEmpty(confirmUrl))
                {
                    Logger.Log("UpdateCheck: Google Drive confirmation required, retrying...");
                    response.Dispose();
                    response = await client.GetAsync(confirmUrl, HttpCompletionOption.ResponseHeadersRead);
                    response.EnsureSuccessStatusCode();
                }
            }

            var totalBytes = response.Content.Headers.ContentLength ?? -1;
            long downloadedBytes = 0;

            using (var contentStream = await response.Content.ReadAsStreamAsync())
            using (var fileStream = new FileStream(tempPath, FileMode.Create, FileAccess.Write, FileShare.None, 8192, true))
            {
                var buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = await contentStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                {
                    await fileStream.WriteAsync(buffer, 0, bytesRead);
                    downloadedBytes += bytesRead;

                    if (totalBytes > 0)
                        progress?.Report((int)(downloadedBytes * 100 / totalBytes));
                }
            }
            response.Dispose();

            Logger.Log($"UpdateCheck: Downloaded {downloadedBytes / 1024} KB to {tempPath}");

            // Verify it's actually an exe (not an HTML error page)
            if (downloadedBytes < 50000)
            {
                Logger.Log("UpdateCheck: Downloaded file too small — likely not a valid installer");
                throw new Exception("Downloaded file appears invalid. Check the download URL.");
            }

            progress?.Report(100);

            // Brief pause so "Installing..." state is visible
            await Task.Delay(1500);

            // Verify the downloaded file carries a valid, trusted Authenticode signature
            // from our own publisher BEFORE running it. The installer elevates to admin,
            // so an unverified binary here would be elevated code execution. Doing this
            // check immediately before launch also closes the window in which a local
            // process could have swapped the file after download.
            if (!VerifyInstallerSignature(tempPath))
            {
                try { if (File.Exists(tempPath)) File.Delete(tempPath); }
                catch (Exception ex) { Logger.Log($"UpdateCheck: Could not delete unverified download: {ex.Message}"); }
                throw new Exception("The downloaded update could not be verified and was discarded. Please update from the releases page manually.");
            }

            // Launch installer silently and exit
            Logger.Log($"SECURITY: Signature verified, launching installer from {tempPath}, size={downloadedBytes} bytes");
            Process.Start(new ProcessStartInfo
            {
                FileName = tempPath,
                Arguments = "/SILENT",
                UseShellExecute = true
            });

            // Exit the app — Inno Setup will close it anyway via CloseApplications=yes
            Application.Current.Dispatcher.Invoke(() => Application.Current.Shutdown());
        }

        /// <summary>
        /// Verifies the file has a valid, trusted Authenticode signature and — when the
        /// running app is itself signed — that it was signed by the same publisher.
        /// Returns false on any doubt so an unverified installer is never run elevated.
        /// </summary>
        private static bool VerifyInstallerSignature(string filePath)
        {
            // Signature verification only protects signed production builds. An unsigned
            // dev/test build cannot anchor trust to a publisher and would otherwise be
            // unable to auto-update at all, so skip the check when we are not signed.
            // (An attacker cannot make a signed production exe report unsigned without
            // already having replaced it.)
            if (!BrandConfig.IsCodeSigned)
            {
                Logger.Log("UpdateCheck: Running build is unsigned (dev/test); skipping installer signature verification.");
                return true;
            }

            // 1. Authenticode trust check (chain + signature validity) via WinVerifyTrust.
            var fileInfo = new WINTRUST_FILE_INFO
            {
                cbStruct = (uint)Marshal.SizeOf<WINTRUST_FILE_INFO>(),
                pcwszFilePath = filePath,
                hFile = IntPtr.Zero,
                pgKnownSubject = IntPtr.Zero
            };
            IntPtr pFile = Marshal.AllocHGlobal(Marshal.SizeOf<WINTRUST_FILE_INFO>());
            IntPtr pData = IntPtr.Zero;
            try
            {
                Marshal.StructureToPtr(fileInfo, pFile, false);

                var data = new WINTRUST_DATA
                {
                    cbStruct = (uint)Marshal.SizeOf<WINTRUST_DATA>(),
                    dwUIChoice = WTD_UI_NONE,
                    fdwRevocationChecks = WTD_REVOKE_NONE,
                    dwUnionChoice = WTD_CHOICE_FILE,
                    pFile = pFile,
                    dwStateAction = WTD_STATEACTION_VERIFY,
                    dwProvFlags = WTD_SAFER_FLAG
                };
                pData = Marshal.AllocHGlobal(Marshal.SizeOf<WINTRUST_DATA>());
                Marshal.StructureToPtr(data, pData, false);

                uint result = WinVerifyTrust(IntPtr.Zero, WINTRUST_ACTION_GENERIC_VERIFY_V2, pData);

                // Always release the state data WinVerifyTrust allocated.
                data.dwStateAction = WTD_STATEACTION_CLOSE;
                Marshal.StructureToPtr(data, pData, true);
                WinVerifyTrust(IntPtr.Zero, WINTRUST_ACTION_GENERIC_VERIFY_V2, pData);

                if (result != 0)
                {
                    Logger.Log($"SECURITY: Installer Authenticode verification failed (0x{result:X8}) for {filePath}");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"SECURITY: Authenticode verification threw: {ex.Message}");
                return false;
            }
            finally
            {
                if (pData != IntPtr.Zero) Marshal.FreeHGlobal(pData);
                Marshal.FreeHGlobal(pFile);
            }

            // 2. Publisher match — anchor to the running app's own signer when available.
            try
            {
                var currentExe = Process.GetCurrentProcess().MainModule?.FileName;
                var appCert = TryGetSignerCertificate(currentExe);
                if (appCert != null)
                {
                    var installerCert = TryGetSignerCertificate(filePath);
                    if (installerCert == null ||
                        !string.Equals(appCert.Subject, installerCert.Subject, StringComparison.Ordinal))
                    {
                        Logger.Log("SECURITY: Installer publisher does not match the running app's publisher.");
                        return false;
                    }
                }
                else
                {
                    // Running app is unsigned (e.g. a dev build). We already required a
                    // trusted Authenticode signature above, which is the best we can do.
                    Logger.Log("UpdateCheck: Running app is unsigned; relying on Authenticode trust only.");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"SECURITY: Publisher comparison failed: {ex.Message}");
                return false;
            }

            return true;
        }

        private static X509Certificate? TryGetSignerCertificate(string? path)
        {
            if (string.IsNullOrEmpty(path) || !File.Exists(path)) return null;
            try { return X509Certificate.CreateFromSignedFile(path); }
            catch { return null; }
        }

        #region WinVerifyTrust interop

        private static readonly Guid WINTRUST_ACTION_GENERIC_VERIFY_V2 =
            new Guid("00AAC56B-CD44-11d0-8CC2-00C04FC295EE");

        private const uint WTD_UI_NONE = 2;
        private const uint WTD_REVOKE_NONE = 0;
        private const uint WTD_CHOICE_FILE = 1;
        private const uint WTD_STATEACTION_VERIFY = 1;
        private const uint WTD_STATEACTION_CLOSE = 2;
        private const uint WTD_SAFER_FLAG = 0x100;

        [DllImport("wintrust.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]
        private static extern uint WinVerifyTrust(IntPtr hwnd, [MarshalAs(UnmanagedType.LPStruct)] Guid pgActionID, IntPtr pWVTData);

        [StructLayout(LayoutKind.Sequential)]
        private struct WINTRUST_FILE_INFO
        {
            public uint cbStruct;
            [MarshalAs(UnmanagedType.LPWStr)] public string pcwszFilePath;
            public IntPtr hFile;
            public IntPtr pgKnownSubject;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct WINTRUST_DATA
        {
            public uint cbStruct;
            public IntPtr pPolicyCallbackData;
            public IntPtr pSIPClientData;
            public uint dwUIChoice;
            public uint fdwRevocationChecks;
            public uint dwUnionChoice;
            public IntPtr pFile;
            public uint dwStateAction;
            public IntPtr hWVTStateData;
            public IntPtr pwszURLReference;
            public uint dwProvFlags;
            public uint dwUIContext;
            public IntPtr pSignatureSettings;
        }

        #endregion

        /// <summary>
        /// Cleans up any leftover installer files from %TEMP% on startup.
        /// </summary>
        public static void CleanupOldInstallers()
        {
            try
            {
                var tempDir = Path.GetTempPath();
                foreach (var file in Directory.GetFiles(tempDir, "PowerDroidSetup-*.exe"))
                {
                    try
                    {
                        File.Delete(file);
                        Logger.Log($"UpdateCheck: Cleaned up {Path.GetFileName(file)}");
                    }
                    catch (Exception ex) { Logger.Log($"UpdateCheck: Could not delete {Path.GetFileName(file)}: {ex.Message}"); }
                }
            }
            catch (Exception ex) { Logger.Log($"UpdateCheck: Cleanup scan failed: {ex.Message}"); }
        }

        /// <summary>
        /// Strips common markdown syntax to produce clean plain text.
        /// </summary>
        /// <summary>
        /// Fetches the release notes for a specific version directly from GitHub (used by the
        /// "What's New" overlay on a manual install, when no online update check has cached them).
        /// Returns plain text, or empty string if there's no matching release / on any failure.
        /// </summary>
        public async Task<string> GetReleaseNotesForVersionAsync(string version)
        {
            try
            {
                var apiUrl = BrandConfig.ReleasesApiUrl.Replace("/releases/latest", "/releases");
                var response = await _httpClient.GetStringAsync(apiUrl);
                using var doc = JsonDocument.Parse(response);

                foreach (var release in doc.RootElement.EnumerateArray())
                {
                    var tag = (release.TryGetProperty("tag_name", out var t) ? t.GetString() : "")?.TrimStart('v') ?? "";
                    if (tag == version)
                    {
                        var body = release.TryGetProperty("body", out var b) ? b.GetString() ?? "" : "";
                        return StripMarkdown(body);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"GetReleaseNotesForVersionAsync error: {ex.Message}");
            }
            return string.Empty;
        }

        /// <summary>
        /// Reads the bundled CHANGELOG.md and returns the section for <paramref name="version"/>
        /// (the lines under "## [x.y.z]" up to the next "## " heading), as plain text. This is the
        /// final offline fallback for the "What's New" overlay. Empty if the section isn't found.
        /// </summary>
        public static string GetBundledChangelogNotes(string version)
        {
            try
            {
                var asm = System.Reflection.Assembly.GetExecutingAssembly();
                var resName = System.Array.Find(asm.GetManifestResourceNames(),
                    n => n.EndsWith("CHANGELOG.md", StringComparison.OrdinalIgnoreCase));
                if (resName == null) return string.Empty;

                using var stream = asm.GetManifestResourceStream(resName);
                if (stream == null) return string.Empty;
                using var reader = new StreamReader(stream);
                var content = reader.ReadToEnd();

                var sb = new System.Text.StringBuilder();
                bool inSection = false;
                foreach (var raw in content.Split('\n'))
                {
                    var line = raw.TrimEnd('\r');
                    if (line.StartsWith("## "))
                    {
                        if (inSection) break; // reached the next version's section
                        // Match "## [2.0.0] - date" or "## 2.0.0"
                        if (line.Contains($"[{version}]") || line.StartsWith($"## {version}"))
                            inSection = true;
                        continue; // skip the heading line itself
                    }
                    if (inSection) sb.Append(line).Append('\n');
                }

                return StripMarkdown(sb.ToString().Trim());
            }
            catch (Exception ex)
            {
                Logger.Log($"GetBundledChangelogNotes error: {ex.Message}");
                return string.Empty;
            }
        }

        public static string StripMarkdown(string md)
        {
            if (string.IsNullOrWhiteSpace(md)) return md;

            var text = md;
            // Remove headers (## Title → Title)
            text = System.Text.RegularExpressions.Regex.Replace(text, @"^#{1,6}\s*", "", System.Text.RegularExpressions.RegexOptions.Multiline);
            // Bold **text** or __text__
            text = System.Text.RegularExpressions.Regex.Replace(text, @"\*\*(.+?)\*\*", "$1");
            text = System.Text.RegularExpressions.Regex.Replace(text, @"__(.+?)__", "$1");
            // Italic *text* or _text_
            text = System.Text.RegularExpressions.Regex.Replace(text, @"\*(.+?)\*", "$1");
            text = System.Text.RegularExpressions.Regex.Replace(text, @"(?<!\w)_(.+?)_(?!\w)", "$1");
            // Inline code `text`
            text = System.Text.RegularExpressions.Regex.Replace(text, @"`(.+?)`", "$1");
            // Links [text](url) → text
            text = System.Text.RegularExpressions.Regex.Replace(text, @"\[(.+?)\]\(.+?\)", "$1");
            // Bullet lists - item → • item
            text = System.Text.RegularExpressions.Regex.Replace(text, @"^[-*]\s+", "\u2022 ", System.Text.RegularExpressions.RegexOptions.Multiline);
            // Collapse multiple blank lines
            text = System.Text.RegularExpressions.Regex.Replace(text, @"\n{3,}", "\n\n");

            return text.Trim();
        }

        /// <summary>
        /// Formats byte count as human-readable size.
        /// </summary>
        public static string FormatSize(long bytes)
        {
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F1} KB";
            return $"{bytes / (1024.0 * 1024.0):F1} MB";
        }

        /// <summary>
        /// Extracts the confirmation download URL from a Google Drive HTML page.
        /// Google Drive shows a "Download anyway" page for large/unscanned files.
        /// </summary>
        private static string? ExtractGDriveConfirmUrl(string html, string originalUrl)
        {
            // Look for the confirm link pattern in the HTML
            // Google Drive uses: /uc?export=download&confirm=TOKEN&id=FILE_ID
            var match = System.Text.RegularExpressions.Regex.Match(
                html, @"href=""(/uc\?export=download[^""]+)""");
            if (match.Success)
            {
                var path = match.Groups[1].Value.Replace("&amp;", "&");
                return "https://drive.google.com" + path;
            }

            // Alternative: look for action="URL" in form
            match = System.Text.RegularExpressions.Regex.Match(
                html, @"action=""(https://drive\.google\.com/uc\?[^""]+)""");
            if (match.Success)
                return match.Groups[1].Value.Replace("&amp;", "&");

            // Fallback: add confirm=t parameter
            return originalUrl + "&confirm=t";
        }

        /// <summary>
        /// Simulates an available update for testing purposes.
        /// </summary>
        public void SimulateUpdate()
        {
            LatestVersion = "99.0.0";
            ReleaseNotes = "## What's New in v99.0.0\n\n"
                + "- **Power Clip** — Persistent clipboard history with OCR text extraction\n"
                + "- **Smart Browse** improvements and bug fixes\n"
                + "- Performance and stability enhancements\n\n"
                + "This is a simulated update for testing the notification UI.";
            ReleaseUrl = BrandConfig.ReleasesPageUrl;
            IsUpdateAvailable = true;
            ShouldShowPopup = true;

            Logger.Log("UpdateCheck: Simulated update v99.0.0");
            UpdateAvailable?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Clears the simulated update state.
        /// </summary>
        public void ClearSimulatedUpdate()
        {
            IsUpdateAvailable = false;
            ShouldShowPopup = false;
            LatestVersion = string.Empty;
            ReleaseNotes = string.Empty;
            ReleaseUrl = string.Empty;
            Logger.Log("UpdateCheck: Cleared simulated update");
        }
    }
}
