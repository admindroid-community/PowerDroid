using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using PowerDroid.Services;

namespace PowerDroid
{
    /// <summary>
    /// Window for selecting a profile from a multi-profile rule or URL group
    /// </summary>
    public partial class RuleProfilePickerWindow : Window
    {
        private string _url;
        private UrlRule? _rule;
        private UrlGroup? _group;
        private List<RuleProfileDisplay> _displayProfiles;
        private bool _isGroupMode;

        /// <summary>
        /// Constructor for multi-profile URL rule
        /// </summary>
        public RuleProfilePickerWindow(string url, UrlRule rule)
        {
            InitializeComponent();
            SourceInitialized += (s, e) => ThemeManager.ApplyTitleBarTheme(this);

            _url = url;
            _rule = rule;
            _isGroupMode = false;

            LoadRuleData();
            UpdateOpenDefaultVisibility();
        }

        /// <summary>
        /// Constructor for multi-profile URL group
        /// </summary>
        public RuleProfilePickerWindow(string url, UrlGroup group)
        {
            InitializeComponent();
            SourceInitialized += (s, e) => ThemeManager.ApplyTitleBarTheme(this);

            _url = url;
            _group = group;
            _isGroupMode = true;

            LoadGroupData();
            UpdateOpenDefaultVisibility();
        }

        private void LoadRuleData()
        {
            // Display URL
            UrlTextBlock.Text = _url;

            // Display rule pattern
            RulePatternRun.Text = _rule!.Pattern;
            MatchedRuleTextBlock.ToolTip = $"Rule Name: {_rule.Pattern}";

            // Load profiles with display info
            _displayProfiles = _rule.Profiles
                .OrderBy(p => p.DisplayOrder)
                .Select(p => new RuleProfileDisplay
                {
                    Id = p.Id,
                    BrowserName = p.BrowserName,
                    BrowserPath = p.BrowserPath,
                    BrowserType = p.BrowserType,
                    ProfileName = p.ProfileName,
                    ProfilePath = p.ProfilePath,
                    ProfileArguments = p.ProfileArguments,
                    DisplayOrder = p.DisplayOrder,
                    CustomDisplayName = p.CustomDisplayName,
                    BrowserColor = BrowserService.BrowserColors.TryGetValue(p.BrowserName, out var color) ? color : "#666666",
                    BrowserIcon = BrowserIconService.GetBrowserIcon(p.BrowserPath)
                })
                .ToList();

            ProfilesItemsControl.ItemsSource = _displayProfiles;

            if (_displayProfiles.Count == 0)
            {
                ConfirmationDialog.ShowInfo(this, "Empty Rule", "No profiles found in this rule. Please add profiles to use multi-profile selection.");
            }
        }

        private void LoadGroupData()
        {
            // Display URL
            UrlTextBlock.Text = _url;

            // Update the label text to say "Grouped Rule:" instead of "URL Pattern:"
            MatchedRuleTextBlock.Inlines.Clear();
            MatchedRuleTextBlock.Inlines.Add(new Run("Grouped Rule: ") { FontWeight = FontWeights.SemiBold });
            MatchedRuleTextBlock.Inlines.Add(new Run(_group!.Name));
            MatchedRuleTextBlock.ToolTip = $"Grouped Rule: {_group.Name}";

            // Load profiles with display info
            _displayProfiles = _group.Profiles
                .OrderBy(p => p.DisplayOrder)
                .Select(p => new RuleProfileDisplay
                {
                    Id = p.Id,
                    BrowserName = p.BrowserName,
                    BrowserPath = p.BrowserPath,
                    BrowserType = p.BrowserType,
                    ProfileName = p.ProfileName,
                    ProfilePath = p.ProfilePath,
                    ProfileArguments = p.ProfileArguments,
                    DisplayOrder = p.DisplayOrder,
                    CustomDisplayName = p.CustomDisplayName,
                    BrowserColor = BrowserService.BrowserColors.TryGetValue(p.BrowserName, out var color) ? color : "#666666",
                    BrowserIcon = BrowserIconService.GetBrowserIcon(p.BrowserPath)
                })
                .ToList();

            ProfilesItemsControl.ItemsSource = _displayProfiles;

            if (_displayProfiles.Count == 0)
            {
                ConfirmationDialog.ShowInfo(this, "Empty Group", "No profiles found in this group. Please add profiles to use multi-profile selection.");
            }
        }

        private void Profile_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is FrameworkElement element && element.Tag is RuleProfileDisplay profile)
            {
                // Open browser with selected profile
                OpenBrowser(profile);

                // Close window
                Close();
            }
        }

        private void OpenBrowser(RuleProfileDisplay profile)
        {
            try
            {
                bool incognito = _isGroupMode ? (_group?.Incognito ?? false) : (_rule?.Incognito ?? false);
                Services.BrowserLaunchHelper.Launch(
                    profile.BrowserPath, profile.BrowserName, profile.BrowserType,
                    profile.ProfileArguments, _url, incognito);
                Logger.Log($"Opened {profile.BrowserName} with profile {profile.ProfileName} (incognito={incognito})");

                // Save last active browser/profile for future auto-selection
                var browserInfo = new BrowserInfo { Name = profile.BrowserName, ExecutablePath = profile.BrowserPath, Type = profile.BrowserType };
                var profileInfo = new ProfileInfo { Name = profile.ProfileName, Path = profile.ProfilePath, Arguments = profile.ProfileArguments };
                SettingsManager.UpdateLastActiveBrowser(browserInfo, profileInfo);
            }
            catch (Exception ex)
            {
                Logger.Log($"Error opening browser: {ex.Message}");
                ConfirmationDialog.ShowInfo(this, "Error", $"Failed to open browser:\n{ex.Message}");
            }
        }

        private void UpdateOpenDefaultVisibility()
        {
            var settings = SettingsManager.LoadSettings();
            OpenDefaultButton.Visibility = !string.IsNullOrEmpty(settings.DefaultBrowserPath)
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void OpenDefault_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var settings = SettingsManager.LoadSettings();
                var safeUrl = App.SanitizeUrlForArgument(_url);
                if (!string.IsNullOrEmpty(settings.DefaultBrowserPath))
                {
                    Services.BrowserFocusHelper.LaunchAndFocus(settings.DefaultBrowserPath, $"\"{safeUrl}\"");
                    Logger.Log($"Opened URL in fallback browser: {settings.DefaultBrowserName} ({settings.DefaultBrowserPath})");
                }
                else if (App.IsValidBrowseUrl(_url))
                {
                    Process.Start(new ProcessStartInfo { FileName = _url, UseShellExecute = true });
                    Logger.Log("Opened URL with system default browser");
                }
                else
                {
                    Logger.Log($"Rejected invalid URL from shell execution: {Logger.SanitizeUrl(_url)}");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"Error opening fallback browser: {ex.Message}");
            }
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

    /// <summary>
    /// Extended RuleProfile with display properties
    /// </summary>
    internal class RuleProfileDisplay : RuleProfile
    {
        public string BrowserColor { get; set; } = "#666666";
        public ImageSource? BrowserIcon { get; set; }

        /// <summary>
        /// Gets the display name - uses CustomDisplayName if set, otherwise defaults to "BrowserName - ProfileName"
        /// </summary>
        public new string DisplayName => !string.IsNullOrEmpty(CustomDisplayName)
            ? CustomDisplayName
            : (string.IsNullOrEmpty(ProfileName) ? BrowserName : $"{BrowserName} - {ProfileName}");

        /// <summary>
        /// Gets the browser/profile description (always shows "BrowserName - ProfileName")
        /// </summary>
        public new string BrowserProfileDescription => string.IsNullOrEmpty(ProfileName)
            ? BrowserName
            : $"{BrowserName} - {ProfileName}";
    }
}
