namespace PowerDroid.Models
{
    /// <summary>
    /// Snapshot of Power Clip image-storage usage, used by both the Clip Settings meter
    /// and the "almost full" warning banners so they always agree on one source of truth.
    /// </summary>
    public class ImageStorageStatus
    {
        /// <summary>Total bytes currently used by files in the clip-images folder.</summary>
        public long UsedBytes { get; set; }

        /// <summary>
        /// Effective ceiling = min(configured cap, used + drive free space). The folder can
        /// never grow past what the physical drive can actually hold.
        /// </summary>
        public long EffectiveCapBytes { get; set; }

        /// <summary>True when the drive's free space is the tighter limit (not the configured cap).</summary>
        public bool DiskLimited { get; set; }

        public double UsedMB { get; set; }
        public double EffectiveCapMB { get; set; }

        /// <summary>Used / EffectiveCap, clamped to 1.0.</summary>
        public double Ratio { get; set; }

        /// <summary>True when usage is at or above the near-full threshold (95%).</summary>
        public bool NearFull { get; set; }

        /// <summary>Count of unpinned image entries that "Free up space" can remove.</summary>
        public int ClearableImageCount { get; set; }
    }
}
