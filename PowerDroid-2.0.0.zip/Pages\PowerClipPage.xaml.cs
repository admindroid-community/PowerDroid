using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid.Pages
{
    public partial class PowerClipPage : UserControl
    {
        private List<ClipboardEntry> _allEntries = new List<ClipboardEntry>();
        private List<ClipboardEntry> _filteredEntries = new List<ClipboardEntry>();

        // Debounces search input so each keystroke doesn't rebuild the whole list.
        private DispatcherTimer? _searchDebounceTimer;
        private const int SEARCH_DEBOUNCE_MS = 200;

        public PowerClipPage()
        {
            InitializeComponent();
            Loaded += PowerClipPage_Loaded;
            Unloaded += PowerClipPage_Unloaded;
        }

        private void PowerClipPage_Loaded(object sender, RoutedEventArgs e)
        {
            PowerClipService.Instance.HistoryChanged += OnHistoryChanged;
            LoadData();
        }

        private void PowerClipPage_Unloaded(object sender, RoutedEventArgs e)
        {
            PowerClipService.Instance.HistoryChanged -= OnHistoryChanged;
        }

        private void OnHistoryChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(() => LoadData());
        }

        public void LoadData()
        {
            try
            {
                WarningBanner.Refresh();

                _allEntries = PowerClipService.Instance.GetEntries();
                PopulateAppFilter();
                ApplyFilters();

                if (EntriesListView.Items.Count > 0)
                    EntriesListView.ScrollIntoView(EntriesListView.Items[0]);

                ShortcutBadgeText.Text = HotkeyService.GetClipHotkeyDisplay();
            }
            catch (Exception ex)
            {
                Logger.Log($"PowerClipPage.LoadData ERROR: {ex.Message}");
            }
        }

        #region Warning Banner

        // The warning banner (monitoring + storage, with priority) lives in the shared
        // ClipWarningBanner control. After it runs an action, reload so the list/state reflect it.
        private void WarningBanner_Changed(object? sender, EventArgs e) => LoadData();

        #endregion

        #region Filtering

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Coalesce fast typing into a single filter pass ~200ms after the last keystroke.
            if (_searchDebounceTimer == null)
            {
                _searchDebounceTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(SEARCH_DEBOUNCE_MS) };
                _searchDebounceTimer.Tick += (_, _) => { _searchDebounceTimer!.Stop(); ApplyFilters(); };
            }
            _searchDebounceTimer.Stop();
            _searchDebounceTimer.Start();
        }

        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!IsLoaded) return;
            ApplyFilters();
        }

        private void AppFilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!IsLoaded) return;
            ApplyFilters();
        }

        private void PopulateAppFilter()
        {
            AppFilterComboBox.SelectionChanged -= AppFilterComboBox_SelectionChanged;
            var currentTag = (AppFilterComboBox.SelectedItem as ComboBoxItem)?.Tag as string;

            var apps = PowerClipService.Instance.GetSourceApps();

            AppFilterComboBox.Items.Clear();
            AppFilterComboBox.Items.Add(new ComboBoxItem { Content = "All Apps", Tag = "All" });
            foreach (var app in apps.OrderBy(kv => kv.Value, StringComparer.OrdinalIgnoreCase))
            {
                var tb = new TextBlock
                {
                    Text = app.Value,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    MaxWidth = 130
                };
                AppFilterComboBox.Items.Add(new ComboBoxItem { Content = tb, Tag = app.Key, ToolTip = app.Value });
            }

            // Restore previous selection if still valid
            var match = AppFilterComboBox.Items.OfType<ComboBoxItem>()
                .FirstOrDefault(i => i.Tag as string == currentTag);
            AppFilterComboBox.SelectedItem = match ?? AppFilterComboBox.Items[0];

            AppFilterComboBox.SelectionChanged += AppFilterComboBox_SelectionChanged;
        }

        private void ClearSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchBox.Text = string.Empty;
        }

        private void ApplyFilters()
        {
            if (EntriesListView == null) return;

            var entries = _allEntries.AsEnumerable();

            // Apply text search
            var searchText = SearchBox?.Text?.Trim();
            if (!string.IsNullOrEmpty(searchText))
            {
                entries = entries.Where(e =>
                    e.Content.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0);
            }

            // Apply type filter
            if (FilterComboBox?.SelectedItem is ComboBoxItem filterItem &&
                filterItem.Tag is string tag && tag != "All")
            {
                if (Enum.TryParse<ClipboardEntryType>(tag, out var entryType))
                {
                    entries = entries.Where(e => e.Type == entryType);
                }
            }

            // Apply app filter
            if (AppFilterComboBox?.SelectedItem is ComboBoxItem appItem &&
                appItem.Tag is string appTag && appTag != "All")
            {
                entries = entries.Where(e =>
                    string.Equals(e.SourceAppId, appTag, StringComparison.OrdinalIgnoreCase));
            }

            _filteredEntries = entries.ToList();
            RenderEntries();
            UpdateFooter(_filteredEntries.Count);
        }

        #endregion

        #region Rendering

        private void RenderEntries()
        {
            // Show empty or no-results state
            if (_allEntries.Count == 0)
            {
                EmptyState.Visibility = Visibility.Visible;
                NoResultsState.Visibility = Visibility.Collapsed;
                EntriesListView.Visibility = Visibility.Collapsed;
                EntriesListView.ItemsSource = null;
                return;
            }

            if (_filteredEntries.Count == 0)
            {
                EmptyState.Visibility = Visibility.Collapsed;
                NoResultsState.Visibility = Visibility.Visible;
                EntriesListView.Visibility = Visibility.Collapsed;
                EntriesListView.ItemsSource = null;
                return;
            }

            EmptyState.Visibility = Visibility.Collapsed;
            NoResultsState.Visibility = Visibility.Collapsed;
            EntriesListView.Visibility = Visibility.Visible;

            // Build flat list of UI elements — VirtualizingStackPanel handles rendering only visible ones
            var items = new List<UIElement>();

            var pinned = _filteredEntries.Where(e => e.IsPinned).OrderByDescending(e => e.Timestamp).ToList();
            var unpinned = _filteredEntries.Where(e => !e.IsPinned).OrderByDescending(e => e.Timestamp).ToList();
            var today = DateTime.Now.Date;
            var yesterday = today.AddDays(-1);

            if (pinned.Count > 0)
            {
                items.Add(CreateSectionHeader("Pinned"));
                foreach (var e in pinned) items.Add(CreateEntryCard(e));
            }

            var todayEntries = unpinned.Where(e => e.Timestamp.Date == today).ToList();
            if (todayEntries.Count > 0)
            {
                items.Add(CreateSectionHeader("Today"));
                foreach (var e in todayEntries) items.Add(CreateEntryCard(e));
            }

            var yesterdayEntries = unpinned.Where(e => e.Timestamp.Date == yesterday).ToList();
            if (yesterdayEntries.Count > 0)
            {
                items.Add(CreateSectionHeader("Yesterday"));
                foreach (var e in yesterdayEntries) items.Add(CreateEntryCard(e));
            }

            var olderEntries = unpinned.Where(e => e.Timestamp.Date < yesterday).ToList();
            if (olderEntries.Count > 0)
            {
                items.Add(CreateSectionHeader("Older"));
                foreach (var e in olderEntries) items.Add(CreateEntryCard(e));
            }

            EntriesListView.ItemsSource = items;
        }

        private UIElement CreateSectionHeader(string text)
        {
            var headerBlock = new TextBlock
            {
                Text = text,
                Margin = new Thickness(0, 8, 0, 8),
            };
            headerBlock.SetResourceReference(TextBlock.StyleProperty, "SectionHeaderStyle");
            return headerBlock;
        }

        private void EntriesListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // Placeholder — no action on double-click in full page
        }

        private UIElement CreateEntryCard(ClipboardEntry entry)
        {
            var card = new Border
            {
                CornerRadius = new CornerRadius(4),
                BorderThickness = new Thickness(1),
                MinHeight = 64,
                Padding = new Thickness(14, 10, 14, 10),
                Margin = new Thickness(0, 0, 0, 4),
                Cursor = Cursors.Arrow,
                Tag = entry.Id
            };
            card.SetResourceReference(Border.BackgroundProperty, "CardBackgroundBrush");
            card.SetResourceReference(Border.BorderBrushProperty, "CardStrokeBrush");

            // Subtle hover effect
            card.MouseEnter += (s, args) =>
            {
                card.SetResourceReference(Border.BackgroundProperty, "NavigationItemHoverBrush");
            };
            card.MouseLeave += (s, args) =>
            {
                card.SetResourceReference(Border.BackgroundProperty, "CardBackgroundBrush");
            };

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) });  // type icon
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });  // content
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) });  // timestamp
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) });  // actions

            // Type icon
            var typeIcon = new TextBlock
            {
                Text = GetTypeIcon(entry),
                FontSize = 14,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 10, 0),
            };
            typeIcon.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");
            typeIcon.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
            Grid.SetColumn(typeIcon, 0);
            grid.Children.Add(typeIcon);

            // Content — image preview or selectable text
            if (entry.Type == ClipboardEntryType.Image)
            {
                var imagePanel = new StackPanel { Margin = new Thickness(0, 0, 12, 0) };

                // Image preview
                try
                {
                    if (System.IO.File.Exists(entry.Content))
                    {
                        var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                        bitmap.BeginInit();
                        bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                        bitmap.UriSource = new Uri(entry.Content);
                        bitmap.DecodePixelHeight = 120;
                        bitmap.EndInit();
                        bitmap.Freeze();

                        var img = new Image
                        {
                            Source = bitmap,
                            MaxHeight = 120,
                            HorizontalAlignment = HorizontalAlignment.Left,
                            Stretch = Stretch.Uniform,
                            Margin = new Thickness(0, 4, 0, 4)
                        };
                        RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);
                        imagePanel.Children.Add(img);

                        // Dimensions + file size
                        var fileInfo = new System.IO.FileInfo(entry.Content);
                        var sizeText = fileInfo.Length < 1024 * 1024
                            ? $"{fileInfo.Length / 1024} KB"
                            : $"{fileInfo.Length / 1024.0 / 1024.0:F1} MB";

                        var infoText = new TextBlock
                        {
                            Text = $"{bitmap.PixelWidth}x{bitmap.PixelHeight} · {sizeText} · {System.IO.Path.GetExtension(entry.Content).TrimStart('.').ToUpper()}",
                            FontSize = 11,
                            Margin = new Thickness(0, 0, 0, 2)
                        };
                        infoText.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
                        imagePanel.Children.Add(infoText);
                    }
                    else
                    {
                        var missingText = new TextBlock { Text = "[Image file missing]", FontSize = 12, FontStyle = FontStyles.Italic };
                        missingText.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
                        imagePanel.Children.Add(missingText);
                    }
                }
                catch
                {
                    var errorText = new TextBlock { Text = "[Cannot load image]", FontSize = 12, FontStyle = FontStyles.Italic };
                    errorText.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
                    imagePanel.Children.Add(errorText);
                }

                // Source app + action links for images
                if (!string.IsNullOrEmpty(entry.SourceApp))
                {
                    imagePanel.Children.Add(CreateEntryInfoLine(entry));
                }

                Grid.SetColumn(imagePanel, 1);
                grid.Children.Add(imagePanel);
            }
            else
            {
                var contentPanel = new StackPanel
                {
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 12, 0)
                };

                var contentText = new TextBox
                {
                    Text = TruncateContent(entry.Content, 100),
                    IsReadOnly = true,
                    BorderThickness = new Thickness(0),
                    Background = Brushes.Transparent,
                    TextWrapping = TextWrapping.NoWrap,
                    FontSize = 13,
                    Padding = new Thickness(0),
                    Cursor = Cursors.IBeam,
                };
                contentText.SetResourceReference(TextBox.SelectionBrushProperty, "AccentBrush");

                contentText.SetResourceReference(TextBox.ForegroundProperty, "TextPrimaryBrush");

                contentPanel.Children.Add(contentText);

                // Source app + action links
                if (!string.IsNullOrEmpty(entry.SourceApp) ||
                    entry.Type == ClipboardEntryType.Url ||
                    entry.Type == ClipboardEntryType.FilePath)
                {
                    contentPanel.Children.Add(CreateEntryInfoLine(entry));
                }

                Grid.SetColumn(contentPanel, 1);
                grid.Children.Add(contentPanel);
            }

            // Relative timestamp
            var timestampText = new TextBlock
            {
                Text = FormatRelativeTime(entry.Timestamp),
                FontSize = 12,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 12, 0),
            };
            timestampText.SetResourceReference(TextBlock.StyleProperty, "CaptionTextStyle");
            timestampText.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
            Grid.SetColumn(timestampText, 2);
            grid.Children.Add(timestampText);

            // Action buttons
            var actionsPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center
            };

            // Copy button
            var copyBtn = CreateActionButton("\uE8C8", "Copy", entry.Id, CopyEntry_Click, "IconButtonBlueStyle");
            actionsPanel.Children.Add(copyBtn);

            // Extract Text (OCR) — Images only, and only when an OCR engine is available
            // (absent on Windows N/KN or without a language pack — would be a no-op button).
            if (entry.Type == ClipboardEntryType.Image && System.IO.File.Exists(entry.Content)
                && Services.OcrService.IsAvailable())
            {
                var ocrBtn = CreateActionButton("\uE8AC", "Extract Text", entry.Id, ExtractText_Click, "IconButtonBlueStyle");
                actionsPanel.Children.Add(ocrBtn);
            }

            // Pin/Unpin button: pinned uses the solid filled vector pushpin; not-pinned keeps the
            // original Segoe glyph. The tooltip conveys the pin/unpin action.
            var pinTooltip = entry.IsPinned ? "Unpin" : "Pin";
            var pinBtn = entry.IsPinned
                ? CreateActionButton("", pinTooltip, entry.Id, PinEntry_Click, "IconButtonOrangeStyle", ClipIcons.CreatePushpin())
                : CreateActionButton("\ue840", pinTooltip, entry.Id, PinEntry_Click, "IconButtonOrangeStyle");
            actionsPanel.Children.Add(pinBtn);

            // Delete button
            var deleteBtn = CreateActionButton("\uE74D", "Delete", entry.Id, DeleteEntry_Click, "IconButtonRedStyle");
            actionsPanel.Children.Add(deleteBtn);

            Grid.SetColumn(actionsPanel, 3);
            grid.Children.Add(actionsPanel);

            card.Child = grid;
            return card;
        }

        private static FrameworkElement CreateEntryInfoLine(ClipboardEntry entry)
        {
            var panel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 0)
            };

            // Source app
            if (!string.IsNullOrEmpty(entry.SourceApp))
            {
                var appName = string.IsNullOrEmpty(entry.SourceDetail)
                    ? entry.SourceApp!
                    : $"{entry.SourceApp} · {entry.SourceDetail}";

                var sourceText = new TextBlock
                {
                    Text = $"from {appName}",
                    FontSize = 10,
                };
                sourceText.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
                panel.Children.Add(sourceText);
            }

            // Action link — Open Link for URLs, Open Path for file paths
            string? actionText = null;
            string? actionTarget = null;

            if (entry.Type == ClipboardEntryType.Url)
            {
                actionText = "Open Link";
                actionTarget = entry.Content;
            }
            else if (entry.Type == ClipboardEntryType.FilePath)
            {
                actionText = "Open Path";
                // Normalize '/' to '\' so explorer.exe and the File/Directory checks accept
                // forward-slash paths (e.g. C:/Users/...) as well as native backslash paths.
                actionTarget = entry.Content.Replace('/', '\\');
            }

            // Validate before showing action link — only valid HTTP/HTTPS URLs or local paths (no UNC)
            bool isValidAction = false;
            if (entry.Type == ClipboardEntryType.Url && App.IsValidBrowseUrl(actionTarget ?? ""))
                isValidAction = true;
            else if (entry.Type == ClipboardEntryType.FilePath && actionTarget != null
                     && !actionTarget.StartsWith(@"\\") && (System.IO.File.Exists(actionTarget) || System.IO.Directory.Exists(actionTarget)))
                isValidAction = true;

            if (actionText != null && actionTarget != null && isValidAction)
            {
                if (panel.Children.Count > 0)
                {
                    var sep = new TextBlock
                    {
                        Text = " · ",
                        FontSize = 10,
                    };
                    sep.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
                    panel.Children.Add(sep);
                }

                var link = new TextBlock
                {
                    Text = actionText,
                    FontSize = 10,
                    Cursor = Cursors.Hand,
                    TextDecorations = TextDecorations.Underline,
                };
                link.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
                var target = actionTarget;
                var isFilePath = entry.Type == ClipboardEntryType.FilePath;
                link.MouseLeftButtonUp += (s, e) =>
                {
                    try
                    {
                        if (isFilePath)
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe") { Arguments = $"\"{target}\"", UseShellExecute = false });
                        else
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(target) { UseShellExecute = true });
                    }
                    catch (Exception ex) { Logger.Log($"Failed to open clipboard content: {ex.Message}"); }
                };
                panel.Children.Add(link);
            }

            return panel;
        }

        private Button CreateActionButton(string icon, string tooltip, string tag, RoutedEventHandler handler, string styleName, FrameworkElement? customContent = null)
        {
            var button = new Button
            {
                ToolTip = tooltip,
                Tag = tag,
                Margin = new Thickness(2, 0, 0, 0),
                Cursor = Cursors.Hand
            };
            button.SetResourceReference(Button.StyleProperty, styleName);
            button.Click += handler;

            // Vector icon (e.g. the pushpin Path) — used as-is when supplied.
            if (customContent != null)
            {
                button.Content = customContent;
                return button;
            }

            var iconBlock = new TextBlock
            {
                Text = icon,
                FontSize = 14
            };
            iconBlock.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");

            // Follow the parent button's Foreground (default color + hover accent from the style).
            var binding = new System.Windows.Data.Binding("Foreground")
            {
                RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.FindAncestor, typeof(Button), 1)
            };
            iconBlock.SetBinding(TextBlock.ForegroundProperty, binding);

            button.Content = iconBlock;
            return button;
        }

        #endregion

        #region Actions

        private void CopyEntry_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string id)
            {
                try
                {
                    var entry = _allEntries.FirstOrDefault(x => x.Id == id);
                    if (entry != null)
                    {
                        ClipboardMonitorService.Instance.SuppressNextCapture();
                        if (entry.Type == ClipboardEntryType.Image && System.IO.File.Exists(entry.Content))
                        {
                            if (entry.Content.EndsWith(".gif", StringComparison.OrdinalIgnoreCase))
                            {
                                // GIF: set as file drop (apps like Teams/Slack paste GIFs from file drops)
                                var data = new DataObject();
                                data.SetFileDropList(new System.Collections.Specialized.StringCollection { entry.Content });
                                // Also set raw GIF bytes for apps that support it
                                data.SetData("GIF", new System.IO.MemoryStream(System.IO.File.ReadAllBytes(entry.Content)));
                                // Also set as bitmap fallback
                                var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                                bitmap.BeginInit();
                                bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                                bitmap.UriSource = new Uri(entry.Content);
                                bitmap.EndInit();
                                data.SetImage(bitmap);
                                Clipboard.SetDataObject(data);
                            }
                            else
                            {
                                var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                                bitmap.BeginInit();
                                bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                                bitmap.UriSource = new Uri(entry.Content);
                                bitmap.EndInit();
                                Clipboard.SetImage(bitmap);
                            }
                        }
                        else
                        {
                            ClipboardWriter.SetTextEntry(entry);
                        }
                        Logger.Log($"PowerClipPage: Copied entry {id} to clipboard");

                        // Visual feedback: swap icon to checkmark for 1.5s
                        if (button.Content is TextBlock iconBlock)
                        {
                            var originalIcon = iconBlock.Text;
                            iconBlock.Text = "\uE73E"; // Checkmark
                            button.IsEnabled = false;

                            var timer = new System.Windows.Threading.DispatcherTimer
                            {
                                Interval = TimeSpan.FromMilliseconds(1500)
                            };
                            timer.Tick += (_, _) =>
                            {
                                timer.Stop();
                                iconBlock.Text = originalIcon;
                                button.IsEnabled = true;
                            };
                            timer.Start();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"PowerClipPage.CopyEntry ERROR: {ex.Message}");
                }
            }
        }

        private async void ExtractText_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string id)
            {
                try
                {
                    var entry = _allEntries.FirstOrDefault(x => x.Id == id);
                    if (entry == null || entry.Type != ClipboardEntryType.Image) return;

                    // Visual feedback: show processing
                    TextBlock? iconBlock = button.Content as TextBlock;
                    string? originalIcon = iconBlock?.Text;
                    if (iconBlock != null)
                    {
                        iconBlock.Text = "\uE916"; // Processing icon
                        button.IsEnabled = false;
                    }

                    // Use cached result if available
                    var text = entry.CachedOcrText
                        ?? await Services.OcrService.ExtractTextAsync(entry.Content);

                    if (!string.IsNullOrEmpty(text))
                    {
                        entry.CachedOcrText = text;
                        ClipboardMonitorService.Instance.SuppressNextCapture();
                        Clipboard.SetText(text);
                        PowerClipService.Instance.AddOcrText(text, entry);
                        Logger.Log($"PowerClipPage: Extracted text from image {id} ({text.Length} chars){(entry.CachedOcrText != null ? " (cached)" : "")}");

                        // Checkmark feedback
                        if (iconBlock != null)
                        {
                            iconBlock.Text = "\uE73E"; // Checkmark
                            var timer = new System.Windows.Threading.DispatcherTimer
                            {
                                Interval = TimeSpan.FromMilliseconds(1500)
                            };
                            timer.Tick += (_, _) =>
                            {
                                timer.Stop();
                                iconBlock.Text = originalIcon ?? "\uE8AC";
                                button.IsEnabled = true;
                            };
                            timer.Start();
                        }
                    }
                    else
                    {
                        // No text found feedback
                        if (iconBlock != null)
                        {
                            iconBlock.Text = "\uE711"; // X icon
                            button.ToolTip = "No text found";
                            var timer = new System.Windows.Threading.DispatcherTimer
                            {
                                Interval = TimeSpan.FromMilliseconds(1500)
                            };
                            timer.Tick += (_, _) =>
                            {
                                timer.Stop();
                                iconBlock.Text = originalIcon ?? "\uE8AC";
                                button.ToolTip = "Extract Text";
                                button.IsEnabled = true;
                            };
                            timer.Start();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"PowerClipPage.ExtractText ERROR: {ex}");
                }
            }
        }

        private void PinEntry_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string id)
            {
                try
                {
                    var entry = _allEntries.FirstOrDefault(x => x.Id == id);
                    if (entry != null)
                    {
                        if (entry.IsPinned)
                        {
                            PowerClipService.Instance.Unpin(id);
                            Logger.Log($"PowerClipPage: Unpinned entry {id}");
                        }
                        else
                        {
                            var pinnedCount = _allEntries.Count(x => x.IsPinned);
                            if (pinnedCount >= PowerClipService.MaxPinnedEntries)
                            {
                                ConfirmationDialog.ShowInfo(
                                    Window.GetWindow(this),
                                    "Pin Limit Reached",
                                    $"Maximum {PowerClipService.MaxPinnedEntries} pinned entries allowed.\nUnpin an existing entry first.");
                                return;
                            }
                            PowerClipService.Instance.Pin(id);
                            Logger.Log($"PowerClipPage: Pinned entry {id}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"PowerClipPage.PinEntry ERROR: {ex.Message}");
                }
            }
        }

        private void DeleteEntry_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string id)
            {
                try
                {
                    PowerClipService.Instance.Delete(id);
                    Logger.Log($"PowerClipPage: Deleted entry {id}");
                }
                catch (Exception ex)
                {
                    Logger.Log($"PowerClipPage.DeleteEntry ERROR: {ex.Message}");
                }
            }
        }

        // Main "Clear" split-button action: clears all unpinned entries in the current filtered view.
        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            PerformClear("All");
        }

        // Arrow-dropdown option (All / Older than N days).
        private void ClearOption_Click(object sender, RoutedEventArgs e)
        {
            ClearDropdownToggle.IsChecked = false;   // close the popup
            if (sender is Button btn && btn.Tag is string tag)
                PerformClear(tag);
        }

        private void PerformClear(string tag)
        {
            if (string.IsNullOrEmpty(tag)) return;

            // Target set = current filtered view, unpinned only (+ age cutoff for age tags).
            IEnumerable<ClipboardEntry> candidates = _filteredEntries.Where(en => !en.IsPinned);

            bool isAge = tag != "All";
            int days = 0;
            if (isAge)
            {
                days = int.Parse(tag);
                var cutoff = DateTime.Now.AddDays(-days);
                candidates = candidates.Where(en => en.Timestamp < cutoff);
            }

            var targetIds = candidates.Select(en => en.Id).ToList();
            var window = Window.GetWindow(this);

            if (targetIds.Count == 0)
            {
                ConfirmationDialog.ShowInfo(window, "Nothing to Clear",
                    BuildNothingToClearMessage(isAge, days));
                return;
            }

            var (title, message, confirmText) = BuildClearConfirmation(isAge, days, targetIds.Count);
            if (ConfirmationDialog.Show(window, title, message, confirmText, "Cancel"))
            {
                try
                {
                    PowerClipService.Instance.DeleteMany(targetIds);
                    Logger.Log($"PowerClipPage: Cleared {targetIds.Count} entries (tag={tag}, filtered={HasActiveFilters()})");
                }
                catch (Exception ex)
                {
                    Logger.Log($"PowerClipPage.ClearHistory ERROR: {ex.Message}");
                }
            }
        }

        private bool HasActiveFilters()
        {
            if (!string.IsNullOrEmpty(SearchBox?.Text?.Trim())) return true;
            if (FilterComboBox?.SelectedItem is ComboBoxItem t && t.Tag is string tt && tt != "All") return true;
            if (AppFilterComboBox?.SelectedItem is ComboBoxItem a && a.Tag is string at && at != "All") return true;
            return false;
        }

        /// <summary>Human-readable list of active filters, e.g. "Type: URLs", "App: Chrome", "Search: \"foo\"".</summary>
        private List<string> DescribeActiveFilters()
        {
            var parts = new List<string>();
            if (FilterComboBox?.SelectedItem is ComboBoxItem t && t.Tag is string tt && tt != "All")
                parts.Add($"Type: {t.Content?.ToString() ?? tt}");
            if (AppFilterComboBox?.SelectedItem is ComboBoxItem a && a.Tag is string at && at != "All")
                parts.Add($"App: {(a.Content as TextBlock)?.Text ?? a.ToolTip?.ToString() ?? "selected app"}");
            var search = SearchBox?.Text?.Trim();
            if (!string.IsNullOrEmpty(search)) parts.Add($"Search: \"{search}\"");
            return parts;
        }

        private (string title, string message, string confirmText) BuildClearConfirmation(bool isAge, int days, int count)
        {
            var noun = count == 1 ? "entry" : "entries";
            var sb = new StringBuilder();
            if (HasActiveFilters())
            {
                var scope = isAge
                    ? $"older than {days} day{(days == 1 ? "" : "s")} matching your current filters"
                    : "matching your current filters";
                sb.AppendLine($"This will clear {count} {noun} {scope}.");
                sb.AppendLine();
                sb.AppendLine("Active filters:");
                foreach (var f in DescribeActiveFilters()) sb.AppendLine($"  • {f}");
                sb.AppendLine();
            }
            else
            {
                sb.AppendLine(isAge
                    ? $"This will clear {count} {noun} older than {days} day{(days == 1 ? "" : "s")}."
                    : $"This will clear all {count} {noun} in your clipboard history.");
                sb.AppendLine();
            }
            sb.AppendLine("Pinned entries will be kept.");
            sb.Append("This action cannot be undone.");

            var confirmText = HasActiveFilters() ? "Clear Filtered" : (isAge ? "Clear" : "Clear All");
            return ("Clear Clipboard History", sb.ToString(), confirmText);
        }

        private string BuildNothingToClearMessage(bool isAge, int days)
        {
            if (HasActiveFilters())
                return "No unpinned entries match your current filters" +
                       (isAge ? $" and are older than {days} day{(days == 1 ? "" : "s")}." : ".");
            return isAge
                ? $"No unpinned entries are older than {days} day{(days == 1 ? "" : "s")}."
                : "There are no unpinned entries to clear.";
        }

        #endregion

        #region Helpers

        private void UpdateFooter(int displayedCount)
        {
            var total = _allEntries.Count;
            var maxEntries = PowerClipService.Instance.GetSettings().MaxEntries;

            FooterText.Text = maxEntries > 0 ? $"{total}/{maxEntries}" : $"{total}";
        }

        private static string TruncateContent(string content, int maxLength)
        {
            if (string.IsNullOrEmpty(content)) return string.Empty;

            // Replace newlines with spaces for display
            var singleLine = content.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");

            if (singleLine.Length <= maxLength) return singleLine;
            return singleLine.Substring(0, maxLength) + "...";
        }

        private static string FormatRelativeTime(DateTime timestamp)
        {
            var diff = DateTime.Now - timestamp;

            if (diff.TotalSeconds < 60)
                return "Just now";
            if (diff.TotalMinutes < 60)
                return $"{(int)diff.TotalMinutes}m ago";
            if (diff.TotalHours < 24)
                return $"{(int)diff.TotalHours}h ago";
            if (diff.TotalDays < 2)
                return "Yesterday";
            if (diff.TotalDays < 7)
                return $"{(int)diff.TotalDays} days ago";
            if (diff.TotalDays < 30)
                return $"{(int)(diff.TotalDays / 7)} weeks ago";

            return timestamp.ToString("MMM d");
        }

        private static string GetTypeIcon(ClipboardEntry entry)
        {
            return entry.Type switch
            {
                ClipboardEntryType.Url => "\uE71B",       // Globe/Link icon
                ClipboardEntryType.FilePath => "\uE8B7",   // Folder icon
                ClipboardEntryType.Image => "\uE8B9",      // Image icon
                ClipboardEntryType.Text => "\uE8C1",       // Document icon
                _ => "\uE8C1"
            };
        }

        #endregion
    }
}
