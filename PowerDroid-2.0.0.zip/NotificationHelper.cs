﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using PowerDroid.Services;
using Microsoft.Win32;

namespace PowerDroid
{
    public static class NotificationHelper
    {
        private static string? _lastUrl = null;

        /// <summary>
        /// Detects if Windows is using a light app theme by reading the registry.
        /// </summary>
        public static bool IsSystemLightTheme()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                var value = key?.GetValue("AppsUseLightTheme");
                return value is int intVal && intVal == 1;
            }
            catch
            {
                return false; // Default to dark theme on error
            }
        }
        public static void ShowNotification(string url,Action MainWindowShow)
        {
            Logger.Log($"Notification open: {Logger.SanitizeUrl(url)}");

            try
            {
                _lastUrl = url;

                // Extract domain for display
                string displayText;
                try
                {
                    var uri = new Uri(url);
                    displayText = uri.Host;
                }
                catch
                {
                    displayText = url.Length > 50 ? url.Substring(0, 47) + "..." : url;
                }

                // Show custom notification
                Logger.Log($"{displayText} Notification open start");
                Application.Current.Dispatcher.Invoke(() =>
                {
                    var notification = new CustomNotificationWindow(displayText, url, MainWindowShow);
                    notification.Show();
                });
            }
            catch (Exception ex)
            {
                Logger.Log($"Notification failed: {ex.Message}");
            }
        }

        public static void ShowDisabledMatchNotification(string url, string matchName, string matchType, Action runAction, Action enableAction)
        {
            Logger.Log($"Disabled match notification: {Logger.SanitizeUrl(url)} (disabled {matchType}: {matchName})");

            try
            {
                string displayText;
                try
                {
                    var uri = new Uri(url);
                    displayText = uri.Host;
                }
                catch
                {
                    displayText = url.Length > 50 ? url.Substring(0, 47) + "..." : url;
                }

                Application.Current.Dispatcher.Invoke(() =>
                {
                    var notification = new DisabledMatchNotificationWindow(displayText, matchName, matchType, runAction, enableAction);
                    notification.Show();
                });
            }
            catch (Exception ex)
            {
                Logger.Log($"Disabled match notification failed: {ex.Message}");
            }
        }

        private static void OpenRuleCreator(string url, Action MainWindowShow)
        {
            try
            {
                // Extract domain for rule pattern
                string pattern;
                try
                {
                    var uri = new Uri(url);
                    pattern = uri.Host;
                }
                catch
                {
                    pattern = url;
                }

                // Open AddRuleWindow with pre-filled pattern
                var addRuleWindow = new AddRuleWindow(pattern, url);
                addRuleWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;

                if (addRuleWindow.ShowDialog() == true)
                {
                    // Rule was created - reuse existing SettingsWindow or create new one
                    var settingsWindow = System.Windows.Application.Current.Windows
                        .OfType<SettingsWindow>()
                        .FirstOrDefault();

                    if (settingsWindow != null)
                    {
                        settingsWindow.NavigateToRules();
                        settingsWindow.WindowState = WindowState.Normal;
                        settingsWindow.Activate();
                    }
                    else
                    {
                        settingsWindow = new SettingsWindow();
                        settingsWindow.NavigateToRules();
                        settingsWindow.Closed += (s, args) =>
                        {
                            Logger.Log("SettingsWindow closed (from notification)");
                            AppLifecycleService.ShutdownOrStayInBackground("Rule created - settings closed");
                        };
                        settingsWindow.Show();
                    }
                }
                else
                {
                    // User cancelled
                    AppLifecycleService.ShutdownOrStayInBackground("Rule creation cancelled");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"OpenRuleCreator error: {ex.Message}");
            }
        }

        // Custom notification window
        private class CustomNotificationWindow : Window
        {
            private DispatcherTimer _autoCloseTimer;
            private readonly string _url;
            private const int NOTIFICATION_TIMEOUT = 8000; // 8 seconds
            private bool ruleWindowOpen = false;
            private Border? _progressBar;
            private double _progressBarWidth;
            private DateTime _animationStartTime;
            private double _remainingTime;
            private bool _positioned;

            public CustomNotificationWindow(string displayText, string url, Action MainWindowShow)
            {
                _url = url;
                _remainingTime = NOTIFICATION_TIMEOUT;

                // Window properties
                WindowStyle = WindowStyle.None;
                AllowsTransparency = true;
                Background = Brushes.Transparent;
                ResizeMode = ResizeMode.NoResize;
                ShowInTaskbar = false;
                Topmost = true;
                Width = 380;
                SizeToContent = SizeToContent.Height; // Dynamic height based on content
                WindowStartupLocation = WindowStartupLocation.Manual;
                // Born on the primary at (0,0) so SizeToContent measures at the primary's DPI and the
                // toast never does a cross-monitor DPI move before it's positioned (which is what made
                // it split across displays). (0,0) is always the primary monitor's origin.
                Left = 0;
                Top = 0;
                Opacity = 0; // Hidden until positioned in ContentRendered (avoids a flash at 0,0)

                // Create UI first (needed for SizeToContent)
                Content = CreateNotificationContent(displayText, MainWindowShow);

                // Setup auto-close timer
                _autoCloseTimer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromMilliseconds(NOTIFICATION_TIMEOUT)
                };
                _autoCloseTimer.Tick += (s, e) => CloseNotification();

                // Position and animate once content is fully rendered. SizeToContent height
                // is only final at ContentRendered (not Loaded), so positioning in Loaded
                // used a stale height and left the toast floating above the taskbar.
                ContentRendered += (s, e) =>
                {
                    if (_positioned) return;
                    _positioned = true;

                    // Bottom-right of the primary monitor, sized for its DPI (see ToastPositioner).
                    ToastPositioner.PositionBottomRight(this);

                    AnimateIn();
                    StartProgressBarAnimation();
                    _autoCloseTimer.Start();
                    _animationStartTime = DateTime.Now;
                };

                // Pause timer and animation on mouse enter
                MouseEnter += (s, e) =>
                {
                    _autoCloseTimer.Stop();
                    _remainingTime -= (DateTime.Now - _animationStartTime).TotalMilliseconds;
                    if (_remainingTime < 0) _remainingTime = 0;
                    _progressBar?.BeginAnimation(WidthProperty, null);
                };

                // Resume timer and animation on mouse leave
                MouseLeave += (s, e) =>
                {
                    if (_remainingTime > 0)
                    {
                        _autoCloseTimer.Interval = TimeSpan.FromMilliseconds(_remainingTime);
                        _autoCloseTimer.Start();
                        _animationStartTime = DateTime.Now;
                        ResumeProgressBarAnimation();
                    }
                };
                Logger.Log("Notification constructor end");
            }

            private Border CreateNotificationContent(string displayText, Action MainWindowShow)
            {
                bool isLight = !ThemeManager.IsDarkTheme;

                var mainBorder = new Border
                {
                    Background = new SolidColorBrush(isLight
                        ? Color.FromRgb(252, 252, 252)          // Light: Win11 white card
                        : Color.FromArgb(230, 28, 28, 32)),    // Dark: frosted dark
                    BorderBrush = new SolidColorBrush(isLight
                        ? Color.FromArgb(30, 0, 0, 0)           // Light: barely visible border
                        : Color.FromArgb(50, 255, 255, 255)),   // Dark: subtle white glow
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(8),
                    Margin = new Thickness(10),
                    Effect = new System.Windows.Media.Effects.DropShadowEffect
                    {
                        Color = Color.FromRgb(0, 0, 0),
                        Opacity = isLight ? 0.08 : 0.5,
                        BlurRadius = isLight ? 20 : 32,
                        ShadowDepth = isLight ? 2 : 4,
                        Direction = 270
                    }
                };

                var grid = new Grid();
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Header
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Status
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // URL
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Context
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Button
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Progress bar

                // Header with icon, title and close button
                var headerGrid = new Grid { Margin = new Thickness(14, 12, 12, 4) };
                headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // Icon
                headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // Title
                headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // Close

                // App icon - using pack URI like SettingsWindow
                var appIcon = new Image
                {
                    Width = 20,
                    Height = 20,
                    Margin = new Thickness(0, 0, 10, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                try
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri("pack://application:,,,/Assets/Icons/favicon-32x32.png", UriKind.Absolute);
                    bitmap.DecodePixelWidth = 32;
                    bitmap.DecodePixelHeight = 32;
                    bitmap.EndInit();
                    appIcon.Source = bitmap;
                    RenderOptions.SetBitmapScalingMode(appIcon, BitmapScalingMode.HighQuality);
                }
                catch { /* Ignore icon loading errors */ }
                Grid.SetColumn(appIcon, 0);

                var titleText = new TextBlock
                {
                    Text = BrandConfig.AppDisplayName,
                    FontWeight = FontWeights.SemiBold,
                    FontSize = 13,
                    Foreground = new SolidColorBrush(isLight ? Color.FromRgb(51, 51, 51) : Color.FromRgb(255, 255, 255)),
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetColumn(titleText, 1);

                var closeButton = CreateCloseButton(isLight);
                closeButton.Click += (s, e) => CloseNotification();
                Grid.SetColumn(closeButton, 2);

                headerGrid.Children.Add(appIcon);
                headerGrid.Children.Add(titleText);
                headerGrid.Children.Add(closeButton);
                Grid.SetRow(headerGrid, 0);

                // Status line with checkmark
                var statusPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(16, 4, 16, 2)
                };
                var greenColor = isLight ? Color.FromRgb(46, 125, 50) : Color.FromRgb(76, 175, 80);
                var checkmark = new TextBlock
                {
                    Text = "\u2713",
                    FontSize = 12,
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(greenColor),
                    Margin = new Thickness(0, 0, 6, 0)
                };
                var statusText = new TextBlock
                {
                    Text = "Opened in fallback browser",
                    FontSize = 12,
                    Foreground = new SolidColorBrush(greenColor)
                };
                statusPanel.Children.Add(checkmark);
                statusPanel.Children.Add(statusText);
                Grid.SetRow(statusPanel, 1);

                // URL display
                var urlText = new TextBlock
                {
                    Text = displayText,
                    FontSize = 13,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(isLight ? Color.FromRgb(0, 120, 212) : Color.FromRgb(100, 181, 246)),
                    TextWrapping = TextWrapping.NoWrap,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    Margin = new Thickness(16, 4, 16, 4)
                };
                Grid.SetRow(urlText, 2);

                // Context text
                var contextText = new TextBlock
                {
                    Text = "Want this site to always open in a specific browser profile?",
                    FontSize = 11,
                    Foreground = new SolidColorBrush(isLight ? Color.FromRgb(102, 102, 102) : Color.FromRgb(180, 180, 180)),
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(16, 2, 16, 12)
                };
                Grid.SetRow(contextText, 3);

                // Action button
                var buttonPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Margin = new Thickness(16, 4, 16, 14)
                };

                var createRuleButton = CreateStyledButton("Create Rule");
                createRuleButton.Click += (s, e) =>
                {
                    ruleWindowOpen = true;           // Set FIRST to prevent shutdown
                    _autoCloseTimer?.Stop();         // Stop timer to prevent race condition
                    CloseNotification();             // Close notification immediately
                    OpenRuleCreator(_url, MainWindowShow);  // Then open the rule window
                };
                buttonPanel.Children.Add(createRuleButton);
                Grid.SetRow(buttonPanel, 4);

                // Progress bar container - hidden for now
                var progressContainer = new Border
                {
                    Background = new SolidColorBrush(isLight ? Color.FromArgb(40, 0, 0, 0) : Color.FromArgb(40, 255, 255, 255)),
                    Height = 4,
                    CornerRadius = new CornerRadius(2),
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    Margin = new Thickness(16, 8, 16, 16),
                    ClipToBounds = true,
                    Visibility = Visibility.Collapsed // Hidden for now
                };

                _progressBarWidth = 348; // Full width minus margins (380 - 16 - 16)
                _progressBar = new Border
                {
                    Background = new LinearGradientBrush(
                        Color.FromRgb(0, 120, 212),
                        Color.FromRgb(0, 150, 255),
                        0),
                    Height = 4,
                    Width = _progressBarWidth,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    CornerRadius = new CornerRadius(2)
                };
                progressContainer.Child = _progressBar;
                Grid.SetRow(progressContainer, 5);

                grid.Children.Add(headerGrid);
                grid.Children.Add(statusPanel);
                grid.Children.Add(urlText);
                grid.Children.Add(contextText);
                grid.Children.Add(buttonPanel);
                grid.Children.Add(progressContainer);

                mainBorder.Child = grid;
                return mainBorder;
            }

            private void AnimateIn()
            {
                // Slide left into place with a fade. Keep the offset small so the window's majority
                // stays on the primary monitor for the whole slide — animating Left fully across a
                // monitor boundary is what mispositioned/split the toast under PerMonitorV2.
                double restLeft = Left;
                var slideLeft = new DoubleAnimation
                {
                    From = restLeft + 48,
                    To = restLeft,
                    Duration = TimeSpan.FromMilliseconds(350),
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                };

                var fadeIn = new DoubleAnimation
                {
                    From = 0,
                    To = 1,
                    Duration = TimeSpan.FromMilliseconds(250)
                };

                BeginAnimation(LeftProperty, slideLeft);
                BeginAnimation(OpacityProperty, fadeIn);
            }

            private void StartProgressBarAnimation()
            {
                if (_progressBar == null) return;

                var animation = new DoubleAnimation
                {
                    From = _progressBarWidth,
                    To = 0,
                    Duration = TimeSpan.FromMilliseconds(NOTIFICATION_TIMEOUT)
                };
                _progressBar.BeginAnimation(WidthProperty, animation);
            }

            private void ResumeProgressBarAnimation()
            {
                if (_progressBar == null || _remainingTime <= 0) return;

                var currentWidth = _progressBar.ActualWidth > 0 ? _progressBar.ActualWidth : (_progressBarWidth * _remainingTime / NOTIFICATION_TIMEOUT);
                var animation = new DoubleAnimation
                {
                    From = currentWidth,
                    To = 0,
                    Duration = TimeSpan.FromMilliseconds(_remainingTime)
                };
                _progressBar.BeginAnimation(WidthProperty, animation);
            }

            private Button CreateCloseButton(bool isLight = false)
            {
                var button = new Button
                {
                    Content = "✕",
                    Width = 24,
                    Height = 24,
                    FontSize = 11,
                    Cursor = System.Windows.Input.Cursors.Hand,
                    VerticalAlignment = VerticalAlignment.Top
                };

                var template = new ControlTemplate(typeof(Button));

                var borderFactory = new FrameworkElementFactory(typeof(Border));
                borderFactory.Name = "border";
                borderFactory.SetValue(Border.BackgroundProperty, Brushes.Transparent);
                borderFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(4));

                var contentPresenterFactory = new FrameworkElementFactory(typeof(ContentPresenter));
                contentPresenterFactory.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
                contentPresenterFactory.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);

                borderFactory.AppendChild(contentPresenterFactory);
                template.VisualTree = borderFactory;

                // Hover - grey background
                var hoverTrigger = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
                hoverTrigger.Setters.Add(new Setter(Border.BackgroundProperty,
                    new SolidColorBrush(isLight ? Color.FromArgb(26, 0, 0, 0) : Color.FromArgb(60, 255, 255, 255)), "border"));
                template.Triggers.Add(hoverTrigger);

                // Pressed - darker grey
                var pressedTrigger = new Trigger { Property = Button.IsPressedProperty, Value = true };
                pressedTrigger.Setters.Add(new Setter(Border.BackgroundProperty,
                    new SolidColorBrush(isLight ? Color.FromArgb(50, 0, 0, 0) : Color.FromArgb(100, 255, 255, 255)), "border"));
                template.Triggers.Add(pressedTrigger);

                button.Template = template;
                button.Foreground = new SolidColorBrush(isLight ? Color.FromRgb(102, 102, 102) : Color.FromRgb(160, 160, 160));

                return button;
            }

            private Button CreateStyledButton(string content)
            {
                var button = new Button
                {
                    Content = content,
                    FontSize = 12,
                    Cursor = System.Windows.Input.Cursors.Hand
                };

                // Create ControlTemplate with rounded corners and hover effect
                var template = new ControlTemplate(typeof(Button));

                var borderFactory = new FrameworkElementFactory(typeof(Border));
                borderFactory.Name = "border";
                borderFactory.SetValue(Border.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0, 120, 212)));
                borderFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(4));
                borderFactory.SetValue(Border.PaddingProperty, new Thickness(16, 6, 16, 6));

                var contentPresenterFactory = new FrameworkElementFactory(typeof(ContentPresenter));
                contentPresenterFactory.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
                contentPresenterFactory.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);

                borderFactory.AppendChild(contentPresenterFactory);
                template.VisualTree = borderFactory;

                // Add hover trigger
                var hoverTrigger = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
                hoverTrigger.Setters.Add(new Setter(Border.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0, 103, 184)), "border"));
                template.Triggers.Add(hoverTrigger);

                // Add pressed trigger
                var pressedTrigger = new Trigger { Property = Button.IsPressedProperty, Value = true };
                pressedTrigger.Setters.Add(new Setter(Border.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0, 90, 158)), "border"));
                template.Triggers.Add(pressedTrigger);

                button.Template = template;
                button.Foreground = Brushes.White;

                return button;
            }

            private void CloseNotification()
            {
                _autoCloseTimer?.Stop();
                _progressBar?.BeginAnimation(WidthProperty, null);

                // Slide right with a fade (small offset — see AnimateIn).
                double curLeft = Left;
                var slideRight = new DoubleAnimation
                {
                    From = curLeft,
                    To = curLeft + 48,
                    Duration = TimeSpan.FromMilliseconds(300),
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
                };

                var fadeOut = new DoubleAnimation
                {
                    From = 1,
                    To = 0,
                    Duration = TimeSpan.FromMilliseconds(250)
                };

                fadeOut.Completed += (s, e) => CloseAction();
                BeginAnimation(LeftProperty, slideRight);
                BeginAnimation(OpacityProperty, fadeOut);
            }
            private void CloseAction() {
                Close();
                if (!ruleWindowOpen) AppLifecycleService.ShutdownOrStayInBackground("Notification closed");
            }
        }

        // Notification window for disabled rule/group matches
        private class DisabledMatchNotificationWindow : Window
        {
            private DispatcherTimer _autoCloseTimer;
            private const int NOTIFICATION_TIMEOUT = 8000;
            private bool _enableClicked = false;
            private Border? _progressBar;
            private double _progressBarWidth;
            private DateTime _animationStartTime;
            private double _remainingTime;
            private bool _positioned;

            public DisabledMatchNotificationWindow(string displayText, string matchName, string matchType, Action runAction, Action enableAction)
            {
                _remainingTime = NOTIFICATION_TIMEOUT;

                WindowStyle = WindowStyle.None;
                AllowsTransparency = true;
                Background = Brushes.Transparent;
                ResizeMode = ResizeMode.NoResize;
                ShowInTaskbar = false;
                Topmost = true;
                Width = 380;
                SizeToContent = SizeToContent.Height;
                WindowStartupLocation = WindowStartupLocation.Manual;
                // Born on the primary at (0,0) so SizeToContent measures at the primary's DPI and the
                // toast never does a cross-monitor DPI move before it's positioned (which is what made
                // it split across displays). (0,0) is always the primary monitor's origin.
                Left = 0;
                Top = 0;
                Opacity = 0; // Hidden until positioned in ContentRendered (avoids a flash at 0,0)

                Content = CreateContent(displayText, matchName, matchType, runAction, enableAction);

                _autoCloseTimer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromMilliseconds(NOTIFICATION_TIMEOUT)
                };
                _autoCloseTimer.Tick += (s, e) => CloseNotification();

                // ContentRendered (not Loaded): SizeToContent height is only final after render.
                ContentRendered += (s, e) =>
                {
                    if (_positioned) return;
                    _positioned = true;

                    // Bottom-right of the primary monitor, sized for its DPI (see ToastPositioner).
                    ToastPositioner.PositionBottomRight(this);
                    AnimateIn();
                    _autoCloseTimer.Start();
                    _animationStartTime = DateTime.Now;
                };

                MouseEnter += (s, e) =>
                {
                    _autoCloseTimer.Stop();
                    _remainingTime -= (DateTime.Now - _animationStartTime).TotalMilliseconds;
                    if (_remainingTime < 0) _remainingTime = 0;
                    _progressBar?.BeginAnimation(WidthProperty, null);
                };

                MouseLeave += (s, e) =>
                {
                    if (_remainingTime > 0)
                    {
                        _autoCloseTimer.Interval = TimeSpan.FromMilliseconds(_remainingTime);
                        _autoCloseTimer.Start();
                        _animationStartTime = DateTime.Now;
                        ResumeProgressBarAnimation();
                    }
                };
            }

            private Border CreateContent(string displayText, string matchName, string matchType, Action runAction, Action enableAction)
            {
                bool isLight = !ThemeManager.IsDarkTheme;

                var mainBorder = new Border
                {
                    Background = new SolidColorBrush(isLight
                        ? Color.FromRgb(252, 252, 252)          // Light: Win11 white card
                        : Color.FromArgb(230, 28, 28, 32)),    // Dark: frosted dark
                    BorderBrush = new SolidColorBrush(isLight
                        ? Color.FromArgb(30, 0, 0, 0)           // Light: barely visible border
                        : Color.FromArgb(50, 255, 255, 255)),   // Dark: subtle white glow
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(8),
                    Margin = new Thickness(10),
                    Effect = new System.Windows.Media.Effects.DropShadowEffect
                    {
                        Color = Color.FromRgb(0, 0, 0),
                        Opacity = isLight ? 0.08 : 0.5,
                        BlurRadius = isLight ? 20 : 32,
                        ShadowDepth = isLight ? 2 : 4,
                        Direction = 270
                    }
                };

                var grid = new Grid();
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Header
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Status
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // URL
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Context
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Button

                // Header
                var headerGrid = new Grid { Margin = new Thickness(14, 12, 12, 4) };
                headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var appIcon = new Image
                {
                    Width = 20,
                    Height = 20,
                    Margin = new Thickness(0, 0, 10, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                try
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri("pack://application:,,,/Assets/Icons/favicon-32x32.png", UriKind.Absolute);
                    bitmap.DecodePixelWidth = 32;
                    bitmap.DecodePixelHeight = 32;
                    bitmap.EndInit();
                    appIcon.Source = bitmap;
                    RenderOptions.SetBitmapScalingMode(appIcon, BitmapScalingMode.HighQuality);
                }
                catch { }
                Grid.SetColumn(appIcon, 0);

                var titleText = new TextBlock
                {
                    Text = BrandConfig.AppDisplayName,
                    FontWeight = FontWeights.SemiBold,
                    FontSize = 13,
                    Foreground = new SolidColorBrush(isLight ? Color.FromRgb(51, 51, 51) : Color.FromRgb(255, 255, 255)),
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetColumn(titleText, 1);

                var closeButton = CreateCloseButton(isLight);
                closeButton.Click += (s, e) => CloseNotification();
                Grid.SetColumn(closeButton, 2);

                headerGrid.Children.Add(appIcon);
                headerGrid.Children.Add(titleText);
                headerGrid.Children.Add(closeButton);
                Grid.SetRow(headerGrid, 0);

                // Status line - orange warning
                var statusPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(16, 4, 16, 2)
                };
                var orangeColor = isLight ? Color.FromRgb(230, 81, 0) : Color.FromRgb(255, 167, 38);
                var warningIcon = new TextBlock
                {
                    Text = "\u26A0",
                    FontSize = 12,
                    Foreground = new SolidColorBrush(orangeColor),
                    Margin = new Thickness(0, 0, 6, 0)
                };
                var statusText = new TextBlock
                {
                    Text = "Opened in fallback browser",
                    FontSize = 12,
                    Foreground = new SolidColorBrush(orangeColor)
                };
                statusPanel.Children.Add(warningIcon);
                statusPanel.Children.Add(statusText);
                Grid.SetRow(statusPanel, 1);

                // URL display
                var urlText = new TextBlock
                {
                    Text = displayText,
                    FontSize = 13,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(isLight ? Color.FromRgb(0, 120, 212) : Color.FromRgb(100, 181, 246)),
                    TextWrapping = TextWrapping.NoWrap,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    Margin = new Thickness(16, 4, 16, 4)
                };
                Grid.SetRow(urlText, 2);

                // Context text
                var contextText = new TextBlock
                {
                    Text = matchType == "group"
                        ? $"Disabled group \"{matchName}\" matched.\nNote: Enabling will apply to all patterns in this group."
                        : $"Disabled rule \"{matchName}\" matched.",
                    FontSize = 11,
                    Foreground = new SolidColorBrush(isLight ? Color.FromRgb(102, 102, 102) : Color.FromRgb(180, 180, 180)),
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(16, 2, 16, 12)
                };
                if (matchName.Length > 40)
                    contextText.ToolTip = matchName;
                Grid.SetRow(contextText, 3);

                // Action buttons
                var buttonPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Margin = new Thickness(16, 4, 16, 14)
                };

                // Secondary: Enable & Open (re-enable permanently + open)
                var enableOpenButton = CreateSecondaryButton("Enable & Open", isLight);
                enableOpenButton.Click += (s, e) =>
                {
                    _enableClicked = true;
                    _autoCloseTimer?.Stop();
                    try
                    {
                        runAction();
                        enableAction();
                        Logger.Log($"Disabled {matchType} '{matchName}' re-enabled and opened via notification");
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"Error enabling {matchType}: {ex.Message}");
                    }
                    CloseNotification();
                };
                buttonPanel.Children.Add(enableOpenButton);

                // Primary: Open (one-time open without re-enabling)
                var openButton = CreateStyledButton("Open");
                openButton.Margin = new Thickness(8, 0, 0, 0);
                openButton.Click += (s, e) =>
                {
                    _enableClicked = true;
                    _autoCloseTimer?.Stop();
                    try
                    {
                        runAction();
                        Logger.Log($"Disabled {matchType} '{matchName}' opened once via notification");
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"Error opening {matchType}: {ex.Message}");
                    }
                    CloseNotification();
                };
                buttonPanel.Children.Add(openButton);
                Grid.SetRow(buttonPanel, 4);

                grid.Children.Add(headerGrid);
                grid.Children.Add(statusPanel);
                grid.Children.Add(urlText);
                grid.Children.Add(contextText);
                grid.Children.Add(buttonPanel);

                mainBorder.Child = grid;
                return mainBorder;
            }

            private void AnimateIn()
            {
                // Slide left into place with a fade. Keep the offset small so the window's majority
                // stays on the primary monitor for the whole slide — animating Left fully across a
                // monitor boundary is what mispositioned/split the toast under PerMonitorV2.
                double restLeft = Left;
                var slideLeft = new DoubleAnimation
                {
                    From = restLeft + 48,
                    To = restLeft,
                    Duration = TimeSpan.FromMilliseconds(350),
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                };

                var fadeIn = new DoubleAnimation
                {
                    From = 0,
                    To = 1,
                    Duration = TimeSpan.FromMilliseconds(250)
                };

                BeginAnimation(LeftProperty, slideLeft);
                BeginAnimation(OpacityProperty, fadeIn);
            }

            private void ResumeProgressBarAnimation()
            {
                if (_progressBar == null || _remainingTime <= 0) return;
                var currentWidth = _progressBar.ActualWidth > 0 ? _progressBar.ActualWidth : (_progressBarWidth * _remainingTime / NOTIFICATION_TIMEOUT);
                var animation = new DoubleAnimation
                {
                    From = currentWidth,
                    To = 0,
                    Duration = TimeSpan.FromMilliseconds(_remainingTime)
                };
                _progressBar.BeginAnimation(WidthProperty, animation);
            }

            private Button CreateCloseButton(bool isLight = false)
            {
                var button = new Button
                {
                    Content = "\u2715",
                    Width = 24,
                    Height = 24,
                    FontSize = 11,
                    Cursor = System.Windows.Input.Cursors.Hand,
                    VerticalAlignment = VerticalAlignment.Top
                };

                var template = new ControlTemplate(typeof(Button));
                var borderFactory = new FrameworkElementFactory(typeof(Border));
                borderFactory.Name = "border";
                borderFactory.SetValue(Border.BackgroundProperty, Brushes.Transparent);
                borderFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(4));
                var contentPresenterFactory = new FrameworkElementFactory(typeof(ContentPresenter));
                contentPresenterFactory.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
                contentPresenterFactory.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
                borderFactory.AppendChild(contentPresenterFactory);
                template.VisualTree = borderFactory;

                var hoverTrigger = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
                hoverTrigger.Setters.Add(new Setter(Border.BackgroundProperty,
                    new SolidColorBrush(isLight ? Color.FromArgb(26, 0, 0, 0) : Color.FromArgb(60, 255, 255, 255)), "border"));
                template.Triggers.Add(hoverTrigger);

                var pressedTrigger = new Trigger { Property = Button.IsPressedProperty, Value = true };
                pressedTrigger.Setters.Add(new Setter(Border.BackgroundProperty,
                    new SolidColorBrush(isLight ? Color.FromArgb(50, 0, 0, 0) : Color.FromArgb(100, 255, 255, 255)), "border"));
                template.Triggers.Add(pressedTrigger);

                button.Template = template;
                button.Foreground = new SolidColorBrush(isLight ? Color.FromRgb(102, 102, 102) : Color.FromRgb(160, 160, 160));
                return button;
            }

            private Button CreateSecondaryButton(string content, bool isLight = false)
            {
                var button = new Button
                {
                    Content = content,
                    FontSize = 12,
                    Cursor = System.Windows.Input.Cursors.Hand
                };

                var template = new ControlTemplate(typeof(Button));
                var borderFactory = new FrameworkElementFactory(typeof(Border));
                borderFactory.Name = "border";
                borderFactory.SetValue(Border.BackgroundProperty,
                    new SolidColorBrush(isLight ? Color.FromArgb(15, 0, 0, 0) : Color.FromArgb(30, 255, 255, 255)));
                borderFactory.SetValue(Border.BorderBrushProperty,
                    new SolidColorBrush(isLight ? Color.FromArgb(40, 0, 0, 0) : Color.FromArgb(80, 255, 255, 255)));
                borderFactory.SetValue(Border.BorderThicknessProperty, new Thickness(1));
                borderFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(4));
                borderFactory.SetValue(Border.PaddingProperty, new Thickness(16, 5, 16, 5));
                var contentPresenterFactory = new FrameworkElementFactory(typeof(ContentPresenter));
                contentPresenterFactory.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
                contentPresenterFactory.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
                borderFactory.AppendChild(contentPresenterFactory);
                template.VisualTree = borderFactory;

                var hoverTrigger = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
                hoverTrigger.Setters.Add(new Setter(Border.BackgroundProperty,
                    new SolidColorBrush(isLight ? Color.FromArgb(30, 0, 0, 0) : Color.FromArgb(60, 255, 255, 255)), "border"));
                template.Triggers.Add(hoverTrigger);

                var pressedTrigger = new Trigger { Property = Button.IsPressedProperty, Value = true };
                pressedTrigger.Setters.Add(new Setter(Border.BackgroundProperty,
                    new SolidColorBrush(isLight ? Color.FromArgb(45, 0, 0, 0) : Color.FromArgb(90, 255, 255, 255)), "border"));
                template.Triggers.Add(pressedTrigger);

                button.Template = template;
                button.Foreground = new SolidColorBrush(isLight ? Color.FromRgb(51, 51, 51) : Color.FromRgb(200, 200, 200));
                return button;
            }

            private Button CreateStyledButton(string content)
            {
                var button = new Button
                {
                    Content = content,
                    FontSize = 12,
                    Cursor = System.Windows.Input.Cursors.Hand
                };

                var template = new ControlTemplate(typeof(Button));
                var borderFactory = new FrameworkElementFactory(typeof(Border));
                borderFactory.Name = "border";
                borderFactory.SetValue(Border.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0, 120, 212)));
                borderFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(4));
                borderFactory.SetValue(Border.PaddingProperty, new Thickness(16, 6, 16, 6));
                var contentPresenterFactory = new FrameworkElementFactory(typeof(ContentPresenter));
                contentPresenterFactory.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
                contentPresenterFactory.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
                borderFactory.AppendChild(contentPresenterFactory);
                template.VisualTree = borderFactory;

                var hoverTrigger = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
                hoverTrigger.Setters.Add(new Setter(Border.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0, 103, 184)), "border"));
                template.Triggers.Add(hoverTrigger);

                var pressedTrigger = new Trigger { Property = Button.IsPressedProperty, Value = true };
                pressedTrigger.Setters.Add(new Setter(Border.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0, 90, 158)), "border"));
                template.Triggers.Add(pressedTrigger);

                button.Template = template;
                button.Foreground = Brushes.White;
                return button;
            }

            private void CloseNotification()
            {
                _autoCloseTimer?.Stop();
                _progressBar?.BeginAnimation(WidthProperty, null);

                // Slide right with a fade (small offset — see AnimateIn).
                double curLeft = Left;
                var slideRight = new DoubleAnimation
                {
                    From = curLeft,
                    To = curLeft + 48,
                    Duration = TimeSpan.FromMilliseconds(300),
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
                };

                var fadeOut = new DoubleAnimation
                {
                    From = 1,
                    To = 0,
                    Duration = TimeSpan.FromMilliseconds(250)
                };

                fadeOut.Completed += (s, e) =>
                {
                    Close();
                    if (!_enableClicked) AppLifecycleService.ShutdownOrStayInBackground("Disabled match notification closed");
                };
                BeginAnimation(LeftProperty, slideRight);
                BeginAnimation(OpacityProperty, fadeOut);
            }
        }
    }
}