using System;
using System.Text.Json.Serialization;

namespace PowerDroid.Models
{
    public enum ClipboardEntryType
    {
        Text,
        Url,
        FilePath,
        Image
    }

    /// <summary>
    /// A single clipboard history entry captured by Power Clip.
    /// </summary>
    public class ClipboardEntry
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Content { get; set; } = string.Empty;

        /// <summary>
        /// Verbatim CF_HTML ("HTML Format") blob captured alongside the text, when the source
        /// provided one (e.g. a copied hyperlink). Null for plain copies. Persisted so the rich
        /// form survives restarts; restored as-is on copy-back to preserve hyperlinks/formatting.
        /// </summary>
        public string? RichHtml { get; set; }

        public ClipboardEntryType Type { get; set; } = ClipboardEntryType.Text;
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public bool IsPinned { get; set; }

        /// <summary>User-friendly source app name (e.g., "Google Chrome", "VS Code").</summary>
        public string? SourceApp { get; set; }

        /// <summary>Stable process name for matching (e.g., "chrome", "msedge", "Code").</summary>
        public string? SourceAppId { get; set; }

        /// <summary>Additional detail such as browser profile name (e.g., "Work").</summary>
        public string? SourceDetail { get; set; }

        /// <summary>Cached OCR text extracted from image. Not persisted to JSON.</summary>
        [JsonIgnore]
        public string? CachedOcrText { get; set; }

        /// <summary>True when the entry carries preserved rich HTML (hyperlink/formatting).</summary>
        [JsonIgnore]
        public bool HasRichHtml => !string.IsNullOrEmpty(RichHtml);

        /// <summary>
        /// Human-readable type shown in the UI. Entries that carry preserved formatting are
        /// surfaced as "Rich Text" to distinguish them from plain text (no action implied).
        /// </summary>
        [JsonIgnore]
        public string TypeLabel => Type switch
        {
            ClipboardEntryType.Url => "URL",
            ClipboardEntryType.FilePath => "File Path",
            ClipboardEntryType.Image => "Image",
            _ when HasRichHtml => "Rich Text",
            _ => "Text"
        };
    }
}
