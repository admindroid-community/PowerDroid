using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using PowerDroid.Models;
using PowerDroid.Services;
using Microsoft.Win32;

namespace PowerDroid.Pages
{
    public partial class BrowserSettingsPage : UserControl
    {
        public event EventHandler? DataImported;

        public BrowserSettingsPage()
        {
            InitializeComponent();
            Loaded += BrowserSettingsPage_Loaded;
            Unloaded += BrowserSettingsPage_Unloaded;
        }

        private void BrowserSettingsPage_Loaded(object sender, RoutedEventArgs e)
        {
            ThemeManager.ThemeChanged += OnThemeChanged;
            LoadData();
        }

        private void BrowserSettingsPage_Unloaded(object sender, RoutedEventArgs e)
        {
            ThemeManager.ThemeChanged -= OnThemeChanged;
        }

        private void OnThemeChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                UpdateRegistrationStatus();
            });
        }

        public void LoadData()
        {
            InitializeRulesToggle();
            InitializeNotificationsToggle();
            UpdateRegistrationStatus();
            LoadFallbackBrowser();
        }

        #region Default Browser

        private void UpdateRegistrationStatus()
        {
            try
            {
                bool isDefaultBrowser = RegistryHelper.IsSystemDefaultBrowser();

                if (isDefaultBrowser)
                {
                    DefaultBrowserActiveCard.Visibility = Visibility.Visible;
                    DefaultBrowserSetupCard.Visibility = Visibility.Collapsed;
                }
                else
                {
                    DefaultBrowserActiveCard.Visibility = Visibility.Collapsed;
                    DefaultBrowserSetupCard.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserSettingsPage.UpdateRegistrationStatus ERROR: {ex.Message}");
            }
        }

        private void OpenWindowsSettings_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Ensure browser is registered before opening Windows Settings
                if (!RegistryHelper.IsRegistered())
                {
                    Logger.Log("Browser not registered - registering before opening Windows Settings");
                    RegistryHelper.RegisterAsDefaultBrowser();
                }

                Process.Start(new ProcessStartInfo
                {
                    FileName = $"ms-settings:defaultapps?registeredAppUser={BrandConfig.RegistryAppId}",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserSettingsPage.OpenWindowsSettings_Click ERROR: {ex.Message}");
                ConfirmationDialog.ShowInfo(
                    Window.GetWindow(this),
                    "Error",
                    "Could not open Windows Settings.");
            }
        }

        #endregion

        #region Fallback Browser

        /// <summary>Sentinel profile name meaning "launch with no profile argument".</summary>
        private const string LastActiveProfileName = "Last Active";

        private void LoadFallbackBrowser()
        {
            try
            {
                var browsers = BrowserService.GetBrowsersWithColors();
                FallbackBrowserComboBox.SelectionChanged -= FallbackBrowserComboBox_SelectionChanged;
                FallbackBrowserComboBox.ItemsSource = browsers;

                var settings = SettingsManager.LoadSettings();
                if (!string.IsNullOrEmpty(settings.DefaultBrowserPath))
                {
                    FallbackBrowserComboBox.SelectedItem =
                        browsers.FirstOrDefault(b =>
                            b.ExecutablePath.Equals(
                                settings.DefaultBrowserPath,
                                StringComparison.OrdinalIgnoreCase));
                }

                if (FallbackBrowserComboBox.SelectedItem == null && browsers.Count > 0)
                {
                    FallbackBrowserComboBox.SelectedItem = browsers[0];
                }

                FallbackBrowserComboBox.SelectionChanged += FallbackBrowserComboBox_SelectionChanged;

                // Populate the profile list for the resolved fallback browser and select the
                // saved profile (or "Last Active" when none is pinned).
                LoadFallbackProfiles(
                    FallbackBrowserComboBox.SelectedItem as BrowserInfoWithColor,
                    settings.DefaultBrowserProfileName);
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserSettingsPage.LoadFallbackBrowser ERROR: {ex.Message}");
            }
        }

        /// <summary>
        /// Fills the fallback profile dropdown with a "Last Active" sentinel (index 0) followed by
        /// the given browser's profiles (with avatars), then selects the entry matching
        /// <paramref name="selectName"/>. Reuses the same ProfileDisplayInfo/avatar picker as the
        /// rule-creation dialog.
        /// </summary>
        private void LoadFallbackProfiles(BrowserInfoWithColor browserWithColor, string selectName)
        {
            FallbackProfileComboBox.SelectionChanged -= FallbackProfileComboBox_SelectionChanged;

            // Index 0 is the "Last Active" sentinel (no avatar, no email).
            var items = new List<ProfileDisplayInfo>
            {
                new ProfileDisplayInfo { Name = LastActiveProfileName, IsLastActive = true }
            };

            if (browserWithColor != null)
            {
                items.AddRange(
                    BrowserService.GetProfiles(browserWithColor)
                                  .Select(ProfileDisplayInfo.FromProfileInfo));
            }

            FallbackProfileComboBox.ItemsSource = items;

            // Match a real profile by name (index >= 1); fall back to "Last Active" (index 0).
            var selected = string.IsNullOrEmpty(selectName)
                ? null
                : items.Skip(1).FirstOrDefault(p => p.Name == selectName);
            FallbackProfileComboBox.SelectedItem = selected ?? items[0];

            FallbackProfileComboBox.SelectionChanged += FallbackProfileComboBox_SelectionChanged;

            // Load avatars asynchronously; PropertyChanged refreshes the bindings.
            _ = LoadFallbackAvatarsAsync(items);
        }

        private async Task LoadFallbackAvatarsAsync(List<ProfileDisplayInfo> profiles)
        {
            foreach (var profile in profiles)
            {
                if (!string.IsNullOrEmpty(profile.AvatarUrl))
                {
                    var avatar = await ProfileAvatarService.GetAvatarAsync(profile.AvatarUrl, profile.Path);
                    if (avatar != null)
                    {
                        await Dispatcher.InvokeAsync(() => profile.Avatar = avatar);
                    }
                }
            }
        }

        private void FallbackBrowserComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FallbackBrowserComboBox.SelectedItem is BrowserInfoWithColor browserWithColor)
            {
                var browser = new BrowserInfo
                {
                    Name = browserWithColor.Name,
                    ExecutablePath = browserWithColor.ExecutablePath,
                    Type = browserWithColor.Type
                };
                var settings = SettingsManager.LoadSettings();
                settings.DefaultBrowserName = browser.Name;
                settings.DefaultBrowserPath = browser.ExecutablePath;
                settings.DefaultBrowserType = browser.Type;
                // Profiles are browser-specific; a pin from the previous browser no longer
                // applies. Reset to "Last Active".
                settings.DefaultBrowserProfileName = string.Empty;
                settings.DefaultBrowserProfilePath = string.Empty;
                settings.DefaultBrowserProfileArguments = string.Empty;
                SettingsManager.SaveSettings(settings);
                Logger.Log($"User changed fallback browser to: {browser.Name} (profile reset to Last Active)");

                LoadFallbackProfiles(browserWithColor, string.Empty);
            }
        }

        private void FallbackProfileComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FallbackProfileComboBox.SelectedItem is not ProfileDisplayInfo profile)
                return;

            var settings = SettingsManager.LoadSettings();

            // Index 0 is the "Last Active" sentinel → clear the pin.
            if (FallbackProfileComboBox.SelectedIndex <= 0)
            {
                settings.DefaultBrowserProfileName = string.Empty;
                settings.DefaultBrowserProfilePath = string.Empty;
                settings.DefaultBrowserProfileArguments = string.Empty;
                Logger.Log("Fallback profile set to Last Active (no profile argument)");
            }
            else
            {
                settings.DefaultBrowserProfileName = profile.Name;
                settings.DefaultBrowserProfilePath = profile.Path;
                settings.DefaultBrowserProfileArguments = profile.Arguments;
                Logger.Log($"Fallback profile pinned to: {profile.Name}");
            }

            SettingsManager.SaveSettings(settings);
        }

        #endregion

        #region Rules Processing

        private void InitializeRulesToggle()
        {
            try
            {
                var settings = SettingsManager.LoadSettings();

                // Set toggle state without triggering the event
                RulesEnabledToggle.Checked -= RulesEnabledToggle_Changed;
                RulesEnabledToggle.Unchecked -= RulesEnabledToggle_Changed;
                RulesEnabledToggle.IsChecked = settings.IsEnabled;
                RulesEnabledToggle.Checked += RulesEnabledToggle_Changed;
                RulesEnabledToggle.Unchecked += RulesEnabledToggle_Changed;
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserSettingsPage.InitializeRulesToggle ERROR: {ex.Message}");
            }
        }

        private void RulesEnabledToggle_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                var isEnabled = RulesEnabledToggle.IsChecked == true;

                var settings = SettingsManager.LoadSettings();
                settings.IsEnabled = isEnabled;
                SettingsManager.SaveSettings(settings);

                Logger.Log($"Rules processing {(isEnabled ? "enabled" : "disabled")}");

                // Update navigation indicator in parent window
                if (Window.GetWindow(this) is SettingsWindow settingsWindow)
                {
                    settingsWindow.UpdateNavigationStatus();
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserSettingsPage.RulesEnabledToggle_Changed ERROR: {ex.Message}");
            }
        }

        #endregion

        #region Notifications

        private void InitializeNotificationsToggle()
        {
            try
            {
                var settings = SettingsManager.LoadSettings();

                // Set toggle state without triggering the event
                NotificationsToggle.Checked -= NotificationsToggle_Changed;
                NotificationsToggle.Unchecked -= NotificationsToggle_Changed;
                NotificationsToggle.IsChecked = settings.ShowNotifications;
                NotificationsToggle.Checked += NotificationsToggle_Changed;
                NotificationsToggle.Unchecked += NotificationsToggle_Changed;
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserSettingsPage.InitializeNotificationsToggle ERROR: {ex.Message}");
            }
        }

        private void NotificationsToggle_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                var isEnabled = NotificationsToggle.IsChecked == true;

                var settings = SettingsManager.LoadSettings();
                settings.ShowNotifications = isEnabled;
                SettingsManager.SaveSettings(settings);

                Logger.Log($"Unmatched URL notifications {(isEnabled ? "enabled" : "disabled")}");
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserSettingsPage.NotificationsToggle_Changed ERROR: {ex.Message}");
            }
        }

        #endregion

        #region Backup & Restore

        private void ExportData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dialog = new SaveFileDialog
                {
                    Title = $"Export {BrandConfig.AppDisplayName} Data",
                    Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*",
                    DefaultExt = "json",
                    FileName = $"{BrandConfig.AppDisplayName}_Backup_{DateTime.Now:yyyy-MM-dd}"
                };

                if (dialog.ShowDialog() == true)
                {
                    DataExportService.Export(dialog.FileName);

                    ConfirmationDialog.ShowInfo(
                        Window.GetWindow(this),
                        "Export Complete",
                        "Your data has been saved successfully.\n\n" +
                        "This backup includes your individual rules,\ngrouped rules, and browser settings.");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"ExportData_Click ERROR: {ex.Message}");
                ConfirmationDialog.ShowInfo(
                    Window.GetWindow(this),
                    "Export Failed",
                    $"Something went wrong while exporting your data.\n\n{ex.Message}");
            }
        }

        private void ImportData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dialog = new OpenFileDialog
                {
                    Title = $"Import {BrandConfig.AppDisplayName} Data",
                    Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*",
                    DefaultExt = "json"
                };

                if (dialog.ShowDialog() == true)
                {
                    var (valid, message, package) = DataExportService.ValidateExportFile(dialog.FileName);

                    if (!valid)
                    {
                        ConfirmationDialog.ShowInfo(
                            Window.GetWindow(this),
                            "Invalid File",
                            $"This file can't be imported.\n\n{message}");
                        return;
                    }

                    bool isCrossMachine = !string.Equals(
                        package?.MachineName, Environment.MachineName,
                        StringComparison.OrdinalIgnoreCase);

                    bool confirmed;
                    if (isCrossMachine)
                    {
                        confirmed = ConfirmationDialog.Show(
                            Window.GetWindow(this),
                            "External Backup",
                            $"{message}\n\n" +
                            "Browser profiles from that computer won't work on yours.\n" +
                            "URL patterns will be imported and assigned to your default browser.",
                            "Clear & Import", "Cancel",
                            warningText: "Your current rules will be replaced.");
                    }
                    else
                    {
                        confirmed = ConfirmationDialog.Show(
                            Window.GetWindow(this),
                            "Import Backup",
                            $"{message}\n\n" +
                            "A safety backup of your current data will be created automatically.",
                            "Clear & Import", "Cancel",
                            warningText: "Your current rules will be replaced.");
                    }

                    if (!confirmed)
                        return;

                    var result = DataExportService.Import(dialog.FileName, replaceExisting: true);
                    DataExportService.ValidateAndRemapProfiles(forceDefaults: isCrossMachine);

                    if (result.Success)
                    {
                        ConfirmationDialog.ShowInfo(
                            Window.GetWindow(this),
                            "Import Complete",
                            $"Your data has been restored successfully.\n\n{result.Message}");

                        LoadData();
                        DataImported?.Invoke(this, EventArgs.Empty);
                    }
                    else
                    {
                        ConfirmationDialog.ShowInfo(
                            Window.GetWindow(this),
                            "Import Failed",
                            $"The import could not be completed.\n\n{result.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"ImportData_Click ERROR: {ex.Message}");
                ConfirmationDialog.ShowInfo(
                    Window.GetWindow(this),
                    "Import Failed",
                    $"Something went wrong while importing your data.\n\n{ex.Message}");
            }
        }

        #endregion
    }
}
