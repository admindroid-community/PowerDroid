using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using PowerDroid.Dialogs;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid
{
    /// <summary>
    /// Window for creating and editing URL groups.
    /// Now supports multi-profile configurations through the BrowserProfileMultiSelector control.
    /// </summary>
    public partial class EditUrlGroupWindow : Window
    {
        private UrlGroup _group;
        private bool _isEditMode;
        private bool _isBuiltIn;
        private ObservableCollection<UrlPattern> _patterns;
        private List<UrlPattern> _filteredPatterns = new List<UrlPattern>();
        private List<UrlPattern> _originalBuiltInPatterns = new List<UrlPattern>();
        private List<string> _pendingRuleDeletions = new List<string>();
        private List<(string GroupId, string GroupName, string Pattern)> _pendingGroupPatternRemovals = new();

        // Change detection fields for edit mode
        private string _initialName = "";
        private string _initialDescription = "";
        private bool _initialClipboardNotify = true;
        private bool _initialIncognito = false;
        private string? _initialSourceApp;
        private List<string> _initialPatternStrings = new List<string>();
        private List<RuleProfile> _initialProfiles = new List<RuleProfile>();

        /// <summary>
        /// Indicates if individual rules were added via "Move to Rule" during this session.
        /// The caller should check this to refresh the rules list.
        /// </summary>
        public bool RulesWereModified { get; private set; }

        public EditUrlGroupWindow() : this(null)
        {
        }

        public EditUrlGroupWindow(UrlGroup? existingGroup)
        {
            Logger.Log("EditUrlGroupWindow: Constructor started");
            try
            {
                Logger.Log("EditUrlGroupWindow: Calling InitializeComponent...");
                InitializeComponent();
                Logger.Log("EditUrlGroupWindow: InitializeComponent completed");
            }
            catch (Exception ex)
            {
                Logger.Log($"EditUrlGroupWindow InitializeComponent ERROR: {ex.Message}");
                Logger.Log($"EditUrlGroupWindow InitializeComponent STACKTRACE: {ex.StackTrace}");
                throw;
            }

            SourceInitialized += (s, e) => ThemeManager.ApplyTitleBarTheme(this);
            ContentRendered += (s, e) => NewPatternTextBox.Focus();

            _isEditMode = existingGroup != null;
            _group = existingGroup ?? new UrlGroup();
            _isBuiltIn = _group.IsBuiltIn;
            _patterns = new ObservableCollection<UrlPattern>(_group.UrlPatterns ?? new List<UrlPattern>());

            // Store original patterns for built-in groups to enable restore
            if (_isBuiltIn)
            {
                // Load original patterns from the template manifest
                var manifest = Services.BuiltInTemplateManager.LoadTemplateManifest();
                var builtInTemplate = manifest.Templates.FirstOrDefault(t => t.Id == _group.Id);
                if (builtInTemplate != null)
                {
                    _originalBuiltInPatterns = builtInTemplate.Patterns.Select(p => new UrlPattern
                    {
                        Id = p.Id,
                        Pattern = p.Pattern,
                        IsBuiltIn = true,
                        VersionAdded = p.VersionAdded
                    }).ToList();
                }
            }

            // Configure UI based on IsBuiltIn
            ConfigureBuiltInMode();

            if (_isEditMode)
            {
                Title = "Edit Grouped Rule";
                GroupNameTextBox.Text = _group.Name;
                DescriptionTextBox.Text = _group.Description;

                // Load clipboard notification setting
                ClipboardNotifyToggle.IsChecked = _group.ClipboardNotificationsEnabled;

                // Load incognito setting
                IncognitoToggle.IsChecked = _group.Incognito;

                // Load source app filter
                SelectSourceApp(_group.SourceAppFilter);

                // Load profiles into the selector
                LoadExistingProfiles();

                // Store initial values for change detection
                _initialName = _group.Name ?? "";
                _initialDescription = _group.Description ?? "";
                _initialClipboardNotify = _group.ClipboardNotificationsEnabled;
                _initialIncognito = _group.Incognito;
                _initialSourceApp = _group.SourceAppFilter;
                _initialPatternStrings = _patterns.Select(p => p.Pattern).ToList();
                _initialProfiles = _group.Profiles?.Select(p => new RuleProfile
                {
                    BrowserName = p.BrowserName,
                    BrowserPath = p.BrowserPath,
                    BrowserType = p.BrowserType,
                    ProfileName = p.ProfileName,
                    ProfilePath = p.ProfilePath,
                    ProfileArguments = p.ProfileArguments
                }).ToList() ?? new List<RuleProfile>();

                // Hide Save button until changes detected
                SaveButton.Visibility = Visibility.Collapsed;

                // Wire up change detection events
                GroupNameTextBox.TextChanged += (s, e) => CheckForChanges();
                DescriptionTextBox.TextChanged += (s, e) => CheckForChanges();
                ClipboardNotifyToggle.Checked += (s, e) => CheckForChanges();
                ClipboardNotifyToggle.Unchecked += (s, e) => CheckForChanges();
                IncognitoToggle.Checked += (s, e) => CheckForChanges();
                IncognitoToggle.Unchecked += (s, e) => CheckForChanges();
                SourceAppComboBox.SelectionChanged += (s, e) => CheckForChanges();
                ProfileSelector.SelectionChanged += (s, e) => { CheckForChanges(); UpdateProfileCountBadge(); };
                ProfileSelector.ModeChanged += (s, e) => UpdateProfileCountBadge();
            }
            else
            {
                Title = "New Grouped Rule";
                SaveButton.Content = "Add";
            }

            // Disable clipboard toggle if global clipboard monitoring is off
            var globalSettings = SettingsManager.LoadSettings();
            if (!globalSettings.ClipboardMonitoring.IsEnabled)
            {
                ClipboardNotifyToggle.IsEnabled = false;
                ClipboardNotifyPanel.Opacity = 0.5;
                ClipboardNotifyPanel.ToolTip = "Enable clipboard monitoring in Settings to use this feature";
            }

            // Keep the selector's help text in sync with the incognito toggle — both the initial
            // edit-mode value (set above) and any later changes.
            ProfileSelector.IsIncognito = IncognitoToggle.IsChecked == true;
            IncognitoToggle.Checked += (s, e) => ProfileSelector.IsIncognito = true;
            IncognitoToggle.Unchecked += (s, e) => ProfileSelector.IsIncognito = false;

            // Populate source app dropdown
            PopulateSourceAppComboBox();

            RefreshPatternsList();
        }

        private void ConfigureBuiltInMode()
        {
            UpdateResetDefaultsVisibility();
        }

        private void UpdateResetDefaultsVisibility()
        {
            if (!_isBuiltIn)
            {
                ResetDefaultsLink.Visibility = Visibility.Collapsed;
                return;
            }

            // Show only when group has been customized (patterns differ from original)
            var currentSet = _patterns.Select(p => p.Pattern.ToLower()).OrderBy(p => p).ToList();
            var originalSet = _originalBuiltInPatterns.Select(p => p.Pattern.ToLower()).OrderBy(p => p).ToList();
            bool hasCustomChanges = !currentSet.SequenceEqual(originalSet);

            ResetDefaultsLink.Visibility = hasCustomChanges ? Visibility.Visible : Visibility.Collapsed;
        }

        private void LoadExistingProfiles()
        {
            // Check if group has multi-profile configuration
            if (_group.Profiles != null && _group.Profiles.Count > 0)
            {
                ProfileSelector.LoadProfiles(_group.Profiles);
            }
            else if (!string.IsNullOrEmpty(_group.DefaultBrowserPath))
            {
                // Legacy single profile - load from default fields
                ProfileSelector.LoadSingleProfile(_group.DefaultBrowserPath, _group.DefaultProfilePath);
            }

            UpdateProfileCountBadge();
        }

        private void RefreshPatternsList()
        {
            string searchText = NewPatternTextBox?.Text?.Trim().ToLower() ?? "";

            // Always re-filter from _patterns to avoid stale data after removes
            if (!string.IsNullOrEmpty(searchText))
            {
                _filteredPatterns = _patterns
                    .Where(p => p.Pattern.ToLower().Contains(searchText))
                    .ToList();
            }

            var displayList = string.IsNullOrEmpty(searchText)
                ? _patterns.ToList()
                : _filteredPatterns;

            PatternsItemsControl.ItemsSource = null;
            PatternsItemsControl.ItemsSource = displayList;

            // Show empty state when: no patterns at all, OR search with no results
            bool hasSearchText = !string.IsNullOrEmpty(searchText);
            bool showEmptyState = _patterns.Count == 0 || (hasSearchText && displayList.Count == 0);

            NoResultsPanel.Visibility = showEmptyState ? Visibility.Visible : Visibility.Collapsed;
            PatternsListBorder.Visibility = showEmptyState ? Visibility.Collapsed : Visibility.Visible;

            // Update empty state text based on context
            if (_patterns.Count == 0)
            {
                NoResultsText.Text = "No patterns yet";
                NoResultsHint.Text = "Add a pattern above to get started";
            }
            else
            {
                NoResultsText.Text = "No URL found";
                NoResultsHint.Text = "Press Enter or click Add to create this pattern";
            }

            // Update count text
            var totalCount = _patterns.Count;
            if (hasSearchText && displayList.Count != totalCount)
            {
                PatternCountText.Text = $"{displayList.Count} of {totalCount} patterns";
            }
            else
            {
                PatternCountText.Text = $"{totalCount} pattern{(totalCount != 1 ? "s" : "")}";
            }
            PatternCountBadge.Text = totalCount.ToString();

            UpdateResetDefaultsVisibility();
        }

        private void UpdateProfileCountBadge()
        {
            var count = ProfileSelector.ProfileCount;
            if (count > 1)
            {
                ProfileCountBadge.Visibility = Visibility.Visible;
                ProfileCountText.Text = count.ToString();
            }
            else
            {
                ProfileCountBadge.Visibility = Visibility.Collapsed;
            }
        }

        private void CheckForChanges()
        {
            if (!_isEditMode) return;

            var currentPatternStrings = _patterns.Select(p => p.Pattern).ToList();
            bool patternsChanged = !PatternsAreEqual(_initialPatternStrings, currentPatternStrings);

            var currentProfiles = ProfileSelector.GetAllProfiles();
            bool profilesChanged = !ProfilesAreEqual(_initialProfiles, currentProfiles);

            var currentSourceApp = GetSelectedSourceAppFilter();
            bool hasChanges = GroupNameTextBox.Text.Trim() != _initialName
                || DescriptionTextBox.Text.Trim() != _initialDescription
                || ClipboardNotifyToggle.IsChecked != _initialClipboardNotify
                || IncognitoToggle.IsChecked != _initialIncognito
                || currentSourceApp != _initialSourceApp
                || patternsChanged
                || profilesChanged;

            SaveButton.Visibility = hasChanges ? Visibility.Visible : Visibility.Collapsed;
        }

        private static bool PatternsAreEqual(List<string> initial, List<string> current)
        {
            if (initial.Count != current.Count) return false;
            var sortedInitial = initial.OrderBy(p => p).ToList();
            var sortedCurrent = current.OrderBy(p => p).ToList();
            return sortedInitial.SequenceEqual(sortedCurrent);
        }

        private static bool ProfilesAreEqual(List<RuleProfile> initial, List<RuleProfile> current)
        {
            if (initial.Count != current.Count) return false;
            for (int i = 0; i < initial.Count; i++)
            {
                if (initial[i].BrowserPath != current[i].BrowserPath ||
                    initial[i].ProfilePath != current[i].ProfilePath)
                    return false;
            }
            return true;
        }

        private void NewPatternTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            FilterPatterns();
        }

        private void FilterPatterns()
        {
            string searchText = NewPatternTextBox?.Text?.Trim().ToLower() ?? "";

            // Update placeholder visibility
            if (PatternPlaceholder != null)
            {
                PatternPlaceholder.Visibility = string.IsNullOrEmpty(NewPatternTextBox?.Text)
                    ? Visibility.Visible : Visibility.Collapsed;
            }

            // Update clear button visibility
            if (ClearPatternButton != null)
            {
                ClearPatternButton.Visibility = string.IsNullOrEmpty(NewPatternTextBox?.Text)
                    ? Visibility.Collapsed : Visibility.Visible;
            }

            if (string.IsNullOrEmpty(searchText))
            {
                // Show all patterns
                _filteredPatterns = _patterns.ToList();
                if (AddPatternButton != null)
                    AddPatternButton.IsEnabled = false;
            }
            else
            {
                // Filter patterns that contain the search text
                _filteredPatterns = _patterns
                    .Where(p => p.Pattern.ToLower().Contains(searchText))
                    .ToList();

                // Enable Add button when the exact pattern doesn't already exist
                bool exactMatch = _patterns.Any(p => p.Pattern.ToLower() == searchText);
                if (AddPatternButton != null)
                    AddPatternButton.IsEnabled = !exactMatch;
            }

            RefreshPatternsList();
        }

        private void ClearPattern_Click(object sender, RoutedEventArgs e)
        {
            NewPatternTextBox.Clear();
            NewPatternTextBox.Focus();
        }

        private void NewPatternTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                AddPattern();
            }
        }

        private void AddPattern_Click(object sender, RoutedEventArgs e)
        {
            AddPattern();
        }

        private void AddPattern()
        {
            string pattern = NewPatternTextBox.Text.Trim();

            if (string.IsNullOrEmpty(pattern))
            {
                return;
            }

            // Hide previous warning
            PatternWarningBorder.Visibility = Visibility.Collapsed;

            // Validate pattern format AND check for individual rule conflicts AND other group conflicts
            var result = ValidationService.ValidatePatternForGroup(pattern, _isEditMode ? _group?.Id : null);

            // Show error if format invalid
            if (!result.IsValid)
            {
                var errorMessage = string.Join("\n", result.Errors.Select(e => e.Message));
                ConfirmationDialog.ShowInfo(this, "Invalid Pattern", errorMessage);
                return;
            }

            // Use normalized pattern
            var normalizedPattern = result.NormalizedValue ?? pattern.ToLower();

            // Check for duplicate in current list
            if (_patterns.Any(p => p.Pattern.ToLower() == normalizedPattern.ToLower()))
            {
                ConfirmationDialog.ShowInfo(this, "Duplicate Pattern", "This pattern is already in the list.");
                return;
            }

            // Check for conflicts with individual rules or other groups
            if (result.HasWarnings)
            {
                var individualRuleConflict = result.Warnings
                    .FirstOrDefault(w => w.Code == ValidationCodes.GROUP_PATTERN_EXISTS_AS_RULE);
                var otherWarnings = result.Warnings
                    .Where(w => w.Code != ValidationCodes.GROUP_PATTERN_EXISTS_AS_RULE).ToList();

                // If pattern exists as individual rule, offer to delete it and add here
                if (individualRuleConflict != null)
                {
                    if (!ConfirmationDialog.Show(this,
                        "Pattern Conflict",
                        "This pattern exists as an individual rule. Delete the individual rule and add it to this group?",
                        "Delete & Add", "Cancel"))
                    {
                        return;
                    }

                    // Queue ALL matching rules for deletion on save (not just the first match)
                    var allRules = UrlRuleManager.LoadRules();
                    var conflictingRules = allRules.Where(r =>
                        ValidationService.NormalizePattern(r.Pattern) == normalizedPattern);
                    foreach (var conflictingRule in conflictingRules)
                    {
                        if (!_pendingRuleDeletions.Contains(conflictingRule.Id))
                        {
                            Logger.Log($"AddPattern: Queuing rule for deletion: '{conflictingRule.Pattern}' (Id={conflictingRule.Id}, IsEnabled={conflictingRule.IsEnabled})");
                            _pendingRuleDeletions.Add(conflictingRule.Id);
                        }
                    }
                }

                // If pattern exists in another group, offer to move it here
                var groupOverlap = otherWarnings
                    .FirstOrDefault(w => w.Code == ValidationCodes.GROUP_PATTERN_OVERLAP);
                var remainingWarnings = otherWarnings
                    .Where(w => w.Code != ValidationCodes.GROUP_PATTERN_OVERLAP).ToList();

                if (groupOverlap != null)
                {
                    if (!ConfirmationDialog.Show(this,
                        "Pattern Conflict",
                        $"This pattern already exists in group '{groupOverlap.ConflictingEntity}'.\n\nRemove it from that group and add it here?",
                        "Move Here", "Cancel"))
                    {
                        return;
                    }

                    // Queue the pattern removal from the other group
                    var allGroups = UrlGroupManager.LoadGroups();
                    var conflictingGroup = allGroups.FirstOrDefault(g =>
                        g.Name == groupOverlap.ConflictingEntity);
                    if (conflictingGroup != null)
                    {
                        Logger.Log($"AddPattern: Queuing pattern removal from group '{conflictingGroup.Name}': {normalizedPattern}");
                        _pendingGroupPatternRemovals.Add((conflictingGroup.Id, conflictingGroup.Name, normalizedPattern));
                    }
                }

                // Show remaining warnings if any
                if (remainingWarnings.Any())
                {
                    var errorMessages = string.Join("\n", remainingWarnings.Select(w => w.Message));
                    PatternWarningText.Text = errorMessages;
                    PatternWarningBorder.Visibility = Visibility.Visible;
                    PatternWarningBorder.BringIntoView();
                    return;
                }
            }

            // Add pattern as new UrlPattern object
            _patterns.Add(new UrlPattern
            {
                Pattern = normalizedPattern,
                IsBuiltIn = false,
                CreatedDate = DateTime.Now
            });
            NewPatternTextBox.Clear();
            NewPatternTextBox.Focus();
            FilterPatterns(); // Reset filter state after adding
            CheckForChanges(); // Update save button visibility

            // Scroll to bottom to show newly added pattern (after layout update)
            Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Loaded, new Action(() =>
            {
                PatternsScrollViewer.ScrollToEnd();
            }));
        }

        private void RemovePattern_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button)
            {
                UrlPattern? patternToRemove = null;
                string patternText = "";

                // Handle both UrlPattern object binding and string binding
                if (button.Tag is UrlPattern urlPattern)
                {
                    patternToRemove = urlPattern;
                    patternText = urlPattern.Pattern;
                }
                else if (button.DataContext is UrlPattern dcPattern)
                {
                    patternToRemove = dcPattern;
                    patternText = dcPattern.Pattern;
                }

                if (patternToRemove != null)
                {
                    if (ConfirmationDialog.Show(this, "Remove Pattern",
                        $"Are you sure you want to remove '{patternText}' from this group?", "Remove", "Cancel"))
                    {
                        // Track deleted built-in patterns so they won't be re-added on template updates
                        if (patternToRemove.IsBuiltIn && !string.IsNullOrEmpty(patternToRemove.Id))
                        {
                            if (!_group.DeletedBuiltInPatternIds.Contains(patternToRemove.Id))
                            {
                                _group.DeletedBuiltInPatternIds.Add(patternToRemove.Id);
                            }
                        }

                        _patterns.Remove(patternToRemove);
                        RefreshPatternsList();
                        CheckForChanges(); // Update save button visibility
                    }
                }
            }
        }

        private void ResetToDefaults_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (_originalBuiltInPatterns.Count == 0) return;

            if (!ConfirmationDialog.Show(this,
                "Reset to Defaults",
                "Any custom URL patterns will be removed and the group will be reverted to its original built-in patterns.",
                "Reset", "Cancel"))
            {
                return;
            }

            // Clear all current patterns and restore original built-in patterns
            _patterns.Clear();
            _group.DeletedBuiltInPatternIds.Clear();

            foreach (var pattern in _originalBuiltInPatterns)
            {
                _patterns.Add(new UrlPattern
                {
                    Id = pattern.Id,
                    Pattern = pattern.Pattern,
                    IsBuiltIn = true,
                    VersionAdded = pattern.VersionAdded,
                    CreatedDate = pattern.CreatedDate
                });
            }

            RefreshPatternsList();
            CheckForChanges();
        }

        private void MovePatternToRule_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button)
            {
                UrlPattern? patternToMove = null;

                // Handle both UrlPattern object binding and DataContext
                if (button.Tag is UrlPattern urlPattern)
                {
                    patternToMove = urlPattern;
                }
                else if (button.DataContext is UrlPattern dcPattern)
                {
                    patternToMove = dcPattern;
                }

                if (patternToMove != null)
                {
                    try
                    {
                        // If this is the last pattern, confirm that moving it will delete the group
                        bool isLastPattern = _patterns.Count == 1;
                        if (isLastPattern)
                        {
                            bool confirmed = ConfirmationDialog.Show(
                                this,
                                "Move Last Pattern",
                                "This is the last URL pattern in this group. Moving it will delete the group.\n\nDo you want to continue?",
                                "Move & Delete Group",
                                "Cancel");
                            if (!confirmed) return;
                        }

                        // Open AddRuleWindow with the pattern pre-filled, passing group ID to exclude from validation
                        var addWindow = new AddRuleWindow(patternToMove.Pattern, _group.Id, true);
                        addWindow.Owner = this;

                        if (addWindow.ShowDialog() == true)
                        {
                            // Track deleted built-in patterns
                            if (patternToMove.IsBuiltIn && !string.IsNullOrEmpty(patternToMove.Id))
                            {
                                if (!_group.DeletedBuiltInPatternIds.Contains(patternToMove.Id))
                                {
                                    _group.DeletedBuiltInPatternIds.Add(patternToMove.Id);
                                }
                            }

                            // Remove pattern from current group
                            _patterns.Remove(patternToMove);

                            // Flag that rules were modified so caller can refresh rules list
                            RulesWereModified = true;

                            if (isLastPattern)
                            {
                                // Delete the now-empty group and close the editor
                                UrlGroupManager.DeleteGroup(_group.Id);
                                DialogResult = true;
                                Close();
                                return;
                            }

                            RefreshPatternsList();
                            CheckForChanges(); // Update save button visibility
                            ShowInlineNotification($"'{patternToMove.Pattern}' moved to individual rule");
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"MovePatternToRule_Click ERROR: {ex.Message}");
                        ConfirmationDialog.ShowInfo(this, "Error", $"Error moving pattern: {ex.Message}");
                    }
                }
            }
        }

        private void ClosePatternWarning_Click(object sender, RoutedEventArgs e)
        {
            PatternWarningBorder.Visibility = Visibility.Collapsed;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            // Clear previous validation messages
            ValidationPanel.Clear();

            // Get profiles from the selector
            var profiles = ProfileSelector.GetAllProfiles();

            // Validate using ValidationService (pass pattern strings for validation)
            var result = ValidationService.ValidateUrlGroup(
                GroupNameTextBox.Text,
                _patterns.Select(p => p.Pattern).ToList(),
                profiles,
                _isEditMode ? _group?.Id : null
            );

            // Show only errors in the inline panel (warnings are handled by confirmation dialogs)
            if (result.Errors.Any())
            {
                ValidationPanel.SetValidationResult(result);
            }

            // Block on errors
            if (!result.IsValid)
            {
                return;
            }

            // Handle warnings
            if (result.HasWarnings)
            {
                var individualRuleConflicts = result.Warnings
                    .Where(w => w.Code == ValidationCodes.GROUP_PATTERN_EXISTS_AS_RULE).ToList();
                var otherWarnings = result.Warnings
                    .Where(w => w.Code != ValidationCodes.GROUP_PATTERN_EXISTS_AS_RULE).ToList();

                // Filter out conflicts already queued from AddPattern()
                var allRules = UrlRuleManager.LoadRules();
                var newConflicts = individualRuleConflicts.Where(w =>
                {
                    // Check if ANY rule with this pattern is not yet queued for deletion
                    var matchingRules = allRules.Where(r =>
                        ValidationService.NormalizePattern(r.Pattern) == ValidationService.NormalizePattern(w.ConflictingEntity ?? ""));
                    return matchingRules.Any(r => !_pendingRuleDeletions.Contains(r.Id));
                }).ToList();

                // If there are new conflicts not yet queued, ask the user
                if (newConflicts.Count > 0)
                {
                    var patterns = string.Join(", ", newConflicts.Select(w => w.ConflictingEntity));
                    Logger.Log($"Save_Click: {newConflicts.Count} new individual rule conflict(s): {patterns}");
                    if (!ConfirmationDialog.Show(this,
                        "Pattern Conflict",
                        $"The following patterns exist as individual rules: {patterns}\n\nDelete the individual rules and save the group?",
                        "Delete & Save", "Cancel"))
                    {
                        Logger.Log("Save_Click: User cancelled conflict deletion");
                        return;
                    }

                    // Queue ALL matching rules for deletion (not just the first match)
                    foreach (var conflict in newConflicts)
                    {
                        var conflictingRules = allRules.Where(r =>
                            ValidationService.NormalizePattern(r.Pattern) == ValidationService.NormalizePattern(conflict.ConflictingEntity ?? ""));
                        foreach (var conflictingRule in conflictingRules)
                        {
                            if (!_pendingRuleDeletions.Contains(conflictingRule.Id))
                            {
                                Logger.Log($"Save_Click: Queuing rule for deletion: '{conflictingRule.Pattern}' (Id={conflictingRule.Id}, IsEnabled={conflictingRule.IsEnabled})");
                                _pendingRuleDeletions.Add(conflictingRule.Id);
                            }
                        }
                    }
                }

                // Handle group overlap warnings — skip any already resolved during AddPattern
                var groupOverlaps = otherWarnings
                    .Where(w => w.Code == ValidationCodes.GROUP_PATTERN_OVERLAP)
                    .Where(w => !_pendingGroupPatternRemovals.Any(p =>
                        p.GroupName == w.ConflictingEntity))
                    .ToList();
                var remainingWarnings = otherWarnings
                    .Where(w => w.Code != ValidationCodes.GROUP_PATTERN_OVERLAP).ToList();

                if (groupOverlaps.Count > 0)
                {
                    var patterns = string.Join(", ", groupOverlaps.Select(w => w.ConflictingEntity));
                    if (!ConfirmationDialog.Show(this,
                        "Pattern Conflict",
                        $"The following patterns overlap with other groups: {patterns}\n\nRemove them from the other groups and save?",
                        "Move & Save", "Cancel"))
                    {
                        return;
                    }

                    var allGroups = UrlGroupManager.LoadGroups();
                    foreach (var overlap in groupOverlaps)
                    {
                        var conflictingGroup = allGroups.FirstOrDefault(g =>
                            g.Name == overlap.ConflictingEntity);
                        if (conflictingGroup != null)
                        {
                            // Find the actual pattern that overlaps
                            var overlapPattern = _patterns.FirstOrDefault(p =>
                                conflictingGroup.UrlPatterns?.Any(gp =>
                                    ValidationService.NormalizePattern(gp.Pattern) == ValidationService.NormalizePattern(p.Pattern)) == true);
                            if (overlapPattern != null)
                            {
                                Logger.Log($"Save_Click: Queuing pattern removal from group '{conflictingGroup.Name}': {overlapPattern.Pattern}");
                                _pendingGroupPatternRemovals.Add((conflictingGroup.Id, conflictingGroup.Name, overlapPattern.Pattern));
                            }
                        }
                    }
                }

                // Confirm any remaining warnings (hierarchy, etc.)
                if (remainingWarnings.Count > 0)
                {
                    if (!ValidationWarningDialog.ShowWarnings(this, remainingWarnings))
                    {
                        return;
                    }
                }
            }

            // Update group
            _group.Name = GroupNameTextBox.Text.Trim();
            _group.Description = DescriptionTextBox.Text.Trim();
            _group.UrlPatterns = _patterns.ToList();
            _group.ModifiedDate = DateTime.Now;
            _group.Profiles = profiles;
            _group.ClipboardNotificationsEnabled = ClipboardNotifyToggle.IsChecked == true;
            _group.Incognito = IncognitoToggle.IsChecked == true;
            _group.SourceAppFilter = GetSelectedSourceAppFilter();
            _group.HasBeenConfigured = true;  // Mark as user-configured

            // Set behavior based on profile count
            if (profiles.Count > 1)
            {
                _group.Behavior = UrlGroupBehavior.ShowProfilePicker;
            }
            else
            {
                _group.Behavior = UrlGroupBehavior.UseDefault;
            }

            // Also set legacy fields from first profile for compatibility
            if (profiles.Count > 0)
            {
                var first = profiles[0];
                _group.DefaultBrowserName = first.BrowserName;
                _group.DefaultBrowserPath = first.BrowserPath;
                _group.DefaultBrowserType = first.BrowserType;
                _group.DefaultProfileName = first.ProfileName;
                _group.DefaultProfilePath = first.ProfilePath;
                _group.DefaultProfileArguments = first.ProfileArguments;
            }

            _group.LinkedProfileGroupId = string.Empty;

            try
            {
                if (_isEditMode)
                {
                    UrlGroupManager.UpdateGroup(_group);
                }
                else
                {
                    UrlGroupManager.AddGroup(_group);
                }

                // Now that the group is saved, execute pending individual rule deletions
                if (_pendingRuleDeletions.Count > 0)
                {
                    Logger.Log($"Save_Click: Deleting {_pendingRuleDeletions.Count} pending individual rule(s)");
                    foreach (var ruleId in _pendingRuleDeletions)
                    {
                        Logger.Log($"Save_Click: Deleting individual rule Id={ruleId}");
                        UrlRuleManager.DeleteRule(ruleId);
                    }
                    RulesWereModified = true; // Signal caller to refresh rules list
                }

                // Execute pending group pattern removals (group-to-group moves)
                if (_pendingGroupPatternRemovals.Count > 0)
                {
                    Logger.Log($"Save_Click: Removing {_pendingGroupPatternRemovals.Count} pattern(s) from other groups");
                    foreach (var (groupId, groupName, pattern) in _pendingGroupPatternRemovals)
                    {
                        var sourceGroup = UrlGroupManager.LoadGroups().FirstOrDefault(g => g.Id == groupId);
                        if (sourceGroup?.UrlPatterns != null)
                        {
                            var normalized = ValidationService.NormalizePattern(pattern);
                            var removed = sourceGroup.UrlPatterns.RemoveAll(p =>
                                ValidationService.NormalizePattern(p.Pattern) == normalized);
                            if (removed > 0)
                            {
                                Logger.Log($"Save_Click: Removed pattern '{pattern}' from group '{groupName}'");
                                UrlGroupManager.UpdateGroup(sourceGroup);
                            }
                        }
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                ConfirmationDialog.ShowInfo(this, "Error", $"Error saving grouped rule: {ex.Message}");
            }
        }

        private bool HasUnsavedChanges()
        {
            if (_isEditMode)
            {
                var currentPatternStrings = _patterns.Select(p => p.Pattern).ToList();
                bool patternsChanged = !PatternsAreEqual(_initialPatternStrings, currentPatternStrings);
                var currentProfiles = ProfileSelector.GetAllProfiles();
                bool profilesChanged = !ProfilesAreEqual(_initialProfiles, currentProfiles);

                return GroupNameTextBox.Text.Trim() != _initialName
                    || DescriptionTextBox.Text.Trim() != _initialDescription
                    || ClipboardNotifyToggle.IsChecked != _initialClipboardNotify
                    || IncognitoToggle.IsChecked != _initialIncognito
                    || patternsChanged
                    || profilesChanged;
            }
            else
            {
                // New group: any content means unsaved work
                return _patterns.Count > 0
                    || !string.IsNullOrWhiteSpace(GroupNameTextBox.Text);
            }
        }

        private void ShowInlineNotification(string message)
        {
            InlineNotificationText.Text = message;
            InlineNotification.Visibility = Visibility.Visible;

            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(3) };
            timer.Tick += (s, e) =>
            {
                InlineNotification.Visibility = Visibility.Collapsed;
                timer.Stop();
            };
            timer.Start();
        }

        private void SourceAppComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // Change detection handled by the edit-mode wiring
        }

        private void PopulateSourceAppComboBox()
        {
            SourceAppComboBox.Items.Clear();

            var anyItem = new System.Windows.Controls.ComboBoxItem { Content = "Any app", Tag = (string?)null };
            SourceAppComboBox.Items.Add(anyItem);

            var apps = Services.SourceAppDetector.GetAvailableSourceApps();
            foreach (var app in apps)
            {
                var item = new System.Windows.Controls.ComboBoxItem
                {
                    Content = app.DisplayName,
                    Tag = app.ProcessName
                };
                SourceAppComboBox.Items.Add(item);
            }

            SourceAppComboBox.SelectedIndex = 0;
        }

        private void SelectSourceApp(string? processName)
        {
            if (string.IsNullOrEmpty(processName))
            {
                SourceAppComboBox.SelectedIndex = 0;
                return;
            }

            for (int i = 0; i < SourceAppComboBox.Items.Count; i++)
            {
                if (SourceAppComboBox.Items[i] is System.Windows.Controls.ComboBoxItem item &&
                    processName.Equals(item.Tag as string, StringComparison.OrdinalIgnoreCase))
                {
                    SourceAppComboBox.SelectedIndex = i;
                    return;
                }
            }

            // App not in list — add it dynamically
            var friendly = Services.SourceAppDetector.GetFriendlyAppName(processName);
            var newItem = new System.Windows.Controls.ComboBoxItem { Content = friendly, Tag = processName };
            SourceAppComboBox.Items.Add(newItem);
            SourceAppComboBox.SelectedItem = newItem;
        }

        private string? GetSelectedSourceAppFilter()
        {
            if (SourceAppComboBox.SelectedItem is System.Windows.Controls.ComboBoxItem item)
                return item.Tag as string;
            return null;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            if (HasUnsavedChanges())
            {
                if (!ConfirmationDialog.Show(this,
                    "Discard Changes",
                    "You have unsaved changes. Do you want to discard them?",
                    "Yes", "No"))
                {
                    return;
                }
            }

            DialogResult = false;
            Close();
        }
    }
}
