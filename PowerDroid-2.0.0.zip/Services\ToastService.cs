using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace PowerDroid.Services
{
    /// <summary>
    /// Lightweight, auto-dismissing toast anchored to the bottom-center of an owner window.
    /// Borderless, top-most, non-activating; fades in, lingers briefly, then fades out and closes.
    /// </summary>
    public static class ToastService
    {
        public static void Show(Window? owner, string message, int durationMs = 2000)
        {
            if (owner == null || string.IsNullOrWhiteSpace(message)) return;

            try
            {
                // Info glyph gives the toast a clear "notice" affordance so it reads as more than
                // plain text. Segoe Fluent Icons on Win11, Segoe MDL2 Assets fallback on Win10.
                var icon = new TextBlock
                {
                    Text = "", // Info
                    FontFamily = new FontFamily("Segoe Fluent Icons, Segoe MDL2 Assets"),
                    FontSize = 15,
                    Foreground = new SolidColorBrush(Color.FromRgb(0x4C, 0xC2, 0xFF)), // light blue for contrast on dark
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 10, 0)
                };

                var text = new TextBlock
                {
                    Text = message,
                    FontSize = 12,
                    Foreground = Brushes.White,
                    TextWrapping = TextWrapping.Wrap,
                    MaxWidth = 320,
                    VerticalAlignment = VerticalAlignment.Center
                };

                var content = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    VerticalAlignment = VerticalAlignment.Center
                };
                content.Children.Add(icon);
                content.Children.Add(text);

                var border = new Border
                {
                    Background = new SolidColorBrush(Color.FromArgb(0xF0, 0x32, 0x32, 0x32)),
                    CornerRadius = new CornerRadius(6),
                    Padding = new Thickness(14, 10, 16, 10),
                    Child = content,
                    Effect = new System.Windows.Media.Effects.DropShadowEffect
                    {
                        ShadowDepth = 3,
                        BlurRadius = 18,
                        Opacity = 0.45,
                        Color = Colors.Black
                    }
                };

                var win = new Window
                {
                    WindowStyle = WindowStyle.None,
                    AllowsTransparency = true,
                    Background = Brushes.Transparent,
                    ShowInTaskbar = false,
                    ShowActivated = false,
                    Topmost = true,
                    ResizeMode = ResizeMode.NoResize,
                    SizeToContent = SizeToContent.WidthAndHeight,
                    Content = new Border { Padding = new Thickness(12), Background = Brushes.Transparent, Child = border },
                    Opacity = 0
                };

                win.Loaded += (s, e) =>
                {
                    try
                    {
                        // Anchor bottom-center of the owner.
                        win.Left = owner.Left + (owner.ActualWidth - win.ActualWidth) / 2;
                        win.Top = owner.Top + owner.ActualHeight - win.ActualHeight - 24;
                    }
                    catch { }

                    var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180));
                    win.BeginAnimation(UIElement.OpacityProperty, fadeIn);

                    var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(durationMs) };
                    timer.Tick += (ts, te) =>
                    {
                        timer.Stop();
                        var fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(280));
                        fadeOut.Completed += (cs, ce) => { try { win.Close(); } catch { } };
                        win.BeginAnimation(UIElement.OpacityProperty, fadeOut);
                    };
                    timer.Start();
                };

                win.Show();
            }
            catch (Exception ex)
            {
                Logger.Log($"ToastService.Show error: {ex.Message}");
            }
        }
    }
}
