using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using PowerDroid.Models;

namespace PowerDroid.Services
{
    /// <summary>
    /// Service that monitors the Windows clipboard for URL changes.
    /// Uses Win32 AddClipboardFormatListener for efficient clipboard monitoring.
    /// </summary>
    public class ClipboardMonitorService : IDisposable
    {
        #region Win32 Interop

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool AddClipboardFormatListener(IntPtr hwnd);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RemoveClipboardFormatListener(IntPtr hwnd);

        private const int WM_CLIPBOARDUPDATE = 0x031D;

        #endregion

        #region Singleton

        private static ClipboardMonitorService? _instance;
        private static readonly object _lock = new object();

        public static ClipboardMonitorService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new ClipboardMonitorService();
                    }
                }
                return _instance;
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// Fired when a valid URL is detected in the clipboard that matches a rule with notifications enabled.
        /// </summary>
        public event EventHandler<ClipboardUrlEventArgs>? UrlDetected;

        /// <summary>
        /// Fired for ALL clipboard text captures (used by Power Clip).
        /// </summary>
        public event EventHandler<ClipboardTextEventArgs>? ClipboardTextCaptured;

        /// <summary>
        /// Fired when an image is detected on the clipboard (used by Power Clip).
        /// </summary>
        public event EventHandler<ClipboardImageEventArgs>? ClipboardImageCaptured;

        /// <summary>
        /// Fired when a GIF is detected on the clipboard (raw bytes, preserves animation).
        /// </summary>
        public event EventHandler<ClipboardGifEventArgs>? ClipboardGifCaptured;

        #endregion

        #region Fields

        private HwndSource? _hwndSource;
        private bool _isRunning;
        private readonly ConcurrentDictionary<string, DateTime> _recentDomains = new();
        private string? _lastClipboardText;
        private DateTime _lastClipboardTime;
        private const int DEDUP_WINDOW_MS = 3000; // 3 seconds to deduplicate rapid clipboard events
        private bool _disposed;
        private long _suppressUntilTicks; // suppress window end (DateTime ticks); long for Interlocked atomicity
        private const int SUPPRESS_WINDOW_MS = 600; // window to ignore self-initiated copies (a single copy can fire multiple events)
        private const long MaxGifDownloadBytes = 10 * 1024 * 1024; // 10 MB max GIF download size
        private const int MaxRichHtmlBytes = 256 * 1024; // 256 KB cap on captured CF_HTML; over it we keep plain text only
        private const int MinImageDimension = 8; // reject sub-8px captures (transient Clipboard.GetImage garbage)
        private const int ClipboardSettleDelayMs = 120; // let the source app finish its post-copy work (e.g. Snipping Tool's "saved" toast) before we open the clipboard

        private static readonly HttpClient _sharedHttpClient = new()
        {
            Timeout = TimeSpan.FromSeconds(10)
        };

        private static readonly Regex GifUrlPattern = new(
            @"<img[^>]+src=""([^""]+\.gif[^""]*)""",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        #endregion

        #region Properties

        public bool IsRunning => _isRunning;

        /// <summary>
        /// Suppresses clipboard captures for a short window. Use before setting the clipboard from
        /// within the app (e.g. the Copy/Extract buttons). A single Clipboard.Set* call can raise
        /// multiple WM_CLIPBOARDUPDATE events, so a one-shot flag is unreliable — we ignore all
        /// events until the window elapses.
        /// </summary>
        public void SuppressNextCapture() =>
            Interlocked.Exchange(ref _suppressUntilTicks, DateTime.Now.AddMilliseconds(SUPPRESS_WINDOW_MS).Ticks);

        #endregion

        #region Constructor

        private ClipboardMonitorService()
        {
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Starts monitoring the clipboard for URL changes.
        /// </summary>
        public void Start()
        {
            if (_isRunning) return;

            Logger.Log("ClipboardMonitorService: Starting clipboard monitoring");

            Application.Current.Dispatcher.Invoke(() =>
            {
                // Create a hidden window to receive clipboard messages
                var parameters = new HwndSourceParameters("ClipboardMonitorWindow")
                {
                    Width = 0,
                    Height = 0,
                    PositionX = 0,
                    PositionY = 0,
                    WindowStyle = 0x800000 // WS_SYSMENU - minimal window
                };

                _hwndSource = new HwndSource(parameters);
                _hwndSource.AddHook(WndProc);

                if (AddClipboardFormatListener(_hwndSource.Handle))
                {
                    _isRunning = true;
                    Logger.Log("ClipboardMonitorService: Clipboard listener registered successfully");
                }
                else
                {
                    var error = Marshal.GetLastWin32Error();
                    Logger.Log($"ClipboardMonitorService: Failed to register clipboard listener. Error: {error}");
                }
            });
        }

        /// <summary>
        /// Stops monitoring the clipboard.
        /// </summary>
        public void Stop()
        {
            if (!_isRunning) return;

            Logger.Log("ClipboardMonitorService: Stopping clipboard monitoring");

            Application.Current.Dispatcher.Invoke(() =>
            {
                if (_hwndSource != null)
                {
                    RemoveClipboardFormatListener(_hwndSource.Handle);
                    _hwndSource.RemoveHook(WndProc);
                    _hwndSource.Dispose();
                    _hwndSource = null;
                }

                _isRunning = false;
                Logger.Log("ClipboardMonitorService: Clipboard monitoring stopped");
            });
        }

        /// <summary>
        /// Clears the cooldown cache, allowing immediate notifications.
        /// </summary>
        public void ClearCooldownCache()
        {
            _recentDomains.Clear();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Validates that a URL is safe to download (HTTPS only, no private/internal IPs).
        /// </summary>
        private static bool IsUrlSafeToDownload(string url)
        {
            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
                return false;

            if (!string.Equals(uri.Scheme, "https", StringComparison.OrdinalIgnoreCase))
                return false;

            // Reject localhost and private IP ranges
            if (uri.IsLoopback)
                return false;

            if (IPAddress.TryParse(uri.Host, out var ip))
            {
                var bytes = ip.GetAddressBytes();
                if (bytes.Length == 4)
                {
                    // 10.x.x.x, 172.16-31.x.x, 192.168.x.x
                    if (bytes[0] == 10) return false;
                    if (bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31) return false;
                    if (bytes[0] == 192 && bytes[1] == 168) return false;
                    if (bytes[0] == 127) return false;
                }
            }

            return true;
        }

        /// <summary>
        /// True when the clipboard owner marked the content as excluded from clipboard history
        /// (password managers, browser password fields, banking apps). Mirrors the marker formats
        /// Windows Clipboard History (Win+V) honors so secrets never enter Power Clip's store.
        /// </summary>
        private static bool IsExcludedFromHistory(System.Windows.IDataObject dataObj)
        {
            try
            {
                // Presence alone signals "do not process" — used for passwords/secrets.
                if (dataObj.GetDataPresent("ExcludeClipboardContentFromMonitorProcessing"))
                    return true;

                // DWORD flag; a value of 0 means "keep out of clipboard history".
                if (dataObj.GetDataPresent("CanIncludeInClipboardHistory") &&
                    ReadDwordFormat(dataObj, "CanIncludeInClipboardHistory") == 0)
                    return true;
            }
            catch { /* best-effort: never block capture on a marker read failure */ }

            return false;
        }

        /// <summary>Reads a 4-byte DWORD clipboard format value, or null if unavailable.</summary>
        private static int? ReadDwordFormat(System.Windows.IDataObject dataObj, string format)
        {
            try
            {
                if (dataObj.GetData(format) is System.IO.MemoryStream ms)
                {
                    var bytes = ms.ToArray();
                    if (bytes.Length >= 4)
                        return BitConverter.ToInt32(bytes, 0);
                }
            }
            catch { }

            return null;
        }

        /// <summary>
        /// Decodes the clipboard's "PNG" stream into a frozen BitmapSource when present. Apps like
        /// Greenshot place a lossless PNG alongside the DIB; preferring it sidesteps the 32-bit alpha
        /// corruption Clipboard.GetImage() introduces. Returns null when no PNG stream is available.
        /// </summary>
        private static BitmapSource? TryDecodePngStream(System.Windows.IDataObject? dataObj)
        {
            if (dataObj == null) return null;

            foreach (var fmt in new[] { "PNG", "image/png" })
            {
                try
                {
                    if (!dataObj.GetDataPresent(fmt)) continue;
                    if (dataObj.GetData(fmt) is not System.IO.Stream stream) continue;

                    using var ms = new System.IO.MemoryStream();
                    stream.CopyTo(ms);
                    if (ms.Length == 0) continue;
                    ms.Position = 0;

                    var decoder = new PngBitmapDecoder(ms, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
                    if (decoder.Frames.Count > 0)
                    {
                        var frame = decoder.Frames[0];
                        if (frame.CanFreeze) frame.Freeze();
                        return frame;
                    }
                }
                catch { /* fall through to next format / GetImage fallback */ }
            }

            return null;
        }

        /// <summary>
        /// Flattens a fully-transparent BitmapSource to opaque. Clipboard.GetImage() reads 32-bit DIBs
        /// (e.g. from Greenshot) treating the unused 4th byte as alpha=0, yielding an invisible image
        /// even though the RGB data is intact. When every pixel is transparent we force alpha to 255;
        /// images with any genuine opacity are returned unchanged.
        /// </summary>
        private static BitmapSource? RepairTransparentImage(BitmapSource? source)
        {
            if (source == null) return null;

            try
            {
                var bgra = source.Format == PixelFormats.Bgra32
                    ? source
                    : new FormatConvertedBitmap(source, PixelFormats.Bgra32, null, 0);

                int w = bgra.PixelWidth, h = bgra.PixelHeight;
                int stride = w * 4;
                var pixels = new byte[h * stride];
                bgra.CopyPixels(pixels, stride, 0);

                for (int i = 3; i < pixels.Length; i += 4)
                {
                    if (pixels[i] != 0)
                        return source; // has real alpha somewhere — leave untouched
                }

                // Entirely transparent → the DIB's alpha bytes were just padding. Reveal the image.
                for (int i = 3; i < pixels.Length; i += 4)
                    pixels[i] = 255;

                var repaired = BitmapSource.Create(
                    w, h, bgra.DpiX, bgra.DpiY, PixelFormats.Bgra32, null, pixels, stride);
                repaired.Freeze();
                return repaired;
            }
            catch
            {
                return source;
            }
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_CLIPBOARDUPDATE)
            {
                handled = true;
                OnClipboardUpdate();
            }

            return IntPtr.Zero;
        }

        private async void OnClipboardUpdate()
        {
            try
            {
                if (DateTime.Now.Ticks < Interlocked.Read(ref _suppressUntilTicks))
                {
                    return;
                }

                // Be a polite clipboard reader: yield briefly so the app that just copied (e.g. the
                // Snipping Tool) can finish its own post-copy bookkeeping and show its "saved to
                // clipboard" toast before we open the clipboard. Opening it the instant
                // WM_CLIPBOARDUPDATE fires contends for the single global clipboard lock and forces
                // delayed-render formats to materialize, which suppresses that notification.
                await System.Threading.Tasks.Task.Delay(ClipboardSettleDelayMs);

                // Get clipboard content with retry for transient clipboard locks
                string? text = null;
                System.Windows.Media.Imaging.BitmapSource? image = null;
                byte[]? gifBytes = null;
                string? richHtml = null;

                for (int attempt = 0; attempt < 3; attempt++)
                {
                    try
                    {
                        (text, image, gifBytes) = await Application.Current.Dispatcher.InvokeAsync(() =>
                        {
                            var dataObj = Clipboard.GetDataObject();

                            // Honor the clipboard owner's privacy opt-out (passwords, secrets) using the
                            // same marker formats Windows Clipboard History (Win+V) respects. Skip capture
                            // entirely so sensitive content never lands in Power Clip's plaintext store.
                            if (dataObj != null && IsExcludedFromHistory(dataObj))
                            {
                                Logger.Log("ClipboardMonitorService: Content marked as excluded from clipboard history — skipping capture");
                                return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, (byte[]?)null);
                            }

                            if (Clipboard.ContainsText())
                            {
                                var plain = Clipboard.GetText();

                                // Capture the rich HTML alongside the text when the source provided
                                // one (e.g. a hyperlink). Stored verbatim and size-capped; plain text
                                // remains the fallback so nothing regresses if HTML is absent/oversized.
                                try
                                {
                                    if (Clipboard.ContainsData(DataFormats.Html) &&
                                        Clipboard.GetData(DataFormats.Html) is string html &&
                                        !string.IsNullOrEmpty(html) &&
                                        System.Text.Encoding.UTF8.GetByteCount(html) <= MaxRichHtmlBytes)
                                    {
                                        richHtml = html;
                                    }
                                }
                                catch { /* HTML is best-effort; plain text already captured */ }

                                return (plain, (System.Windows.Media.Imaging.BitmapSource?)null, (byte[]?)null);
                            }

                            // Check for raw GIF data first (preserves animation)
                            if (dataObj != null)
                            {
                                // Note: intentionally NOT calling dataObj.GetFormats() here. Enumerating
                                // every format eagerly materializes delayed-render data and is the heaviest
                                // interference for image captures (it can suppress the source app's own
                                // "copied" notification). The probes below use GetDataPresent per specific
                                // format instead.

                                // Try multiple GIF format names
                                foreach (var fmt in new[] { "GIF", "image/gif", "gif" })
                                {
                                    if (dataObj.GetDataPresent(fmt))
                                    {
                                        var data = dataObj.GetData(fmt);
                                        if (data is System.IO.MemoryStream ms)
                                            return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, ms.ToArray());
                                        if (data is System.IO.Stream stream)
                                        {
                                            using var reader = new System.IO.MemoryStream();
                                            stream.CopyTo(reader);
                                            return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, reader.ToArray());
                                        }
                                    }
                                }

                                // Try FileContents (some apps put GIFs as file drops)
                                if (dataObj.GetDataPresent(DataFormats.FileDrop))
                                {
                                    var files = dataObj.GetData(DataFormats.FileDrop) as string[];
                                    if (files?.Length == 1 && files[0].EndsWith(".gif", StringComparison.OrdinalIgnoreCase) && System.IO.File.Exists(files[0]))
                                    {
                                        var bytes = System.IO.File.ReadAllBytes(files[0]);
                                        return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, bytes);
                                    }
                                }

                                // Try HTML Format — extract original image URL (browsers put GIF source URL here)
                                if (dataObj.GetDataPresent("HTML Format") && Clipboard.ContainsImage())
                                {
                                    var html = dataObj.GetData("HTML Format") as string;
                                    if (!string.IsNullOrEmpty(html))
                                    {
                                        var match = GifUrlPattern.Match(html);
                                        if (match.Success)
                                        {
                                            var gifUrl = match.Groups[1].Value;
                                            if (IsUrlSafeToDownload(gifUrl))
                                            {
                                                Logger.Log($"ClipboardMonitorService: Found GIF URL in HTML Format: {Logger.SanitizeUrl(gifUrl)}");
                                                try
                                                {
                                                    var gifData = _sharedHttpClient.GetByteArrayAsync(gifUrl).GetAwaiter().GetResult();
                                                    if (gifData.Length > 0 && gifData.Length <= MaxGifDownloadBytes)
                                                        return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, gifData);
                                                }
                                                catch (Exception dlEx)
                                                {
                                                    Logger.Log($"ClipboardMonitorService: Failed to download GIF: {dlEx.Message}");
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Prefer the lossless PNG stream when an app provides one (e.g. Greenshot).
                            // Clipboard.GetImage() reads CF_DIB and mishandles 32-bit alpha, producing a
                            // fully transparent (invisible) image. Fall back to GetImage() with a
                            // transparency repair when no PNG stream is present.
                            var pngImage = TryDecodePngStream(dataObj);
                            if (pngImage != null)
                                return ((string?)null, pngImage, (byte[]?)null);

                            if (Clipboard.ContainsImage())
                                return ((string?)null, RepairTransparentImage(Clipboard.GetImage()), (byte[]?)null);

                            return ((string?)null, (System.Windows.Media.Imaging.BitmapSource?)null, (byte[]?)null);
                        });
                        break; // Success
                    }
                    catch (System.Runtime.InteropServices.COMException) when (attempt < 2)
                    {
                        // Clipboard locked by another app — wait and retry without blocking UI
                        await System.Threading.Tasks.Task.Delay(100);
                    }
                }

                // Detect source application once, early — before any event firing
                var sourceApp = SourceAppDetector.GetCurrentSourceApp();

                // Handle GIF capture (raw bytes, preserves animation)
                if (gifBytes != null && gifBytes.Length > 0)
                {
                    ClipboardGifCaptured?.Invoke(this, new ClipboardGifEventArgs(gifBytes, sourceApp));
                    return;
                }

                // Handle image capture (static BitmapSource → PNG)
                if (image != null)
                {
                    if (!image.IsFrozen) image.Freeze();

                    // Guard against garbage captures: Clipboard.GetImage() can momentarily return a
                    // tiny/corrupt bitmap when read mid-update. Native clipboard history never stores
                    // these, so drop anything below a sane minimum size.
                    if (image.PixelWidth < MinImageDimension || image.PixelHeight < MinImageDimension)
                    {
                        Logger.Log($"ClipboardMonitorService: Ignoring undersized image capture ({image.PixelWidth}x{image.PixelHeight})");
                        return;
                    }

                    ClipboardImageCaptured?.Invoke(this, new ClipboardImageEventArgs(image, sourceApp));
                    return;
                }

                if (string.IsNullOrWhiteSpace(text))
                    return;

                // Deduplicate rapid clipboard events (e.g. browsers fire multiple events per copy)
                // but allow re-copying the same URL after the dedup window expires
                var now = DateTime.Now;
                if (text == _lastClipboardText && (now - _lastClipboardTime).TotalMilliseconds < DEDUP_WINDOW_MS)
                    return;

                _lastClipboardText = text;
                _lastClipboardTime = now;

                // Fire event for Power Clip (captures ALL text, not just URLs)
                ClipboardTextCaptured?.Invoke(this, new ClipboardTextEventArgs(text, sourceApp, richHtml));

                // Check if it's a valid URL
                var url = NormalizeUrl(text.Trim());
                if (url == null)
                    return;

                Logger.Log($"ClipboardMonitorService: Valid URL detected: {Logger.SanitizeUrl(url)}");

                // Get settings
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;

                // Check if paused
                if (settings.IsPaused)
                {
                    Logger.Log("ClipboardMonitorService: Monitoring is paused, ignoring URL");
                    return;
                }

                // Extract domain
                string domain;
                try
                {
                    domain = new Uri(url).Host.ToLowerInvariant();
                }
                catch
                {
                    return;
                }

                // Check cooldown
                if (!ShouldNotify(domain, settings.CooldownSeconds))
                {
                    Logger.Log($"ClipboardMonitorService: Domain '{domain}' is in cooldown period");
                    return;
                }

                // Check if URL matches a rule (single pass for both enabled and disabled matches)
                var fullMatch = UrlRuleManager.FindMatchWithDisabledCheck(url, sourceApp?.ProcessName);
                var match = fullMatch.Match;
                if (match.Type == MatchType.NoMatch)
                {
                    if (fullMatch.HasDisabledMatch)
                    {
                        Logger.Log($"ClipboardMonitorService: Disabled rule/group exists for URL, suppressing notification");
                    }
                    else
                    {
                        Logger.Log($"ClipboardMonitorService: URL doesn't match any rule, ignoring");
                    }
                    return;
                }

                // Check if the matched rule has clipboard notifications enabled
                bool clipboardEnabled = match.Type switch
                {
                    MatchType.IndividualRule => match.Rule?.ClipboardNotificationsEnabled ?? true,
                    MatchType.UrlGroup => match.Group?.ClipboardNotificationsEnabled ?? true,
                    MatchType.GroupOverride => match.Group?.ClipboardNotificationsEnabled ?? true,
                    _ => false
                };

                if (!clipboardEnabled)
                {
                    Logger.Log($"ClipboardMonitorService: Rule has clipboard notifications disabled");
                    return;
                }

                // Fire event
                UrlDetected?.Invoke(this, new ClipboardUrlEventArgs(url, domain, sourceApp));
            }
            catch (Exception ex)
            {
                Logger.Log($"ClipboardMonitorService: Error processing clipboard: {ex.Message}");
            }
        }

        private string? NormalizeUrl(string text)
        {
            // Skip if text is too long (likely not a URL)
            if (text.Length > 2000)
                return null;

            // Skip if text contains newlines (likely multi-line text)
            if (text.Contains('\n') || text.Contains('\r'))
                return null;

            // Check for common URL patterns
            string url = text;

            // Handle www. prefix without protocol
            if (url.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                url = "https://" + url;
            }

            // Must start with http:// or https://
            if (!url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
                !url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }

            // Validate as URI
            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
                return null;

            // Must be HTTP or HTTPS
            if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)
                return null;

            // Must have a valid host
            if (string.IsNullOrWhiteSpace(uri.Host))
                return null;

            // Host must contain a dot (filter out localhost, etc. if desired)
            // But allow localhost for development
            if (!uri.Host.Contains('.') && uri.Host != "localhost")
                return null;

            return url;
        }

        private bool ShouldNotify(string domain, int cooldownSeconds)
        {
            var now = DateTime.Now;

            // Clean up old entries
            var cutoff = now.AddMinutes(-5);
            foreach (var key in _recentDomains.Keys.ToList())
            {
                if (_recentDomains.TryGetValue(key, out var time) && time < cutoff)
                {
                    _recentDomains.TryRemove(key, out _);
                }
            }

            // Check cooldown
            if (_recentDomains.TryGetValue(domain, out var lastNotified))
            {
                if ((now - lastNotified).TotalSeconds < cooldownSeconds)
                {
                    return false;
                }
            }

            // Update last notified time
            _recentDomains[domain] = now;
            return true;
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            if (_disposed) return;

            Stop();
            _disposed = true;
        }

        #endregion
    }

    /// <summary>
    /// Event args for clipboard text capture events (used by Power Clip).
    /// </summary>
    public class ClipboardTextEventArgs : EventArgs
    {
        public string Text { get; }
        public SourceAppInfo? SourceApp { get; }

        /// <summary>Verbatim CF_HTML blob captured with the text, when present. Null otherwise.</summary>
        public string? RichHtml { get; }

        public ClipboardTextEventArgs(string text, SourceAppInfo? sourceApp, string? richHtml = null)
        {
            Text = text;
            SourceApp = sourceApp;
            RichHtml = richHtml;
        }
    }

    /// <summary>
    /// Event args for clipboard URL detection events.
    /// </summary>
    public class ClipboardUrlEventArgs : EventArgs
    {
        public string Url { get; }
        public string Domain { get; }
        public SourceAppInfo? SourceApp { get; }

        public ClipboardUrlEventArgs(string url, string domain, SourceAppInfo? sourceApp = null)
        {
            Url = url;
            Domain = domain;
            SourceApp = sourceApp;
        }
    }

    /// <summary>
    /// Event args for clipboard image capture events.
    /// </summary>
    public class ClipboardImageEventArgs : EventArgs
    {
        public System.Windows.Media.Imaging.BitmapSource Image { get; }
        public SourceAppInfo? SourceApp { get; }

        public ClipboardImageEventArgs(System.Windows.Media.Imaging.BitmapSource image, SourceAppInfo? sourceApp)
        {
            Image = image;
            SourceApp = sourceApp;
        }
    }

    /// <summary>
    /// Event args for clipboard GIF capture events.
    /// </summary>
    public class ClipboardGifEventArgs : EventArgs
    {
        public byte[] GifBytes { get; }
        public SourceAppInfo? SourceApp { get; }

        public ClipboardGifEventArgs(byte[] gifBytes, SourceAppInfo? sourceApp)
        {
            GifBytes = gifBytes;
            SourceApp = sourceApp;
        }
    }
}
