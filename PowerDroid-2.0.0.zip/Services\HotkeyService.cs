using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Interop;

namespace PowerDroid.Services
{
    /// <summary>
    /// Singleton service for global keyboard shortcuts.
    /// Uses Win32 RegisterHotKey for the Rules/Launcher hotkeys, and a global low-level keyboard
    /// hook for the Power Clip "double-Shift" gesture (two quick Shift taps, JetBrains-style).
    /// Double-Shift is used for Power Clip because — unlike Alt-based hotkeys — a bare Shift never
    /// triggers Office/Windows menu accelerators, so it doesn't steal focus from the target editor.
    /// </summary>
    public class HotkeyService : IDisposable
    {
        #region Win32 Interop

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll")]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc callback, IntPtr hInstance, uint threadId);

        [DllImport("user32.dll")]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll")]
        private static extern uint GetCurrentThreadId();

        [DllImport("user32.dll")]
        private static extern int GetMessage(out MSG lpMsg, IntPtr hWnd, uint min, uint max);

        [DllImport("user32.dll")]
        private static extern bool TranslateMessage(ref MSG lpMsg);

        [DllImport("user32.dll")]
        private static extern IntPtr DispatchMessage(ref MSG lpMsg);

        [DllImport("user32.dll")]
        private static extern bool PostThreadMessage(uint idThread, uint Msg, IntPtr wParam, IntPtr lParam);

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT { public int x, y; }

        [StructLayout(LayoutKind.Sequential)]
        private struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam, lParam; public uint time; public POINT pt; }

        [StructLayout(LayoutKind.Sequential)]
        private struct KBDLLHOOKSTRUCT { public uint vkCode, scanCode, flags, time; public IntPtr dwExtraInfo; }

        private const int WM_HOTKEY = 0x0312;
        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_KEYUP = 0x0101;
        private const int WM_SYSKEYDOWN = 0x0104;
        private const int WM_SYSKEYUP = 0x0105;
        private const uint WM_QUIT = 0x0012;
        private const uint LLKHF_INJECTED = 0x10;
        private const int VK_SHIFT = 0x10;
        private const int VK_LSHIFT = 0xA0;
        private const int VK_RSHIFT = 0xA1;
        private const int VK_CONTROL = 0x11;
        private const int VK_LCONTROL = 0xA2;
        private const int VK_RCONTROL = 0xA3;

        /// <summary>Max gap between the two modifier taps to count as a double-tap gesture.</summary>
        private const double DoubleTapMs = 350;

        // Power Clip trigger modes (HotkeySettings.ClipTrigger).
        public const string TRIGGER_DOUBLE_SHIFT = "DoubleShift";
        public const string TRIGGER_DOUBLE_CTRL = "DoubleCtrl";
        public const string TRIGGER_CUSTOM = "Custom";

        /// <summary>Human-readable label for the current Power Clip trigger, for UI display.</summary>
        public static string GetClipHotkeyDisplay()
        {
            var hk = SettingsManager.LoadSettings().Hotkeys;
            return hk.ClipTrigger switch
            {
                TRIGGER_DOUBLE_CTRL => "Ctrl + Ctrl",
                TRIGGER_CUSTOM => FormatHotkey(hk.ClipModifiers, hk.ClipKey),
                _ => "Shift + Shift",
            };
        }

        // Hotkey IDs
        private const int HOTKEY_RULES = 1;
        private const int HOTKEY_POWERCLIP = 2;
        private const int HOTKEY_LAUNCHER = 3;
        private const int HOTKEY_TEST = 9;   // transient id used only by CanRegister

        // Modifier constants (for UI display)
        public const uint MOD_ALT = 0x0001;
        public const uint MOD_CTRL = 0x0002;
        public const uint MOD_SHIFT = 0x0004;

        #endregion

        #region Singleton

        private static HotkeyService? _instance;
        private static readonly object _lock = new object();

        public static HotkeyService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new HotkeyService();
                    }
                }
                return _instance;
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// Fired when a registered hotkey is pressed. Parameter is the page name ("Rules" or "PowerClip").
        /// </summary>
        public event EventHandler<string>? HotkeyPressed;

        #endregion

        #region Fields

        private HwndSource? _hwndSource;
        private bool _isRunning;
        private bool _disposed;

        // Double-tap detection (global low-level keyboard hook on a dedicated thread + pump).
        private Thread? _kbThread;
        private uint _kbThreadId;
        private IntPtr _kbHook;
        private LowLevelKeyboardProc? _kbProc;
        private bool _gestureIsShift = true;  // which modifier the gesture watches (Shift vs Ctrl)
        // Detection state — touched only on the hook thread.
        private bool _modDown;                // the watched modifier is held (ignore auto-repeat downs)
        private bool _modUsedWithOtherKey;    // another key was pressed during this modifier hold
        private long _firstTapUpTick;         // timestamp of the first clean tap's key-up

        #endregion

        #region Constructor

        private HotkeyService()
        {
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Registers global hotkeys from settings and starts listening.
        /// </summary>
        public void Start()
        {
            if (_isRunning) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                var parameters = new HwndSourceParameters("HotkeyListenerWindow")
                {
                    Width = 0,
                    Height = 0,
                    PositionX = 0,
                    PositionY = 0,
                    WindowStyle = 0x800000 // WS_SYSMENU
                };

                _hwndSource = new HwndSource(parameters);
                _hwndSource.AddHook(WndProc);

                RegisterFromSettings();
                StartDoubleShiftHook();
                _isRunning = true;
            });
        }

        /// <summary>
        /// Unregisters hotkeys and stops listening.
        /// </summary>
        public void Stop()
        {
            if (!_isRunning) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                if (_hwndSource != null)
                {
                    UnregisterHotKey(_hwndSource.Handle, HOTKEY_RULES);
                    UnregisterHotKey(_hwndSource.Handle, HOTKEY_LAUNCHER);
                    _hwndSource.RemoveHook(WndProc);
                    _hwndSource.Dispose();
                    _hwndSource = null;
                }

                StopDoubleShiftHook();

                _isRunning = false;
                Logger.Log("HotkeyService: Global hotkeys unregistered");
            });
        }

        /// <summary>
        /// Re-reads settings and re-registers hotkeys. Call after user changes shortcuts.
        /// </summary>
        public void Reload()
        {
            if (!_isRunning || _hwndSource == null) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                UnregisterHotKey(_hwndSource.Handle, HOTKEY_RULES);
                UnregisterHotKey(_hwndSource.Handle, HOTKEY_POWERCLIP);
                UnregisterHotKey(_hwndSource.Handle, HOTKEY_LAUNCHER);
                RegisterFromSettings();
                // The Power Clip trigger mode may have changed, so restart the gesture hook.
                StopDoubleShiftHook();
                StartDoubleShiftHook();
            });
        }

        /// <summary>
        /// Temporarily disables all global hotkeys and the Power Clip gesture hook. Call while the
        /// user is recording a custom shortcut so the keys they press don't fire the real action
        /// (open the rules page, launcher, or clipboard popup). Pair with <see cref="Resume"/>.
        /// </summary>
        public void Suspend()
        {
            if (!_isRunning || _hwndSource == null) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                if (_hwndSource == null) return;
                UnregisterHotKey(_hwndSource.Handle, HOTKEY_RULES);
                UnregisterHotKey(_hwndSource.Handle, HOTKEY_POWERCLIP);
                UnregisterHotKey(_hwndSource.Handle, HOTKEY_LAUNCHER);
                StopDoubleShiftHook();
            });
        }

        /// <summary>Re-enables global hotkeys after a <see cref="Suspend"/> (recording finished).</summary>
        public void Resume() => Reload();

        /// <summary>
        /// Formats a modifier+key combination as a display string (e.g., "Ctrl+Shift+R").
        /// </summary>
        public static string FormatHotkey(uint modifiers, uint vk)
        {
            var parts = new System.Collections.Generic.List<string>();
            if ((modifiers & MOD_CTRL) != 0) parts.Add("Ctrl");
            if ((modifiers & MOD_ALT) != 0) parts.Add("Alt");
            if ((modifiers & MOD_SHIFT) != 0) parts.Add("Shift");
            parts.Add(KeyName(vk));
            return string.Join("+", parts);
        }

        /// <summary>
        /// Returns a friendly name if the combo is a well-known Windows/editing shortcut that would
        /// disrupt normal use if bound globally (e.g. Ctrl+C "Copy"), or null if it's safe to bind.
        /// Windows has no API to detect these — they register successfully via RegisterHotKey because
        /// they're application accelerators, not registered global hotkeys — so, like PowerToys, we
        /// keep a small curated list. Only bare Ctrl+&lt;key&gt; combos collide; adding Alt/Shift makes
        /// them safe (which is why the app's Alt-based defaults and Ctrl+Shift combos are unaffected).
        /// </summary>
        public static string? GetReservedShortcutName(uint modifiers, uint vk)
        {
            if (modifiers != MOD_CTRL) return null;

            return vk switch
            {
                0x43 => "Copy (Ctrl+C)",
                0x56 => "Paste (Ctrl+V)",
                0x58 => "Cut (Ctrl+X)",
                0x5A => "Undo (Ctrl+Z)",
                0x59 => "Redo (Ctrl+Y)",
                0x41 => "Select All (Ctrl+A)",
                0x53 => "Save (Ctrl+S)",
                0x46 => "Find (Ctrl+F)",
                0x50 => "Print (Ctrl+P)",
                0x4E => "New (Ctrl+N)",
                0x4F => "Open (Ctrl+O)",
                0x57 => "Close (Ctrl+W)",
                0x54 => "New Tab (Ctrl+T)",
                _ => null
            };
        }

        /// <summary>
        /// Tests whether a modifier+key combo can be claimed as a global hotkey right now — i.e. it
        /// isn't already owned by Windows or another application. Registers it momentarily and
        /// immediately unregisters on success. Call while the service is <see cref="Suspend"/>ed
        /// during shortcut recording so the app's own hotkeys don't count as external conflicts.
        /// Returns true (don't block the user) when the listener window isn't available to test.
        /// </summary>
        public bool CanRegister(uint modifiers, uint vk)
        {
            if (vk == 0) return true;

            bool ok = true; // if we can't test (no listener window), don't block the user
            Application.Current.Dispatcher.Invoke(() =>
            {
                if (_hwndSource == null) return;
                if (RegisterHotKey(_hwndSource.Handle, HOTKEY_TEST, modifiers, vk))
                {
                    UnregisterHotKey(_hwndSource.Handle, HOTKEY_TEST);
                    ok = true;
                }
                else
                {
                    ok = false;
                }
            });
            return ok;
        }

        #endregion

        #region Private Methods

        private void RegisterFromSettings()
        {
            var settings = SettingsManager.LoadSettings().Hotkeys;

            if (settings.RulesKey != 0 && _hwndSource != null)
            {
                if (!RegisterHotKey(_hwndSource.Handle, HOTKEY_RULES, settings.RulesModifiers, settings.RulesKey))
                    Logger.Log($"HotkeyService: Failed to register Rules hotkey {FormatHotkey(settings.RulesModifiers, settings.RulesKey)} (error {Marshal.GetLastWin32Error()})");
            }

            // Power Clip: in Custom mode use a normal RegisterHotKey combo; the gesture modes
            // (double-Shift / double-Ctrl) are handled by the low-level keyboard hook instead.
            if (BrandConfig.PowerClipEnabled && settings.ClipTrigger == TRIGGER_CUSTOM
                && settings.ClipKey != 0 && _hwndSource != null)
            {
                if (!RegisterHotKey(_hwndSource.Handle, HOTKEY_POWERCLIP, settings.ClipModifiers, settings.ClipKey))
                    Logger.Log($"HotkeyService: Failed to register Clip hotkey {FormatHotkey(settings.ClipModifiers, settings.ClipKey)} (error {Marshal.GetLastWin32Error()})");
            }

            if (settings.LauncherKey != 0 && _hwndSource != null)
            {
                if (!RegisterHotKey(_hwndSource.Handle, HOTKEY_LAUNCHER, settings.LauncherModifiers, settings.LauncherKey))
                    Logger.Log($"HotkeyService: Failed to register Launcher hotkey {FormatHotkey(settings.LauncherModifiers, settings.LauncherKey)} (error {Marshal.GetLastWin32Error()})");
            }

            Logger.Log($"HotkeyService: Registered — Rules: {FormatHotkey(settings.RulesModifiers, settings.RulesKey)}, Clip: {GetClipHotkeyDisplay()} ({settings.ClipTrigger}), Launcher: {FormatHotkey(settings.LauncherModifiers, settings.LauncherKey)}");
        }

        private static string KeyName(uint vk)
        {
            if (vk >= 0x30 && vk <= 0x39) return ((char)vk).ToString(); // 0-9
            if (vk >= 0x41 && vk <= 0x5A) return ((char)vk).ToString(); // A-Z
            if (vk >= 0x70 && vk <= 0x7B) return $"F{vk - 0x6F}";      // F1-F12
            if (vk >= 0x60 && vk <= 0x69) return $"Num{vk - 0x60}";    // Numpad 0-9

            switch (vk)
            {
                case 0x20: return "Space";
                case 0x0D: return "Enter";
                case 0x08: return "Backspace";
                case 0x09: return "Tab";
                case 0x1B: return "Esc";
                case 0x2E: return "Del";
                case 0x2D: return "Ins";
                case 0x24: return "Home";
                case 0x23: return "End";
                case 0x21: return "PgUp";
                case 0x22: return "PgDn";
                case 0x25: return "←";
                case 0x26: return "↑";
                case 0x27: return "→";
                case 0x28: return "↓";
                // OEM punctuation (US layout)
                case 0xC0: return "`";
                case 0xBD: return "-";
                case 0xBB: return "=";
                case 0xDB: return "[";
                case 0xDD: return "]";
                case 0xDC: return "\\";
                case 0xBA: return ";";
                case 0xDE: return "'";
                case 0xBC: return ",";
                case 0xBE: return ".";
                case 0xBF: return "/";
                // Numpad operators
                case 0x6A: return "Num*";
                case 0x6B: return "Num+";
                case 0x6D: return "Num-";
                case 0x6E: return "Num.";
                case 0x6F: return "Num/";
            }

            // Fall back to WPF's key name (e.g. "MediaPlayPause") before a raw hex code.
            var wpfKey = System.Windows.Input.KeyInterop.KeyFromVirtualKey((int)vk);
            return wpfKey != System.Windows.Input.Key.None ? wpfKey.ToString() : $"0x{vk:X2}";
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_HOTKEY)
            {
                handled = true;
                int id = wParam.ToInt32();

                string? pageName = id switch
                {
                    HOTKEY_RULES => "Rules",
                    HOTKEY_POWERCLIP => "PowerClip",
                    HOTKEY_LAUNCHER => "Launcher",
                    _ => null
                };

                if (pageName != null)
                {
                    Logger.Log($"HotkeyService: Hotkey pressed for {pageName}");
                    HotkeyPressed?.Invoke(this, pageName);
                }
            }

            return IntPtr.Zero;
        }

        #endregion

        #region Double-Shift hook

        private void StartDoubleShiftHook()
        {
            if (!BrandConfig.PowerClipEnabled || _kbThread != null) return;

            // Only the gesture modes use the hook; Custom mode uses RegisterHotKey instead.
            var trigger = SettingsManager.LoadSettings().Hotkeys.ClipTrigger;
            if (trigger != TRIGGER_DOUBLE_SHIFT && trigger != TRIGGER_DOUBLE_CTRL) return;
            _gestureIsShift = trigger != TRIGGER_DOUBLE_CTRL;
            _modDown = false;
            _modUsedWithOtherKey = false;
            _firstTapUpTick = 0;

            _kbThread = new Thread(DoubleShiftThreadProc)
            {
                IsBackground = true,
                Name = "PowerClipDoubleTap"
            };
            _kbThread.Start();
        }

        // True if vk is the (left/right/generic) form of the modifier the gesture watches.
        private bool IsGestureModifier(int vk) => _gestureIsShift
            ? (vk == VK_SHIFT || vk == VK_LSHIFT || vk == VK_RSHIFT)
            : (vk == VK_CONTROL || vk == VK_LCONTROL || vk == VK_RCONTROL);

        private void StopDoubleShiftHook()
        {
            if (_kbThreadId != 0)
            {
                PostThreadMessage(_kbThreadId, WM_QUIT, IntPtr.Zero, IntPtr.Zero);
                _kbThreadId = 0;
            }
            _kbThread = null;
        }

        // Runs the low-level keyboard hook on its own thread with a message pump, so the callback is
        // serviced even when the UI thread is busy (Windows silently drops LL hooks that time out).
        private void DoubleShiftThreadProc()
        {
            _kbThreadId = GetCurrentThreadId();
            _kbProc = DoubleShiftHookCallback; // keep the delegate alive for the hook's lifetime
            _kbHook = SetWindowsHookEx(WH_KEYBOARD_LL, _kbProc, IntPtr.Zero, 0);

            while (GetMessage(out MSG msg, IntPtr.Zero, 0, 0) > 0)
            {
                TranslateMessage(ref msg);
                DispatchMessage(ref msg);
            }

            if (_kbHook != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_kbHook);
                _kbHook = IntPtr.Zero;
            }
        }

        // Detects two clean taps of the watched modifier (Shift or Ctrl) within DoubleTapMs
        // (JetBrains-style). A "clean" tap is a press/release with no other key in between;
        // injected (synthetic) events and auto-repeat are ignored so a held modifier and our own
        // synthesized keystrokes never trigger it.
        private IntPtr DoubleShiftHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                var data = Marshal.PtrToStructure<KBDLLHOOKSTRUCT>(lParam);
                if ((data.flags & LLKHF_INJECTED) == 0)
                {
                    int msg = (int)wParam;
                    int vk = (int)data.vkCode;
                    bool isMod = IsGestureModifier(vk);

                    if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN)
                    {
                        if (isMod)
                        {
                            if (!_modDown)
                            {
                                _modDown = true;
                                _modUsedWithOtherKey = false;
                            }
                            // else: auto-repeat while held — ignore
                        }
                        else
                        {
                            // Any other key cancels a pending double-tap and marks this modifier
                            // hold as "used with another key" (e.g. Ctrl+C), so its release isn't
                            // counted as a solo tap.
                            if (_modDown) _modUsedWithOtherKey = true;
                            _firstTapUpTick = 0;
                        }
                    }
                    else if (msg == WM_KEYUP || msg == WM_SYSKEYUP)
                    {
                        if (isMod)
                        {
                            _modDown = false;
                            if (_modUsedWithOtherKey)
                            {
                                _firstTapUpTick = 0; // wasn't a solo tap
                            }
                            else
                            {
                                long now = Stopwatch.GetTimestamp();
                                if (_firstTapUpTick != 0 &&
                                    (now - _firstTapUpTick) * 1000.0 / Stopwatch.Frequency <= DoubleTapMs)
                                {
                                    _firstTapUpTick = 0;
                                    Logger.Log($"HotkeyService: double-tap ({(_gestureIsShift ? "Shift" : "Ctrl")}) detected for PowerClip");
                                    HotkeyPressed?.Invoke(this, "PowerClip");
                                }
                                else
                                {
                                    _firstTapUpTick = now; // this is the first tap
                                }
                            }
                        }
                    }
                }
            }
            return CallNextHookEx(_kbHook, nCode, wParam, lParam);
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            if (_disposed) return;

            Stop();
            _disposed = true;
        }

        #endregion
    }
}
