using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid.Controls
{
    /// <summary>
    /// Reusable list of all installed browsers grouped with their profiles. Each profile can be
    /// launched normally or in a private/incognito window, and pinned to a top "Pinned" section.
    /// Hosted both in the compact popup (CompactMode) and the full Settings "Browsers" page.
    /// </summary>
    public partial class BrowserProfileListView : UserControl
    {
        private sealed class GroupVm
        {
            public BrowserInfoWithColor Browser { get; init; } = null!;
            public List<ProfileDisplayInfo> Profiles { get; init; } = new();
        }

        // A keyboard-selectable launchable row, in display order.
        private sealed class RowVm
        {
            public Border Border { get; init; } = null!;
            public BrowserInfoWithColor Browser { get; init; } = null!;
            public ProfileDisplayInfo Profile { get; init; } = null!;
        }

        // Collapse key for the Favourites section (browser groups key off their exe path).
        private const string FavKey = "::favourites::";

        private readonly List<GroupVm> _groups = new();
        private readonly HashSet<string> _collapsed = new(); // collapse keys (FavKey + browser exe paths)
        private readonly List<RowVm> _rows = new();
        private int _selectedIndex = -1;

        private bool _compactMode;

        /// <summary>Raised after a profile is launched, so a host popup can close itself.</summary>
        public event EventHandler? ProfileLaunched;

        /// <summary>Raised when sections expand/collapse so a host can update an Expand/Collapse All control.</summary>
        public event EventHandler? CollapseStateChanged;

        public BrowserProfileListView()
        {
            InitializeComponent();
        }

        /// <summary>Tighter spacing for the narrow compact popup.</summary>
        public bool CompactMode
        {
            get => _compactMode;
            set { _compactMode = value; }
        }

        /// <summary>Re-scans browsers/profiles from cache and renders.</summary>
        public void LoadData()
        {
            BuildGroups();
            Render();
        }

        /// <summary>Clears the detection cache and reloads (F5 / manual refresh).</summary>
        public void Refresh()
        {
            BrowserDetector.ClearCache();
            LoadData();
        }

        /// <summary>Focuses the filter box (host calls this when the view becomes visible).</summary>
        public void FocusSearch()
        {
            SearchBox.Focus();
            SearchBox.SelectAll();
        }

        public void ClearFilter()
        {
            SearchBox.Text = string.Empty;
        }

        /// <summary>
        /// Appends a character to the filter and keeps the caret at the end. Host-driven: when the
        /// compact window is launched from a global hotkey it often can't take real keyboard focus,
        /// so the keyboard hook feeds type-to-filter here instead of relying on the TextBox focus.
        /// </summary>
        public void AppendToFilter(char c)
        {
            SearchBox.Text += c;
            SearchBox.CaretIndex = SearchBox.Text.Length;
        }

        /// <summary>Removes the last filter character (host-driven backspace, see AppendToFilter).</summary>
        public void BackspaceFilter()
        {
            if (SearchBox.Text.Length > 0)
                SearchBox.Text = SearchBox.Text.Substring(0, SearchBox.Text.Length - 1);
            SearchBox.CaretIndex = SearchBox.Text.Length;
        }

        private void ClearSearch_Click(object sender, RoutedEventArgs e)
        {
            ClearFilter();
            SearchBox.Focus();
        }

        private void BuildGroups()
        {
            _groups.Clear();
            try
            {
                var browsers = BrowserService.GetBrowsersWithColors();
                foreach (var browser in browsers)
                {
                    var profiles = BrowserService.GetProfiles(browser)
                        .Select(ProfileDisplayInfo.FromProfileInfo)
                        .ToList();
                    _groups.Add(new GroupVm { Browser = browser, Profiles = profiles });
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserProfileListView.BuildGroups error: {ex.Message}");
            }
        }

        private bool Matches(GroupVm g, ProfileDisplayInfo p, string filter)
        {
            if (string.IsNullOrEmpty(filter)) return true;
            return (g.Browser.Name?.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0)
                || (p.Name?.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0)
                || (p.Email?.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void Render()
        {
            RootPanel.Children.Clear();
            _rows.Clear();
            _selectedIndex = -1;

            var filter = SearchBox.Text?.Trim() ?? string.Empty;
            bool filtering = !string.IsNullOrEmpty(filter);

            if (_groups.Count == 0)
            {
                EmptyText.Text = "No browsers found";
                EmptyText.Visibility = Visibility.Visible;
                RaiseCollapseStateChanged();
                return;
            }

            // Number of section headers shown (favourites + browser groups). Used so the empty
            // message only appears when nothing matches — NOT when sections are merely collapsed.
            int groupsShown = 0;

            // Favourites (pinned across browsers) — a collapsible section, respecting the filter.
            var favourites = new List<(GroupVm g, ProfileDisplayInfo p)>();
            foreach (var g in _groups)
                foreach (var p in g.Profiles)
                    if (SettingsManager.IsProfilePinned(g.Browser.ExecutablePath, p.Path) && Matches(g, p, filter))
                        favourites.Add((g, p));

            if (favourites.Count > 0)
            {
                bool favCollapsed = !filtering && _collapsed.Contains(FavKey);
                RootPanel.Children.Add(CreateFavouritesHeader(favCollapsed));
                groupsShown++;
                if (!favCollapsed)
                    foreach (var (g, p) in favourites)
                        RootPanel.Children.Add(CreateProfileRow(g.Browser, p, indent: true, showBadge: true));
            }

            // Browser groups.
            foreach (var g in _groups)
            {
                var visibleProfiles = g.Profiles.Where(p => Matches(g, p, filter)).ToList();
                if (visibleProfiles.Count == 0) continue;

                bool collapsed = !filtering && _collapsed.Contains(g.Browser.ExecutablePath);
                RootPanel.Children.Add(CreateGroupHeader(g.Browser, collapsed, visibleProfiles.Count));
                groupsShown++;

                if (!collapsed)
                {
                    foreach (var p in visibleProfiles)
                        RootPanel.Children.Add(CreateProfileRow(g.Browser, p, indent: true, showBadge: false));
                }
            }

            if (groupsShown == 0)
            {
                EmptyText.Text = filtering ? "No matching profiles" : "No profiles found";
                EmptyText.Visibility = Visibility.Visible;
            }
            else
            {
                EmptyText.Visibility = Visibility.Collapsed;
                if (_rows.Count > 0)
                {
                    // Pre-highlight the first row so Enter launches it immediately (like the Clipboard tab).
                    _selectedIndex = 0;
                    UpdateSelectionHighlight();
                }
            }

            RaiseCollapseStateChanged();
        }

        #region Expand / collapse

        /// <summary>Collapse keys for all sections currently present (favourites + each browser).</summary>
        private List<string> GetCollapseKeys()
        {
            var keys = new List<string>();
            bool anyPinned = _groups.Any(g => g.Profiles.Any(p =>
                SettingsManager.IsProfilePinned(g.Browser.ExecutablePath, p.Path)));
            if (anyPinned) keys.Add(FavKey);
            foreach (var g in _groups) keys.Add(g.Browser.ExecutablePath);
            return keys;
        }

        /// <summary>True if at least one section is currently expanded.</summary>
        public bool AnyExpanded() => GetCollapseKeys().Any(k => !_collapsed.Contains(k));

        public void ExpandAll()
        {
            _collapsed.Clear();
            Render();
        }

        public void CollapseAll()
        {
            foreach (var k in GetCollapseKeys()) _collapsed.Add(k);
            Render();
        }

        private void RaiseCollapseStateChanged() => CollapseStateChanged?.Invoke(this, EventArgs.Empty);

        #endregion

        private UIElement CreateFavouritesHeader(bool collapsed)
        {
            var heart = new TextBlock
            {
                Text = "", // HeartFill
                FontSize = 13,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0),
                Foreground = new SolidColorBrush(Color.FromRgb(0xE2, 0x55, 0x63))
            };
            heart.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");
            return CreateCollapsibleHeader(FavKey, heart, "Favourites", collapsed);
        }

        private UIElement CreateCollapsibleHeader(string collapseKey, UIElement? iconElement, string title, bool collapsed)
        {
            var border = new Border
            {
                Padding = new Thickness(6, 6, 6, 4),
                Margin = new Thickness(2, 6, 2, 0),
                CornerRadius = new CornerRadius(4),
                Cursor = Cursors.Hand,
                Background = Brushes.Transparent
            };

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });   // chevron
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });   // icon
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // title

            var chevron = new TextBlock
            {
                Text = collapsed ? "" : "", // ChevronRight / ChevronDown
                FontSize = 10,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(2, 0, 8, 0)
            };
            chevron.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");
            chevron.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
            Grid.SetColumn(chevron, 0);
            grid.Children.Add(chevron);

            if (iconElement != null)
            {
                Grid.SetColumn(iconElement, 1);
                grid.Children.Add(iconElement);
            }

            var name = new TextBlock
            {
                Text = title,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center
            };
            name.SetResourceReference(TextBlock.ForegroundProperty, "TextPrimaryBrush");
            Grid.SetColumn(name, 2);
            grid.Children.Add(name);

            border.Child = grid;
            border.MouseEnter += (s, e) => border.SetResourceReference(Border.BackgroundProperty, "NavigationItemHoverBrush");
            border.MouseLeave += (s, e) => border.Background = Brushes.Transparent;
            border.MouseLeftButtonUp += (s, e) =>
            {
                if (_collapsed.Contains(collapseKey))
                    _collapsed.Remove(collapseKey);
                else
                    _collapsed.Add(collapseKey);
                Render();
            };
            return border;
        }

        private UIElement CreateGroupHeader(BrowserInfoWithColor browser, bool collapsed, int count)
        {
            var border = new Border
            {
                Padding = new Thickness(6, 6, 6, 4),
                Margin = new Thickness(2, 6, 2, 0),
                CornerRadius = new CornerRadius(4),
                Cursor = Cursors.Hand,
                Background = Brushes.Transparent
            };

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });   // chevron
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });   // icon
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // name

            var chevron = new TextBlock
            {
                Text = collapsed ? "" : "", // ChevronRight / ChevronDown
                FontSize = 10,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(2, 0, 8, 0)
            };
            chevron.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");
            chevron.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
            Grid.SetColumn(chevron, 0);
            grid.Children.Add(chevron);

            if (browser.Icon != null)
            {
                var icon = new Image
                {
                    Source = browser.Icon,
                    Width = 16,
                    Height = 16,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 8, 0)
                };
                Grid.SetColumn(icon, 1);
                grid.Children.Add(icon);
            }

            var name = new TextBlock
            {
                Text = browser.Name,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center
            };
            name.SetResourceReference(TextBlock.ForegroundProperty, "TextPrimaryBrush");
            Grid.SetColumn(name, 2);
            grid.Children.Add(name);

            border.Child = grid;
            border.MouseEnter += (s, e) => border.SetResourceReference(Border.BackgroundProperty, "NavigationItemHoverBrush");
            border.MouseLeave += (s, e) => border.Background = Brushes.Transparent;
            border.MouseLeftButtonUp += (s, e) =>
            {
                if (_collapsed.Contains(browser.ExecutablePath))
                    _collapsed.Remove(browser.ExecutablePath);
                else
                    _collapsed.Add(browser.ExecutablePath);
                Render();
            };
            return border;
        }

        private Border CreateProfileRow(BrowserInfoWithColor browser, ProfileDisplayInfo profile, bool indent, bool showBadge)
        {
            var border = new Border
            {
                MinHeight = _compactMode ? 40 : 46,
                Padding = _compactMode ? new Thickness(8, 5, 6, 5) : new Thickness(10, 7, 8, 7),
                // Offset child profiles so they sit visually under the browser header.
                Margin = new Thickness(indent ? 22 : 4, 2, 4, 2),
                CornerRadius = new CornerRadius(6),
                Cursor = Cursors.Hand,
                Background = Brushes.Transparent,
                // Constant thickness + transparent default so the selection outline doesn't shift layout.
                BorderThickness = new Thickness(1.5),
                BorderBrush = Brushes.Transparent
            };

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });   // avatar
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // text
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });   // pin
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });   // open
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });   // incognito

            // Avatar (initials with async image swap), optionally badged with the browser icon
            var avatar = BuildAvatar(profile, showBadge ? browser : null);
            Grid.SetColumn(avatar, 0);
            grid.Children.Add(avatar);

            // Name + email
            var textPanel = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            var nameText = new TextBlock
            {
                Text = profile.Name,
                FontSize = 12,
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            nameText.SetResourceReference(TextBlock.ForegroundProperty, "TextPrimaryBrush");
            textPanel.Children.Add(nameText);
            if (!string.IsNullOrWhiteSpace(profile.Email))
            {
                var emailText = new TextBlock
                {
                    Text = profile.Email,
                    FontSize = 10,
                    TextTrimming = TextTrimming.CharacterEllipsis
                };
                emailText.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
                textPanel.Children.Add(emailText);
            }
            Grid.SetColumn(textPanel, 1);
            grid.Children.Add(textPanel);

            // Pin toggle
            bool isPinned = SettingsManager.IsProfilePinned(browser.ExecutablePath, profile.Path);
            var pinBtn = CreateIconButton(isPinned ? "" : "", isPinned ? "Remove from Favourites" : "Add to Favourites", "IconButtonRedStyle",
                explicitForeground: isPinned ? new SolidColorBrush(Color.FromRgb(0xE2, 0x55, 0x63)) : null,
                onClick: () =>
                {
                    SettingsManager.ToggleProfilePin(browser.ExecutablePath, profile.Path);
                    Render();
                });
            Grid.SetColumn(pinBtn, 2);
            grid.Children.Add(pinBtn);

            // Open (normal)
            var openBtn = CreateIconButton("", "Open", "IconButtonBlueStyle",
                onClick: () => LaunchProfile(browser, profile, incognito: false));
            Grid.SetColumn(openBtn, 3);
            grid.Children.Add(openBtn);

            // Open Incognito (only when the browser family has a known private flag)
            if (BrowserLaunchHelper.GetIncognitoArg(browser.Name, browser.Type) != null)
            {
                var incoBtn = CreateIncognitoButton("Open Incognito",
                    onClick: () => LaunchProfile(browser, profile, incognito: true));
                Grid.SetColumn(incoBtn, 4);
                grid.Children.Add(incoBtn);
            }

            border.Child = grid;

            var row = new RowVm { Border = border, Browser = browser, Profile = profile };
            _rows.Add(row);
            int rowIndex = _rows.Count - 1;

            border.MouseEnter += (s, e) => { if (rowIndex != _selectedIndex) border.SetResourceReference(Border.BackgroundProperty, "NavigationItemHoverBrush"); };
            border.MouseLeave += (s, e) => { if (rowIndex != _selectedIndex) border.Background = Brushes.Transparent; };
            border.MouseLeftButtonUp += (s, e) => LaunchProfile(browser, profile, incognito: false);

            return border;
        }

        private Grid BuildAvatar(ProfileDisplayInfo profile, BrowserInfoWithColor? badgeBrowser)
        {
            var avatar = new Grid
            {
                Width = 24,
                Height = 24,
                Margin = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center
            };

            var initialsEllipse = new Ellipse { Width = 24, Height = 24 };
            initialsEllipse.SetResourceReference(Shape.FillProperty, "ProfileAvatarBgBrush");
            var initialsText = new TextBlock
            {
                Text = profile.Initial,
                FontSize = 11,
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            initialsText.SetResourceReference(TextBlock.ForegroundProperty, "ProfileAvatarFgBrush");

            var imgEllipse = new Ellipse { Width = 24, Height = 24, Visibility = Visibility.Collapsed };

            avatar.Children.Add(initialsEllipse);
            avatar.Children.Add(initialsText);
            avatar.Children.Add(imgEllipse);

            void ApplyAvatar()
            {
                if (profile.Avatar != null)
                {
                    imgEllipse.Fill = new ImageBrush(profile.Avatar) { Stretch = Stretch.UniformToFill };
                    imgEllipse.Visibility = Visibility.Visible;
                    initialsEllipse.Visibility = Visibility.Collapsed;
                    initialsText.Visibility = Visibility.Collapsed;
                }
            }

            profile.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(ProfileDisplayInfo.Avatar))
                    Dispatcher.Invoke(ApplyAvatar);
            };
            ApplyAvatar();

            // Kick off async avatar fetch (no-op if already loaded or no URL).
            if (profile.Avatar == null && !string.IsNullOrEmpty(profile.AvatarUrl))
                _ = LoadAvatarAsync(profile);

            // Browser-icon badge at the bottom-right (used in the mixed "Pinned" section).
            if (badgeBrowser?.Icon != null)
            {
                var badge = new Border
                {
                    Width = 13,
                    Height = 13,
                    CornerRadius = new CornerRadius(7),
                    HorizontalAlignment = HorizontalAlignment.Right,
                    VerticalAlignment = VerticalAlignment.Bottom,
                    Margin = new Thickness(0, 0, -2, -2),
                    Padding = new Thickness(1)
                };
                badge.SetResourceReference(Border.BackgroundProperty, "CardBackgroundBrush");
                var badgeImg = new Image { Source = badgeBrowser.Icon, Width = 11, Height = 11 };
                RenderOptions.SetBitmapScalingMode(badgeImg, BitmapScalingMode.HighQuality);
                badge.Child = badgeImg;
                avatar.Children.Add(badge);
            }

            return avatar;
        }

        private static async Task LoadAvatarAsync(ProfileDisplayInfo profile)
        {
            try
            {
                var avatar = await ProfileAvatarService.GetAvatarAsync(profile.AvatarUrl!, profile.Path);
                if (avatar != null)
                    profile.Avatar = avatar; // PropertyChanged updates the row
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserProfileListView avatar load failed: {ex.Message}");
            }
        }

        private Button CreateIconButton(string glyph, string tooltip, string styleName, Action onClick, Brush? explicitForeground = null)
        {
            var iconBlock = new TextBlock { Text = glyph, FontSize = 14 };
            iconBlock.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");

            if (explicitForeground != null)
            {
                iconBlock.Foreground = explicitForeground;
            }
            else
            {
                var binding = new System.Windows.Data.Binding("Foreground")
                {
                    RelativeSource = new System.Windows.Data.RelativeSource(
                        System.Windows.Data.RelativeSourceMode.FindAncestor, typeof(Button), 1)
                };
                iconBlock.SetBinding(TextBlock.ForegroundProperty, binding);
            }

            var button = new Button
            {
                ToolTip = tooltip,
                Margin = new Thickness(0, 0, 2, 0),
                Cursor = Cursors.Hand,
                Content = iconBlock,
                VerticalAlignment = VerticalAlignment.Center
            };
            button.SetResourceReference(Button.StyleProperty, styleName);
            button.Click += (s, e) => { e.Handled = true; onClick(); };
            return button;
        }

        /// <summary>
        /// "Open Incognito" button. Drawn as a vector hat + glasses so it always renders
        /// (the Segoe Fluent InPrivate glyph is missing on some systems and showed as tofu).
        /// </summary>
        private Button CreateIncognitoButton(string tooltip, Action onClick)
        {
            var group = new GeometryGroup();
            // Hat dome (open curve)
            group.Children.Add(Geometry.Parse("M6,9 C6,4.5 7.5,3 10.5,3 C13.5,3 15,4.5 15,9"));
            // Hat brim
            group.Children.Add(new LineGeometry(new Point(3.5, 9), new Point(17.5, 9)));
            // Glasses lenses (stroked rings)
            group.Children.Add(new EllipseGeometry(new Point(7, 14), 2.6, 2.6));
            group.Children.Add(new EllipseGeometry(new Point(14, 14), 2.6, 2.6));
            // Bridge between lenses
            group.Children.Add(new LineGeometry(new Point(9.6, 13.7), new Point(11.4, 13.7)));

            var path = new Path
            {
                Data = group,
                StrokeThickness = 1.5,
                StrokeStartLineCap = PenLineCap.Round,
                StrokeEndLineCap = PenLineCap.Round,
                StrokeLineJoin = PenLineJoin.Round
            };
            var strokeBind = new System.Windows.Data.Binding("Foreground")
            {
                RelativeSource = new System.Windows.Data.RelativeSource(
                    System.Windows.Data.RelativeSourceMode.FindAncestor, typeof(Button), 1)
            };
            path.SetBinding(Shape.StrokeProperty, strokeBind);

            var icon = new Viewbox
            {
                Width = 16,
                Height = 16,
                Child = path,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            var button = new Button
            {
                ToolTip = tooltip,
                Margin = new Thickness(0, 0, 2, 0),
                Cursor = Cursors.Hand,
                Content = icon,
                VerticalAlignment = VerticalAlignment.Center
            };
            button.SetResourceReference(Button.StyleProperty, "IconButtonBlueStyle");
            button.Click += (s, e) => { e.Handled = true; onClick(); };
            return button;
        }

        private void LaunchProfile(BrowserInfoWithColor browser, ProfileDisplayInfo profile, bool incognito)
        {
            try
            {
                BrowserLaunchHelper.Launch(browser.ExecutablePath, browser.Name, browser.Type,
                    profile.Arguments, url: null, incognito: incognito);
                Logger.Log($"BrowserProfileListView: launched {browser.Name} / {profile.Name} (incognito={incognito})");
            }
            catch (Exception ex)
            {
                Logger.Log($"BrowserProfileListView launch error: {ex.Message}");
            }
            ProfileLaunched?.Invoke(this, EventArgs.Empty);
        }

        #region Keyboard + filter

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Render();
        }

        private void SearchBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Down:
                    MoveSelection(1);
                    e.Handled = true;
                    break;
                case Key.Up:
                    MoveSelection(-1);
                    e.Handled = true;
                    break;
                case Key.Enter:
                    if (_selectedIndex >= 0 && _selectedIndex < _rows.Count)
                    {
                        bool incognito = (Keyboard.Modifiers & (ModifierKeys.Control | ModifierKeys.Shift)) != 0;
                        var r = _rows[_selectedIndex];
                        LaunchProfile(r.Browser, r.Profile, incognito);
                    }
                    e.Handled = true;
                    break;
                case Key.F5:
                    Refresh();
                    e.Handled = true;
                    break;
                // Escape intentionally bubbles so a host popup can close.
            }
        }

        private void MoveSelection(int delta)
        {
            if (_rows.Count == 0) return;
            if (_selectedIndex < 0)
                _selectedIndex = delta > 0 ? 0 : _rows.Count - 1;
            else
                _selectedIndex = Math.Max(0, Math.Min(_rows.Count - 1, _selectedIndex + delta));
            UpdateSelectionHighlight(scroll: true);
        }

        /// <summary>Move the keyboard selection down one launchable row. For host-driven (hook) nav.</summary>
        public void SelectNext() => MoveSelection(1);

        /// <summary>Move the keyboard selection up one launchable row. For host-driven (hook) nav.</summary>
        public void SelectPrevious() => MoveSelection(-1);

        /// <summary>Launch the currently selected profile (incognito when requested). For host-driven nav.</summary>
        public void LaunchSelected(bool incognito)
        {
            if (_selectedIndex >= 0 && _selectedIndex < _rows.Count)
            {
                var r = _rows[_selectedIndex];
                LaunchProfile(r.Browser, r.Profile, incognito);
            }
        }

        private void UpdateSelectionHighlight(bool scroll = false)
        {
            for (int i = 0; i < _rows.Count; i++)
            {
                if (i == _selectedIndex)
                {
                    // Theme-aware outline (not a background fill) so mouse hover can't clear it.
                    _rows[i].Border.SetResourceReference(Border.BorderBrushProperty, "SelectionOutlineBrush");
                    // Only scroll when the user actively navigates — not on render/tab-switch.
                    if (scroll) _rows[i].Border.BringIntoView();
                }
                else
                {
                    _rows[i].Border.BorderBrush = Brushes.Transparent;
                }
            }
        }

        #endregion
    }
}
