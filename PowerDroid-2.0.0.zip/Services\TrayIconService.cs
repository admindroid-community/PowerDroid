using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using PowerDroid.Models;
using Hardcodet.Wpf.TaskbarNotification;

namespace PowerDroid.Services
{
    /// <summary>
    /// Service that manages the system tray icon for background clipboard monitoring.
    /// Uses Hardcodet.NotifyIcon.Wpf (WPF-native, no WinForms dependency).
    /// </summary>
    public class TrayIconService : IDisposable
    {
        #region Singleton

        private static TrayIconService? _instance;
        private static readonly object _lock = new object();

        public static TrayIconService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new TrayIconService();
                    }
                }
                return _instance;
            }
        }

        #endregion

        #region Fields

        private TaskbarIcon? _taskbarIcon;
        private MenuItem? _statusMenuItem;
        private MenuItem? _resumeMenuItem;
        private MenuItem? _pauseMenuItem;
        private DispatcherTimer? _pauseTimer;
        private bool _disposed;
        private bool _isVisible;

        #endregion

        #region Native

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
        private static extern bool GetCursorPos(out POINT lpPoint);

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        private struct POINT { public int X; public int Y; }

        #endregion

        #region Events

        public event EventHandler? SettingsRequested;
        public event EventHandler? SettingsPageRequested;
        public event EventHandler? ExitRequested;
        public event EventHandler? StateChanged;

        #endregion

        #region Properties

        public bool IsVisible => _isVisible;

        #endregion

        #region Constructor

        private TrayIconService()
        {
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Shows the tray icon.
        /// </summary>
        public void Show()
        {
            Logger.Log($"TrayIconService.Show() called. Already visible: {_isVisible}");

            if (_isVisible) return;

            try
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    // Only create once — reuse existing instance
                    if (_taskbarIcon == null)
                        CreateTaskbarIcon();

                    if (_taskbarIcon != null)
                    {
                        _taskbarIcon.Visibility = Visibility.Visible;
                        _isVisible = true;
                        Logger.Log("TrayIconService: Tray icon shown");
                    }
                    else
                    {
                        Logger.Log("TrayIconService: TaskbarIcon is null after creation!");
                    }
                });
            }
            catch (Exception ex)
            {
                Logger.Log($"TrayIconService.Show() ERROR: {ex.Message}");
            }
        }

        /// <summary>
        /// Hides the tray icon.
        /// </summary>
        public void Hide()
        {
            if (!_isVisible) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                if (_taskbarIcon != null)
                {
                    _taskbarIcon.Visibility = Visibility.Collapsed;
                    _isVisible = false;
                    Logger.Log("TrayIconService: Tray icon hidden");
                }
            });
        }

        /// <summary>
        /// Updates the tray icon state based on current settings.
        /// </summary>
        public void UpdateState()
        {
            if (_taskbarIcon == null || _statusMenuItem == null) return;

            var settings = SettingsManager.LoadSettings().ClipboardMonitoring;

            Application.Current.Dispatcher.Invoke(() =>
            {
                if (!settings.IsEnabled)
                {
                    // Mirror the paused layout: a greyed "Disabled" info line with "Resume
                    // Monitoring" below it (rather than a clickable checkbox).
                    _statusMenuItem.Header = "Disabled";
                    _statusMenuItem.IsChecked = false;
                    _statusMenuItem.IsCheckable = false;
                    _statusMenuItem.IsEnabled = false;
                    _taskbarIcon.ToolTipText = $"{BrandConfig.AppDisplayName}\nClipboard monitoring is off";
                    if (_resumeMenuItem != null) _resumeMenuItem.Visibility = Visibility.Visible;
                    if (_pauseMenuItem != null) { _pauseMenuItem.Header = "Pause for..."; _pauseMenuItem.IsEnabled = false; }
                }
                else if (settings.IsPaused)
                {
                    var remaining = settings.RemainingPauseTime;
                    _statusMenuItem.Header = remaining.HasValue
                        ? $"Resumes in {FormatRemainingTime(remaining)}"
                        : "Paused";
                    _statusMenuItem.IsChecked = false;
                    _statusMenuItem.IsEnabled = false;
                    _statusMenuItem.IsCheckable = false;
                    _taskbarIcon.ToolTipText = remaining.HasValue
                        ? $"{BrandConfig.AppDisplayName}\nMonitoring resumes in {FormatRemainingTime(remaining)}"
                        : $"{BrandConfig.AppDisplayName}\nMonitoring paused";
                    if (_resumeMenuItem != null) _resumeMenuItem.Visibility = Visibility.Visible;
                    if (_pauseMenuItem != null) { _pauseMenuItem.Header = "Extend Time"; _pauseMenuItem.IsEnabled = true; }
                }
                else
                {
                    _statusMenuItem.Header = "Active";
                    _statusMenuItem.IsChecked = true;
                    _statusMenuItem.IsEnabled = true;
                    _statusMenuItem.IsCheckable = true;
                    _taskbarIcon.ToolTipText = $"{BrandConfig.AppDisplayName}\nClipboard monitoring is active";
                    if (_resumeMenuItem != null) _resumeMenuItem.Visibility = Visibility.Collapsed;
                    if (_pauseMenuItem != null) { _pauseMenuItem.Header = "Pause for..."; _pauseMenuItem.IsEnabled = true; }
                }

                StateChanged?.Invoke(this, EventArgs.Empty);
            });
        }

        /// <summary>
        /// Shows a brief balloon notification.
        /// </summary>
        public void ShowBalloon(string title, string text, BalloonIcon icon = BalloonIcon.Info, int timeout = 2000)
        {
            if (_taskbarIcon == null) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                _taskbarIcon.ShowBalloonTip(title, text, icon);
            });
        }

        /// <summary>
        /// Pauses clipboard monitoring for the specified duration.
        /// If already paused, extends from the current pause end time.
        /// </summary>
        public void PauseFor(TimeSpan duration)
        {
            var settings = SettingsManager.LoadSettings();
            var cm = settings.ClipboardMonitoring;

            var baseTime = cm.IsPaused && cm.PauseEndTime.HasValue
                ? cm.PauseEndTime.Value
                : DateTime.Now;
            cm.PauseEndTime = baseTime.Add(duration);
            SettingsManager.SaveSettings(settings);

            var totalRemaining = cm.PauseEndTime!.Value - DateTime.Now;
            Logger.Log($"TrayIconService: Monitoring paused/extended by {duration.TotalMinutes} minutes (total remaining: {totalRemaining.TotalMinutes:F0} minutes)");

            StartPauseTimer(totalRemaining);
            UpdateState();
        }

        /// <summary>
        /// Resumes clipboard monitoring — makes it active now whether it was paused or disabled.
        /// </summary>
        public void Resume()
        {
            var settings = SettingsManager.LoadSettings();
            settings.ClipboardMonitoring.IsEnabled = true;
            settings.ClipboardMonitoring.PauseEndTime = null;
            SettingsManager.SaveSettings(settings);

            if (!ClipboardMonitorService.Instance.IsRunning)
                ClipboardMonitorService.Instance.Start();

            StopPauseTimer();
            UpdateState();

            Logger.Log("TrayIconService: Monitoring resumed");
        }

        #endregion

        #region Private Methods

        private void CreateTaskbarIcon()
        {
            var contextMenu = CreateContextMenu();

            // The Hardcodet library mis-computes the menu position under Per-Monitor DPI,
            // so anchor it ourselves once it's laid out (see PositionTrayMenu).
            contextMenu.Opened += (s, e) => PositionTrayMenu(contextMenu);

            _taskbarIcon = new TaskbarIcon
            {
                IconSource = LoadIcon(),
                ToolTipText = BrandConfig.AppDisplayName,
                ContextMenu = contextMenu,
                MenuActivation = PopupActivationMode.RightClick,
                Visibility = Visibility.Collapsed
            };

            // Single left-click opens settings
            _taskbarIcon.TrayLeftMouseUp += (s, e) =>
            {
                SettingsRequested?.Invoke(this, EventArgs.Empty);
            };
        }

        /// <summary>
        /// Positions the tray context menu at the cursor, kept inside the active monitor's
        /// working area. The Hardcodet TaskbarIcon mis-computes placement under Per-Monitor
        /// DPI (the menu lands in the wrong spot), so we compute it generically: read the
        /// physical cursor position, convert to DIPs via the popup's own DPI, and flip the
        /// menu up/left near the screen edges like a normal tray menu. Works across taskbar
        /// positions and DPI scales.
        /// </summary>
        private static void PositionTrayMenu(ContextMenu menu)
        {
            try
            {
                if (!GetCursorPos(out POINT cursor)) return;

                var source = PresentationSource.FromVisual(menu);
                if (source?.CompositionTarget == null) return;

                // Device pixels -> DIPs (M11/M22 == 1 / DPI scale for this monitor).
                var toDip = source.CompositionTarget.TransformFromDevice;
                double cx = cursor.X * toDip.M11;
                double cy = cursor.Y * toDip.M22;

                var wa = System.Windows.Forms.Screen
                    .FromPoint(new System.Drawing.Point(cursor.X, cursor.Y)).WorkingArea;
                double waLeft = wa.Left * toDip.M11;
                double waTop = wa.Top * toDip.M22;
                double waRight = wa.Right * toDip.M11;
                double waBottom = wa.Bottom * toDip.M22;

                double w = menu.ActualWidth;
                double h = menu.ActualHeight;

                // Open down/right when there's room; otherwise flip up/left (bottom-right tray).
                double x = (cx + w <= waRight) ? cx : cx - w;
                double y = (cy + h <= waBottom) ? cy : cy - h;

                // Clamp fully inside the working area.
                if (w > 0) x = Math.Max(waLeft, Math.Min(x, waRight - w));
                if (h > 0) y = Math.Max(waTop, Math.Min(y, waBottom - h));

                menu.Placement = System.Windows.Controls.Primitives.PlacementMode.AbsolutePoint;
                menu.HorizontalOffset = x;
                menu.VerticalOffset = y;
            }
            catch (Exception ex)
            {
                Logger.Log($"TrayIconService: menu placement failed: {ex.Message}");
            }
        }

        private ImageSource? LoadIcon()
        {
            // Try to load from WPF application resources using BitmapDecoder (handles .ico multi-frame)
            try
            {
                var resourceUri = new Uri("pack://application:,,,/Assets/Icons/app.ico", UriKind.Absolute);
                var decoder = BitmapDecoder.Create(resourceUri, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                if (decoder.Frames.Count > 0)
                {
                    // Pick the best frame for tray icon (prefer 16x16, then 32x32 for crisp scaling)
                    var frame = decoder.Frames
                        .OrderBy(f => f.PixelWidth == 16 ? 0 : f.PixelWidth == 32 ? 1 : Math.Abs(f.PixelWidth - 16) + 10)
                        .First();
                    Logger.Log($"TrayIconService: Loaded icon from WPF resource ({frame.PixelWidth}x{frame.PixelHeight})");
                    return frame;
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"TrayIconService: WPF resource load failed: {ex.Message}");
            }

            // Fallback: try to load from file
            try
            {
                var iconPaths = new[]
                {
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Icons", "app.ico"),
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"{BrandConfig.ExeName}.ico")
                };

                foreach (var iconPath in iconPaths)
                {
                    if (File.Exists(iconPath))
                    {
                        var decoder = BitmapDecoder.Create(
                            new Uri(iconPath), BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                        if (decoder.Frames.Count > 0)
                        {
                            var frame = decoder.Frames.OrderBy(f => Math.Abs(f.PixelWidth - 32)).First();
                            Logger.Log($"TrayIconService: Loaded icon from file: {iconPath}");
                            return frame;
                        }
                    }
                }

                Logger.Log("TrayIconService: No icon file found");
            }
            catch (Exception ex)
            {
                Logger.Log($"TrayIconService: File load failed: {ex.Message}");
            }

            return null;
        }

        private ContextMenu CreateContextMenu()
        {
            var contextMenu = new ContextMenu();

            // Clipboard Monitoring submenu (shared by Smart Browse and Power Clip)
            var clipboardMonitoringMenuItem = new MenuItem { Header = "Clipboard Monitoring" };

            _statusMenuItem = new MenuItem
            {
                Header = "Enabled",
                IsCheckable = true,
                IsChecked = true
            };
            _statusMenuItem.Click += StatusMenuItem_Click;
            clipboardMonitoringMenuItem.Items.Add(_statusMenuItem);

            clipboardMonitoringMenuItem.Items.Add(new Separator());

            _resumeMenuItem = new MenuItem { Header = "Resume Now", Visibility = Visibility.Collapsed };
            _resumeMenuItem.Click += (s, e) => Resume();
            clipboardMonitoringMenuItem.Items.Add(_resumeMenuItem);

            _pauseMenuItem = new MenuItem { Header = "Pause for..." };
            _pauseMenuItem.Items.Add(CreatePauseItem("5 minutes", TimeSpan.FromMinutes(5)));
            _pauseMenuItem.Items.Add(CreatePauseItem("15 minutes", TimeSpan.FromMinutes(15)));
            _pauseMenuItem.Items.Add(CreatePauseItem("30 minutes", TimeSpan.FromMinutes(30)));
            _pauseMenuItem.Items.Add(CreatePauseItem("1 hour", TimeSpan.FromHours(1)));
            clipboardMonitoringMenuItem.Items.Add(_pauseMenuItem);

            contextMenu.Items.Add(clipboardMonitoringMenuItem);
            contextMenu.Items.Add(new Separator());

            // Settings
            var settingsItem = new MenuItem { Header = "Settings..." };
            settingsItem.Click += (s, e) => SettingsPageRequested?.Invoke(this, EventArgs.Empty);
            contextMenu.Items.Add(settingsItem);

            contextMenu.Items.Add(new Separator());

            // Quit
            var quitItem = new MenuItem { Header = "Quit" };
            quitItem.Click += (s, e) => ExitRequested?.Invoke(this, EventArgs.Empty);
            contextMenu.Items.Add(quitItem);

            return contextMenu;
        }

        private MenuItem CreatePauseItem(string text, TimeSpan duration)
        {
            var item = new MenuItem { Header = text };
            item.Click += (s, e) => PauseFor(duration);
            return item;
        }

        private void StatusMenuItem_Click(object sender, RoutedEventArgs e)
        {
            var settings = SettingsManager.LoadSettings();

            if (settings.ClipboardMonitoring.IsPaused)
            {
                Resume();
            }
            else
            {
                settings.ClipboardMonitoring.IsEnabled = !settings.ClipboardMonitoring.IsEnabled;
                SettingsManager.SaveSettings(settings);

                if (settings.ClipboardMonitoring.IsEnabled)
                {
                    ClipboardMonitorService.Instance.Start();
                }
                else
                {
                    ClipboardMonitorService.Instance.Stop();
                }

                UpdateState();
            }
        }

        private void StartPauseTimer(TimeSpan duration)
        {
            StopPauseTimer();

            _pauseTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(30)
            };
            _pauseTimer.Tick += (s, e) =>
            {
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                if (!settings.IsPaused)
                {
                    StopPauseTimer();
                    Resume();
                }
                else
                {
                    UpdateState();
                }
            };
            _pauseTimer.Start();
        }

        private void StopPauseTimer()
        {
            if (_pauseTimer != null)
            {
                _pauseTimer.Stop();
                _pauseTimer = null;
            }
        }

        private string FormatRemainingTime(TimeSpan? remaining)
        {
            if (!remaining.HasValue) return "";

            if (remaining.Value.TotalMinutes < 1)
                return $"{(int)remaining.Value.TotalSeconds}s";
            // Round minutes up so a fresh "5 minute" pause reads "5m", not "4m".
            int totalMin = (int)Math.Ceiling(remaining.Value.TotalMinutes);
            if (totalMin < 60)
                return $"{totalMin}m";
            return $"{totalMin / 60}h {totalMin % 60}m";
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            if (_disposed) return;

            StopPauseTimer();

            if (_taskbarIcon != null)
            {
                _taskbarIcon.Visibility = Visibility.Collapsed;
                _taskbarIcon.Dispose();
                _taskbarIcon = null;
            }

            _disposed = true;
        }

        #endregion
    }
}
