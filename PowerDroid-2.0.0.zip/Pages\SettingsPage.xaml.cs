using System;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid.Pages
{
    public partial class SettingsPage : UserControl
    {

        public SettingsPage()
        {
            InitializeComponent();
            Loaded += SettingsPage_Loaded;
            Unloaded += SettingsPage_Unloaded;
        }

        private void SettingsPage_Loaded(object sender, RoutedEventArgs e)
        {
            ThemeManager.ThemeChanged += OnThemeChanged;
            TrayIconService.Instance.StateChanged += TrayIconService_StateChanged;
            Services.UpdateCheckService.Instance.UpdateAvailable += OnUpdateAvailable;
            LoadData();
            RefreshUpdateStatus();
        }

        private void SettingsPage_Unloaded(object sender, RoutedEventArgs e)
        {
            ThemeManager.ThemeChanged -= OnThemeChanged;
            TrayIconService.Instance.StateChanged -= TrayIconService_StateChanged;
            Services.UpdateCheckService.Instance.UpdateAvailable -= OnUpdateAvailable;
        }

        private void OnUpdateAvailable(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(RefreshUpdateStatus);
        }

        private void OnThemeChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                UpdatePauseResumeState(settings);
            });
        }

        private void TrayIconService_StateChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;

                ClipboardMonitoringToggle.Checked -= ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.Unchecked -= ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.IsChecked = settings.IsEnabled;
                ClipboardMonitoringToggle.Checked += ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.Unchecked += ClipboardMonitoringToggle_Changed;

                UpdatePauseResumeState(settings);
            });
        }

        public void LoadData()
        {
            InitializeThemeCombo();
            InitializeHotkeyBoxes();

            InitializeClipboardSettings();

            if (!BrandConfig.PowerClipEnabled)
            {
                ClipHotkeyCard.Visibility = Visibility.Collapsed;
            }
        }

        private void InitializeThemeCombo()
        {
            try
            {
                var settings = SettingsManager.LoadSettings();
                ThemeComboBox.SelectionChanged -= ThemeComboBox_SelectionChanged;
                for (int i = 0; i < ThemeComboBox.Items.Count; i++)
                {
                    if (ThemeComboBox.Items[i] is ComboBoxItem item &&
                        item.Tag is string tag &&
                        tag.Equals(settings.Theme, StringComparison.OrdinalIgnoreCase))
                    {
                        ThemeComboBox.SelectedIndex = i;
                        break;
                    }
                }
                ThemeComboBox.SelectionChanged += ThemeComboBox_SelectionChanged;
            }
            catch (Exception ex)
            {
                Logger.Log($"InitializeThemeCombo ERROR: {ex.Message}");
            }
        }

        private void ThemeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (ThemeComboBox.SelectedItem is ComboBoxItem item && item.Tag is string theme)
                {
                    var settings = SettingsManager.LoadSettings();
                    settings.Theme = theme;
                    SettingsManager.SaveSettings(settings);
                    ThemeManager.ApplyTheme(Enum.Parse<AppTheme>(theme));
                    Logger.Log($"Theme changed to: {theme}");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"ThemeComboBox_SelectionChanged ERROR: {ex.Message}");
            }
        }

        #region Keyboard Shortcuts

        // Guards the trigger-combo handlers while we set their selection programmatically.
        private bool _initializingHotkeys;

        // Built-in default shortcuts for Rules and Launcher (mirror SettingsManager.HotkeySettings
        // defaults). The Default-vs-Custom mode is derived by comparing the stored combo to these.
        private const uint RulesDefaultModifiers = HotkeyService.MOD_ALT;
        private const uint RulesDefaultKey = 0x52;      // R
        private const uint LauncherDefaultModifiers = HotkeyService.MOD_ALT;
        private const uint LauncherDefaultKey = 0x42;   // B

        private void InitializeHotkeyBoxes()
        {
            var hk = SettingsManager.LoadSettings().Hotkeys;

            _initializingHotkeys = true;

            // Rules / Launcher: Default vs Custom is derived by comparing the stored combo to the
            // built-in default, so pre-existing custom hotkeys correctly show as Custom (no new
            // settings field, fully back-compatible). The capture box shows only in Custom mode.
            bool rulesCustom = hk.RulesModifiers != RulesDefaultModifiers || hk.RulesKey != RulesDefaultKey;
            SelectTriggerItem(RulesTriggerCombo, rulesCustom ? "Custom" : "Default");
            RulesHotkeyBox.Text = HotkeyService.FormatHotkey(hk.RulesModifiers, hk.RulesKey);
            RulesHotkeyBox.Visibility = rulesCustom ? Visibility.Visible : Visibility.Collapsed;

            bool launcherCustom = hk.LauncherModifiers != LauncherDefaultModifiers || hk.LauncherKey != LauncherDefaultKey;
            SelectTriggerItem(LauncherTriggerCombo, launcherCustom ? "Custom" : "Default");
            LauncherHotkeyBox.Text = HotkeyService.FormatHotkey(hk.LauncherModifiers, hk.LauncherKey);
            LauncherHotkeyBox.Visibility = launcherCustom ? Visibility.Visible : Visibility.Collapsed;

            // Power Clip trigger: select the matching combo item and show the custom capture box
            // + Alt warning only in Custom mode.
            foreach (ComboBoxItem item in ClipTriggerCombo.Items)
            {
                if ((item.Tag?.ToString() ?? "") == hk.ClipTrigger)
                {
                    ClipTriggerCombo.SelectedItem = item;
                    break;
                }
            }
            if (ClipTriggerCombo.SelectedItem == null)
                ClipTriggerCombo.SelectedIndex = 0; // default to Shift + Shift

            // Reflect the live OS state (Windows persists it), not a saved flag — the toggle is on
            // when the Shift-x5 shortcut is currently disabled.
            StickyKeysToggle.IsChecked = !StickyKeysService.IsShortcutEnabled();

            _initializingHotkeys = false;

            ApplyClipTriggerUi(hk);
        }

        // Disable/restore the Windows "press Shift 5 times" Sticky Keys shortcut per-user. Windows
        // persists the state, so no app-side enforcement is needed.
        private void StickyKeysToggle_Changed(object sender, RoutedEventArgs e)
        {
            if (_initializingHotkeys) return;
            bool disable = StickyKeysToggle.IsChecked == true;
            StickyKeysService.SetShortcutEnabled(!disable);
            Logger.Log($"Sticky Keys shortcut {(disable ? "disabled" : "restored")} by user toggle");
        }

        // Selects the combo item whose Tag matches, or the first item as a fallback.
        private static void SelectTriggerItem(ComboBox combo, string tag)
        {
            foreach (ComboBoxItem item in combo.Items)
            {
                if ((item.Tag?.ToString() ?? "") == tag)
                {
                    combo.SelectedItem = item;
                    return;
                }
            }
            combo.SelectedIndex = 0;
        }

        // Default → reset the combo to its built-in shortcut and hide the capture box.
        // Custom → reveal the capture box and focus it so the user can record immediately.
        private void RulesTriggerCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_initializingHotkeys) return;
            if (RulesTriggerCombo.SelectedItem is not ComboBoxItem item) return;
            bool custom = (item.Tag?.ToString() ?? "") == "Custom";

            var settings = SettingsManager.LoadSettings();
            if (!custom)
            {
                settings.Hotkeys.RulesModifiers = RulesDefaultModifiers;
                settings.Hotkeys.RulesKey = RulesDefaultKey;
                SettingsManager.SaveSettings(settings);
                HotkeyService.Instance.Reload();
            }
            RulesHotkeyBox.Text = HotkeyService.FormatHotkey(settings.Hotkeys.RulesModifiers, settings.Hotkeys.RulesKey);
            RulesHotkeyBox.Visibility = custom ? Visibility.Visible : Visibility.Collapsed;
            if (custom) RulesHotkeyBox.Focus();
            Logger.Log($"Rules shortcut mode changed to {(custom ? "Custom" : "Default")}");
        }

        private void LauncherTriggerCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_initializingHotkeys) return;
            if (LauncherTriggerCombo.SelectedItem is not ComboBoxItem item) return;
            bool custom = (item.Tag?.ToString() ?? "") == "Custom";

            var settings = SettingsManager.LoadSettings();
            if (!custom)
            {
                settings.Hotkeys.LauncherModifiers = LauncherDefaultModifiers;
                settings.Hotkeys.LauncherKey = LauncherDefaultKey;
                SettingsManager.SaveSettings(settings);
                HotkeyService.Instance.Reload();
            }
            LauncherHotkeyBox.Text = HotkeyService.FormatHotkey(settings.Hotkeys.LauncherModifiers, settings.Hotkeys.LauncherKey);
            LauncherHotkeyBox.Visibility = custom ? Visibility.Visible : Visibility.Collapsed;
            if (custom) LauncherHotkeyBox.Focus();
            Logger.Log($"Launcher shortcut mode changed to {(custom ? "Custom" : "Default")}");
        }

        // Shows/hides the custom capture box and the recommendation note to match the selected mode.
        // The note appears whenever Custom is selected — it recommends the conflict-free Shift+Shift.
        private void ApplyClipTriggerUi(HotkeySettings hk)
        {
            bool custom = hk.ClipTrigger == HotkeyService.TRIGGER_CUSTOM;
            ClipHotkeyBox.Visibility = custom ? Visibility.Visible : Visibility.Collapsed;
            ClipHotkeyBox.Text = HotkeyService.FormatHotkey(hk.ClipModifiers, hk.ClipKey);
            ClipAltWarning.Visibility = custom ? Visibility.Visible : Visibility.Collapsed;
        }

        private void ClipTriggerCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_initializingHotkeys) return;
            if (ClipTriggerCombo.SelectedItem is not ComboBoxItem item) return;

            var settings = SettingsManager.LoadSettings();
            settings.Hotkeys.ClipTrigger = item.Tag?.ToString() ?? HotkeyService.TRIGGER_DOUBLE_SHIFT;
            SettingsManager.SaveSettings(settings);

            ApplyClipTriggerUi(settings.Hotkeys);
            HotkeyService.Instance.Reload();
            Logger.Log($"Power Clip trigger changed to {settings.Hotkeys.ClipTrigger}");
        }

        private void HotkeyBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox box)
                box.Text = "Press a shortcut...";
            // Recording started: suspend global hotkeys so the combo being pressed doesn't fire its
            // real action (open the rules page, launcher, or clipboard popup).
            HotkeyService.Instance.Suspend();
        }

        private void HotkeyBox_LostFocus(object sender, RoutedEventArgs e)
        {
            // Restore the current value if the user clicks away without pressing a key. Only the
            // box text is restored (not the combo mode) so a freshly selected "Custom" stays Custom.
            if (sender is TextBox box && box.Text == "Press a shortcut...")
            {
                var hk = SettingsManager.LoadSettings().Hotkeys;
                box.Text = (box.Tag?.ToString()) switch
                {
                    "Rules" => HotkeyService.FormatHotkey(hk.RulesModifiers, hk.RulesKey),
                    "Launcher" => HotkeyService.FormatHotkey(hk.LauncherModifiers, hk.LauncherKey),
                    "Clip" => HotkeyService.FormatHotkey(hk.ClipModifiers, hk.ClipKey),
                    _ => box.Text
                };
            }
            // Recording ended: re-enable global hotkeys.
            HotkeyService.Instance.Resume();
        }

        private void HotkeyBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;

            var key = e.Key == Key.System ? e.SystemKey : e.Key;

            // Ignore lone modifier keys
            if (key == Key.LeftCtrl || key == Key.RightCtrl ||
                key == Key.LeftShift || key == Key.RightShift ||
                key == Key.LeftAlt || key == Key.RightAlt ||
                key == Key.LWin || key == Key.RWin)
                return;

            // Build modifiers
            uint modifiers = 0;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) modifiers |= HotkeyService.MOD_CTRL;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Alt)) modifiers |= HotkeyService.MOD_ALT;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) modifiers |= HotkeyService.MOD_SHIFT;

            // Require at least one modifier
            if (modifiers == 0) return;

            // Convert WPF Key to Win32 VK
            uint vk = (uint)KeyInterop.VirtualKeyFromKey(key);
            if (vk == 0) return;

            var box = sender as TextBox;
            var tag = box?.Tag?.ToString();

            var settings = SettingsManager.LoadSettings();
            var combo = HotkeyService.FormatHotkey(modifiers, vk);

            // Restores the capture box to the shortcut currently saved for this action.
            void RevertBox()
            {
                if (box != null)
                    box.Text = tag switch
                    {
                        "Rules" => HotkeyService.FormatHotkey(settings.Hotkeys.RulesModifiers, settings.Hotkeys.RulesKey),
                        "Launcher" => HotkeyService.FormatHotkey(settings.Hotkeys.LauncherModifiers, settings.Hotkeys.LauncherKey),
                        "Clip" => HotkeyService.FormatHotkey(settings.Hotkeys.ClipModifiers, settings.Hotkeys.ClipKey),
                        _ => box.Text
                    };
                Keyboard.ClearFocus();
            }

            // 1) Reserved Windows/editing shortcut (Ctrl+C, Ctrl+V, …). These register successfully
            //    via RegisterHotKey — they're app accelerators, not global hotkeys — but binding one
            //    globally would hijack normal editing everywhere, so block it explicitly.
            string? reserved = HotkeyService.GetReservedShortcutName(modifiers, vk);
            if (reserved != null)
            {
                ToastService.Show(Window.GetWindow(this),
                    $"{combo} is reserved for {reserved} and can't be used as a shortcut.");
                RevertBox();
                Logger.Log($"Hotkey rejected: {tag} → {combo} is reserved ({reserved})");
                return;
            }

            // 2) Already bound to another of the app's own shortcuts.
            string? conflict = FindHotkeyConflict(settings.Hotkeys, tag, modifiers, vk);
            if (conflict != null)
            {
                ToastService.Show(Window.GetWindow(this), $"{combo} is already used by {conflict}.");
                RevertBox();
                Logger.Log($"Hotkey rejected: {tag} → {combo} conflicts with {conflict}");
                return;
            }

            // 3) External conflict: the combo may already be claimed by Windows or another running
            //    app. Global hotkeys are suspended while recording, so a failed test-registration
            //    means the conflict is external. Keep the previous shortcut rather than silently
            //    saving one that would never fire.
            if (!HotkeyService.Instance.CanRegister(modifiers, vk))
            {
                ToastService.Show(Window.GetWindow(this),
                    $"{combo} is already in use by another application.");
                RevertBox();
                Logger.Log($"Hotkey rejected: {tag} → {combo} already in use by another application");
                return;
            }

            // Save to settings
            if (tag == "Rules")
            {
                settings.Hotkeys.RulesModifiers = modifiers;
                settings.Hotkeys.RulesKey = vk;
            }
            else if (tag == "Clip")
            {
                settings.Hotkeys.ClipModifiers = modifiers;
                settings.Hotkeys.ClipKey = vk;
            }
            else if (tag == "Launcher")
            {
                settings.Hotkeys.LauncherModifiers = modifiers;
                settings.Hotkeys.LauncherKey = vk;
            }

            SettingsManager.SaveSettings(settings);

            // Update display
            if (box != null)
                box.Text = combo;

            // Re-register hotkeys
            HotkeyService.Instance.Reload();

            // Move focus away
            Keyboard.ClearFocus();

            Logger.Log($"Hotkey changed: {tag} → {combo}");
        }

        // Returns the friendly name of the action already bound to (mod, vk), or null if it's free.
        // Skips the shortcut being edited (tag). Power Clip counts only when it uses a custom combo.
        private static string? FindHotkeyConflict(HotkeySettings hk, string? tag, uint mod, uint vk)
        {
            if (tag != "Rules" && hk.RulesModifiers == mod && hk.RulesKey == vk)
                return "Manage Rules";
            if (tag != "Launcher" && hk.LauncherModifiers == mod && hk.LauncherKey == vk)
                return "Browser Launcher";
            if (tag != "Clip" && hk.ClipTrigger == HotkeyService.TRIGGER_CUSTOM
                && hk.ClipModifiers == mod && hk.ClipKey == vk)
                return "Power Clip";
            return null;
        }

        #endregion

        #region Clipboard Monitoring

        private void InitializeClipboardSettings()
        {
            try
            {
                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                var serviceRunning = ClipboardMonitorService.Instance.IsRunning;

                bool shouldBeEnabled = settings.IsEnabled;

                ClipboardMonitoringToggle.Checked -= ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.Unchecked -= ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.IsChecked = shouldBeEnabled;
                ClipboardMonitoringToggle.Checked += ClipboardMonitoringToggle_Changed;
                ClipboardMonitoringToggle.Unchecked += ClipboardMonitoringToggle_Changed;

                if (shouldBeEnabled && !serviceRunning)
                {
                    Logger.Log("SettingsPage: Service not running but should be - starting now");
                    ClipboardMonitorService.Instance.Start();
                    TrayIconService.Instance.Show();
                    TrayIconService.Instance.UpdateState();
                }

                UpdatePauseResumeState(settings);

                Logger.Log($"SettingsPage.InitializeClipboardSettings: Toggle={shouldBeEnabled}, ServiceRunning={serviceRunning}");
            }
            catch (Exception ex)
            {
                Logger.Log($"SettingsPage.InitializeClipboardSettings ERROR: {ex.Message}");
            }
        }

        private void ClipboardMonitoringToggle_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                var isEnabled = ClipboardMonitoringToggle.IsChecked == true;

                var settings = SettingsManager.LoadSettings();
                settings.ClipboardMonitoring.IsEnabled = isEnabled;
                SettingsManager.SaveSettings(settings);

                if (isEnabled)
                {
                    ClipboardMonitorService.Instance.Start();
                    TrayIconService.Instance.Show();
                    TrayIconService.Instance.UpdateState();

                    RegistryHelper.AddToStartup();
                }
                else
                {
                    ClipboardMonitorService.Instance.Stop();
                    TrayIconService.Instance.Show();
                    TrayIconService.Instance.UpdateState();
                }

                UpdatePauseResumeState(settings.ClipboardMonitoring);

                Logger.Log($"Clipboard monitoring {(isEnabled ? "enabled" : "disabled")}");
            }
            catch (Exception ex)
            {
                Logger.Log($"SettingsPage.ClipboardMonitoringToggle_Changed ERROR: {ex.Message}");
            }
        }

        private void UpdatePauseResumeState(ClipboardSettings monitorSettings)
        {
            if (!monitorSettings.IsEnabled)
            {
                PauseMonitoringCard.IsEnabled = false;
                PauseStatusText.Text = "Disabled";
                ResumeButton.Visibility = Visibility.Collapsed;
                PauseDropdown.Tag = "Pause for...";
                StatusIndicatorDot.Fill = (System.Windows.Media.Brush)FindResource("StatusDisabledFgBrush");
            }
            else if (monitorSettings.IsPaused)
            {
                PauseMonitoringCard.IsEnabled = true;
                var remaining = monitorSettings.RemainingPauseTime;
                PauseStatusText.Text = remaining.HasValue
                    ? $"Resumes in {FormatRemainingTime(remaining.Value)}"
                    : "Paused";
                ResumeButton.Visibility = Visibility.Visible;
                PauseDropdown.Tag = "Extend Time";
                StatusIndicatorDot.Fill = (System.Windows.Media.Brush)FindResource("StatusPausedFgBrush");
            }
            else
            {
                PauseMonitoringCard.IsEnabled = true;
                PauseStatusText.Text = "Active";
                ResumeButton.Visibility = Visibility.Collapsed;
                PauseDropdown.Tag = "Pause for...";
                StatusIndicatorDot.Fill = (System.Windows.Media.Brush)FindResource("StatusActiveFgBrush");
            }
        }

        private void ResumeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TrayIconService.Instance.Resume();

                var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                UpdatePauseResumeState(settings);

                Logger.Log("SettingsPage: Monitoring resumed");
            }
            catch (Exception ex)
            {
                Logger.Log($"SettingsPage.ResumeButton_Click ERROR: {ex.Message}");
            }
        }

        private void PauseDropdown_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (sender is ComboBox comboBox && comboBox.SelectedItem is ComboBoxItem item
                    && item.Tag is string minutesStr && int.TryParse(minutesStr, out int minutes))
                {
                    TrayIconService.Instance.PauseFor(TimeSpan.FromMinutes(minutes));

                    var settings = SettingsManager.LoadSettings().ClipboardMonitoring;
                    UpdatePauseResumeState(settings);

                    Logger.Log($"SettingsPage: Monitoring paused for {minutes} minutes");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"SettingsPage.PauseDropdown_SelectionChanged ERROR: {ex.Message}");
            }
            finally
            {
                if (sender is ComboBox cb) cb.SelectedIndex = -1;
            }
        }

        /// <summary>
        /// Formats remaining pause time. Minutes are rounded up so a fresh "5 minute"
        /// pause reads "5m", not "4m" (the countdown ticks 5m → 4m → ... → under a minute).
        /// </summary>
        private static string FormatRemainingTime(TimeSpan remaining)
        {
            if (remaining.TotalMinutes < 1)
                return $"{(int)remaining.TotalSeconds}s";
            int totalMin = (int)Math.Ceiling(remaining.TotalMinutes);
            if (totalMin < 60)
                return $"{totalMin}m";
            return $"{totalMin / 60}h {totalMin % 60}m";
        }

        #endregion

        private void AppVersionText_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is TextBlock textBlock)
            {
                var version = Assembly.GetExecutingAssembly().GetName().Version;
                textBlock.Text = version != null ? $"v{version.Major}.{version.Minor}.{version.Build}" : "v1.0.0";
            }
        }

        private void Hyperlink_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true });
            }
            catch (Exception ex) { Logger.Log($"Hyperlink navigation failed: {ex.Message}"); }
            e.Handled = true;
        }

        #region Update Check

        /// <summary>
        /// Refreshes the update available card based on the current state.
        /// </summary>
        public void RefreshUpdateStatus()
        {
            var service = Services.UpdateCheckService.Instance;
            if (service.IsUpdateAvailable)
            {
                // Update available — show info directly, hide check button
                UpdateStatusText.Text = $"Update available \u2014 v{service.LatestVersion}";
                UpdateIcon.Text = "\uE896";
                UpdateIcon.SetResourceReference(TextBlock.ForegroundProperty, "StatusSuccessFgBrush");

                UpdateVersionText.Text = !string.IsNullOrWhiteSpace(service.ReleaseTitle)
                    ? $"{service.ReleaseTitle} (v{service.LatestVersion})"
                    : $"PowerDroid v{service.LatestVersion}";
                UpdateCurrentVersionText.Text = $"Currently installed: v{BrandConfig.Version}";
                UpdateSizeText.Text = service.InstallerSizeBytes > 0
                    ? $"\u00B7 {Services.UpdateCheckService.FormatSize(service.InstallerSizeBytes)}"
                    : "";
                UpdateVersionBadge.Text = $"v{service.LatestVersion}";
                UpdateVersionBadge.Visibility = Visibility.Visible;
                UpdateCheckRow.Visibility = Visibility.Collapsed;
                UpdateNotesText.Text = !string.IsNullOrWhiteSpace(service.ReleaseNotes)
                    ? service.ReleaseNotes
                    : "Visit the releases page for details.";
                // Set view release link
                if (!string.IsNullOrEmpty(service.ReleaseUrl))
                    ViewReleaseHyperlink.NavigateUri = new Uri(service.ReleaseUrl);
                UpdateAvailableCard.Visibility = Visibility.Visible;
            }
            else
            {
                // Up to date — show check button
                UpdateIcon.Text = "\uE895";
                UpdateIcon.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
                UpdateVersionBadge.Visibility = Visibility.Collapsed;
                UpdateCheckRow.Visibility = Visibility.Visible;
                UpdateAvailableCard.Visibility = Visibility.Collapsed;

                var settings = SettingsManager.LoadSettings();
                UpdateStatusText.Text = settings.LastUpdateCheckTime > DateTime.MinValue
                    ? "You're up to date"
                    : "Check for new versions";
            }
        }

        private async void CheckForUpdates_Click(object sender, RoutedEventArgs e)
        {
            CheckForUpdatesButton.IsEnabled = false;
            CheckForUpdatesButton.Content = "Checking...";
            UpdateStatusText.Text = "Checking for updates...";

            try
            {
                // Force a fresh check by resetting the cache time
                var settings = SettingsManager.LoadSettings();
                settings.LastUpdateCheckTime = DateTime.MinValue;
                SettingsManager.SaveSettings(settings);

                await Services.UpdateCheckService.Instance.CheckForUpdatesAsync();
                RefreshUpdateStatus();

                // Update the dot in the parent window
                var settingsWindow = Window.GetWindow(this) as SettingsWindow;
                if (Services.UpdateCheckService.Instance.IsUpdateAvailable)
                    settingsWindow?.ShowUpdateNotification();
                else
                    settingsWindow?.HideUpdateDot();
            }
            catch (Exception ex)
            {
                UpdateStatusText.Text = "Could not check for updates";
                Logger.Log($"CheckForUpdates_Click: {ex.Message}");
            }
            finally
            {
                CheckForUpdatesButton.IsEnabled = true;
                CheckForUpdatesButton.Content = "Check Now";
            }
        }

        /// <summary>
        /// Public entry point to start the download & install flow (called from overlay).
        /// </summary>
        public void StartDownloadAndInstall()
        {
            DownloadUpdate_Click(DownloadInstallButton, new RoutedEventArgs());
        }

        private async void DownloadUpdate_Click(object sender, RoutedEventArgs e)
        {
            // Confirmation
            var service = Services.UpdateCheckService.Instance;
            var size = service.InstallerSizeBytes;
            var sizeText = size > 0 ? $" ({Services.UpdateCheckService.FormatSize(size)})" : "";
            var confirmed = ConfirmationDialog.Show(
                Window.GetWindow(this),
                "Download & Install Update",
                $"This will download PowerDroid v{service.LatestVersion}{sizeText} and restart the application to install the update.\n\nContinue?",
                "Download & Install",
                "Cancel");

            if (!confirmed) return;

            DownloadInstallButton.IsEnabled = false;
            DownloadInstallButton.Content = "Downloading...";
            DownloadProgressPanel.Visibility = Visibility.Visible;
            DownloadProgressBar.Value = 0;
            DownloadProgressText.Text = "0%";

            try
            {
                var progress = new Progress<int>(percent =>
                {
                    DownloadProgressBar.Value = percent;
                    DownloadProgressText.Text = $"{percent}%";
                    DownloadInstallButton.Content = $"Downloading... {percent}%";
                });

                await Services.UpdateCheckService.Instance.DownloadAndInstallAsync(progress);

                // Show installing state briefly before shutdown
                DownloadInstallButton.Content = "Installing...";
                DownloadProgressText.Text = "Restarting...";
            }
            catch (Exception ex)
            {
                Logger.Log($"DownloadUpdate_Click: {ex.Message}");
                DownloadInstallButton.Content = "Download & Install";
                DownloadInstallButton.IsEnabled = true;
                DownloadProgressPanel.Visibility = Visibility.Collapsed;
                UpdateStatusText.Text = "Download failed — try again";
            }
        }

        private void SkipUpdate_Click(object sender, RoutedEventArgs e)
        {
            Services.UpdateCheckService.Instance.SkipCurrentVersion();
            UpdateAvailableCard.Visibility = Visibility.Collapsed;
            UpdateStatusText.Text = "Update skipped";
            var settingsWindow = Window.GetWindow(this) as SettingsWindow;
            settingsWindow?.HideUpdateDot();
        }

        #endregion

    }
}
