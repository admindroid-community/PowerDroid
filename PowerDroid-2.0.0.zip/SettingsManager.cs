﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.Json;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid
{
    public class AppSettings
    {
        /// <summary>
        /// Schema version for data migration. Increment when making breaking changes.
        /// Version history:
        /// - 1: Initial version (implicit, pre-versioning)
        /// - 2: Added schema versioning, multi-profile rules
        /// </summary>
        public int SchemaVersion { get; set; } = 2;

        /// <summary>
        /// Application version that last saved these settings.
        /// </summary>
        public string AppVersion { get; set; } = Assembly.GetExecutingAssembly().GetName().Version?.ToString() ?? "1.0.0";

        /// <summary>
        /// Timestamp when settings were last saved.
        /// </summary>
        public DateTime LastSaved { get; set; } = DateTime.UtcNow;

        public bool IsEnabled { get; set; } = true;
        public string DefaultBrowserName { get; set; } = string.Empty;
        public string DefaultBrowserPath { get; set; } = string.Empty;
        public string DefaultBrowserType { get; set; } = string.Empty;

        /// <summary>
        /// Pinned profile name for the fallback browser. Empty = "Last Active"
        /// (launch with no profile argument, the historical behavior).
        /// </summary>
        public string DefaultBrowserProfileName { get; set; } = string.Empty;

        /// <summary>
        /// Stable profile path of the pinned fallback profile. Preferred over the
        /// display name for matching, since browsers append suffixes like "(Profile 3)"
        /// to names. Empty = "Last Active".
        /// </summary>
        public string DefaultBrowserProfilePath { get; set; } = string.Empty;

        /// <summary>
        /// Launch arguments for the pinned fallback profile. Empty = "Last Active".
        /// </summary>
        public string DefaultBrowserProfileArguments { get; set; } = string.Empty;
        public bool ShowNotifications { get; set; } = true;
        public bool UseLastActiveBrowser { get; set; } = true;
        public string LastActiveBrowserName { get; set; } = string.Empty;
        public string LastActiveBrowserPath { get; set; } = string.Empty;
        public string LastActiveBrowserType { get; set; } = string.Empty;
        public string LastActiveProfileName { get; set; } = string.Empty;
        public string LastActiveProfilePath { get; set; } = string.Empty;
        public string LastActiveProfileArguments { get; set; } = string.Empty;
        public DateTime LastActiveTime { get; set; } = DateTime.MinValue;

        /// <summary>
        /// Last selected navigation page (Home, Rules, Settings, Docs)
        /// </summary>
        public string LastSelectedPage { get; set; } = "Home";

        /// <summary>
        /// When enabled, automatically detect Windows account and apply
        /// matching browser profiles to the M365 URL group.
        /// </summary>
        public bool AutoDetectM365Profile { get; set; } = false;

        /// <summary>
        /// When true, overwrite existing M365 group configuration.
        /// When false (default), only apply if the group has no profiles configured.
        /// </summary>
        public bool AutoDetectOverwriteExisting { get; set; } = false;

        /// <summary>
        /// Cached detected Windows account email (for display).
        /// </summary>
        public string DetectedAccountEmail { get; set; } = string.Empty;

        /// <summary>
        /// Cached count of matched profiles.
        /// </summary>
        public int DetectedProfileCount { get; set; } = 0;

        /// <summary>
        /// Version of the built-in templates that have been applied.
        /// Used to determine if template updates need to be applied on app startup.
        /// </summary>
        public string InstalledTemplateVersion { get; set; } = string.Empty;

        /// <summary>
        /// Settings for clipboard URL monitoring feature.
        /// </summary>
        public ClipboardSettings ClipboardMonitoring { get; set; } = new();

        /// <summary>
        /// Application theme: "System", "Light", or "Dark". Default is System.
        /// </summary>
        public string Theme { get; set; } = "System";

        /// <summary>
        /// Whether the user has seen the first-run welcome window.
        /// </summary>
        public bool HasSeenWelcome { get; set; } = false;

        /// <summary>
        /// Persisted sort state for the Individual Rules DataGrid.
        /// Supports multi-column sorting (Shift+Click).
        /// </summary>
        public List<SortColumnState> RulesSortColumns { get; set; } = new();

        /// <summary>
        /// Keyboard shortcut configuration.
        /// </summary>
        public HotkeySettings Hotkeys { get; set; } = new();

        /// <summary>
        /// Profiles the user pinned in the browser launcher. Each entry is a stable composite
        /// key "browserPath|profilePath" so the same profile name across browsers never collides.
        /// </summary>
        public List<string> PinnedBrowserProfiles { get; set; } = new();

        // === UPDATE CHECK ===

        /// <summary>When the last successful update check was performed (UTC).</summary>
        public DateTime LastUpdateCheckTime { get; set; } = DateTime.MinValue;

        /// <summary>Latest version found from the update API.</summary>
        public string LastKnownUpdateVersion { get; set; } = string.Empty;

        /// <summary>Release notes from the latest version.</summary>
        public string LastKnownReleaseNotes { get; set; } = string.Empty;

        /// <summary>Release title from the latest version.</summary>
        public string LastKnownReleaseTitle { get; set; } = string.Empty;

        /// <summary>Direct download URL for the installer asset.</summary>
        public string LastKnownInstallerUrl { get; set; } = string.Empty;

        /// <summary>Version the user chose to skip.</summary>
        public string SkippedUpdateVersion { get; set; } = string.Empty;

        /// <summary>Whether the user has seen the update popup for the current update.</summary>
        public bool HasSeenUpdatePopup { get; set; } = false;

        /// <summary>The app version before the last update. Used to detect fresh upgrades and show "What's New".</summary>
        public string PreviousAppVersion { get; set; } = string.Empty;

        /// <summary>Whether the "What's New" overlay has been shown for the current version.</summary>
        public bool HasSeenWhatsNew { get; set; } = false;
    }

    public class HotkeySettings
    {
        /// <summary>Modifier flags for Rules shortcut (MOD_CTRL=2, MOD_SHIFT=4, MOD_ALT=1).</summary>
        public uint RulesModifiers { get; set; } = 1; // Alt

        /// <summary>Virtual key code for Rules shortcut.</summary>
        public uint RulesKey { get; set; } = 0x52; // R

        /// <summary>
        /// How Power Clip is triggered: "DoubleShift" (default) or "DoubleCtrl" tap gesture, or
        /// "Custom" to use ClipModifiers+ClipKey as a normal RegisterHotKey combo.
        /// </summary>
        public string ClipTrigger { get; set; } = "DoubleShift";

        /// <summary>Modifier flags for the Power Clip shortcut when ClipTrigger is "Custom".</summary>
        public uint ClipModifiers { get; set; } = 2 | 4; // Ctrl+Shift (used only in Custom mode)

        /// <summary>Virtual key code for the Power Clip shortcut when ClipTrigger is "Custom".</summary>
        public uint ClipKey { get; set; } = 0x56; // V

        /// <summary>Modifier flags for the browser/profile launcher shortcut.</summary>
        public uint LauncherModifiers { get; set; } = 1; // Alt

        /// <summary>Virtual key code for the browser/profile launcher shortcut.</summary>
        public uint LauncherKey { get; set; } = 0x42; // B

        /// <summary>
        /// Guards the one-time startup default: on first launch, if the user does not use Sticky
        /// Keys (the feature is off), the Windows "press Shift 5 times" shortcut is disabled for
        /// them automatically (so the Shift-based Power Clip trigger can't trip it). Set once so we
        /// never re-apply and fight a user who later turns Sticky Keys on. After this, the shortcut
        /// state lives in Windows (SPIF_UPDATEINIFILE) and is controlled only by the Settings toggle.
        /// </summary>
        public bool StickyKeysDefaultApplied { get; set; } = false;
    }

    public class SortColumnState
    {
        public string Column { get; set; } = string.Empty;
        public string Direction { get; set; } = "Ascending";
    }

    public static class SettingsManager
    {
        private static readonly string SettingsPath = Path.Combine(
            AppConfig.AppDataFolder,
            "settings.json"
        );

        private static AppSettings? _cachedSettings = null;

        /// <summary>
        /// Current schema version. Increment when making breaking changes to data format.
        /// Version history:
        /// - 1: Initial version (implicit, pre-versioning)
        /// - 2: Added schema versioning, multi-profile rules
        /// - 3: Added UrlPattern objects with metadata, template versioning
        /// </summary>
        public const int CurrentSchemaVersion = 3;

        public static AppSettings LoadSettings()
        {
            if (_cachedSettings != null)
                return _cachedSettings;

            _cachedSettings = JsonStorageService.Load<AppSettings>(SettingsPath);

            // Check for schema version migrations
            if (_cachedSettings.SchemaVersion < CurrentSchemaVersion)
            {
                MigrateSettings(_cachedSettings);
            }

            return _cachedSettings;
        }

        /// <summary>
        /// Performs schema migrations based on version number.
        /// </summary>
        private static void MigrateSettings(AppSettings settings)
        {
            // Create backup before migration
            JsonStorageService.CreatePreMigrationBackup(SettingsPath, $"v{settings.SchemaVersion}-to-v{CurrentSchemaVersion}");

            // Version 0/1 -> 2: Add schema versioning (no data changes needed)
            if (settings.SchemaVersion < 2)
            {
                Logger.Log($"Migrating settings from schema v{settings.SchemaVersion} to v2");
                settings.SchemaVersion = 2;
            }

            // Version 2 -> 3: Added UrlPattern objects with metadata, template versioning
            // Note: URL group pattern migration is handled in UrlGroupManager.LoadGroups()
            if (settings.SchemaVersion < 3)
            {
                Logger.Log($"Migrating settings from schema v{settings.SchemaVersion} to v3");
                settings.SchemaVersion = 3;
                // InstalledTemplateVersion will be set by BuiltInTemplateManager on first run
            }

            // Save after all migrations
            if (settings.SchemaVersion == CurrentSchemaVersion)
            {
                SaveSettings(settings);
            }
        }

        public static void SaveSettings(AppSettings settings)
        {
            // Update metadata before saving
            settings.LastSaved = DateTime.UtcNow;
            settings.AppVersion = Assembly.GetExecutingAssembly().GetName().Version?.ToString() ?? "1.0.0";

            JsonStorageService.Save(SettingsPath, settings);
            _cachedSettings = settings;
        }

        public static void ClearCache()
        {
            _cachedSettings = null;
        }

        public static void UpdateLastActiveBrowser(BrowserInfo browser, ProfileInfo profile)
        {
            var settings = LoadSettings();
            settings.LastActiveBrowserName = browser.Name;
            settings.LastActiveBrowserPath = browser.ExecutablePath;
            settings.LastActiveBrowserType = browser.Type;
            settings.LastActiveProfileName = profile.Name;
            settings.LastActiveProfilePath = profile.Path;
            settings.LastActiveProfileArguments = profile.Arguments;
            settings.LastActiveTime = DateTime.Now;
            SaveSettings(settings);
        }

        /// <summary>
        /// Builds the stable pin key for a browser/profile combination.
        /// </summary>
        public static string MakeProfilePinKey(string browserPath, string profilePath)
            => $"{browserPath}|{profilePath}";

        /// <summary>
        /// Whether the given browser/profile is pinned in the launcher.
        /// </summary>
        public static bool IsProfilePinned(string browserPath, string profilePath)
            => LoadSettings().PinnedBrowserProfiles.Contains(MakeProfilePinKey(browserPath, profilePath));

        /// <summary>
        /// Toggles the pinned state of a browser/profile and persists it. Returns the new state.
        /// </summary>
        public static bool ToggleProfilePin(string browserPath, string profilePath)
        {
            var settings = LoadSettings();
            var key = MakeProfilePinKey(browserPath, profilePath);
            bool nowPinned;
            if (settings.PinnedBrowserProfiles.Contains(key))
            {
                settings.PinnedBrowserProfiles.Remove(key);
                nowPinned = false;
            }
            else
            {
                settings.PinnedBrowserProfiles.Add(key);
                nowPinned = true;
            }
            SaveSettings(settings);
            return nowPinned;
        }

        public static bool HasRecentLastActiveBrowser()
        {
            var settings = LoadSettings();
            if (string.IsNullOrEmpty(settings.LastActiveBrowserPath))
                return false;

            // Consider "recent" if within the last 24 hours
            return DateTime.Now - settings.LastActiveTime < TimeSpan.FromHours(24);
        }
    }
}