using System;
using System.IO;

namespace PowerDroid
{
    /// <summary>
    /// Central branding configuration for the PowerDroid suite.
    /// Change names here and they propagate everywhere.
    /// </summary>
    public static class BrandConfig
    {
        // === SUITE IDENTITY ===
        public const string SuiteName = "PowerDroid";
        public const string SuiteTagline = "Windows Power Utility Suite";
        public const string Publisher = "AdminDroid";
        public const string Version = "2.0.0";

        // === FEATURE NAMES ===
        public const string PowerBrowserName = "Smart Browse";
        public const string PowerBrowserDescription = "Intelligent browser selection and URL routing";
        public const string PowerClipName = "Power Clip";
        public const string PowerClipDescription = "Persist and search everything you copy";

        // === FEATURE FLAGS ===
        /// <summary>Power Clip is deferred to v2.0. Set to true to enable.</summary>
        public const bool PowerClipEnabled = true;
        /// <summary>True if the running exe is Authenticode-signed.</summary>
        public static readonly bool IsCodeSigned = CheckCodeSigned();

        private static bool CheckCodeSigned()
        {
            try
            {
                var cert = System.Security.Cryptography.X509Certificates.X509Certificate2.CreateFromSignedFile(
                    System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? "");
                return cert != null;
            }
            catch { return false; }
        }

        // === UPDATE CHECK ===
        /// <summary>GitHub Releases API endpoint for version checks.</summary>
        public const string ReleasesApiUrl = "https://api.github.com/repos/admindroid-community/PowerDroid/releases/latest";
        /// <summary>URL users are directed to for downloading updates.</summary>
        public const string ReleasesPageUrl = "https://github.com/admindroid-community/PowerDroid/releases";
        /// <summary>Fallback download page if no installer asset found in API response.</summary>
        public const string InstallerDownloadUrl = "https://github.com/admindroid-community/PowerDroid/releases";

        // === DISPLAY (user-facing) ===
        public const string AppDisplayName = SuiteName;
        public const string WindowTitle = SuiteName;

        // === STABLE IDENTIFIERS (NEVER change after release) ===
        /// <summary>Registry browser registration identity. Used in all Windows browser registration keys.</summary>
        public const string RegistryAppId = "PowerDroidSmartBrowse";
        public const string DataFolderName = "PowerDroid";
        public const string LegacyDataFolderName = "LinkRouter";
        public const string ExeName = "PowerDroid";
        public static readonly string MutexId = $"PowerDroid_{Environment.UserName}_SingleInstance_Mutex";
        public static readonly string PipeId = $"PowerDroid_{Environment.UserName}_SingleInstance_Pipe";

        // === DERIVED PATHS ===
        public static readonly string AppDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            DataFolderName);

        public static readonly string LegacyAppDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            LegacyDataFolderName);
    }

    /// <summary>
    /// Features available in the PowerDroid suite.
    /// </summary>
    public enum PowerDroidFeature
    {
        SmartBrowse,        // v1.0
        PowerClip,          // v2.0
        TerminalManager,    // future
        BulkRenamer,        // future
        HostsManager,       // future
        SmartFileMover      // future
    }
}
