using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace PowerDroid
{
    /// <summary>
    /// Positions notification toast windows at the bottom-right of the primary monitor.
    ///
    /// The app is PerMonitorV2 DPI-aware, so a toast created on one monitor and moved to a
    /// differently-scaled monitor gets rescaled by WPF. The robust technique (per Microsoft's
    /// PerMonitorV2 guidance) is to compute the window's size in PHYSICAL pixels for the TARGET
    /// monitor's DPI and set position AND size together — never SWP_NOSIZE, which would keep a
    /// size measured on the wrong monitor and make the toast overflow / split across displays.
    /// </summary>
    internal static class ToastPositioner
    {
        /// <summary>
        /// Places <paramref name="window"/> flush at the primary monitor's bottom-right work area
        /// (taskbar-aware), sized for the primary monitor's DPI. Call from ContentRendered — by then
        /// the HWND exists and SizeToContent has produced the final logical (DIP) size. Returns the
        /// resulting DIP Left (Window.Left after the move).
        /// </summary>
        internal static double PositionBottomRight(Window window, int marginDip = 20)
        {
            try
            {
                var hwnd = new WindowInteropHelper(window).Handle;
                if (hwnd == IntPtr.Zero) return window.Left;

                var wa = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea; // physical px

                // Effective DPI of the primary monitor — NOT the monitor the window may currently
                // sit on. We size the toast for where it will land.
                double scale = 1.0;
                IntPtr hMon = MonitorFromPoint(new POINT { x = 0, y = 0 }, MONITOR_DEFAULTTOPRIMARY);
                if (hMon != IntPtr.Zero && GetDpiForMonitor(hMon, MDT_EFFECTIVE_DPI, out uint dpiX, out _) == 0)
                    scale = dpiX / 96.0;

                // The window's logical (DIP) size is monitor-independent; convert it to the primary's
                // physical pixels. Setting this size explicitly (below) is what stops the toast from
                // keeping a size measured on another-scale monitor and overflowing the edge.
                int physW = (int)Math.Round(window.ActualWidth * scale);
                int physH = (int)Math.Round(window.ActualHeight * scale);
                int margin = (int)Math.Round(marginDip * scale);

                int x = wa.Right - physW - margin;
                int y = wa.Bottom - physH - margin;

                // Position AND size together (no SWP_NOSIZE). WPF then reconciles Left/Top/Width/Height
                // for the primary monitor's DPI, landing the toast wholly on the primary.
                SetWindowPos(hwnd, IntPtr.Zero, x, y, physW, physH, SWP_NOZORDER);

                return window.Left;
            }
            catch
            {
                return window.Left;
            }
        }

        private const uint SWP_NOZORDER = 0x0004;
        private const uint MONITOR_DEFAULTTOPRIMARY = 0x00000001;
        private const int MDT_EFFECTIVE_DPI = 0;

        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromPoint(POINT pt, uint dwFlags);

        [DllImport("shcore.dll")]
        private static extern int GetDpiForMonitor(IntPtr hmonitor, int dpiType, out uint dpiX, out uint dpiY);

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT { public int x, y; }
    }
}
