using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PowerDroid
{
    /// <summary>
    /// Shared vector icons for the clipboard views. Using a Path (rather than a Segoe
    /// Fluent glyph) guarantees a bold, solid, filled pushpin that matches the requested
    /// look regardless of the icon font installed.
    /// </summary>
    internal static class ClipIcons
    {
        // Solid filled pushpin (Material "push_pin"), rendered diagonally so it reads as a
        // classic thumbtack: head at the upper-right, needle to the lower-left.
        private const string PushpinData =
            "M16,12V4H17V2H7V4H8V12L6,14V16H11.2V22H12.8V16H18V14L16,12Z";

        /// <summary>
        /// Creates a filled pushpin Path. When <paramref name="fill"/> is null the fill binds
        /// to the ancestor Button's Foreground (so it follows the button style + hover accent).
        /// </summary>
        public static Path CreatePushpin(double size = 13, Brush? fill = null)
        {
            var path = new Path
            {
                Data = Geometry.Parse(PushpinData),
                Stretch = Stretch.Uniform,
                Width = size,
                Height = size,
                LayoutTransform = new RotateTransform(45),
                SnapsToDevicePixels = true,
            };

            if (fill != null)
            {
                path.Fill = fill;
            }
            else
            {
                var binding = new Binding("Foreground")
                {
                    RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Button), 1)
                };
                path.SetBinding(Shape.FillProperty, binding);
            }

            return path;
        }
    }
}
