using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using PowerDroid.Dialogs;
using PowerDroid.Services;

namespace PowerDroid
{
    /// <summary>
    /// Unified window for adding and editing URL rules.
    /// Supports both single and multi-profile configurations.
    /// </summary>
    public partial class AddRuleWindow : Window
    {
        private UrlRule? _existingRule;
        private bool _isEditMode;
        private string? _sourceGroupId;

        // Full URL toggle fields
        private string? _sourceUrl;
        private string? _domainPattern;
        private bool _showingFullUrl = false;

        // Change detection fields for edit mode
        private string _initialPattern = "";
        private string _initialDescription = "";
        private bool _initialClipboardNotify = true;
        private bool _initialIncognito = false;
        private string? _initialSourceApp;
        private List<RuleProfile> _initialProfiles = new List<RuleProfile>();

        /// <summary>
        /// Constructor for adding a new rule
        /// </summary>
        public AddRuleWindow()
        {
            InitializeComponent();
            SourceInitialized += (s, e) => ThemeManager.ApplyTitleBarTheme(this);
            ContentRendered += (s, e) => PatternTextBox.Focus();
            _isEditMode = false;
            SaveButton.Content = "Add";

            // Detect manually-pasted full URLs so the user can keep the full path
            // (with a "Switch to domain only" toggle) instead of being forced to a domain.
            DataObject.AddPastingHandler(PatternTextBox, OnPatternPaste);

            ProfileSelector.SelectionChanged += (s, e) => UpdateProfileCountBadge();
            ProfileSelector.ModeChanged += (s, e) => UpdateProfileCountBadge();

            // Keep the selector's help text in sync with the incognito toggle (fires on the
            // edit-mode load too, since IncognitoToggle.IsChecked is set after this constructor).
            IncognitoToggle.Checked += (s, e) => ProfileSelector.IsIncognito = true;
            IncognitoToggle.Unchecked += (s, e) => ProfileSelector.IsIncognito = false;

            // Disable clipboard toggle if global clipboard monitoring is off
            var globalSettings = SettingsManager.LoadSettings();
            if (!globalSettings.ClipboardMonitoring.IsEnabled)
            {
                ClipboardNotifyToggle.IsEnabled = false;
                ClipboardNotifyPanel.Opacity = 0.5;
                ClipboardNotifyPanel.ToolTip = "Enable clipboard monitoring in Settings to use this feature";
            }

            // Populate source app dropdown
            PopulateSourceAppComboBox();
        }

        /// <summary>
        /// Constructor for adding a new rule with a suggested pattern and optional full source URL
        /// </summary>
        public AddRuleWindow(string suggestedPattern, string? fullUrl = null) : this()
        {
            PatternTextBox.Text = suggestedPattern;

            if (fullUrl != null)
            {
                _domainPattern = suggestedPattern;
                _sourceUrl = ValidationService.NormalizePattern(fullUrl);
                if (_sourceUrl != _domainPattern)
                    ToggleUrlLink.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// Constructor for moving a pattern from a group to an individual rule
        /// </summary>
        public AddRuleWindow(string suggestedPattern, string sourceGroupId, bool isFromGroup) : this()
        {
            PatternTextBox.Text = suggestedPattern;
            _sourceGroupId = sourceGroupId;
        }

        /// <summary>
        /// Constructor for editing an existing rule
        /// </summary>
        public AddRuleWindow(UrlRule existingRule) : this()
        {
            _existingRule = existingRule;
            _isEditMode = true;

            // Update UI for edit mode
            RuleEditorWindow.Title = "Edit URL Rule";
            SaveButton.Content = "Save";
            SaveButton.Visibility = Visibility.Collapsed; // Hide until changes detected

            // Load existing data
            PatternTextBox.Text = existingRule.Pattern;
            DescriptionTextBox.Text = existingRule.Description;

            // Load profiles into the selector
            if (existingRule.Profiles != null && existingRule.Profiles.Count > 0)
            {
                ProfileSelector.LoadProfiles(existingRule.Profiles);
            }
            else if (!string.IsNullOrEmpty(existingRule.BrowserPath))
            {
                // Legacy single profile - load from legacy fields
                ProfileSelector.LoadSingleProfile(existingRule.BrowserPath, existingRule.ProfilePath);
            }

            // Load clipboard notification setting
            ClipboardNotifyToggle.IsChecked = existingRule.ClipboardNotificationsEnabled;

            // Load incognito setting
            IncognitoToggle.IsChecked = existingRule.Incognito;

            // Load source app filter
            SelectSourceApp(existingRule.SourceAppFilter);

            // Store initial values for change detection
            _initialPattern = existingRule.Pattern ?? "";
            _initialDescription = existingRule.Description ?? "";
            _initialClipboardNotify = existingRule.ClipboardNotificationsEnabled;
            _initialIncognito = existingRule.Incognito;
            _initialSourceApp = existingRule.SourceAppFilter;
            _initialProfiles = existingRule.Profiles?.Select(p => new RuleProfile
            {
                BrowserName = p.BrowserName,
                BrowserPath = p.BrowserPath,
                BrowserType = p.BrowserType,
                ProfileName = p.ProfileName,
                ProfilePath = p.ProfilePath,
                ProfileArguments = p.ProfileArguments
            }).ToList() ?? new List<RuleProfile>();

            // Wire up change detection events
            PatternTextBox.TextChanged += (s, e) => CheckForChanges();
            DescriptionTextBox.TextChanged += (s, e) => CheckForChanges();
            ClipboardNotifyToggle.Checked += (s, e) => CheckForChanges();
            ClipboardNotifyToggle.Unchecked += (s, e) => CheckForChanges();
            IncognitoToggle.Checked += (s, e) => CheckForChanges();
            IncognitoToggle.Unchecked += (s, e) => CheckForChanges();
            SourceAppComboBox.SelectionChanged += (s, e) => CheckForChanges();
            ProfileSelector.SelectionChanged += (s, e) => { CheckForChanges(); UpdateProfileCountBadge(); };
            ProfileSelector.ModeChanged += (s, e) => UpdateProfileCountBadge();

            UpdateProfileCountBadge();
        }

        private void UpdateProfileCountBadge()
        {
            var count = ProfileSelector.ProfileCount;
            if (count > 1)
            {
                ProfileCountBadge.Visibility = Visibility.Visible;
                ProfileCountText.Text = count.ToString();
            }
            else
            {
                ProfileCountBadge.Visibility = Visibility.Collapsed;
            }
        }

        private void CheckForChanges()
        {
            if (!_isEditMode) return;

            var currentProfiles = ProfileSelector.GetAllProfiles();
            bool profilesChanged = !ProfilesAreEqual(_initialProfiles, currentProfiles);

            var currentSourceApp = GetSelectedSourceAppFilter();
            bool hasChanges = PatternTextBox.Text.Trim() != _initialPattern
                || DescriptionTextBox.Text.Trim() != _initialDescription
                || ClipboardNotifyToggle.IsChecked != _initialClipboardNotify
                || IncognitoToggle.IsChecked != _initialIncognito
                || currentSourceApp != _initialSourceApp
                || profilesChanged;

            SaveButton.Visibility = hasChanges ? Visibility.Visible : Visibility.Collapsed;
        }

        private bool ProfilesAreEqual(List<RuleProfile> initial, List<RuleProfile> current)
        {
            if (initial.Count != current.Count) return false;

            for (int i = 0; i < initial.Count; i++)
            {
                if (initial[i].BrowserPath != current[i].BrowserPath ||
                    initial[i].ProfilePath != current[i].ProfilePath)
                    return false;
            }
            return true;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Clear previous validation messages
            ValidationPanel.Clear();

            // Get profiles from the selector
            var profiles = ProfileSelector.GetAllProfiles();

            // Validate using ValidationService
            var result = ValidationService.ValidateIndividualRule(
                PatternTextBox.Text,
                profiles,
                _isEditMode ? _existingRule?.Id : null,
                _sourceGroupId
            );

            // Show only errors in the inline panel (warnings are handled by confirmation dialogs)
            if (result.Errors.Any())
            {
                ValidationPanel.SetValidationResult(result);
            }

            // Block on errors
            if (!result.IsValid)
            {
                return;
            }

            // Track whether we need to remove this pattern from groups after save
            bool shouldRemoveFromGroups = false;

            // Handle warnings
            if (result.HasWarnings)
            {
                var groupConflict = result.Warnings
                    .FirstOrDefault(w => w.Code == ValidationCodes.PATTERN_EXISTS_IN_GROUP);
                var otherWarnings = result.Warnings
                    .Where(w => w.Code != ValidationCodes.PATTERN_EXISTS_IN_GROUP).ToList();

                // If pattern exists in a group, offer to remove it from the group and create the individual rule
                if (groupConflict != null)
                {
                    if (!ConfirmationDialog.Show(this,
                        "Pattern Conflict",
                        $"This pattern exists in grouped rule '{groupConflict.ConflictingEntity}'. Remove it from the group and create the individual rule?",
                        "Remove & Create", "Cancel"))
                    {
                        return;
                    }

                    // Defer group cleanup until after rule save succeeds
                    shouldRemoveFromGroups = true;
                }

                // Confirm any remaining warnings (hierarchy conflicts, etc.)
                if (otherWarnings.Any())
                {
                    if (!ValidationWarningDialog.ShowWarnings(this, otherWarnings))
                    {
                        return;
                    }
                }
            }

            // Use normalized pattern
            var normalizedPattern = result.NormalizedValue ?? PatternTextBox.Text.Trim();

            if (_isEditMode && _existingRule != null)
            {
                // Update existing rule
                _existingRule.Pattern = normalizedPattern;
                _existingRule.Description = DescriptionTextBox.Text.Trim();
                _existingRule.Profiles = profiles;
                _existingRule.ClipboardNotificationsEnabled = ClipboardNotifyToggle.IsChecked == true;
                _existingRule.Incognito = IncognitoToggle.IsChecked == true;
                _existingRule.SourceAppFilter = GetSelectedSourceAppFilter();

                // Update legacy fields from first profile for compatibility
                if (profiles.Count > 0)
                {
                    var first = profiles[0];
                    _existingRule.BrowserName = first.BrowserName;
                    _existingRule.BrowserPath = first.BrowserPath;
                    _existingRule.BrowserType = first.BrowserType;
                    _existingRule.ProfileName = first.ProfileName;
                    _existingRule.ProfilePath = first.ProfilePath;
                    _existingRule.ProfileArguments = first.ProfileArguments;
                }

                try
                {
                    UrlRuleManager.UpdateRule(_existingRule);
                    // Rule saved — now remove pattern from conflicting groups
                    if (shouldRemoveFromGroups)
                    {
                        RemovePatternFromGroups(normalizedPattern);
                    }
                    DialogResult = true;
                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error updating rule: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                // Create new rule
                var rule = new UrlRule
                {
                    Pattern = normalizedPattern,
                    Description = DescriptionTextBox.Text.Trim(),
                    Profiles = profiles,
                    ClipboardNotificationsEnabled = ClipboardNotifyToggle.IsChecked == true,
                    Incognito = IncognitoToggle.IsChecked == true,
                    SourceAppFilter = GetSelectedSourceAppFilter()
                };

                // Set legacy fields from first profile for compatibility
                if (profiles.Count > 0)
                {
                    var first = profiles[0];
                    rule.BrowserName = first.BrowserName;
                    rule.BrowserPath = first.BrowserPath;
                    rule.BrowserType = first.BrowserType;
                    rule.ProfileName = first.ProfileName;
                    rule.ProfilePath = first.ProfilePath;
                    rule.ProfileArguments = first.ProfileArguments;
                }

                try
                {
                    UrlRuleManager.AddRule(rule);
                    // Rule saved — now remove pattern from conflicting groups
                    if (shouldRemoveFromGroups)
                    {
                        RemovePatternFromGroups(normalizedPattern);
                    }
                    DialogResult = true;
                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error saving rule: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void ToggleUrl_Click(object sender, MouseButtonEventArgs e)
        {
            _showingFullUrl = !_showingFullUrl;
            PatternTextBox.Text = _showingFullUrl ? _sourceUrl : _domainPattern;
            ToggleUrlLink.Text = _showingFullUrl ? "Switch to domain only" : "Switch to full URL";
        }

        /// <summary>
        /// When a full URL (with a path) is pasted into the pattern box, keep the full URL
        /// as the pattern and surface the "Switch to domain only" toggle so the user can
        /// reduce it if they want. Domain-only pastes behave as before.
        /// </summary>
        private void OnPatternPaste(object sender, DataObjectPastingEventArgs e)
        {
            if (!e.SourceDataObject.GetDataPresent(DataFormats.UnicodeText, true))
                return;

            var pasted = e.SourceDataObject.GetData(DataFormats.UnicodeText) as string;
            if (string.IsNullOrWhiteSpace(pasted))
                return;

            var full = ValidationService.NormalizePattern(pasted);
            var domain = ValidationService.ExtractDomain(pasted);

            // Only a "full URL" if there's a path/query beyond the bare domain.
            if (string.IsNullOrEmpty(full) || full == domain)
                return;

            _sourceUrl = full;
            _domainPattern = domain;
            _showingFullUrl = true;

            // Take over the paste so the normalized full URL lands in the box (consistent casing).
            PatternTextBox.Text = full;
            PatternTextBox.CaretIndex = full.Length;
            e.CancelCommand();

            ToggleUrlLink.Text = "Switch to domain only";
            ToggleUrlLink.Visibility = Visibility.Visible;
        }

        private void SourceAppComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // Change detection handled by the edit-mode wiring
        }

        private void PopulateSourceAppComboBox()
        {
            SourceAppComboBox.Items.Clear();

            // "Any app" as default
            var anyItem = new System.Windows.Controls.ComboBoxItem { Content = "Any app", Tag = (string?)null };
            SourceAppComboBox.Items.Add(anyItem);

            // Populate from running processes + clipboard history
            var apps = SourceAppDetector.GetAvailableSourceApps();
            foreach (var app in apps)
            {
                var item = new System.Windows.Controls.ComboBoxItem
                {
                    Content = app.DisplayName,
                    Tag = app.ProcessName
                };
                SourceAppComboBox.Items.Add(item);
            }

            SourceAppComboBox.SelectedIndex = 0;
        }

        private void SelectSourceApp(string? processName)
        {
            if (string.IsNullOrEmpty(processName))
            {
                SourceAppComboBox.SelectedIndex = 0;
                return;
            }

            for (int i = 0; i < SourceAppComboBox.Items.Count; i++)
            {
                if (SourceAppComboBox.Items[i] is System.Windows.Controls.ComboBoxItem item &&
                    processName.Equals(item.Tag as string, StringComparison.OrdinalIgnoreCase))
                {
                    SourceAppComboBox.SelectedIndex = i;
                    return;
                }
            }

            // App not in list — add it dynamically
            var friendly = SourceAppDetector.GetFriendlyAppName(processName);
            var newItem = new System.Windows.Controls.ComboBoxItem { Content = friendly, Tag = processName };
            SourceAppComboBox.Items.Add(newItem);
            SourceAppComboBox.SelectedItem = newItem;
        }

        private string? GetSelectedSourceAppFilter()
        {
            if (SourceAppComboBox.SelectedItem is System.Windows.Controls.ComboBoxItem item)
                return item.Tag as string;
            return null;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        /// <summary>
        /// Removes a pattern from all groups that contain it. Called after the individual rule save succeeds.
        /// </summary>
        private void RemovePatternFromGroups(string normalizedPattern)
        {
            var groups = UrlGroupManager.LoadGroups().ToList();
            foreach (var group in groups)
            {
                var matchingPattern = group.UrlPatterns?
                    .FirstOrDefault(p => ValidationService.NormalizePattern(p.Pattern) == normalizedPattern);
                if (matchingPattern != null && group.UrlPatterns != null)
                {
                    group.UrlPatterns.Remove(matchingPattern);
                    UrlGroupManager.UpdateGroup(group);
                }
            }
        }
    }
}
