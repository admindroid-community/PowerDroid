using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using PowerDroid.Models;

namespace PowerDroid.Services
{
    /// <summary>
    /// Singleton service for the Power Clip feature.
    /// Captures and persists all clipboard text with auto-detection, deduplication, and retention.
    /// </summary>
    public class PowerClipService
    {
        #region Singleton

        private static PowerClipService? _instance;
        private static readonly object _lock = new object();

        public static PowerClipService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new PowerClipService();
                    }
                }
                return _instance;
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// Fired after any mutation to the clipboard history (add, pin, unpin, delete, clear).
        /// </summary>
        public event EventHandler? HistoryChanged;

        #endregion

        #region Fields

        private readonly string _settingsPath;
        private readonly string _historyPath;
        private readonly string _imageFolder;
        private PowerClipSettings _settings;
        private List<ClipboardEntry> _entries;
        private bool _initialized;
        private Dictionary<string, string> _sourceAppCache = new(StringComparer.OrdinalIgnoreCase);
        private string? _lastContent;
        private DateTime _lastCaptureTime;
        private string? _lastImageHash;
        private const int DEDUP_WINDOW_SECONDS = 3;
        private const long MAX_IMAGE_BYTES = 4 * 1024 * 1024; // 4 MB per image
        private const double STORAGE_NEAR_FULL_RATIO = 0.95;

        // Debounced persistence: a burst of captures coalesces into one disk write
        // rather than a full-history serialize + backup per capture. Flushed on exit.
        private DispatcherTimer? _saveTimer;
        private const int SAVE_DEBOUNCE_MS = 1500;

        #endregion

        #region Constructor

        private PowerClipService()
        {
            _settingsPath = Path.Combine(AppConfig.AppDataFolder, "powerclip-settings.json");
            _historyPath = Path.Combine(AppConfig.AppDataFolder, "powerclip-history.json");
            _imageFolder = Path.Combine(AppConfig.AppDataFolder, "clip-images");
            _settings = new PowerClipSettings();
            _entries = new List<ClipboardEntry>();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Loads settings and history from disk, performs retention cleanup, and subscribes to clipboard events.
        /// </summary>
        public void Initialize()
        {
            // Idempotent: safe to call from multiple background-startup paths. Re-running would
            // re-subscribe clipboard events and reload from disk (discarding in-memory entries).
            if (_initialized) return;
            _initialized = true;

            Logger.Log($"{BrandConfig.PowerClipName}: Initializing");

            _settings = JsonStorageService.Load<PowerClipSettings>(_settingsPath);
            // History can contain sensitive copied content (passwords, OTPs, card numbers),
            // so it is encrypted at rest with DPAPI. LoadEncrypted transparently migrates an
            // existing plaintext history file on first read.
            _entries = JsonStorageService.LoadEncrypted<List<ClipboardEntry>>(_historyPath);

            // Retention cleanup: remove non-pinned entries older than RetentionDays (skip if 0)
            if (_settings.RetentionDays > 0)
            {
                var cutoff = DateTime.Now.AddDays(-_settings.RetentionDays);
                var before = _entries.Count;
                var expiredEntries = _entries.Where(e => !e.IsPinned && e.Timestamp < cutoff).ToList();
                foreach (var entry in expiredEntries)
                {
                    DeleteEntryFile(entry);
                    _entries.Remove(entry);
                }

                var removed = before - _entries.Count;
                if (removed > 0)
                {
                    Logger.Log($"{BrandConfig.PowerClipName}: Retention cleanup removed {removed} entries older than {_settings.RetentionDays} days");
                    SaveHistory();
                }
            }

            // Enforce image storage cap on startup
            EnforceImageStorageCap();

            // Subscribe to clipboard events
            ClipboardMonitorService.Instance.ClipboardTextCaptured += OnClipboardTextCaptured;
            ClipboardMonitorService.Instance.ClipboardImageCaptured += OnClipboardImageCaptured;
            ClipboardMonitorService.Instance.ClipboardGifCaptured += OnClipboardGifCaptured;

            RebuildSourceAppCache();
            Logger.Log($"{BrandConfig.PowerClipName}: Initialized with {_entries.Count} entries, {_sourceAppCache.Count} source apps");
        }

        /// <summary>
        /// Searches clipboard history by content (case-insensitive substring match).
        /// </summary>
        public List<ClipboardEntry> Search(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return new List<ClipboardEntry>(_entries);

            return _entries
                .Where(e => e.Content.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();
        }

        /// <summary>
        /// Pins an entry so it is exempt from retention cleanup and MaxEntries trimming.
        /// </summary>
        public const int MaxPinnedEntries = 10;

        /// <summary>
        /// Pins an entry. Returns false if the entry doesn't exist or the pin limit is reached.
        /// </summary>
        public bool Pin(string id)
        {
            var entry = _entries.FirstOrDefault(e => e.Id == id);
            if (entry == null) return false;

            if (entry.IsPinned) return true;

            if (_entries.Count(e => e.IsPinned) >= MaxPinnedEntries)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Pin limit reached ({MaxPinnedEntries})");
                return false;
            }

            entry.IsPinned = true;
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
            return true;
        }

        /// <summary>
        /// Unpins an entry, making it subject to normal retention and trimming rules.
        /// </summary>
        public void Unpin(string id)
        {
            var entry = _entries.FirstOrDefault(e => e.Id == id);
            if (entry == null) return;

            entry.IsPinned = false;
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Deletes a single entry by ID.
        /// </summary>
        public void Delete(string id)
        {
            var entry = _entries.FirstOrDefault(e => e.Id == id);
            if (entry == null) return;

            DeleteEntryFile(entry);
            _entries.Remove(entry);

            RebuildSourceAppCache();
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Deletes multiple entries by ID in one batch. Image files are removed via DeleteEntryFile.
        /// SaveHistory + HistoryChanged fire exactly once. Caller owns pin/age policy — this removes
        /// exactly the IDs given (mirrors Delete(id), which also ignores pin status).
        /// </summary>
        public void DeleteMany(IEnumerable<string> ids)
        {
            if (ids == null) return;
            var idSet = new HashSet<string>(ids);
            if (idSet.Count == 0) return;

            var toRemove = _entries.Where(e => idSet.Contains(e.Id)).ToList();
            if (toRemove.Count == 0) return;

            foreach (var entry in toRemove)
            {
                DeleteEntryFile(entry);   // no-ops for non-image entries
                _entries.Remove(entry);
            }

            RebuildSourceAppCache();
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Clears all non-pinned clipboard history entries. Pinned entries are
        /// preserved (matching native Windows Clipboard History behavior, where
        /// pinned items remain until explicitly unpinned).
        /// </summary>
        public void ClearAllUnpinned()
        {
            var toRemove = _entries.Where(e => !e.IsPinned).ToList();
            if (toRemove.Count == 0) return;

            foreach (var entry in toRemove)
            {
                DeleteEntryFile(entry);
                _entries.Remove(entry);
            }

            RebuildSourceAppCache();
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Clears all non-pinned image entries (and their files on disk) to free space.
        /// Pinned images are preserved, matching the other clear operations.
        /// </summary>
        public void ClearAllImagesUnpinned()
        {
            var toRemove = _entries.Where(e => e.Type == ClipboardEntryType.Image && !e.IsPinned).ToList();
            if (toRemove.Count == 0) return;

            foreach (var entry in toRemove)
            {
                DeleteEntryFile(entry);
                _entries.Remove(entry);
            }

            RebuildSourceAppCache();
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Computes a snapshot of image-storage usage clamped to real disk space, so the
        /// settings meter and the warning banners share one source of truth. The configured
        /// cap is only a self-imposed quota; the folder can never grow past what the drive
        /// can actually hold, so the effective ceiling is min(cap, used + free space).
        /// </summary>
        public ImageStorageStatus GetImageStorageStatus()
        {
            long usedBytes = 0;
            if (Directory.Exists(_imageFolder))
            {
                usedBytes = new DirectoryInfo(_imageFolder).GetFiles().Sum(f => f.Length);
            }

            long configuredBytes = _settings.MaxImageStorageMB * 1024 * 1024;
            long effectiveBytes = configuredBytes;
            bool diskLimited = false;
            try
            {
                var root = Path.GetPathRoot(Path.GetFullPath(_imageFolder));
                if (!string.IsNullOrEmpty(root))
                {
                    long freeBytes = new DriveInfo(root).AvailableFreeSpace;
                    long diskCeilingBytes = usedBytes + freeBytes;
                    if (diskCeilingBytes < configuredBytes)
                    {
                        effectiveBytes = diskCeilingBytes;
                        diskLimited = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: image storage free-space check failed: {ex.Message}");
            }

            double ratio = effectiveBytes > 0 ? Math.Min((double)usedBytes / effectiveBytes, 1.0) : 0;

            return new ImageStorageStatus
            {
                UsedBytes = usedBytes,
                EffectiveCapBytes = effectiveBytes,
                DiskLimited = diskLimited,
                UsedMB = usedBytes / 1024.0 / 1024.0,
                EffectiveCapMB = effectiveBytes / 1024.0 / 1024.0,
                Ratio = ratio,
                NearFull = ratio >= STORAGE_NEAR_FULL_RATIO,
                ClearableImageCount = _entries.Count(e => e.Type == ClipboardEntryType.Image && !e.IsPinned)
            };
        }

        /// <summary>
        /// Clears non-pinned clipboard entries older than the specified cutoff date.
        /// </summary>
        public void ClearBefore(DateTime cutoff)
        {
            var toRemove = _entries.Where(e => !e.IsPinned && e.Timestamp < cutoff).ToList();
            if (toRemove.Count == 0) return;

            foreach (var entry in toRemove)
            {
                DeleteEntryFile(entry);
                _entries.Remove(entry);
            }

            RebuildSourceAppCache();
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Adds a pre-built clipboard entry (used for testing/seeding).
        /// </summary>
        public void AddEntry(ClipboardEntry entry)
        {
            _entries.Add(entry);
            IndexSourceApp(entry);
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Adds OCR-extracted text as a Text entry, applying the same dedup as normal
        /// clipboard captures: skip only if it matches the single most-recent entry.
        /// The same text can still reappear later if other content was copied in between.
        /// Inherits the source app of the image the text was extracted from.
        /// </summary>
        public void AddOcrText(string text, ClipboardEntry? sourceImage = null)
        {
            if (!_settings.IsEnabled)
                return;

            if (string.IsNullOrWhiteSpace(text))
                return;

            var content = text.Trim();

            // Deduplicate against the last item alone (mirrors OnClipboardTextCaptured)
            var latest = _entries.OrderByDescending(e => e.Timestamp).FirstOrDefault();
            if (latest != null && latest.Content == content)
                return;

            var entry = new ClipboardEntry
            {
                Content = content,
                Type = DetectEntryType(content),
                Timestamp = DateTime.Now,
                SourceApp = sourceImage?.SourceApp,
                SourceAppId = sourceImage?.SourceAppId,
                SourceDetail = sourceImage?.SourceDetail
            };

            _entries.Add(entry);
            IndexSourceApp(entry);
            EnforceMaxEntries();
            SaveHistory();
            HistoryChanged?.Invoke(this, EventArgs.Empty);

            Logger.Log($"{BrandConfig.PowerClipName}: Added OCR text entry ({content.Length} chars)");
        }

        /// <summary>
        /// Returns a copy of all clipboard history entries (newest first).
        /// </summary>
        public List<ClipboardEntry> GetEntries()
        {
            return _entries.OrderByDescending(e => e.Timestamp).ToList();
        }

        /// <summary>
        /// Returns cached dictionary of source apps that appear in clipboard history.
        /// Key = SourceAppId (process name), Value = SourceApp (display name).
        /// </summary>
        public Dictionary<string, string> GetSourceApps() => new(_sourceAppCache);

        private void RebuildSourceAppCache()
        {
            _sourceAppCache = _entries
                .Where(e => !string.IsNullOrEmpty(e.SourceAppId))
                .GroupBy(e => e.SourceAppId!, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(
                    g => g.Key,
                    g => g.First().SourceApp ?? g.Key,
                    StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Incrementally records a single entry's source app in the cache (O(1)), used on
        /// the add path instead of a full rebuild. First-seen display name wins, matching
        /// RebuildSourceAppCache's group-first semantics.
        /// </summary>
        private void IndexSourceApp(ClipboardEntry entry)
        {
            if (string.IsNullOrEmpty(entry.SourceAppId)) return;
            if (!_sourceAppCache.ContainsKey(entry.SourceAppId))
                _sourceAppCache[entry.SourceAppId] = entry.SourceApp ?? entry.SourceAppId;
        }

        /// <summary>
        /// Updates and persists Power Clip settings.
        /// </summary>
        public void SaveSettings(PowerClipSettings settings)
        {
            _settings = settings;
            JsonStorageService.Save(_settingsPath, _settings);
            Logger.Log($"{BrandConfig.PowerClipName}: Settings saved");

            // Enforce max entries cap immediately
            EnforceMaxEntries();
        }

        /// <summary>
        /// Returns the current settings.
        /// </summary>
        public PowerClipSettings GetSettings()
        {
            return _settings;
        }

        /// <summary>
        /// Whether Power Clip is turned on. When false, clipboard history is not stored and the
        /// compact popup will not open (callers check this). Toggled from Clip Settings; the
        /// shared clipboard monitor keeps running for Smart Browse's URL detection regardless.
        /// </summary>
        public bool IsEnabled => _settings.IsEnabled;

        #endregion

        #region Private Methods

        private void OnClipboardTextCaptured(object? sender, ClipboardTextEventArgs e)
        {
            try
            {
                if (!_settings.IsEnabled)
                    return;

                if (string.IsNullOrWhiteSpace(e.Text))
                    return;

                var content = e.Text.Trim();

                // Deduplicate: skip only if same as the most recent entry
                var now = DateTime.Now;
                var latest = _entries.OrderByDescending(e => e.Timestamp).FirstOrDefault();
                if (latest != null && latest.Content == content)
                    return;

                _lastContent = content;
                _lastCaptureTime = now;

                // Auto-detect entry type
                var entryType = DetectEntryType(content);

                // Check if this type is enabled in settings
                if (entryType == ClipboardEntryType.Url && !_settings.CaptureUrls)
                    return;
                if (entryType == ClipboardEntryType.Text && !_settings.CaptureText)
                    return;
                if (entryType == ClipboardEntryType.FilePath && !_settings.CaptureFilePaths)
                    return;

                // Create entry
                var entry = new ClipboardEntry
                {
                    Content = content,
                    RichHtml = e.RichHtml,
                    Type = entryType,
                    Timestamp = now,
                    SourceApp = e.SourceApp?.DisplayName,
                    SourceAppId = e.SourceApp?.ProcessName,
                    SourceDetail = e.SourceApp?.BrowserProfileName
                };

                _entries.Add(entry);
                IndexSourceApp(entry);

                // Enforce MaxEntries cap: trim oldest non-pinned entries
                EnforceMaxEntries();

                SaveHistory();
                HistoryChanged?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Error capturing clipboard text: {ex.Message}");
            }
        }

        /// <summary>
        /// Auto-detects the type of clipboard content.
        /// </summary>
        private static ClipboardEntryType DetectEntryType(string content)
        {
            // Skip multiline content — URLs and file paths are single-line
            bool isMultiline = content.Contains('\n') || content.Contains('\r');

            if (!isMultiline)
            {
                // URL: starts with http://, https://, or www.
                if (content.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                    content.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ||
                    content.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
                {
                    return ClipboardEntryType.Url;
                }

                // File path: drive letter (e.g. C:\ or C:/) or UNC path (\\ or //). Both
                // separators are accepted; the open action normalizes '/' to '\'.
                if ((content.Length >= 3 && char.IsLetter(content[0]) && content[1] == ':' && (content[2] == '\\' || content[2] == '/')) ||
                    content.StartsWith("\\\\") || content.StartsWith("//"))
                {
                    return ClipboardEntryType.FilePath;
                }
            }

            return ClipboardEntryType.Text;
        }

        /// <summary>
        /// Removes oldest non-pinned entries when the total count exceeds MaxEntries.
        /// </summary>
        private void EnforceMaxEntries()
        {
            if (_settings.MaxEntries <= 0)
                return;

            while (_entries.Count > _settings.MaxEntries)
            {
                var oldest = _entries
                    .Where(e => !e.IsPinned)
                    .OrderBy(e => e.Timestamp)
                    .FirstOrDefault();

                if (oldest == null)
                    break;

                DeleteEntryFile(oldest);
                _entries.Remove(oldest);
            }
        }

        private void OnClipboardImageCaptured(object? sender, ClipboardImageEventArgs e)
        {
            try
            {
                if (!_settings.IsEnabled)
                    return;

                if (!_settings.CaptureImages)
                    return;

                var image = e.Image;

                // Encode to PNG bytes
                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(image));
                byte[] imageBytes;
                using (var ms = new MemoryStream())
                {
                    encoder.Save(ms);
                    imageBytes = ms.ToArray();
                }

                // Skip if over 4 MB
                if (imageBytes.Length > MAX_IMAGE_BYTES)
                {
                    Logger.Log($"{BrandConfig.PowerClipName}: Skipping image ({imageBytes.Length / 1024} KB) — exceeds 4 MB limit");
                    return;
                }

                // Dedup: compute hash and compare to last image
                var hash = Convert.ToBase64String(SHA256.HashData(imageBytes));
                if (hash == _lastImageHash)
                    return;
                _lastImageHash = hash;

                // Also check existing image entries by filename hash prefix
                if (_entries.Any(e => e.Type == ClipboardEntryType.Image && Path.GetFileNameWithoutExtension(e.Content) == hash.Replace("/", "_").Replace("+", "-")[..16]))
                    return;

                // Ensure image folder exists
                if (!Directory.Exists(_imageFolder))
                    Directory.CreateDirectory(_imageFolder);

                // Save to file
                var safeHash = hash.Replace("/", "_").Replace("+", "-")[..16];
                var fileName = $"{safeHash}.png";
                var filePath = Path.Combine(_imageFolder, fileName);

                // Skip if file already exists (same image content)
                if (File.Exists(filePath))
                    return;

                File.WriteAllBytes(filePath, imageBytes);

                // Create entry
                var entry = new ClipboardEntry
                {
                    Content = filePath,
                    Type = ClipboardEntryType.Image,
                    Timestamp = DateTime.Now,
                    SourceApp = e.SourceApp?.DisplayName,
                    SourceAppId = e.SourceApp?.ProcessName,
                    SourceDetail = e.SourceApp?.BrowserProfileName
                };

                _entries.Add(entry);
                IndexSourceApp(entry);
                EnforceMaxEntries();
                EnforceImageStorageCap();
                SaveHistory();
                HistoryChanged?.Invoke(this, EventArgs.Empty);

                Logger.Log($"{BrandConfig.PowerClipName}: Captured image ({imageBytes.Length / 1024} KB, {image.PixelWidth}x{image.PixelHeight})");
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Error capturing clipboard image: {ex.Message}");
            }
        }

        private void OnClipboardGifCaptured(object? sender, ClipboardGifEventArgs e)
        {
            try
            {
                if (!_settings.IsEnabled)
                    return;

                if (!_settings.CaptureImages)
                    return;

                var gifBytes = e.GifBytes;
                bool savedAsPng = false;

                // If GIF exceeds size limit, convert first frame to PNG instead of skipping
                if (gifBytes.Length > MAX_IMAGE_BYTES)
                {
                    Logger.Log($"{BrandConfig.PowerClipName}: GIF ({gifBytes.Length / 1024} KB) exceeds 4 MB — converting to PNG");
                    try
                    {
                        using var gifStream = new MemoryStream(gifBytes);
                        var decoder = new System.Windows.Media.Imaging.GifBitmapDecoder(
                            gifStream,
                            System.Windows.Media.Imaging.BitmapCreateOptions.PreservePixelFormat,
                            System.Windows.Media.Imaging.BitmapCacheOption.OnLoad);
                        var firstFrame = decoder.Frames[0];

                        var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
                        encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(firstFrame));
                        using var pngStream = new MemoryStream();
                        encoder.Save(pngStream);
                        gifBytes = pngStream.ToArray();
                        savedAsPng = true;
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"{BrandConfig.PowerClipName}: Failed to convert GIF to PNG: {ex.Message}");
                        return;
                    }
                }

                // Dedup: hash and compare
                var hash = Convert.ToBase64String(SHA256.HashData(gifBytes));
                if (hash == _lastImageHash)
                    return;
                _lastImageHash = hash;

                var safeHash = hash.Replace("/", "_").Replace("+", "-")[..16];
                if (_entries.Any(e => e.Type == ClipboardEntryType.Image && Path.GetFileNameWithoutExtension(e.Content) == safeHash))
                    return;

                if (!Directory.Exists(_imageFolder))
                    Directory.CreateDirectory(_imageFolder);

                var fileName = savedAsPng ? $"{safeHash}.png" : $"{safeHash}.gif";
                var filePath = Path.Combine(_imageFolder, fileName);

                if (File.Exists(filePath))
                    return;

                File.WriteAllBytes(filePath, gifBytes);

                var entry = new ClipboardEntry
                {
                    Content = filePath,
                    Type = ClipboardEntryType.Image,
                    Timestamp = DateTime.Now,
                    SourceApp = e.SourceApp?.DisplayName,
                    SourceAppId = e.SourceApp?.ProcessName,
                    SourceDetail = e.SourceApp?.BrowserProfileName
                };

                _entries.Add(entry);
                IndexSourceApp(entry);
                EnforceMaxEntries();
                EnforceImageStorageCap();
                SaveHistory();
                HistoryChanged?.Invoke(this, EventArgs.Empty);

                Logger.Log($"{BrandConfig.PowerClipName}: Captured {(savedAsPng ? "GIF as PNG" : "GIF")} ({gifBytes.Length / 1024} KB)");
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Error capturing clipboard GIF: {ex.Message}");
            }
        }

        /// <summary>
        /// Validates that a file path is within the image folder to prevent path traversal attacks.
        /// </summary>
        private bool IsPathWithinImageFolder(string path)
        {
            try
            {
                var fullPath = Path.GetFullPath(path);
                var folderPath = Path.GetFullPath(_imageFolder + Path.DirectorySeparatorChar);
                return fullPath.StartsWith(folderPath, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Deletes the image file associated with an entry if it's an Image type.
        /// </summary>
        private void DeleteEntryFile(ClipboardEntry entry)
        {
            if (entry.Type != ClipboardEntryType.Image) return;

            try
            {
                if (IsPathWithinImageFolder(entry.Content) && File.Exists(entry.Content))
                {
                    File.Delete(entry.Content);
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Failed to delete image file: {ex.Message}");
            }
        }

        /// <summary>
        /// Enforces the image storage size cap by removing oldest non-pinned image entries.
        /// </summary>
        private void EnforceImageStorageCap()
        {
            if (_settings.MaxImageStorageMB <= 0 || !Directory.Exists(_imageFolder))
                return;

            var maxBytes = _settings.MaxImageStorageMB * 1024 * 1024;
            var dirInfo = new DirectoryInfo(_imageFolder);
            var totalSize = dirInfo.GetFiles("*.png").Concat(dirInfo.GetFiles("*.gif"))
                .Sum(f => f.Length);

            if (totalSize <= maxBytes) return;

            // Remove oldest non-pinned image entries until under cap
            var imageEntries = _entries
                .Where(e => e.Type == ClipboardEntryType.Image && !e.IsPinned)
                .OrderBy(e => e.Timestamp)
                .ToList();

            foreach (var entry in imageEntries)
            {
                if (totalSize <= maxBytes) break;

                // Only entries whose on-disk file actually counts toward the cap can
                // reduce usage. An entry whose file is missing or outside the image
                // folder contributes nothing to totalSize, so removing it here would
                // not lower usage — skip it (avoids over-trimming and data loss when
                // some entries are orphaned). Orphan cleanup is handled separately.
                if (!IsPathWithinImageFolder(entry.Content) || !File.Exists(entry.Content))
                    continue;

                try
                {
                    var fileSize = new FileInfo(entry.Content).Length;
                    File.Delete(entry.Content);
                    totalSize -= fileSize;
                    _entries.Remove(entry);
                }
                catch { }
            }

            SaveHistory();
            Logger.Log($"{BrandConfig.PowerClipName}: Image storage cap enforced, now {totalSize / 1024 / 1024} MB");
        }

        private void SaveHistory()
        {
            // Source-app cache is maintained incrementally on add (IndexSourceApp) and
            // fully rebuilt on the infrequent delete/clear paths, so it must NOT be
            // rebuilt here — this runs on every capture and the GroupBy was O(n).
            ScheduleSave();
        }

        /// <summary>
        /// Debounces the actual disk write so a burst of clipboard captures results in
        /// a single serialization. Runs the flush on the UI dispatcher (the same thread
        /// that mutates <see cref="_entries"/>) to avoid racing the list. Falls back to a
        /// synchronous write when no dispatcher is available (e.g. tests).
        /// </summary>
        private void ScheduleSave()
        {
            var dispatcher = Application.Current?.Dispatcher;
            if (dispatcher == null)
            {
                PersistHistory();
                return;
            }
            if (!dispatcher.CheckAccess())
            {
                dispatcher.Invoke(ScheduleSave);
                return;
            }

            if (_saveTimer == null)
            {
                _saveTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(SAVE_DEBOUNCE_MS) };
                _saveTimer.Tick += (_, _) => { _saveTimer!.Stop(); PersistHistory(); };
            }
            _saveTimer.Stop();
            _saveTimer.Start();
        }

        /// <summary>
        /// Immediately writes the pending history to disk. Call on app shutdown so a
        /// debounced-but-not-yet-flushed change is not lost.
        /// </summary>
        public void FlushHistory()
        {
            _saveTimer?.Stop();
            PersistHistory();
        }

        private void PersistHistory()
        {
            try
            {
                // Encrypted at rest (DPAPI): history may hold sensitive copied content.
                // High-churn file — the atomic temp+move in SaveEncrypted still guards
                // against partial-write corruption.
                JsonStorageService.SaveEncrypted(_historyPath, _entries);
            }
            catch (Exception ex)
            {
                Logger.Log($"{BrandConfig.PowerClipName}: Failed to save history: {ex.Message}");
            }
        }

        #endregion
    }
}
