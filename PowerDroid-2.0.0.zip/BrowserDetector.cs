﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text.Json;
using Microsoft.Win32;

namespace PowerDroid
{
    public class BrowserInfo
    {
        public string Name { get; set; } = string.Empty;
        public string ExecutablePath { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
    }

    public class ProfileInfo
    {
        public string Name { get; set; }
        public string? Email { get; set; }
        public string Path { get; set; }
        public string Arguments { get; set; }

        public string? AvatarUrl { get; set; }
        public int ProfileIndex { get; set; }

        public string DisplayName =>
            string.IsNullOrWhiteSpace(Email)
                ? Name
                : $"{Name} ({Email})";

        /// <summary>
        /// Extracts the domain portion from the email address for matching.
        /// </summary>
        public string EmailDomain =>
            string.IsNullOrEmpty(Email)
                ? string.Empty
                : Email.Contains("@")
                    ? Email.Substring(Email.IndexOf('@') + 1).ToLowerInvariant()
                    : string.Empty;
    }


    public static class BrowserDetector
    {
        private static List<BrowserInfo>? _cachedBrowsers = null;
        private static DateTime _browsersCacheTime = DateTime.MinValue;
        private static readonly TimeSpan _browsersCacheTTL = TimeSpan.FromMinutes(5);

        // Per-browser profile cache (keyed by executable path). Profile reads hit disk
        // (Chromium "Local State" JSON / Firefox profile store), and GetBrowserProfiles is
        // called on the clipboard-capture hot path, so cache with the same TTL as browsers.
        private static readonly object _profilesCacheLock = new();
        private static readonly Dictionary<string, (DateTime time, List<ProfileInfo> profiles)> _profilesCache
            = new(StringComparer.OrdinalIgnoreCase);
        private static readonly TimeSpan _profilesCacheTTL = TimeSpan.FromMinutes(5);

        /// <summary>
        /// Clears the browser detection cache, forcing the next call to GetInstalledBrowsers()
        /// to re-scan the system. Call this before displaying browser lists to users.
        /// </summary>
        public static void ClearCache()
        {
            _cachedBrowsers = null;
            _browsersCacheTime = DateTime.MinValue;
            lock (_profilesCacheLock) { _profilesCache.Clear(); }
        }

        public static List<BrowserInfo> GetInstalledBrowsers()
        {
            if (_cachedBrowsers != null && (DateTime.Now - _browsersCacheTime) < _browsersCacheTTL)
                return _cachedBrowsers;

            var browsers = new List<BrowserInfo>();

            // Check for Chrome
            var chromePath = GetChromePath();
            if (!string.IsNullOrEmpty(chromePath))
            {
                browsers.Add(new BrowserInfo
                {
                    Name = "Google Chrome",
                    ExecutablePath = chromePath,
                    Type = "Chrome"
                });
            }

            // Check for Edge
            var edgePath = GetEdgePath();
            if (!string.IsNullOrEmpty(edgePath))
            {
                browsers.Add(new BrowserInfo
                {
                    Name = "Microsoft Edge",
                    ExecutablePath = edgePath,
                    Type = "Edge"
                });
            }

            // Check for Firefox
            var firefoxPath = GetFirefoxPath();
            if (!string.IsNullOrEmpty(firefoxPath))
            {
                browsers.Add(new BrowserInfo
                {
                    Name = "Mozilla Firefox",
                    ExecutablePath = firefoxPath,
                    Type = "Firefox"
                });
            }

            // Check for Brave
            var bravePath = GetBravePath();
            if (!string.IsNullOrEmpty(bravePath))
            {
                browsers.Add(new BrowserInfo
                {
                    Name = "Brave Browser",
                    ExecutablePath = bravePath,
                    Type = "Chrome"
                });
            }

            // Check for Opera
            var operaPath = GetOperaPath();
            if (!string.IsNullOrEmpty(operaPath))
            {
                browsers.Add(new BrowserInfo
                {
                    Name = "Opera",
                    ExecutablePath = operaPath,
                    Type = "Chrome"
                });
            }

            // Check for Opera GX
            var operaGXPath = GetOperaGXPath();
            if (!string.IsNullOrEmpty(operaGXPath))
            {
                browsers.Add(new BrowserInfo
                {
                    Name = "Opera GX",
                    ExecutablePath = operaGXPath,
                    Type = "Chrome"
                });
            }

            // Scan registry for any additional browsers not in the hardcoded list
            var registryBrowsers = GetRegistryBrowsers(browsers);
            browsers.AddRange(registryBrowsers);

            _cachedBrowsers = browsers;
            _browsersCacheTime = DateTime.Now;

            return browsers;
        }

        public static List<ProfileInfo> GetBrowserProfiles(BrowserInfo browser)
        {
            var cacheKey = !string.IsNullOrEmpty(browser.ExecutablePath) ? browser.ExecutablePath : browser.Name;
            if (!string.IsNullOrEmpty(cacheKey))
            {
                lock (_profilesCacheLock)
                {
                    if (_profilesCache.TryGetValue(cacheKey, out var cached)
                        && (DateTime.Now - cached.time) < _profilesCacheTTL)
                    {
                        // Copy so callers can't mutate the cached list.
                        return new List<ProfileInfo>(cached.profiles);
                    }
                }
            }

            var profiles = new List<ProfileInfo>();

            switch (browser.Type)
            {
                case "Chrome":
                case "Edge":
                    profiles = GetChromiumProfiles(browser.Name, browser.ExecutablePath);
                    break;
                case "Firefox":
                    profiles = GetFirefoxProfiles();
                    break;
            }

            // Always add a default profile option
            if (profiles.Count == 0)
            {
                profiles.Add(new ProfileInfo
                {
                    Name = "Default",
                    Path = "Default",
                    Arguments = string.Empty
                });
            }

            if (!string.IsNullOrEmpty(cacheKey))
            {
                lock (_profilesCacheLock)
                {
                    _profilesCache[cacheKey] = (DateTime.Now, new List<ProfileInfo>(profiles));
                }
            }

            return profiles;
        }

        private static string? FindExecutable(params string[] paths) => paths.FirstOrDefault(File.Exists);

        private static string LocalAppData => Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

        private static string? GetChromePath() => FindExecutable(
            @"C:\Program Files\Google\Chrome\Application\chrome.exe",
            @"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            // Per-user (no-admin) install — common on locked-down machines.
            Path.Combine(LocalAppData, @"Google\Chrome\Application\chrome.exe"));

        private static string? GetEdgePath() => FindExecutable(
            @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            @"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            // Per-user (no-admin) install.
            Path.Combine(LocalAppData, @"Microsoft\Edge\Application\msedge.exe"));

        private static string? GetFirefoxPath()
        {
            try
            {
                using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe");
                return key?.GetValue("") as string;
            }
            catch
            {
                var paths = new[]
                {
                    @"C:\Program Files\Mozilla Firefox\firefox.exe",
                    @"C:\Program Files (x86)\Mozilla Firefox\firefox.exe"
                };

                return paths.FirstOrDefault(File.Exists);
            }
        }

        private static string? GetBravePath()
        {
            var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            return FindExecutable(
                Path.Combine(localAppData, @"BraveSoftware\Brave-Browser\Application\brave.exe"),
                @"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
                @"C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe");
        }

        private static string? GetOperaPath()
        {
            try
            {
                // Try registry (machine-wide)
                using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Clients\StartMenuInternet\OperaStable\shell\open\command"))
                {
                    var value = key?.GetValue("") as string;
                    if (!string.IsNullOrEmpty(value))
                    {
                        // The registry value can be like: "\"C:\\Users\\User\\AppData\\Local\\Programs\\Opera\\launcher.exe\" --"
                        var exePath = value.Split('"').FirstOrDefault(s => s.EndsWith(".exe", StringComparison.OrdinalIgnoreCase));
                        if (File.Exists(exePath))
                            return exePath;
                    }
                }

                // Try registry (per-user)
                using (var key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Clients\StartMenuInternet\OperaStable\shell\open\command"))
                {
                    var value = key?.GetValue("") as string;
                    if (!string.IsNullOrEmpty(value))
                    {
                        var exePath = value.Split('"').FirstOrDefault(s => s.EndsWith(".exe", StringComparison.OrdinalIgnoreCase));
                        if (File.Exists(exePath))
                            return exePath;
                    }
                }
            }
            catch
            {
                // Ignore registry errors
            }

            // Fallback: check common file system paths
            var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            var programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);

            var paths = new[]
            {
        Path.Combine(localAppData, @"Programs\Opera\launcher.exe"),
        Path.Combine(localAppData, @"Programs\Opera\opera.exe"),
        Path.Combine(programFiles, @"Opera\launcher.exe"),
        Path.Combine(programFilesX86, @"Opera\launcher.exe")
    };

            return paths.FirstOrDefault(File.Exists);
        }

        private static string? GetOperaGXPath()
        {
            var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            var programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            return FindExecutable(
                Path.Combine(localAppData, @"Programs\Opera GX\launcher.exe"),
                Path.Combine(programFiles, @"Opera GX\launcher.exe"),
                Path.Combine(programFilesX86, @"Opera GX\launcher.exe"));
        }

        private static string? ExtractExePathFromCommand(string command)
        {
            if (string.IsNullOrEmpty(command))
                return null;

            command = command.Trim();

            if (command.StartsWith("\""))
            {
                var endQuote = command.IndexOf('"', 1);
                if (endQuote > 1)
                    return command.Substring(1, endQuote - 1);
            }

            var exeIndex = command.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
            if (exeIndex >= 0)
                return command.Substring(0, exeIndex + 4);

            return command.Split(' ')[0];
        }

        private static List<BrowserInfo> GetRegistryBrowsers(List<BrowserInfo> existingBrowsers)
        {
            var additional = new List<BrowserInfo>();
            var existingPaths = new HashSet<string>(
                existingBrowsers.Select(b => b.ExecutablePath),
                StringComparer.OrdinalIgnoreCase);

            var registryRoots = new[]
            {
                Registry.LocalMachine,
                Registry.CurrentUser
            };

            foreach (var root in registryRoots)
            {
                try
                {
                    using var clientsKey = root.OpenSubKey(@"SOFTWARE\Clients\StartMenuInternet");
                    if (clientsKey == null) continue;

                    foreach (var subkeyName in clientsKey.GetSubKeyNames())
                    {
                        try
                        {
                            if (string.Equals(subkeyName, RegistryHelper.AppName,
                                StringComparison.OrdinalIgnoreCase))
                                continue;

                            using var commandKey = clientsKey.OpenSubKey(
                                $@"{subkeyName}\shell\open\command");
                            var commandValue = commandKey?.GetValue("") as string;
                            if (string.IsNullOrEmpty(commandValue))
                                continue;

                            var exePath = ExtractExePathFromCommand(commandValue);
                            if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath))
                                continue;

                            // Never list PowerDroid itself as a target browser. Selecting it would
                            // relaunch PowerDroid with the same URL, which re-matches the rule and
                            // loops forever (the cursor spins). Matched by executable rather than
                            // registry subkey name, so a stale/renamed registration identity — e.g. a
                            // leftover "LinkRouter" key from before the rebrand still pointing at
                            // PowerDroid.exe — is caught too, which the name-only check above misses. (#61)
                            if (IsOwnExecutable(exePath))
                                continue;

                            if (existingPaths.Contains(exePath))
                                continue;

                            using var browserKey = clientsKey.OpenSubKey(subkeyName);
                            var displayName = browserKey?.GetValue("") as string;
                            if (string.IsNullOrWhiteSpace(displayName))
                                displayName = subkeyName;

                            // Internet Explorer is retired (2022) and Windows redirects iexplore.exe
                            // to Edge, so it is never a real launch target — exclude it from detection.
                            if (string.Equals(System.IO.Path.GetFileName(exePath), "iexplore.exe", StringComparison.OrdinalIgnoreCase)
                                || displayName.IndexOf("Internet Explorer", StringComparison.OrdinalIgnoreCase) >= 0)
                                continue;

                            // Detect Chromium-based browsers by checking for User Data directory
                            var type = "Other";
                            var appDir = System.IO.Path.GetDirectoryName(exePath);
                            if (appDir != null)
                            {
                                var parentDir = System.IO.Path.GetDirectoryName(appDir);
                                if (parentDir != null && File.Exists(System.IO.Path.Combine(parentDir, "User Data", "Local State")))
                                    type = "Chrome";
                            }

                            existingPaths.Add(exePath);
                            additional.Add(new BrowserInfo
                            {
                                Name = displayName,
                                ExecutablePath = exePath,
                                Type = type
                            });
                        }
                        catch (Exception ex)
                        {
                            Logger.Log($"Error reading registry browser '{subkeyName}': {ex.Message}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"Error scanning registry for browsers: {ex.Message}");
                }
            }

            return additional;
        }

        /// <summary>
        /// True when <paramref name="exePath"/> points to PowerDroid's own executable. PowerDroid
        /// registers itself as a Windows browser, so it must never be offered as a routing target —
        /// selecting it would relaunch PowerDroid with the same URL, which re-matches the rule and
        /// loops forever (the cursor spins until the rule is disabled). (Issue #61)
        ///
        /// The check is by EXECUTABLE FILE NAME, deliberately not by registry subkey name or full path:
        ///  - Not subkey name: the registration identity is fragile. The detection loop's name check
        ///    (subkeyName == RegistryAppId) only catches the *current* identity "PowerDroidSmartBrowse".
        ///    A leftover "LinkRouter" key (written by an internal transition build before the rebrand,
        ///    still pointing at PowerDroid.exe) slips past it. Keying off the exe makes the name moot.
        ///  - File name, not full path: the registration may point at the install-folder copy
        ///    (C:\Program Files\PowerDroid\PowerDroid.exe) while a dev build runs from bin\Debug\…;
        ///    same product, different path. The file name still matches in both cases.
        ///
        /// Steps: (1) candidate file name, (2) our own running exe's file name (Environment.ProcessPath,
        /// which self-adjusts if the product exe is ever renamed; falls back to the branded name so it
        /// never silently fails open when the host can't report a path), (3) case-insensitive compare.
        /// </summary>
        public static bool IsOwnExecutable(string? exePath)
        {
            if (string.IsNullOrWhiteSpace(exePath))
                return false;

            try
            {
                // (1) Candidate's file name, e.g. "PowerDroid.exe".
                var candidateName = Path.GetFileName(exePath);

                // (2) Our own running executable's file name. Environment.ProcessPath is the actual
                // running .exe, so this tracks any future rename automatically; if the host can't
                // report it, fall back to the branded name rather than returning false (which would
                // re-expose the self-listing bug).
                var selfPath = Environment.ProcessPath;
                var selfName = !string.IsNullOrEmpty(selfPath)
                    ? Path.GetFileName(selfPath)
                    : BrandConfig.ExeName + ".exe";

                // (3) Same executable => this registration is us.
                return string.Equals(candidateName, selfName, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        private static List<ProfileInfo> GetChromiumProfiles(string browserName, string? executablePath = null)
        {
            var profiles = new List<ProfileInfo>();
            string userDataPath;

            // Determine user data path based on browser
            if (browserName.Contains("Edge"))
            {
                userDataPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    @"Microsoft\Edge\User Data");
            }
            else if (browserName.Contains("Brave"))
            {
                userDataPath = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    @"BraveSoftware\Brave-Browser\User Data");
            }
            else if (browserName.Contains("Opera GX"))
            {
                userDataPath = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    @"Opera Software\Opera GX Stable");
            }
            else if (browserName.Contains("Opera"))
            {
                userDataPath = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    @"Opera Software\Opera Stable");
            }
            else
            {
                userDataPath = string.Empty;

                // For non-Chrome browsers, try to find User Data near the executable first
                if (!string.IsNullOrEmpty(executablePath))
                {
                    var appDir = System.IO.Path.GetDirectoryName(executablePath);
                    if (appDir != null)
                    {
                        var parentDir = System.IO.Path.GetDirectoryName(appDir);
                        if (parentDir != null)
                        {
                            var candidate = System.IO.Path.Combine(parentDir, "User Data");
                            if (Directory.Exists(candidate))
                                userDataPath = candidate;
                        }
                    }
                }

                // Fall back to Chrome's User Data path
                if (string.IsNullOrEmpty(userDataPath))
                {
                    userDataPath = System.IO.Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        @"Google\Chrome\User Data");
                }
            }

            if (!Directory.Exists(userDataPath))
                return profiles;

            // Get profile names from Local State (contains actual custom names)
            var localStateNames = GetProfileNamesFromLocalState(userDataPath);

            // Add Default profile
            var defaultPrefs = System.IO.Path.Combine(userDataPath, "Default", "Preferences");
            if (File.Exists(defaultPrefs))
            {
                var profileData = GetProfileDataFromPreferences(defaultPrefs);
                // Prefer Local State name, fall back to Preferences name, then "Default"
                var displayName = localStateNames.TryGetValue("Default", out var lsName)
                    ? lsName
                    : (profileData?.Name ?? "Default");
                profiles.Add(new ProfileInfo
                {
                    Name = displayName,
                    Email = profileData?.Email,
                    AvatarUrl = profileData?.AvatarUrl,
                    Path = System.IO.Path.Combine(userDataPath, "Default"),
                    Arguments = "--profile-directory=\"Default\""
                });
            }

            // Add numbered profiles
            var profileDirs = Directory.GetDirectories(userDataPath, "Profile *");
            foreach (var dir in profileDirs)
            {
                var prefsFile = System.IO.Path.Combine(dir, "Preferences");
                if (File.Exists(prefsFile))
                {
                    var dirName = System.IO.Path.GetFileName(dir);
                    var profileData = GetProfileDataFromPreferences(prefsFile);
                    // Prefer Local State name, fall back to Preferences name, then directory name
                    var displayName = localStateNames.TryGetValue(dirName, out var lsName)
                        ? lsName
                        : (profileData?.Name ?? dirName);

                    profiles.Add(new ProfileInfo
                    {
                        Name = displayName,
                        Email = profileData?.Email,
                        AvatarUrl = profileData?.AvatarUrl,
                        Path = dir,
                        Arguments = $"--profile-directory=\"{dirName}\""
                    });
                }
            }

            // Handle duplicate names by appending profile directory
            var duplicateNames = profiles.GroupBy(p => p.Name)
                                         .Where(g => g.Count() > 1)
                                         .Select(g => g.Key)
                                         .ToHashSet();

            foreach (var profile in profiles)
            {
                if (duplicateNames.Contains(profile.Name))
                {
                    // Extract profile directory name from Arguments
                    var match = System.Text.RegularExpressions.Regex.Match(
                        profile.Arguments,
                        @"--profile-directory=""([^""]+)"""
                    );

                    if (match.Success)
                    {
                        string dirName = match.Groups[1].Value;
                        profile.Name = $"{profile.Name} ({dirName})";
                    }
                }
            }

            return profiles;
        }


        private static List<ProfileInfo> GetFirefoxProfiles()
        {
            var firefoxRoot = System.IO.Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), @"Mozilla\Firefox");

            // Tier 1: new Firefox profile system — friendly names/avatars live in
            // "Profile Groups\<StoreID>.sqlite" (the avatar-based "Choose a Firefox profile" UI).
            try
            {
                var fromStore = GetFirefoxProfilesFromStore(firefoxRoot);
                if (fromStore.Count > 0) return fromStore;
            }
            catch (Exception ex) { Logger.Log($"Firefox profile store read failed: {ex.Message}"); }

            // Tier 2: classic profiles.ini (Name + Path for each [ProfileN] section).
            try
            {
                var fromIni = GetFirefoxProfilesFromIni(firefoxRoot);
                if (fromIni.Count > 0) return fromIni;
            }
            catch (Exception ex) { Logger.Log($"Firefox profiles.ini read failed: {ex.Message}"); }

            // Tier 3: last-resort raw directory enumeration (original behavior).
            var profiles = new List<ProfileInfo>();
            try
            {
                var profilesPath = System.IO.Path.Combine(firefoxRoot, "Profiles");
                if (Directory.Exists(profilesPath))
                {
                    foreach (var dir in Directory.GetDirectories(profilesPath))
                    {
                        var dirName = System.IO.Path.GetFileName(dir);
                        var profileName = dirName.Contains('.') ? dirName.Substring(dirName.IndexOf('.') + 1) : dirName;
                        profiles.Add(new ProfileInfo { Name = profileName, Path = dir, Arguments = $"-profile \"{dir}\"" });
                    }
                }
            }
            catch (Exception ex) { Logger.Log($"Firefox directory enumeration failed: {ex.Message}"); }

            return profiles;
        }

        /// <summary>
        /// Reads the new Firefox "profile group" SQLite store referenced by profiles.ini's StoreID.
        /// This is where the avatar-based profile selector stores the user's profile names/paths.
        /// </summary>
        private static List<ProfileInfo> GetFirefoxProfilesFromStore(string firefoxRoot)
        {
            var result = new List<ProfileInfo>();

            var iniPath = System.IO.Path.Combine(firefoxRoot, "profiles.ini");
            if (!File.Exists(iniPath)) return result;

            // Find the StoreID linking profiles.ini to the group store.
            string? storeId = null;
            foreach (var raw in File.ReadAllLines(iniPath))
            {
                var line = raw.Trim();
                if (line.StartsWith("StoreID=", StringComparison.OrdinalIgnoreCase))
                {
                    storeId = line.Substring("StoreID=".Length).Trim();
                    break;
                }
            }
            if (string.IsNullOrEmpty(storeId)) return result;

            var storePath = System.IO.Path.Combine(firefoxRoot, "Profile Groups", storeId + ".sqlite");
            if (!File.Exists(storePath)) return result;

            // Copy the db (+ WAL/SHM) to a temp location so we read a consistent snapshot and never
            // contend with Firefox's lock on the live file.
            var tmpDir = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "pd_ff_" + Guid.NewGuid().ToString("N"));
            try
            {
                Directory.CreateDirectory(tmpDir);
                var tmpDb = System.IO.Path.Combine(tmpDir, "store.sqlite");
                File.Copy(storePath, tmpDb, true);
                foreach (var ext in new[] { "-wal", "-shm" })
                {
                    var side = storePath + ext;
                    if (File.Exists(side)) File.Copy(side, tmpDb + ext, true);
                }

                var connStr = new Microsoft.Data.Sqlite.SqliteConnectionStringBuilder
                {
                    DataSource = tmpDb
                }.ConnectionString;

                using var conn = new Microsoft.Data.Sqlite.SqliteConnection(connStr);
                conn.Open();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT name, path FROM Profiles ORDER BY id";
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    var name = reader.IsDBNull(0) ? string.Empty : reader.GetString(0);
                    var relPath = reader.IsDBNull(1) ? string.Empty : reader.GetString(1);
                    if (string.IsNullOrWhiteSpace(relPath)) continue;

                    var fullPath = System.IO.Path.IsPathRooted(relPath)
                        ? relPath
                        : System.IO.Path.Combine(firefoxRoot, relPath.Replace('/', '\\'));

                    result.Add(new ProfileInfo
                    {
                        Name = string.IsNullOrWhiteSpace(name) ? System.IO.Path.GetFileName(fullPath) : name,
                        Path = fullPath,
                        Arguments = $"-profile \"{fullPath}\""
                    });
                }
            }
            finally
            {
                try { if (Directory.Exists(tmpDir)) Directory.Delete(tmpDir, true); } catch { }
            }

            return result;
        }

        /// <summary>
        /// Reads classic Firefox profiles from profiles.ini ([ProfileN] sections with Name/Path/IsRelative).
        /// </summary>
        private static List<ProfileInfo> GetFirefoxProfilesFromIni(string firefoxRoot)
        {
            var result = new List<ProfileInfo>();
            var iniPath = System.IO.Path.Combine(firefoxRoot, "profiles.ini");
            if (!File.Exists(iniPath)) return result;

            string? curSection = null;
            string? name = null, path = null;
            bool isRelative = true;

            void Flush()
            {
                if (curSection != null && curSection.StartsWith("Profile", StringComparison.OrdinalIgnoreCase)
                    && !string.IsNullOrWhiteSpace(path))
                {
                    var fullPath = isRelative
                        ? System.IO.Path.Combine(firefoxRoot, path!.Replace('/', '\\'))
                        : path!;
                    result.Add(new ProfileInfo
                    {
                        Name = string.IsNullOrWhiteSpace(name) ? System.IO.Path.GetFileName(fullPath) : name!,
                        Path = fullPath,
                        Arguments = $"-profile \"{fullPath}\""
                    });
                }
                name = null; path = null; isRelative = true;
            }

            foreach (var raw in File.ReadAllLines(iniPath))
            {
                var line = raw.Trim();
                if (line.StartsWith("[") && line.EndsWith("]"))
                {
                    Flush();
                    curSection = line.Substring(1, line.Length - 2);
                }
                else if (line.StartsWith("Name=", StringComparison.OrdinalIgnoreCase))
                    name = line.Substring("Name=".Length).Trim();
                else if (line.StartsWith("Path=", StringComparison.OrdinalIgnoreCase))
                    path = line.Substring("Path=".Length).Trim();
                else if (line.StartsWith("IsRelative=", StringComparison.OrdinalIgnoreCase))
                    isRelative = line.Substring("IsRelative=".Length).Trim() != "0";
            }
            Flush();

            return result;
        }

         
        /// <summary>
        /// Data extracted from Chrome/Edge Preferences JSON file
        /// </summary>
        private class ProfilePreferencesData
        {
            public string? Name { get; set; }
            public string? Email { get; set; }
            public string? AvatarUrl { get; set; }

            public string? DisplayName =>
                !string.IsNullOrWhiteSpace(Name) && !string.IsNullOrWhiteSpace(Email)
                    ? $"{Name} ({Email})"
                    : Name;
        }

        /// <summary>
        /// Reads profile display names from Chrome/Edge Local State file.
        /// This contains the actual user-customized profile names.
        /// </summary>
        private static Dictionary<string, string> GetProfileNamesFromLocalState(string userDataPath)
        {
            var names = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var localStatePath = System.IO.Path.Combine(userDataPath, "Local State");

            if (!File.Exists(localStatePath))
                return names;

            try
            {
                var json = File.ReadAllText(localStatePath);
                using var doc = System.Text.Json.JsonDocument.Parse(json);
                var root = doc.RootElement;

                // Navigate to profile.info_cache
                if (root.TryGetProperty("profile", out var profileProp) &&
                    profileProp.TryGetProperty("info_cache", out var infoCache))
                {
                    foreach (var profileEntry in infoCache.EnumerateObject())
                    {
                        string profileDir = profileEntry.Name; // e.g., "Default", "Profile 1"

                        if (profileEntry.Value.TryGetProperty("name", out var nameProp))
                        {
                            var profileName = nameProp.GetString();
                            if (!string.IsNullOrEmpty(profileName))
                            {
                                names[profileDir] = profileName;
                            }
                        }
                    }
                }
            }
            catch
            {
                // If Local State parsing fails, return empty dictionary
                // Callers will fall back to Preferences file names
            }

            return names;
        }

        private static ProfilePreferencesData GetProfileDataFromPreferences(string preferencesPath)
        {
            try
            {
                var json = File.ReadAllText(preferencesPath);
                using var doc = System.Text.Json.JsonDocument.Parse(json);
                var root = doc.RootElement;

                string profileName = null;
                string email = null;
                string avatarUrl = null;

                // profile.name
                if (root.TryGetProperty("profile", out var profileProp) &&
                    profileProp.TryGetProperty("name", out var nameProp))
                {
                    profileName = nameProp.GetString();
                }

                // account_info[0] - email and avatar
                if (root.TryGetProperty("account_info", out var accountInfo) &&
                    accountInfo.ValueKind == System.Text.Json.JsonValueKind.Array &&
                    accountInfo.GetArrayLength() > 0)
                {
                    var account = accountInfo[0];

                    if (account.TryGetProperty("email", out var emailProp))
                    {
                        email = emailProp.GetString();
                    }

                    // Extract avatar URL (picture_url or last_downloaded_image_url_with_size)
                    if (account.TryGetProperty("picture_url", out var pictureUrlProp))
                    {
                        avatarUrl = pictureUrlProp.GetString();
                    }
                    else if (account.TryGetProperty("last_downloaded_image_url_with_size", out var lastImageProp))
                    {
                        avatarUrl = lastImageProp.GetString();
                    }
                }

                return new ProfilePreferencesData
                {
                    Name = profileName,
                    Email = email,
                    AvatarUrl = avatarUrl
                };
            }
            catch
            {
                return null;
            }
        }


        public static BrowserInfo MatchBrowserByPath(string path)
        {
            foreach (var browser in GetInstalledBrowsers())
            {
                if (browser.ExecutablePath == path)
                    return browser;
            }
            return null;
        }
    }
}