using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid.Pages
{
    public partial class HomePage : UserControl
    {
        public event EventHandler? NavigateToRulesRequested;
        public event EventHandler? TestAllRulesRequested;
        public event EventHandler? NavigateToClipboardRequested;
        public event EventHandler? NavigateToSettingsRequested;

        public HomePage()
        {
            InitializeComponent();
            Loaded += HomePage_Loaded;
        }

        private void HomePage_Loaded(object sender, RoutedEventArgs e)
        {
            // Hide dev-only features in production
            if (!AppConfig.DevMode)
            {
                TestAllRulesCard.Visibility = Visibility.Collapsed;
            }

            LoadData();
        }

        public void LoadData()
        {
            UpdateDefaultBrowserWarning();
            LoadBrowserStats();

            if (BrandConfig.PowerClipEnabled)
            {
                LoadClipStats();
            }
            else
            {
                PowerClipSection.Visibility = Visibility.Collapsed;
                ClipboardHistoryCard.Visibility = Visibility.Collapsed;
            }
        }

        private void UpdateDefaultBrowserWarning()
        {
            try
            {
                bool isDefault = RegistryHelper.IsSystemDefaultBrowser();
                DefaultBrowserWarning.Visibility = isDefault ? Visibility.Collapsed : Visibility.Visible;
            }
            catch
            {
                DefaultBrowserWarning.Visibility = Visibility.Collapsed;
            }
        }

        private void SetAsDefault_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Logger.Log("SetAsDefault: Re-registering to ensure all keys are intact");
                RegistryHelper.RegisterAsDefaultBrowser();

                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = $"ms-settings:defaultapps?registeredAppUser={BrandConfig.RegistryAppId}",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                Logger.Log($"SetAsDefault_Click ERROR: {ex.Message}");
            }
        }

        private void LoadBrowserStats()
        {
            try
            {
                var rules = UrlRuleManager.LoadRules();
                var groups = UrlGroupManager.LoadGroups();
                var browsers = BrowserDetector.GetInstalledBrowsers();

                RulesCountText.Text = rules.Count.ToString();
                GroupsCountText.Text = groups.Count.ToString();

                int activeRules = rules.Count(r => r.IsEnabled);
                int activeGroups = groups.Count(g => g.IsEnabled);
                ActiveCountText.Text = (activeRules + activeGroups).ToString();

                BrowsersCountText.Text = browsers.Count.ToString();
            }
            catch (Exception ex)
            {
                Logger.Log($"HomePage.LoadBrowserStats ERROR: {ex.Message}");
            }
        }

        private void LoadClipStats()
        {
            try
            {
                var entries = PowerClipService.Instance.GetEntries();

                ClipTotalText.Text = entries.Count.ToString();
                ClipTextCount.Text = entries.Count(e => e.Type == ClipboardEntryType.Text || e.Type == ClipboardEntryType.FilePath).ToString();
                ClipUrlCount.Text = entries.Count(e => e.Type == ClipboardEntryType.Url).ToString();
                ClipImageCount.Text = entries.Count(e => e.Type == ClipboardEntryType.Image).ToString();
                ClipPinnedCount.Text = entries.Count(e => e.IsPinned).ToString();
            }
            catch (Exception ex)
            {
                Logger.Log($"HomePage.LoadClipStats ERROR: {ex.Message}");
            }
        }

        private void ManageRules_Click(object sender, RoutedEventArgs e)
        {
            NavigateToRulesRequested?.Invoke(this, EventArgs.Empty);
        }

        private void TestAllRules_Click(object sender, RoutedEventArgs e)
        {
            TestAllRulesRequested?.Invoke(this, EventArgs.Empty);
        }

        private void ClipboardHistory_Click(object sender, RoutedEventArgs e)
        {
            NavigateToClipboardRequested?.Invoke(this, EventArgs.Empty);
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            NavigateToSettingsRequested?.Invoke(this, EventArgs.Empty);
        }
    }
}
