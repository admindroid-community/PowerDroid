using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using Microsoft.Win32;

namespace PowerDroid
{
    public enum AppTheme
    {
        System,
        Light,
        Dark
    }

    public static class ThemeManager
    {
        public static event EventHandler? ThemeChanged;
        public static AppTheme CurrentTheme { get; private set; } = AppTheme.System;
        public static bool IsDarkTheme { get; private set; }

        public static void Initialize()
        {
            var settings = SettingsManager.LoadSettings();
            var theme = Enum.TryParse<AppTheme>(settings.Theme, true, out var t) ? t : AppTheme.System;
            ApplyTheme(theme);
            SystemEvents.UserPreferenceChanged += OnSystemPreferenceChanged;
        }

        public static void ApplyTheme(AppTheme theme)
        {
            CurrentTheme = theme;
            bool dark = theme == AppTheme.Dark ||
                        (theme == AppTheme.System && !NotificationHelper.IsSystemLightTheme());
            IsDarkTheme = dark;

            var colorsUri = dark
                ? new Uri("/PowerDroid;component/Themes/DarkColors.xaml", UriKind.Relative)
                : new Uri("/PowerDroid;component/Themes/LightColors.xaml", UriKind.Relative);

            var newColors = new ResourceDictionary { Source = colorsUri };

            // Swap ONLY the colors dictionary (index 0). The styles dictionary
            // (Windows11Theme.xaml, index 1) references every theme color via DynamicResource,
            // so it updates live — including controls in an active hover/pressed state — without
            // re-parsing the large styles file. This is what makes theme switching instant.
            var dictionaries = Application.Current.Resources.MergedDictionaries;
            if (dictionaries.Count >= 1)
            {
                dictionaries[0] = newColors;
            }
            else
            {
                dictionaries.Add(newColors);
            }

            Logger.Log($"Theme applied: {theme} (Dark={dark})");
            ThemeChanged?.Invoke(null, EventArgs.Empty);
        }

        private static void OnSystemPreferenceChanged(object sender, UserPreferenceChangedEventArgs e)
        {
            if (e.Category == UserPreferenceCategory.General && CurrentTheme == AppTheme.System)
            {
                Application.Current.Dispatcher.Invoke(() => ApplyTheme(AppTheme.System));
            }
        }

        public static void Cleanup()
        {
            SystemEvents.UserPreferenceChanged -= OnSystemPreferenceChanged;
        }

        #region Title Bar Dark Mode

        [DllImport("dwmapi.dll", PreserveSig = true)]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

        private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;

        /// <summary>
        /// Sets the Windows title bar to match the current theme (dark/light).
        /// Call from SourceInitialized or after theme change.
        /// </summary>
        public static void ApplyTitleBarTheme(Window window)
        {
            if (PresentationSource.FromVisual(window) is HwndSource source)
            {
                int useDark = IsDarkTheme ? 1 : 0;
                DwmSetWindowAttribute(source.Handle, DWMWA_USE_IMMERSIVE_DARK_MODE, ref useDark, sizeof(int));
            }
        }

        #endregion
    }
}
