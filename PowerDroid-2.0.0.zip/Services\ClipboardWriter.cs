using System;
using System.Windows;
using PowerDroid.Models;

namespace PowerDroid.Services
{
    /// <summary>
    /// Centralizes writing a Power Clip text entry back to the Windows clipboard so every
    /// copy-back path (history Copy, compact-window Copy, Enter-to-paste) behaves identically.
    /// </summary>
    public static class ClipboardWriter
    {
        /// <summary>
        /// Restores a text entry to the clipboard. When the entry carries a captured CF_HTML blob
        /// (e.g. a hyperlink), both the rich HTML and plain text are placed on the clipboard so
        /// HTML-aware targets (Word, Outlook, browsers) get the hyperlink and plain targets get the
        /// text — mirroring the native clipboard. Falls back to plain text on any failure.
        ///
        /// The HTML is restored verbatim: the CF_HTML byte-offset header is never recomputed, so it
        /// stays internally consistent. Callers must SuppressNextCapture() before calling this.
        /// </summary>
        public static void SetTextEntry(ClipboardEntry entry)
        {
            if (entry == null)
                return;

            if (!string.IsNullOrEmpty(entry.RichHtml))
            {
                try
                {
                    var data = new DataObject();
                    data.SetText(entry.Content);                 // plain-text fallback (CF_UNICODETEXT)
                    data.SetData(DataFormats.Html, entry.RichHtml); // verbatim CF_HTML
                    Clipboard.SetDataObject(data, true);          // copy=true so it survives app exit
                    return;
                }
                catch (Exception ex)
                {
                    Logger.Log($"ClipboardWriter: rich HTML copy failed, falling back to plain text: {ex.Message}");
                }
            }

            Clipboard.SetText(entry.Content);
        }
    }
}
