using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace PowerDroid.Behaviors
{
    /// <summary>
    /// App-wide fix for precision-trackpad over-scrolling.
    ///
    /// WPF's <see cref="ScrollViewer"/> scrolls a fixed amount (SystemParameters.WheelScrollLines,
    /// ~3 lines) once per wheel event, ignoring the event's delta magnitude. A mouse sends one
    /// 120-delta event per notch; a Precision Touchpad sends a rapid burst of small-delta events per
    /// swipe, so WPF treats each as a full notch and scrolling runs away.
    ///
    /// This registers a single class handler on <see cref="ScrollViewer"/> that replaces the fixed
    /// step with a scroll amount proportional to the actual wheel delta. A normal mouse notch behaves
    /// exactly as before; small trackpad deltas produce small, smooth movements.
    /// </summary>
    public static class SmoothWheelScroll
    {
        // Pixels scrolled per full mouse notch (delta 120), scaled by the OS wheel-lines setting.
        // ~48px for the default 3 lines — matches WPF's normal mouse behavior. Single speed knob.
        private const double PixelsPerLine = 16.0;

        // Per-ScrollViewer leftover fraction for logical (item) scrollers, so small trackpad deltas
        // accumulate into whole-item scrolls instead of rounding to zero.
        private static readonly ConditionalWeakTable<ScrollViewer, StrongBox<double>> _itemAccum = new();

        /// <summary>
        /// Installs the proportional wheel handler for every <see cref="ScrollViewer"/> in the app.
        /// Call once at startup, before any window is shown.
        /// </summary>
        public static void Register()
        {
            EventManager.RegisterClassHandler(
                typeof(ScrollViewer),
                UIElement.PreviewMouseWheelEvent,
                new MouseWheelEventHandler(OnPreviewMouseWheel));
        }

        private static void OnPreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Handled || e.Delta == 0) return;
            if (sender is not ScrollViewer sv) return;

            // PreviewMouseWheel tunnels outer→inner, so every ScrollViewer ancestor sees the event.
            // Only the one nearest the pointer should react, so nested scroll areas (ComboBox
            // dropdowns, popups) keep working; others let the tunnel continue inward.
            if (NearestScrollViewer(e.OriginalSource as DependencyObject) != sv) return;

            // Nothing to scroll vertically — let it bubble (e.g. to an outer scroller).
            if (sv.ScrollableHeight <= 0) return;

            int lines = SystemParameters.WheelScrollLines;
            if (lines < 0) lines = 3; // -1 means "one page"; treat as the default 3 lines

            if (IsPixelScrolling(sv))
            {
                // Pixel offset — physical scrollers (StackPanel pages) and virtualized lists with
                // ScrollUnit=Pixel. Scroll proportional pixels.
                double pxPerNotch = lines * PixelsPerLine;
                sv.ScrollToVerticalOffset(sv.VerticalOffset - (e.Delta / 120.0) * pxPerNotch);
            }
            else
            {
                // Item offset — e.g. a ComboBox dropdown (ScrollUnit=Item). VerticalOffset is in
                // items, so scroll a proportional number of items, accumulating fractional trackpad
                // deltas until a whole item is reached (otherwise small deltas round to zero).
                var acc = _itemAccum.GetOrCreateValue(sv);
                acc.Value += (e.Delta / 120.0) * lines;
                int whole = (int)acc.Value;
                if (whole != 0)
                {
                    acc.Value -= whole;
                    sv.ScrollToVerticalOffset(sv.VerticalOffset - whole);
                }
            }
            e.Handled = true;
        }

        // Whether the ScrollViewer's VerticalOffset is measured in pixels (vs. items).
        //  - CanContentScroll=false → physical/pixel (e.g. a ScrollViewer wrapping a StackPanel).
        //  - CanContentScroll=true  → item-hosting; pixel vs. item depends on the owning
        //    ItemsControl's VirtualizingPanel.ScrollUnit (ListView sets Pixel; ComboBox = Item).
        private static bool IsPixelScrolling(ScrollViewer sv)
        {
            if (!sv.CanContentScroll) return true;
            return sv.TemplatedParent is DependencyObject owner
                && VirtualizingPanel.GetScrollUnit(owner) == ScrollUnit.Pixel;
        }

        // Walks up the visual tree to the closest ScrollViewer ancestor of the hovered element.
        private static ScrollViewer? NearestScrollViewer(DependencyObject? from)
        {
            while (from != null)
            {
                if (from is ScrollViewer sv) return sv;
                from = VisualTreeHelper.GetParent(from);
            }
            return null;
        }
    }
}
