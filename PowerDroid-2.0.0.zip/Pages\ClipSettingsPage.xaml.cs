using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid.Pages
{
    public partial class ClipSettingsPage : UserControl
    {
        private bool _isLoading;

        public ClipSettingsPage()
        {
            InitializeComponent();
            Loaded += ClipSettingsPage_Loaded;
            Unloaded += ClipSettingsPage_Unloaded;
        }

        private void ClipSettingsPage_Loaded(object sender, RoutedEventArgs e)
        {
            // Refresh the monitoring banner immediately when monitoring state changes,
            // from any source (tray, History page button, etc.).
            TrayIconService.Instance.StateChanged += OnMonitoringStateChanged;
            LoadData();
        }

        private void ClipSettingsPage_Unloaded(object sender, RoutedEventArgs e)
        {
            TrayIconService.Instance.StateChanged -= OnMonitoringStateChanged;
        }

        private void OnMonitoringStateChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(WarningBanner.Refresh);
        }

        public void LoadData()
        {
            _isLoading = true;
            try
            {
                var settings = PowerClipService.Instance.GetSettings();

                // Power Clip master enable toggle
                PowerClipEnabledToggle.Checked -= PowerClipEnabled_Changed;
                PowerClipEnabledToggle.Unchecked -= PowerClipEnabled_Changed;
                PowerClipEnabledToggle.IsChecked = settings.IsEnabled;
                PowerClipEnabledToggle.Checked += PowerClipEnabled_Changed;
                PowerClipEnabledToggle.Unchecked += PowerClipEnabled_Changed;
                ClipDependentPanel.IsEnabled = settings.IsEnabled;

                // Max Entries combo
                MaxEntriesCombo.SelectionChanged -= MaxEntriesCombo_SelectionChanged;
                SelectComboByTag(MaxEntriesCombo, settings.MaxEntries.ToString());
                MaxEntriesCombo.SelectionChanged += MaxEntriesCombo_SelectionChanged;

                // Capture type checkboxes
                CaptureUrlsCheckBox.Checked -= CaptureType_Changed;
                CaptureUrlsCheckBox.Unchecked -= CaptureType_Changed;
                CaptureTextCheckBox.Checked -= CaptureType_Changed;
                CaptureTextCheckBox.Unchecked -= CaptureType_Changed;
                CaptureFilePathsCheckBox.Checked -= CaptureType_Changed;
                CaptureFilePathsCheckBox.Unchecked -= CaptureType_Changed;
                CaptureImagesCheckBox.Checked -= CaptureType_Changed;
                CaptureImagesCheckBox.Unchecked -= CaptureType_Changed;

                CaptureUrlsCheckBox.IsChecked = settings.CaptureUrls;
                CaptureTextCheckBox.IsChecked = settings.CaptureText;
                CaptureFilePathsCheckBox.IsChecked = settings.CaptureFilePaths;
                CaptureImagesCheckBox.IsChecked = settings.CaptureImages;

                CaptureUrlsCheckBox.Checked += CaptureType_Changed;
                CaptureUrlsCheckBox.Unchecked += CaptureType_Changed;
                CaptureTextCheckBox.Checked += CaptureType_Changed;
                CaptureTextCheckBox.Unchecked += CaptureType_Changed;
                CaptureFilePathsCheckBox.Checked += CaptureType_Changed;
                CaptureFilePathsCheckBox.Unchecked += CaptureType_Changed;
                CaptureImagesCheckBox.Checked += CaptureType_Changed;
                CaptureImagesCheckBox.Unchecked += CaptureType_Changed;

                LoadImageStorage();
            }
            catch (Exception ex)
            {
                Logger.Log($"ClipSettingsPage.LoadData ERROR: {ex.Message}");
            }
            finally
            {
                _isLoading = false;
            }
        }

        /// <summary>
        /// Populates the image storage meter and enables the "Free space" button
        /// only when there are unpinned images that can be cleared.
        /// </summary>
        private void LoadImageStorage()
        {
            long maxMB = PowerClipService.Instance.GetSettings().MaxImageStorageMB;
            var status = PowerClipService.Instance.GetImageStorageStatus();

            ImageStorageText.Text = status.DiskLimited
                ? $"{status.UsedMB:F1} MB used of {status.EffectiveCapMB:F0} MB (disk limited)"
                : $"{status.UsedMB:F1} MB used of {maxMB} MB";

            StorageProgressBar.Width = status.Ratio * 120;

            if (status.Ratio > 0.8)
                StorageProgressBar.SetResourceReference(Border.BackgroundProperty, "CriticalBrush");
            else if (status.Ratio > 0.5)
                StorageProgressBar.SetResourceReference(Border.BackgroundProperty, "CautionBrush");
            else
                StorageProgressBar.SetResourceReference(Border.BackgroundProperty, "AccentBrush");

            WarningBanner.Refresh();
            ClearImagesButton.IsEnabled = status.ClearableImageCount > 0;
        }

        // The shared warning banner ran an action (enable/resume monitoring or free up
        // storage); reload so the meter and state reflect it.
        private void WarningBanner_Changed(object? sender, EventArgs e) => LoadData();

        private void ClearImages_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var confirmed = ConfirmationDialog.Show(
                    Window.GetWindow(this),
                    "Free Image Storage",
                    "This will permanently delete all clipboard images to free disk space.\nPinned images will be kept.",
                    "Clear images", "Cancel");

                if (!confirmed) return;

                PowerClipService.Instance.ClearAllImagesUnpinned();
                LoadData();
            }
            catch (Exception ex)
            {
                Logger.Log($"ClipSettingsPage.ClearImages_Click ERROR: {ex.Message}");
            }
        }

        private void SelectComboByTag(ComboBox comboBox, string tagValue)
        {
            for (int i = 0; i < comboBox.Items.Count; i++)
            {
                if (comboBox.Items[i] is ComboBoxItem item &&
                    item.Tag is string tag &&
                    tag == tagValue)
                {
                    comboBox.SelectedIndex = i;
                    return;
                }
            }
        }

        private void MaxEntriesCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isLoading) return;
            try
            {
                if (MaxEntriesCombo.SelectedItem is ComboBoxItem item &&
                    item.Tag is string tag && int.TryParse(tag, out int maxEntries))
                {
                    var currentSettings = PowerClipService.Instance.GetSettings();
                    var currentCount = PowerClipService.Instance.GetEntries().Count;

                    // If reducing below current count, confirm
                    if (maxEntries < currentCount)
                    {
                        var toRemove = currentCount - maxEntries;
                        var confirmed = ConfirmationDialog.Show(
                            Window.GetWindow(this),
                            "Change Max Entries",
                            $"Reducing to {maxEntries} will remove {toRemove} oldest entries.\nPinned entries will be kept.",
                            "Change & Clear", "Cancel");

                        if (!confirmed)
                        {
                            MaxEntriesCombo.SelectionChanged -= MaxEntriesCombo_SelectionChanged;
                            SelectComboByTag(MaxEntriesCombo, currentSettings.MaxEntries.ToString());
                            MaxEntriesCombo.SelectionChanged += MaxEntriesCombo_SelectionChanged;
                            return;
                        }
                    }

                    currentSettings.MaxEntries = maxEntries;
                    PowerClipService.Instance.SaveSettings(currentSettings);
                    Logger.Log($"Clip max entries set to: {maxEntries}");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"MaxEntriesCombo_SelectionChanged ERROR: {ex.Message}");
            }
        }

        private void CaptureType_Changed(object sender, RoutedEventArgs e)
        {
            if (_isLoading) return;
            try
            {
                var settings = PowerClipService.Instance.GetSettings();
                settings.CaptureUrls = CaptureUrlsCheckBox.IsChecked == true;
                settings.CaptureText = CaptureTextCheckBox.IsChecked == true;
                settings.CaptureFilePaths = CaptureFilePathsCheckBox.IsChecked == true;
                settings.CaptureImages = CaptureImagesCheckBox.IsChecked == true;
                PowerClipService.Instance.SaveSettings(settings);
                Logger.Log($"Capture types updated — URLs:{settings.CaptureUrls}, Text:{settings.CaptureText}, FilePaths:{settings.CaptureFilePaths}, Images:{settings.CaptureImages}");
            }
            catch (Exception ex)
            {
                Logger.Log($"CaptureType_Changed ERROR: {ex.Message}");
            }
        }

        private void PowerClipEnabled_Changed(object sender, RoutedEventArgs e)
        {
            if (_isLoading) return;
            try
            {
                var settings = PowerClipService.Instance.GetSettings();
                settings.IsEnabled = PowerClipEnabledToggle.IsChecked == true;
                PowerClipService.Instance.SaveSettings(settings);

                // Grey out the dependent settings when off; refresh the banner and the nav
                // warning icon on the POWER CLIP header.
                ClipDependentPanel.IsEnabled = settings.IsEnabled;
                WarningBanner.Refresh();
                (Window.GetWindow(this) as SettingsWindow)?.UpdateNavigationStatus();
                Logger.Log($"Power Clip enabled set to {settings.IsEnabled}");
            }
            catch (Exception ex)
            {
                Logger.Log($"PowerClipEnabled_Changed ERROR: {ex.Message}");
            }
        }

    }
}
