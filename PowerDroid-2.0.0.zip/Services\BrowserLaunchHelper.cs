using System;

namespace PowerDroid.Services
{
    /// <summary>
    /// Helpers for launching browsers in special modes (e.g. incognito / private).
    /// The private-mode flag differs per browser family, so it lives in one place here.
    /// </summary>
    public static class BrowserLaunchHelper
    {
        /// <summary>
        /// Returns the command-line flag that opens a private/incognito window for the given
        /// browser, or null if the browser family has no known flag (caller should hide the action).
        /// </summary>
        /// <param name="browserName">Display name (used to disambiguate Opera, which is typed "Chrome").</param>
        /// <param name="browserType">Detected type ("Chrome", "Edge", "Firefox", "Other").</param>
        public static string? GetIncognitoArg(string? browserName, string? browserType)
        {
            var name = browserName ?? string.Empty;
            var type = browserType ?? string.Empty;

            // Opera (Chromium-based but typed "Chrome") uses --private, not --incognito.
            if (name.IndexOf("Opera", StringComparison.OrdinalIgnoreCase) >= 0)
                return "--private";

            switch (type)
            {
                case "Edge":
                    return "--inprivate";
                case "Firefox":
                    return "-private-window";
                case "Chrome":
                    return "--incognito";
                default:
                    // Unknown family ("Other") — no reliable private flag.
                    return null;
            }
        }

        /// <summary>
        /// Single source of truth for launching a browser profile. Builds the command line from
        /// the profile arguments, an optional private/incognito flag, and an optional URL, then
        /// launches and focuses. Used by the compact launcher, rule processing, and the picker.
        /// </summary>
        public static void Launch(string exePath, string? browserName, string? browserType,
                                  string? profileArguments, string? url, bool incognito)
        {
            var args = profileArguments ?? string.Empty;

            if (incognito)
            {
                var inc = GetIncognitoArg(browserName, browserType);
                if (!string.IsNullOrEmpty(inc))
                    args = (args + " " + inc).Trim();
            }

            if (!string.IsNullOrEmpty(url))
            {
                // Security: only ever hand a real http/https URL to the browser. A value like
                // "--gpu-launcher=..." is interpreted by Chromium/Firefox as a command-line
                // *switch* even when quoted, so quoting alone is not enough — validate the scheme
                // here (same gate the shell-open fallback paths use) and refuse anything else.
                if (!App.IsValidBrowseUrl(url))
                {
                    Logger.Log($"BrowserLaunchHelper: refusing to launch — URL failed validation: {Logger.SanitizeUrl(url)}");
                    return;
                }

                var safeUrl = App.SanitizeUrlForArgument(url);
                args = (args + " \"" + safeUrl + "\"").Trim();
            }

            BrowserFocusHelper.LaunchAndFocus(exePath, args);
        }
    }
}
