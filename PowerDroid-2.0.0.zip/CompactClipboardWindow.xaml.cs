using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using PowerDroid.Models;
using PowerDroid.Services;

namespace PowerDroid
{
    /// <summary>Which tab the compact popup shows.</summary>
    public enum CompactTab { Browsers, Clipboard }

    /// <summary>
    /// Compact floating popup (like Win+V) with two tabs:
    /// Browsers (launch a profile) and Clipboard (paste history).
    /// </summary>
    public partial class CompactClipboardWindow : Window
    {
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [DllImport("user32.dll")]
        private static extern IntPtr SetWindowsHookEx(int idHook, Delegate callback, IntPtr hInstance, uint threadId);

        [DllImport("user32.dll")]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool GetCursorPos(out POINT lpPoint);

        // Search routing: translate a hook-captured key to the character it would type.
        [DllImport("user32.dll")]
        private static extern bool GetKeyboardState(byte[] lpKeyState);

        [DllImport("user32.dll")]
        private static extern IntPtr GetKeyboardLayout(uint idThread);

        [DllImport("user32.dll")]
        private static extern int ToUnicodeEx(uint wVirtKey, uint wScanCode, byte[] lpKeyState,
            [Out] System.Text.StringBuilder pwszBuff, int cchBuff, uint wFlags, IntPtr dwhkl);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        [DllImport("user32.dll")]
        private static extern short GetKeyState(int nVirtKey);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("kernel32.dll")]
        private static extern uint GetCurrentThreadId();

        [DllImport("user32.dll")]
        private static extern int GetMessage(out MSG lpMsg, IntPtr hWnd, uint min, uint max);

        [DllImport("user32.dll")]
        private static extern bool TranslateMessage(ref MSG lpMsg);

        [DllImport("user32.dll")]
        private static extern IntPtr DispatchMessage(ref MSG lpMsg);

        [DllImport("user32.dll")]
        private static extern bool PostThreadMessage(uint idThread, uint Msg, IntPtr wParam, IntPtr lParam);

        private const uint WM_QUIT = 0x0012;

        [StructLayout(LayoutKind.Sequential)]
        private struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam, lParam; public uint time; public POINT pt; }

        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        private const uint SWP_NOSIZE = 0x0001;
        private const uint SWP_NOZORDER = 0x0004;

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT { public int left, top, right, bottom; }

        private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);
        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int WH_MOUSE_LL = 14;
        private const int WH_KEYBOARD_LL = 13;
        private const int WM_LBUTTONDOWN = 0x0201;
        private const int WM_RBUTTONDOWN = 0x0204;
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_SYSKEYDOWN = 0x0104;
        private const int WM_KEYUP = 0x0101;
        private const int WM_SYSKEYUP = 0x0105;
        private const int VK_LSHIFT = 0xA0;
        private const int VK_RSHIFT = 0xA1;
        private const int VK_RETURN = 0x0D;
        private const int VK_ESCAPE = 0x1B;
        private const int VK_UP = 0x26;
        private const int VK_DOWN = 0x28;
        private const int VK_SPACE = 0x20;
        private const byte VK_SHIFT = 0x10;
        private const byte VK_CONTROL = 0x11;
        private const int VK_MENU = 0x12;   // Alt (used only to exclude Alt-combos from search capture)
        private const int VK_BACK = 0x08;
        private const int VK_CAPITAL = 0x14;
        private const int VK_LWIN = 0x5B;
        private const int VK_RWIN = 0x5C;

        // Cache of decoded 48px row thumbnails (frozen for reuse across popup instances), keyed by
        // file path — so re-rendering the list (every open / search keystroke) never re-decodes
        // the same image from disk. Bounded to avoid unbounded growth.
        private static readonly Dictionary<string, System.Windows.Media.ImageSource> _thumbCache = new();

        // Clipboard-tab search string, built from keys captured by the low-level hook (the popup is
        // non-activating, so the search TextBox never has focus). Mutated only on the UI thread.
        private readonly System.Text.StringBuilder _searchText = new();
        // True while the current tab is shown non-activating (Clipboard). Paste skips focus-restore
        // in this mode because the target app never lost focus.
        private bool _nonActivating;

        private readonly IntPtr _previousWindow;
        private List<ClipboardEntry> _allEntries = new();
        private bool _isPasting;
        private IntPtr _mouseHook;
        private LowLevelMouseProc? _mouseProc;
        private IntPtr _keyboardHook;
        private LowLevelKeyboardProc? _keyboardProc;
        private System.Threading.Thread? _hookThread;
        private uint _hookThreadId;
        // Gates the keyboard hook from the dedicated hook thread (IsVisible is UI-thread only).
        private volatile bool _keyboardNavEnabled;

        // Keyboard navigation state (Clipboard tab)
        private readonly List<(Border Border, ClipboardEntry Entry)> _navItems = new();
        private int _selectedIndex = -1;

        // Multi-select state (Clipboard tab). _selectedIndex is the caret; _selectedIndices is the
        // full selection (indices into _navItems), built via Shift+Click / Shift+Space.
        private readonly HashSet<int> _selectedIndices = new();
        // True while the user is actively building a multi-selection (entered by holding Shift and
        // toggling a row). It resets to false when the window closes, a paste completes, or the
        // selection becomes empty.
        private bool _multiSelectMode;
        // True while the selection is still the implicit auto-default (first row, untouched). Only
        // this default is wiped when Shift is pressed; a real selection the user built (index
        // changed via toggle or arrow) is preserved so they can keep adding to it.
        private bool _defaultSelection;
        private const int MaxPasteSelection = 5;
        // Interval between sequential pastes — a touch higher than the single-paste 100ms to give
        // slow targets margin to read the clipboard before the next item overwrites it (Risk 1).
        private const int MultiPasteIntervalMs = 150;

        // Drag support
        private bool _isDragging;

        // Active tab
        private CompactTab _currentTab = CompactTab.Clipboard;

        // Hover popup
        private System.Windows.Controls.Primitives.Popup? _hoverPopup;
        private System.Windows.Threading.DispatcherTimer? _hoverTimer;
        private Border? _hoveredBorder;
        private ClipboardEntry? _hoveredEntry;
        private bool _isMouseOverPopup;
        private bool _popupActivatable = true;

        public CompactClipboardWindow() : this(CompactTab.Clipboard) { }

        public CompactClipboardWindow(CompactTab initialTab)
        {
            // Capture the foreground window BEFORE our window appears
            _previousWindow = GetForegroundWindow();

            InitializeComponent();

            _currentTab = initialTab;

            // When Power Clip is turned off there's no clipboard history to show, so the compact
            // window is browsers-only: hide the Clipboard tab and never open on it (Alt+B still
            // opens the Browsers launcher normally).
            if (!PowerClipService.Instance.IsEnabled)
            {
                ClipboardTabButton.Visibility = Visibility.Collapsed;
                if (_currentTab == CompactTab.Clipboard)
                    _currentTab = CompactTab.Browsers;
            }

            Loaded += OnLoaded;
            SourceInitialized += OnSourceInitialized;
            PreviewKeyDown += OnKeyDown;
            Closing += (s, e) => CloseCleanup();

            // Subscribe to history changes
            PowerClipService.Instance.HistoryChanged += OnHistoryChanged;

            // Launching a profile from the Browsers tab closes the popup.
            BrowserList.ProfileLaunched += (s, e) =>
            {
                CloseCleanup();
                Close();
            };

            // Keep the Expand/Collapse All label in sync with the list state.
            BrowserList.CollapseStateChanged += (s, e) => UpdateExpandCollapseLink();
        }

        private void OnSourceInitialized(object? sender, EventArgs e)
        {
            // The Clipboard popup is non-activating (WS_EX_NOACTIVATE), applied before the window is
            // first presented, so opening it never deactivates the target app — the editor keeps
            // focus and its caret, light-dismiss UIs (e.g. VS Code Ctrl+P) stay open, and a later
            // synthesized Ctrl+V lands where the user was typing. The search box is driven by the
            // keyboard hook instead of WPF focus (see KeyboardHookCallback), matching Win+V.
            if (_currentTab == CompactTab.Clipboard)
            {
                SetNoActivate(true);
                _nonActivating = true;
            }
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            // Position near cursor using Win32 — all in physical pixels, no DPI conversion needed
            var cursorPos = System.Windows.Forms.Cursor.Position;
            var screen = System.Windows.Forms.Screen.FromPoint(cursorPos);
            var workArea = screen.WorkingArea;

            // Get physical window size
            var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            GetWindowRect(hwnd, out RECT currentRect);
            int winWidth = currentRect.right - currentRect.left;
            int winHeight = currentRect.bottom - currentRect.top;

            int x = Math.Min(cursorPos.X, workArea.Right - winWidth - 10);
            int y = Math.Min(cursorPos.Y, workArea.Bottom - winHeight - 10);
            if (x < workArea.Left) x = workArea.Left + 10;
            if (y < workArea.Top) y = workArea.Top + 10;

            SetWindowPos(hwnd, IntPtr.Zero, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

            ShowTab(_currentTab);

            // Install global mouse hook to detect clicks outside
            _mouseProc = MouseHookCallback;
            _mouseHook = SetWindowsHookEx(WH_MOUSE_LL, _mouseProc, IntPtr.Zero, 0);

            // Run the global keyboard hook on a dedicated thread with its own message pump, so the
            // Up/Down/Enter/Escape callback is serviced even when the UI thread is busy (otherwise
            // Windows times the low-level hook out and the key leaks to the target — e.g. Enter
            // intermittently failing to paste). Actual handling is marshaled back to the UI thread.
            _hookThread = new System.Threading.Thread(KeyboardHookThreadProc)
            {
                IsBackground = true,
                Name = "PowerClipKbHook"
            };
            _hookThread.Start();
        }

        private void KeyboardHookThreadProc()
        {
            _hookThreadId = GetCurrentThreadId();
            _keyboardProc = KeyboardHookCallback;
            _keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, _keyboardProc, IntPtr.Zero, 0);

            // Pump messages so the low-level hook callback runs on this thread. Exits on WM_QUIT,
            // posted by CloseCleanup.
            while (GetMessage(out MSG msg, IntPtr.Zero, 0, 0) > 0)
            {
                TranslateMessage(ref msg);
                DispatchMessage(ref msg);
            }

            if (_keyboardHook != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_keyboardHook);
                _keyboardHook = IntPtr.Zero;
            }
        }


        [StructLayout(LayoutKind.Sequential)]
        private struct POINT { public int x, y; }

        [StructLayout(LayoutKind.Sequential)]
        private struct MSLLHOOKSTRUCT { public POINT pt; public uint mouseData, flags, time; public IntPtr dwExtraInfo; }

        private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && !_isPasting && !_isDragging &&
                (wParam == (IntPtr)WM_LBUTTONDOWN || wParam == (IntPtr)WM_RBUTTONDOWN))
            {
                // Use GetCursorPos — returns in the same DPI-virtualized coordinate system as GetWindowRect
                GetCursorPos(out POINT cursorPt);
                var clickPoint = new System.Windows.Point(cursorPt.x, cursorPt.y);

                bool insideWindow = false;
                bool insidePopup = false;
                try
                {
                    var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
                    if (hwnd != IntPtr.Zero && GetWindowRect(hwnd, out RECT wr))
                    {
                        insideWindow = clickPoint.X >= wr.left && clickPoint.X <= wr.right
                                    && clickPoint.Y >= wr.top && clickPoint.Y <= wr.bottom;
                    }
                }
                catch { }

                if (_hoverPopup?.Child is FrameworkElement popupChild && _hoverPopup.IsOpen)
                {
                    try
                    {
                        var popupSource = PresentationSource.FromVisual(popupChild) as System.Windows.Interop.HwndSource;
                        if (popupSource != null && GetWindowRect(popupSource.Handle, out RECT pr))
                        {
                            insidePopup = clickPoint.X >= pr.left && clickPoint.X <= pr.right
                                       && clickPoint.Y >= pr.top && clickPoint.Y <= pr.bottom;
                        }
                    }
                    catch { }
                }

                if (!insideWindow && !insidePopup)
                {
                    Dispatcher.BeginInvoke(() =>
                    {
                        CloseCleanup();
                        Close();
                    });
                }
            }
            return CallNextHookEx(_mouseHook, nCode, wParam, lParam);
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                CloseCleanup();
                Close();
            }
        }

        private IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            // Only intercept navigation keys on the (non-focusable) Clipboard tab while showing.
            // Do NOT swallow Alt: the target received the hotkey's Alt-down before this hook was
            // installed, so eating the Alt-up would strand the modifier and break all typing.
            // Runs on the dedicated hook thread, so gate on a volatile flag (not the UI-thread-only
            // IsVisible property) and marshal all handling to the UI thread.
            if (nCode >= 0 && _keyboardNavEnabled)
            {
                int msg = (int)wParam;
                bool isKeyDown = msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN;
                bool isKeyUp = msg == WM_KEYUP || msg == WM_SYSKEYUP;
                if (!isKeyDown && !isKeyUp)
                    return CallNextHookEx(_keyboardHook, nCode, wParam, lParam);

                int vkCode = Marshal.ReadInt32(lParam);

                // Clipboard tab: the physical Shift key arms/disarms multi-select. Holding Shift
                // clears the current selection and starts a fresh multi-select; releasing it with
                // nothing picked restores the default first row. Never swallow Shift — it must still
                // produce capitals for type-to-search.
                if (_currentTab != CompactTab.Browsers &&
                    (vkCode == VK_SHIFT || vkCode == VK_LSHIFT || vkCode == VK_RSHIFT))
                {
                    if (isKeyDown)
                        Dispatcher.BeginInvoke(ArmMultiSelect);
                    else
                        Dispatcher.BeginInvoke(DisarmMultiSelect);
                    return CallNextHookEx(_keyboardHook, nCode, wParam, lParam);
                }

                // All remaining handling is on key-down only.
                if (!isKeyDown)
                    return CallNextHookEx(_keyboardHook, nCode, wParam, lParam);

                if (_currentTab == CompactTab.Browsers)
                {
                    // Route Up/Down/Enter/Escape to the focusable BrowserList. Swallowing here means
                    // nav works even if the window couldn't take focus.
                    switch (vkCode)
                    {
                        case VK_DOWN:
                            Dispatcher.BeginInvoke(() => BrowserList.SelectNext());
                            return (IntPtr)1;
                        case VK_UP:
                            Dispatcher.BeginInvoke(() => BrowserList.SelectPrevious());
                            return (IntPtr)1;
                        case VK_RETURN:
                            Dispatcher.BeginInvoke(() =>
                            {
                                bool incognito = (Keyboard.Modifiers & (ModifierKeys.Control | ModifierKeys.Shift)) != 0;
                                BrowserList.LaunchSelected(incognito);
                            });
                            return (IntPtr)1;
                        case VK_ESCAPE:
                            Dispatcher.BeginInvoke(() =>
                            {
                                CloseCleanup();
                                Close();
                            });
                            return (IntPtr)1;
                    }

                    // Type-to-filter. When launched from a global hotkey the window frequently can't
                    // take real keyboard focus (Windows foreground rules), so the search TextBox never
                    // receives keystrokes and typing appears to do nothing (or leaks to the previous
                    // app). Capture printable keys / Backspace here and drive the filter directly,
                    // exactly like the Clipboard tab. Let real shortcuts through (Ctrl/Alt/Win held).
                    bool browserModifierHeld =
                        (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0 ||
                        (GetAsyncKeyState(VK_MENU) & 0x8000) != 0 ||
                        (GetAsyncKeyState(VK_LWIN) & 0x8000) != 0 ||
                        (GetAsyncKeyState(VK_RWIN) & 0x8000) != 0;
                    if (!browserModifierHeld)
                    {
                        if (vkCode == VK_BACK)
                        {
                            Dispatcher.BeginInvoke(() => BrowserList.BackspaceFilter());
                            return (IntPtr)1;
                        }

                        int browserScanCode = Marshal.ReadInt32(lParam, 4);
                        if (TryTranslateToChar((uint)vkCode, (uint)browserScanCode, out char browserCh))
                        {
                            char captured = browserCh;
                            Dispatcher.BeginInvoke(() => BrowserList.AppendToFilter(captured));
                            return (IntPtr)1;
                        }
                    }
                }
                else
                {
                    // Capture modifier state on the hook thread (UI-thread Keyboard.Modifiers is
                    // unreliable here — the popup is non-activating and never has keyboard focus).
                    bool shiftHeld = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;

                    switch (vkCode)
                    {
                    case VK_DOWN:
                        Dispatcher.BeginInvoke(() => MoveSelection(+1));
                        return (IntPtr)1;
                    case VK_UP:
                        Dispatcher.BeginInvoke(() => MoveSelection(-1));
                        return (IntPtr)1;
                    case VK_SPACE:
                        if (shiftHeld)
                        {
                            Dispatcher.BeginInvoke(() =>
                            {
                                if (_selectedIndex >= 0 && _selectedIndex < _navItems.Count)
                                    ToggleSelection(_selectedIndex);
                            });
                            return (IntPtr)1;
                        }
                        break; // plain Space falls through to search-text capture
                    case VK_RETURN:
                        Dispatcher.BeginInvoke(PasteSelected);
                        return (IntPtr)1;
                    case VK_ESCAPE:
                        Dispatcher.BeginInvoke(() =>
                        {
                            // First Escape collapses a multi-selection back to the caret; a second
                            // (or a single/empty selection) closes the popup.
                            if (_selectedIndices.Count > 1)
                                CollapseSelectionToCaret();
                            else
                            {
                                CloseCleanup();
                                Close();
                            }
                        });
                        return (IntPtr)1;
                    }

                    // Everything else feeds the search box. The window is non-activating, so the
                    // search TextBox never has focus — without this, keystrokes would leak into the
                    // target app (the "vbvbvbv" bug). Swallow them and drive the filter instead,
                    // Win+V-style. Let real shortcuts through: if Ctrl/Alt/Win is held, don't capture
                    // (Shift is allowed — needed for shifted symbols).
                    bool modifierHeld =
                        (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0 ||
                        (GetAsyncKeyState(VK_MENU) & 0x8000) != 0 ||
                        (GetAsyncKeyState(VK_LWIN) & 0x8000) != 0 ||
                        (GetAsyncKeyState(VK_RWIN) & 0x8000) != 0;
                    if (!modifierHeld)
                    {
                        if (vkCode == VK_BACK)
                        {
                            Dispatcher.BeginInvoke(() =>
                            {
                                if (_searchText.Length > 0)
                                    _searchText.Remove(_searchText.Length - 1, 1);
                                SetSearchText();
                            });
                            return (IntPtr)1;
                        }

                        int scanCode = Marshal.ReadInt32(lParam, 4);
                        if (TryTranslateToChar((uint)vkCode, (uint)scanCode, out char ch))
                        {
                            char captured = ch;
                            Dispatcher.BeginInvoke(() =>
                            {
                                _searchText.Append(captured);
                                SetSearchText();
                            });
                            return (IntPtr)1;
                        }
                    }
                }
            }
            return CallNextHookEx(_keyboardHook, nCode, wParam, lParam);
        }

        // Translate a hook-captured virtual key into the character it would type, using the live
        // Shift state and the foreground app's keyboard layout. Runs on the hook thread (locals
        // only). Returns false for non-printable keys; dead keys (rc &lt; 0) are flushed with a second
        // call so they don't corrupt the next accented character typed anywhere.
        // Push the hook-built search string into the box and keep the caret at the end (setting
        // .Text otherwise resets the caret to position 0, so it appeared to blink at the start).
        private void SetSearchText()
        {
            SearchBox.Text = _searchText.ToString();
            SearchBox.CaretIndex = SearchBox.Text.Length;
        }

        private static bool TryTranslateToChar(uint vk, uint scan, out char ch)
        {
            ch = '\0';
            var keyState = new byte[256];
            GetKeyboardState(keyState); // baseline; hook-thread modifier bits can be stale, so override:
            keyState[VK_SHIFT] = (byte)(((GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0) ? 0x80 : 0);
            keyState[VK_CONTROL] = 0;
            keyState[VK_MENU] = 0;
            if ((GetKeyState(VK_CAPITAL) & 1) != 0) keyState[VK_CAPITAL] |= 0x01;
            else keyState[VK_CAPITAL] &= 0xFE;

            var hkl = GetKeyboardLayout(GetWindowThreadProcessId(GetForegroundWindow(), out _));
            var sb = new System.Text.StringBuilder(8);
            int rc = ToUnicodeEx(vk, scan, keyState, sb, sb.Capacity, 0, hkl);
            if (rc < 0)
            {
                ToUnicodeEx(vk, scan, keyState, sb, sb.Capacity, 0, hkl); // flush stored dead key
                return false;
            }
            if (rc == 1 && !char.IsControl(sb[0]))
            {
                ch = sb[0];
                return true;
            }
            return false;
        }

        private void ApplySelectionHighlight(bool scroll = false)
        {
            for (int i = 0; i < _navItems.Count; i++)
            {
                var border = _navItems[i].Border;
                if (_selectedIndices.Contains(i))
                {
                    // Theme-aware soft outline marks each selected row. Use the border (not the
                    // background) so mouse hover repainting the background can't clear it.
                    border.SetResourceReference(Border.BorderBrushProperty, "SelectionOutlineBrush");
                }
                else
                {
                    // Transparent (not CardStroke) so only the selection shows and movement stays smooth.
                    border.BorderBrush = Brushes.Transparent;
                }
            }

            // Only scroll when the user actively navigates — never on render/tab-switch, which would
            // jump the list and reposition things under the cursor.
            if (scroll && _selectedIndex >= 0 && _selectedIndex < _navItems.Count)
                EntriesListView.ScrollIntoView(_navItems[_selectedIndex].Border);
        }

        // Move the caret by delta. Plain arrow navigation collapses to a single selection;
        // multi-select is Shift-driven (Shift+Click / Shift+Space).
        private void MoveSelection(int delta)
        {
            if (_navItems.Count == 0) return;
            _selectedIndex = Math.Clamp(_selectedIndex + delta, 0, _navItems.Count - 1);
            // Plain arrow navigation is single-select and a deliberate move: leave multi-select mode
            // and mark the selection as no longer the auto-default.
            _multiSelectMode = false;
            _defaultSelection = false;
            _selectedIndices.Clear();
            _selectedIndices.Add(_selectedIndex);
            ApplySelectionHighlight(scroll: true);
            ShowHoverForSelection();
            UpdatePasteAllButton();
        }

        // Shift pressed: enter multi-select mode. Only the untouched auto-default (first row) is
        // wiped so the user starts fresh; a real selection they already built is preserved so they
        // can keep adding. Guarded against key auto-repeat so it acts once per hold.
        private void ArmMultiSelect()
        {
            if (_currentTab == CompactTab.Browsers || _multiSelectMode) return;
            _multiSelectMode = true;
            if (_defaultSelection)
            {
                _selectedIndices.Clear();
                _defaultSelection = false;
            }
            ApplySelectionHighlight();
            UpdatePasteAllButton();
        }

        // Shift released: leave multi-select mode. If nothing was picked, restore the default first
        // row so Enter still pastes something; a real selection is kept for Paste all / Enter.
        private void DisarmMultiSelect()
        {
            if (!_multiSelectMode) return;
            _multiSelectMode = false;
            if (_selectedIndices.Count == 0 && _navItems.Count > 0)
            {
                _selectedIndex = 0;
                _selectedIndices.Add(0);
                _defaultSelection = true;
            }
            ApplySelectionHighlight();
            UpdatePasteAllButton();
        }

        // Shift-toggle a single row in/out of the selection (respects the cap). Multi-select mode is
        // armed by the physical Shift key (see ArmMultiSelect); this just adds/removes the row.
        private void ToggleSelection(int index)
        {
            if (index < 0 || index >= _navItems.Count) return;

            // A toggle is a deliberate selection: ensure we're in multi-select mode and no longer
            // the auto-default (so a later Shift press won't wipe it).
            _multiSelectMode = true;
            _defaultSelection = false;

            if (_selectedIndices.Contains(index))
            {
                _selectedIndices.Remove(index);
            }
            else if (_selectedIndices.Count >= MaxPasteSelection)
            {
                ShowLimitHint();
            }
            else
            {
                _selectedIndices.Add(index);
            }
            _selectedIndex = index;
            // An emptied selection while still holding Shift stays empty (the "unselected" state);
            // releasing Shift restores the default first row (see DisarmMultiSelect).

            ApplySelectionHighlight(scroll: true);
            ShowHoverForSelection();
            UpdatePasteAllButton();
        }

        private void CollapseSelectionToCaret()
        {
            _selectedIndices.Clear();
            if (_selectedIndex >= 0) _selectedIndices.Add(_selectedIndex);
            ApplySelectionHighlight();
            UpdatePasteAllButton();
        }

        // Selected entries in list order (top-to-bottom), snapshotted before any paste teardown.
        private List<ClipboardEntry> GetSelectedEntriesInOrder()
        {
            return _selectedIndices
                .Where(i => i >= 0 && i < _navItems.Count)
                .OrderBy(i => i)
                .Select(i => _navItems[i].Entry)
                .ToList();
        }

        // Paste the current selection (Enter / "Paste all"). Falls back to the caret row.
        private void PasteSelected()
        {
            var entries = GetSelectedEntriesInOrder();
            if (entries.Count == 0 && _selectedIndex >= 0 && _selectedIndex < _navItems.Count)
                entries.Add(_navItems[_selectedIndex].Entry);
            if (entries.Count > 0)
                PasteEntries(entries);
        }

        // Show the centered "Paste all (N)" button when more than one item is selected. The
        // left-aligned "Hold Shift to multi-select" hint stays put (managed per-tab in ShowTab).
        private void UpdatePasteAllButton()
        {
            bool multi = _selectedIndices.Count > 1;
            if (multi)
                PasteAllText.Text = $"Paste all ({_selectedIndices.Count})";
            PasteAllButton.Visibility = multi ? Visibility.Visible : Visibility.Collapsed;
        }

        // Show a toast when the user tries to exceed the multi-select cap.
        private void ShowLimitHint()
        {
            Services.ToastService.Show(this, $"You can select up to {MaxPasteSelection} items");
        }

        private void PasteAll_Click(object sender, MouseButtonEventArgs e)
        {
            PasteSelected();
        }

        // Row click: Shift toggles the row into the multi-selection; a plain click pastes just that
        // row immediately (unchanged single-item UX).
        private void OnRowClicked(ClipboardEntry entry)
        {
            int index = _navItems.FindIndex(n => ReferenceEquals(n.Entry, entry));
            if (index < 0) return;

            bool shift = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
            if (shift)
                ToggleSelection(index);
            else
                PasteEntry(entry);
        }

        // Open the hover-action popup (preview + Copy/Extract/etc.) for the keyboard-selected row,
        // mirroring mouse hover. Short delay so rapid arrowing doesn't spam popups.
        private void ShowHoverForSelection()
        {
            if (_selectedIndex < 0 || _selectedIndex >= _navItems.Count)
            {
                HidePopup();
                return;
            }
            var (border, entry) = _navItems[_selectedIndex];
            // Keep no-activate: keyboard users paste with Enter and never click popup buttons,
            // so the target app must stay active.
            StartHoverPopup(border, entry, 250, activatable: false);
        }

        private void OnHistoryChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(LoadEntries);
        }

        private void CloseCleanup()
        {
            // Window closing or a paste completing (PasteEntries calls this) exits multi-select mode.
            _multiSelectMode = false;
            _keyboardNavEnabled = false;
            HidePopup();
            PowerClipService.Instance.HistoryChanged -= OnHistoryChanged;
            if (_mouseHook != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_mouseHook);
                _mouseHook = IntPtr.Zero;
            }
            // Stop the hook thread's message loop; it unhooks the keyboard hook as it exits.
            if (_hookThreadId != 0)
            {
                PostThreadMessage(_hookThreadId, WM_QUIT, IntPtr.Zero, IntPtr.Zero);
                _hookThreadId = 0;
            }
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _isDragging = true;
            try
            {
                DragMove();
            }
            finally
            {
                _isDragging = false;
            }
        }

        private void MonitoringOffButton_Click(object sender, RoutedEventArgs e)
        {
            var settings = SettingsManager.LoadSettings();
            if (!settings.ClipboardMonitoring.IsEnabled)
            {
                settings.ClipboardMonitoring.IsEnabled = true;
                SettingsManager.SaveSettings(settings);
                Services.ClipboardMonitorService.Instance.Start();
                Services.TrayIconService.Instance.UpdateState();
            }
            else if (settings.ClipboardMonitoring.IsPaused)
            {
                Services.TrayIconService.Instance.Resume();
            }
            LoadEntries();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            CloseCleanup();
            Close();
        }

        #region Tabs

        /// <summary>The tab currently shown.</summary>
        public CompactTab CurrentTab => _currentTab;

        /// <summary>Switches the active tab and updates layout, focus, and activation.</summary>
        public void ShowTab(CompactTab tab)
        {
            // Never surface the Clipboard tab while Power Clip is off.
            if (tab == CompactTab.Clipboard && !PowerClipService.Instance.IsEnabled)
                tab = CompactTab.Browsers;

            _currentTab = tab;
            bool browsers = tab == CompactTab.Browsers;

            // Dismiss any open hover-action popup so it doesn't linger/reposition over the new tab.
            HidePopup();

            // Keyboard nav (via the hook thread) applies to both tabs. On Browsers the window is also
            // activated for type-to-filter; the hook still owns Up/Down/Enter so nav works even if
            // the window can't grab focus (Windows foreground rules when launched from a hotkey).
            _keyboardNavEnabled = true;

            ClipboardContent.Visibility = browsers ? Visibility.Collapsed : Visibility.Visible;
            ClipSearchBar.Visibility = browsers ? Visibility.Collapsed : Visibility.Visible;
            BrowserList.Visibility = browsers ? Visibility.Visible : Visibility.Collapsed;
            ViewAllLink.Visibility = browsers ? Visibility.Collapsed : Visibility.Visible;
            ExpandCollapseLink.Visibility = browsers ? Visibility.Visible : Visibility.Collapsed;
            // Left footer: the shortcut chip shows on Browsers; the "Hold Shift to multi-select"
            // hint shows on Clipboard. The Paste all button is Clipboard-tab only.
            ShortcutHintChip.Visibility = browsers ? Visibility.Visible : Visibility.Collapsed;
            MultiSelectHint.Visibility = browsers ? Visibility.Collapsed : Visibility.Visible;
            if (browsers) PasteAllButton.Visibility = Visibility.Collapsed;

            SetTabSelected(BrowsersTabButton, BrowsersTabIcon, BrowsersTabLabel, browsers);
            SetTabSelected(ClipboardTabButton, ClipboardTabIcon, ClipboardTabLabel, !browsers);

            // Footer shortcut hint for the active section.
            var hk = SettingsManager.LoadSettings().Hotkeys;
            ShortcutHint.Text = browsers
                ? Services.HotkeyService.FormatHotkey(hk.LauncherModifiers, hk.LauncherKey)
                : Services.HotkeyService.GetClipHotkeyDisplay();

            if (browsers)
            {
                BrowserList.ClearFilter();
                BrowserList.LoadData();
                // Become activatable so type-to-filter and keyboard launch work.
                SetNoActivate(false);
                _nonActivating = false;
                Activate();
                BrowserList.FocusSearch();
            }
            else
            {
                LoadEntries();
                // Stay non-activating so the target app keeps focus (paste lands there, light-dismiss
                // UIs stay open). The search box is fed by the keyboard hook, not WPF focus.
                SetNoActivate(true);
                _nonActivating = true;
            }
        }

        private void SetTabSelected(Border button, TextBlock icon, TextBlock label, bool selected)
        {
            if (selected)
            {
                button.SetResourceReference(Border.BackgroundProperty, "NavigationItemHoverBrush");
                icon.SetResourceReference(TextBlock.ForegroundProperty, "AccentBrush");
                label.SetResourceReference(TextBlock.ForegroundProperty, "AccentBrush");
                label.FontWeight = FontWeights.SemiBold;
            }
            else
            {
                button.Background = Brushes.Transparent;
                icon.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
                label.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
                label.FontWeight = FontWeights.Normal;
            }
        }

        private void BrowsersTab_Click(object sender, MouseButtonEventArgs e) => ShowTab(CompactTab.Browsers);

        private void ClipboardTab_Click(object sender, MouseButtonEventArgs e) => ShowTab(CompactTab.Clipboard);

        private void ExpandCollapse_Click(object sender, MouseButtonEventArgs e)
        {
            if (BrowserList.AnyExpanded())
                BrowserList.CollapseAll();
            else
                BrowserList.ExpandAll();
        }

        private void UpdateExpandCollapseLink()
        {
            ExpandCollapseLink.Text = BrowserList.AnyExpanded() ? "Collapse all" : "Expand all";
        }

        private void OpenSettingsPage(string page)
        {
            var settingsWindow = Application.Current.Windows
                .OfType<SettingsWindow>()
                .FirstOrDefault();

            if (settingsWindow != null)
            {
                settingsWindow.WindowState = WindowState.Normal;
                settingsWindow.Show();
                settingsWindow.Activate();
                settingsWindow.NavigateToPage(page);
            }
            else
            {
                settingsWindow = new SettingsWindow();
                settingsWindow.NavigateToPage(page);
                settingsWindow.Show();
                settingsWindow.Activate();
            }
        }

        #endregion

        #region Entry Loading & Rendering

        private void LoadEntries()
        {
            _allEntries = PowerClipService.Instance.GetEntries();
            PruneThumbnailCache(_allEntries);
            RenderEntries();
            WarningBanner.Refresh();
            ScrollToTop();
        }

        // Drop cached thumbnails for entries that are no longer in history (deleted, cleared, or
        // aged out), so the cache tracks the live image set and never piles up. Runs on every load
        // (which fires on open and on any HistoryChanged), keeping it bounded by history size.
        private static void PruneThumbnailCache(IEnumerable<ClipboardEntry> current)
        {
            if (_thumbCache.Count == 0) return;
            var live = new HashSet<string>(
                current.Where(e => e.Type == ClipboardEntryType.Image).Select(e => e.Content),
                StringComparer.OrdinalIgnoreCase);
            foreach (var stale in _thumbCache.Keys.Where(k => !live.Contains(k)).ToList())
                _thumbCache.Remove(stale);
        }

        // The shared warning banner ran its "Free up space" action; reload to reflect it.
        private void WarningBanner_Changed(object? sender, EventArgs e) => LoadEntries();

        private void ScrollToTop()
        {
            if (EntriesListView.Items.Count > 0)
                EntriesListView.ScrollIntoView(EntriesListView.Items[0]);
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            RenderEntries();
        }

        private void ClearSearch_Click(object sender, RoutedEventArgs e)
        {
            _searchText.Clear();
            SearchBox.Text = string.Empty;
        }

        private void RenderEntries()
        {
            // Check monitoring status first
            var clipSettings = SettingsManager.LoadSettings().ClipboardMonitoring;
            if (!clipSettings.IsEnabled)
            {
                EntriesListView.ItemsSource = null;
                EntriesListView.Visibility = Visibility.Collapsed;
                EmptyText.Visibility = Visibility.Collapsed;
                MonitoringOffTitle.Text = "Monitoring is off";
                MonitoringOffDescription.Text = "Enable clipboard monitoring to capture history.";
                MonitoringOffButton.Content = "Enable";
                MonitoringOffState.Visibility = Visibility.Visible;
                return;
            }
            if (clipSettings.IsPaused)
            {
                var remaining = clipSettings.RemainingPauseTime;
                EntriesListView.ItemsSource = null;
                EntriesListView.Visibility = Visibility.Collapsed;
                EmptyText.Visibility = Visibility.Collapsed;
                MonitoringOffTitle.Text = "Monitoring is paused";
                MonitoringOffDescription.Text = remaining.HasValue
                    ? $"Resumes in {(int)Math.Ceiling(remaining.Value.TotalMinutes)}m"
                    : "Monitoring is temporarily paused.";
                MonitoringOffButton.Content = "Resume Now";
                MonitoringOffState.Visibility = Visibility.Visible;
                return;
            }
            MonitoringOffState.Visibility = Visibility.Collapsed;

            var entries = _allEntries.AsEnumerable();

            // Apply search filter
            var searchText = SearchBox?.Text?.Trim();
            if (!string.IsNullOrEmpty(searchText))
            {
                entries = entries.Where(e =>
                    e.Content.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0);
            }

            var all = entries.ToList();

            if (all.Count == 0)
            {
                EntriesListView.ItemsSource = null;
                EntriesListView.Visibility = Visibility.Collapsed;
                EmptyText.Visibility = Visibility.Visible;
                EmptyText.Text = _allEntries.Count == 0 ? "No clipboard entries" : "No matching entries";
                return;
            }

            EmptyText.Visibility = Visibility.Collapsed;
            EntriesListView.Visibility = Visibility.Visible;

            var items = new List<UIElement>();
            _navItems.Clear();

            var pinned = all.Where(e => e.IsPinned).OrderByDescending(e => e.Timestamp).ToList();
            var recent = all.Where(e => !e.IsPinned).OrderByDescending(e => e.Timestamp).ToList();

            if (pinned.Count > 0)
            {
                items.Add(CreateSectionHeader("Pinned"));
                foreach (var entry in pinned)
                {
                    var row = CreateEntryRow(entry);
                    items.Add(row);
                    _navItems.Add((row, entry));
                }
            }

            if (recent.Count > 0)
            {
                if (pinned.Count > 0)
                    items.Add(CreateSectionHeader("Recent"));
                foreach (var entry in recent)
                {
                    var row = CreateEntryRow(entry);
                    items.Add(row);
                    _navItems.Add((row, entry));
                }
            }

            EntriesListView.ItemsSource = items;

            // Pre-highlight the first entry so Enter pastes it immediately. Rebuilding the list
            // exits any multi-select in progress.
            _selectedIndex = _navItems.Count > 0 ? 0 : -1;
            _selectedIndices.Clear();
            if (_selectedIndex >= 0) _selectedIndices.Add(_selectedIndex);
            _multiSelectMode = false;
            _defaultSelection = _selectedIndex >= 0;
            ApplySelectionHighlight();
            UpdatePasteAllButton();
        }

        // Returns a cached, frozen 48px thumbnail for an image file, decoding once on first use.
        private static System.Windows.Media.ImageSource? GetThumbnail(string path)
        {
            if (_thumbCache.TryGetValue(path, out var cached))
                return cached;

            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.DecodePixelHeight = 48;
            bmp.UriSource = new Uri(path);
            bmp.EndInit();
            bmp.Freeze(); // shareable across threads/instances and cheaper to render

            // Only current entries are ever rendered, and PruneThumbnailCache trims the cache to the
            // live history on each load — so the cache stays bounded by the number of image entries.
            _thumbCache[path] = bmp;
            return bmp;
        }

        private UIElement CreateSectionHeader(string text)
        {
            var header = new TextBlock
            {
                Text = text,
                FontSize = 11,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(8, 4, 0, 2)
            };
            header.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
            return header;
        }

        private void ViewAll_Click(object sender, MouseButtonEventArgs e)
        {
            CloseCleanup();
            Close();

            // Open full PowerDroid window on PowerClip page
            Dispatcher.BeginInvoke(() => OpenSettingsPage("PowerClip"));
        }

        private Border CreateEntryRow(ClipboardEntry entry)
        {
            var border = new Border
            {
                MinHeight = 44,
                Padding = new Thickness(12, 8, 12, 8),
                Margin = new Thickness(4, 2, 4, 2),
                CornerRadius = new CornerRadius(6),
                // Constant thickness with a transparent default border so the selection accent can
                // appear without shifting layout as the highlight moves.
                BorderThickness = new Thickness(1.5),
                BorderBrush = Brushes.Transparent,
                Cursor = Cursors.Hand,
                Tag = entry.Id
            };
            border.SetResourceReference(Border.BackgroundProperty, "SolidBackgroundFillSecondaryBrush");

            // Hover effect + popup trigger
            border.MouseEnter += (s, e) =>
            {
                border.SetResourceReference(Border.BackgroundProperty, "NavigationItemHoverBrush");
                StartHoverPopup(border, entry);
            };
            border.MouseLeave += (s, e) =>
            {
                border.SetResourceReference(Border.BackgroundProperty, "SolidBackgroundFillSecondaryBrush");
                ScheduleHidePopup();
            };

            // Click to paste (Shift/Ctrl build a multi-selection instead of pasting immediately)
            border.MouseLeftButtonUp += (s, e) => OnRowClicked(entry);

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) }); // icon
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // content
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) }); // pin indicator
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) }); // timestamp

            // Type icon
            var icon = new TextBlock
            {
                Text = GetTypeIcon(entry),
                FontSize = 13,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 10, 0)
            };
            icon.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");
            icon.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
            Grid.SetColumn(icon, 0);
            grid.Children.Add(icon);

            // Content — image thumbnail or text (consistent height)
            if (entry.Type == ClipboardEntryType.Image && File.Exists(entry.Content))
            {
                var imagePanel = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                var thumb = new Image
                {
                    Height = 48,
                    MaxWidth = 250,
                    Stretch = Stretch.Uniform,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Margin = new Thickness(0, 2, 8, 2)
                };
                try
                {
                    thumb.Source = GetThumbnail(entry.Content);
                }
                catch { }
                imagePanel.Children.Add(thumb);
                Grid.SetColumn(imagePanel, 1);
                grid.Children.Add(imagePanel);
            }
            else
            {
                var contentPanel = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                var content = new TextBlock
                {
                    Text = TruncateContent(entry.Content, 200),
                    FontSize = 12,
                    TextWrapping = TextWrapping.Wrap,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    // Clamp to 2 lines: fixed line height keeps MaxHeight deterministic, and
                    // TextTrimming ellipsizes the last visible (second) line.
                    LineHeight = 16,
                    LineStackingStrategy = LineStackingStrategy.BlockLineHeight,
                    MaxHeight = 32,
                    Margin = new Thickness(0, 0, 8, 0)
                };
                content.SetResourceReference(TextBlock.ForegroundProperty, "TextPrimaryBrush");
                contentPanel.Children.Add(content);
                Grid.SetColumn(contentPanel, 1);
                grid.Children.Add(contentPanel);
            }

            // Pinned indicator — solid filled vector pushpin (matches the action buttons).
            if (entry.IsPinned)
            {
                var pin = ClipIcons.CreatePushpin(12, new SolidColorBrush(Color.FromRgb(255, 185, 0)));
                pin.VerticalAlignment = VerticalAlignment.Center;
                pin.Margin = new Thickness(4, 0, 6, 0);
                pin.ToolTip = "Pinned";
                Grid.SetColumn(pin, 2);
                grid.Children.Add(pin);
            }

            // Timestamp
            var time = new TextBlock
            {
                Text = FormatTime(entry.Timestamp),
                FontSize = 10,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(4, 0, 0, 0)
            };
            time.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
            Grid.SetColumn(time, 3);
            grid.Children.Add(time);

            border.Child = grid;
            return border;
        }

        #endregion

        #region Hover Popup

        private void StartHoverPopup(Border border, ClipboardEntry entry, int delayMs = 600, bool activatable = true)
        {
            // If already showing for this entry, keep it
            if (_hoverPopup != null && _hoveredEntry?.Id == entry.Id)
                return;

            HidePopup();

            _hoveredBorder = border;
            _hoveredEntry = entry;
            _popupActivatable = activatable;

            // Open after a short settle delay (shorter for keyboard navigation).
            _hoverTimer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(delayMs)
            };
            _hoverTimer.Tick += (s, e) =>
            {
                _hoverTimer.Stop();
                ShowPopup();
            };
            _hoverTimer.Start();
        }

        private void ScheduleHidePopup()
        {
            _hoverTimer?.Stop();

            // Short delay to allow mouse to move to popup
            var hideTimer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(200)
            };
            hideTimer.Tick += (s, e) =>
            {
                hideTimer.Stop();
                if (!_isMouseOverPopup && (_hoveredBorder == null || !_hoveredBorder.IsMouseOver))
                    HidePopup();
            };
            hideTimer.Start();
        }

        private void ShowPopup()
        {
            if (_hoveredBorder == null || _hoveredEntry == null) return;

            var content = BuildPopupContent(_hoveredEntry);
            if (content == null) return;

            // Inner border with content clipping for rounded corners
            var innerBorder = new Border
            {
                Padding = new Thickness(12),
                CornerRadius = new CornerRadius(8),
                BorderThickness = new Thickness(1),
                MinWidth = 200,
                MaxWidth = 400,
                ClipToBounds = true,
            };
            innerBorder.SetResourceReference(Border.BackgroundProperty, "CardBackgroundBrush");
            innerBorder.SetResourceReference(Border.BorderBrushProperty, "CardStrokeBrush");
            innerBorder.Child = content;

            // Outer border for shadow (not clipped)
            var popupBorder = new Border
            {
                Padding = new Thickness(8),
                Background = Brushes.Transparent,
            };
            popupBorder.Effect = new System.Windows.Media.Effects.DropShadowEffect
            {
                ShadowDepth = 2, BlurRadius = 16, Opacity = 0.25, Color = Colors.Black
            };
            popupBorder.Child = innerBorder;

            // Track mouse over popup
            popupBorder.MouseEnter += (s, e) => _isMouseOverPopup = true;
            popupBorder.MouseLeave += (s, e) =>
            {
                _isMouseOverPopup = false;
                ScheduleHidePopup();
            };

            _hoverPopup = new System.Windows.Controls.Primitives.Popup
            {
                Child = popupBorder,
                PlacementTarget = _hoveredBorder,
                Placement = System.Windows.Controls.Primitives.PlacementMode.Left,
                HorizontalOffset = 0,
                AllowsTransparency = true,
                StaysOpen = true,
                IsOpen = true
            };
            // Deliberately do NOT toggle WS_EX_NOACTIVATE here. The window stays non-activating the
            // whole time it's open, so clicking a row to paste never steals focus from the target
            // (which is what makes paste reliable). The popup's action buttons still receive mouse
            // clicks because the Popup is its own top-level surface — activation isn't required.
        }

        private void HidePopup()
        {
            if (_hoverPopup != null)
            {
                _hoverPopup.IsOpen = false;
                _hoverPopup = null;
            }
            _hoverTimer?.Stop();
            _hoveredBorder = null;
            _hoveredEntry = null;
            _isMouseOverPopup = false;
        }

        private void SetNoActivate(bool enable)
        {
            try
            {
                var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
                if (hwnd == IntPtr.Zero) return;
                var exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
                if (enable)
                    SetWindowLong(hwnd, GWL_EXSTYLE, exStyle | WS_EX_NOACTIVATE);
                else
                    SetWindowLong(hwnd, GWL_EXSTYLE, exStyle & ~WS_EX_NOACTIVATE);
            }
            catch { }
        }

        private StackPanel? BuildPopupContent(ClipboardEntry entry)
        {
            try
            {
                var panel = new StackPanel { MaxWidth = 370 };

                // "Paste selection" affordance — created in the text branch (if any), then inserted
                // into the action-buttons row below. Stays null / unused for non-text previews.
                Button? pasteSelBtn = null;

                // Preview content
                if (entry.Type == ClipboardEntryType.Image && File.Exists(entry.Content))
                {
                    try
                    {
                        if (entry.Content.EndsWith(".gif", StringComparison.OrdinalIgnoreCase))
                        {
                            var gif = new MediaElement
                            {
                                MaxWidth = 350, MaxHeight = 250,
                                LoadedBehavior = MediaState.Play,
                                UnloadedBehavior = MediaState.Manual,
                                Stretch = Stretch.Uniform,
                            };
                            gif.MediaEnded += (s, ev) => { try { gif.Position = TimeSpan.Zero; gif.Play(); } catch { } };
                            gif.MediaFailed += (s, ev) => { };
                            gif.Source = new Uri(entry.Content);
                            var gifBorder = new Border
                            {
                                CornerRadius = new CornerRadius(4),
                                ClipToBounds = true,
                                Margin = new Thickness(0, 0, 0, 6)
                            };
                            gifBorder.Child = gif;
                            panel.Children.Add(gifBorder);
                        }
                        else
                        {
                            var preview = new BitmapImage();
                            preview.BeginInit();
                            preview.CacheOption = BitmapCacheOption.OnLoad;
                            preview.DecodePixelWidth = 350;
                            preview.UriSource = new Uri(entry.Content);
                            preview.EndInit();
                            var imgBorder = new Border
                            {
                                CornerRadius = new CornerRadius(4),
                                ClipToBounds = true,
                                Margin = new Thickness(0, 0, 0, 6)
                            };
                            imgBorder.Child = new Image
                            {
                                Source = preview, MaxWidth = 350, MaxHeight = 250,
                                Stretch = Stretch.Uniform,
                            };
                            panel.Children.Add(imgBorder);
                        }

                        var fi = new FileInfo(entry.Content);
                        var ext = Path.GetExtension(entry.Content).TrimStart('.').ToUpperInvariant();
                        var bmp = new BitmapImage();
                        bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad;
                        bmp.UriSource = new Uri(entry.Content); bmp.EndInit();
                        var detail = new TextBlock
                        {
                            Text = $"{bmp.PixelWidth}x{bmp.PixelHeight} · {fi.Length / 1024} KB · {ext}",
                            FontSize = 11, Margin = new Thickness(0, 0, 0, 6)
                        };
                        detail.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
                        panel.Children.Add(detail);
                    }
                    catch { }
                }
                else
                {
                    var text = new TextBox
                    {
                        Text = entry.Content,
                        TextWrapping = TextWrapping.Wrap,
                        FontSize = 12, MaxHeight = 204,
                        IsReadOnly = true,
                        IsReadOnlyCaretVisible = false,
                        BorderThickness = new Thickness(0),
                        Background = System.Windows.Media.Brushes.Transparent,
                        // Padding on the text content (not the outer border) so the text is inset on all
                        // sides while the scrollbar track stays flush at the right edge.
                        Padding = new Thickness(8),
                        Cursor = Cursors.IBeam,
                        IsInactiveSelectionHighlightEnabled = true, // keep highlight when focus moves to paste bar
                        VerticalScrollBarVisibility = ScrollBarVisibility.Auto, // scroll long content instead of truncating
                    };
                    text.SetResourceReference(TextBox.ForegroundProperty, "TextPrimaryBrush");
                    // Use the app's compact scrollbar (thin, rounded thumb) instead of the native one.
                    if (TryFindResource("CompactScrollBarStyle") is Style compactScrollBar)
                        text.Resources[typeof(System.Windows.Controls.Primitives.ScrollBar)] = compactScrollBar;

                    // Set the scrollable text off from the card with its own subtle fill + padding.
                    var textBg = new Border
                    {
                        CornerRadius = new CornerRadius(4),
                        BorderThickness = new Thickness(1),
                        // No padding here — the text's own Padding insets the text, keeping the scrollbar flush.
                        Padding = new Thickness(0),
                        MaxWidth = 360,
                        Child = text,
                    };
                    textBg.SetResourceReference(Border.BackgroundProperty, "CardBackgroundSecondaryBrush");
                    textBg.SetResourceReference(Border.BorderBrushProperty, "CardStrokeBrush");
                    panel.Children.Add(textBg);

                    // "Paste selection" bar — hidden until the user selects part of the text, then
                    // pastes only that substring via the shared paste pipeline.
                    pasteSelBtn = CreatePopupTextAction("", "Paste selection", () => { });
                    pasteSelBtn.Visibility = Visibility.Collapsed;

                    text.SelectionChanged += (s, e) =>
                        pasteSelBtn.Visibility = text.SelectionLength > 0 ? Visibility.Visible : Visibility.Collapsed;
                    pasteSelBtn.Click += (s, e) =>
                    {
                        var sel = text.SelectedText;
                        if (!string.IsNullOrEmpty(sel))
                            PasteSelectedText(sel);
                    };

                    var typeName = entry.TypeLabel;
                    var info = new TextBlock
                    {
                        Text = $"{entry.Content.Length} chars · {typeName}",
                        FontSize = 11, Margin = new Thickness(0, 4, 0, 0)
                    };
                    info.SetResourceReference(TextBlock.ForegroundProperty, "TextSecondaryBrush");
                    panel.Children.Add(info);
                }

                // Source app
                if (!string.IsNullOrEmpty(entry.SourceApp))
                {
                    var appName = string.IsNullOrEmpty(entry.SourceDetail)
                        ? entry.SourceApp : $"{entry.SourceApp} · {entry.SourceDetail}";
                    var src = new TextBlock { Text = $"from {appName}", FontSize = 10, Margin = new Thickness(0, 2, 0, 0) };
                    src.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
                    panel.Children.Add(src);
                }

                // Action buttons
                var actions = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(0, 8, 0, 0)
                };

                // No "Copy" action here. Clicking a row already places the content on the clipboard
                // and pastes it (Windows-clipboard model), so a separate Copy icon was redundant and
                // misled users into thinking they had to click it to copy (issue #75).

                // Extract Text (Images only — OCR), gated on engine availability so the
                // action doesn't appear as a no-op on N/KN or language-pack-less systems.
                if (entry.Type == ClipboardEntryType.Image && File.Exists(entry.Content)
                    && OcrService.IsAvailable())
                {
                    actions.Children.Add(CreatePopupAction("\uE8AC", "Extract Text", async () =>
                    {
                        var text = entry.CachedOcrText
                            ?? await OcrService.ExtractTextAsync(entry.Content);

                        if (!string.IsNullOrEmpty(text))
                        {
                            entry.CachedOcrText = text;
                            ClipboardMonitorService.Instance.SuppressNextCapture();
                            Clipboard.SetText(text);
                            PowerClipService.Instance.AddOcrText(text, entry);
                        }
                        HidePopup();
                    }));
                }

                // Open Link (URLs) — only valid HTTP/HTTPS URLs
                if (entry.Type == ClipboardEntryType.Url && App.IsValidBrowseUrl(entry.Content))
                {
                    actions.Children.Add(CreatePopupAction("\uE71B", "Open Link", () =>
                    {
                        try { Process.Start(new ProcessStartInfo(entry.Content) { UseShellExecute = true }); }
                        catch (Exception ex) { Logger.Log($"Failed to open clipboard URL: {ex.Message}"); }
                        HidePopup();
                    }));
                }

                // Open Path (file paths) — block UNC paths, use explorer.exe
                if (entry.Type == ClipboardEntryType.FilePath)
                {
                    // Accept both separators: normalize '/' to '\' so explorer.exe and the
                    // directory checks work for forward-slash paths (e.g. C:/Users/...).
                    var normalized = entry.Content.Replace('/', '\\');
                    var folder = Path.GetDirectoryName(normalized) ?? normalized;
                    if (!folder.StartsWith(@"\\") && Directory.Exists(folder))
                    {
                        actions.Children.Add(CreatePopupAction("\uE838", "Open Path", () =>
                        {
                            try { Process.Start(new ProcessStartInfo("explorer.exe") { Arguments = $"\"{folder}\"", UseShellExecute = false }); }
                            catch (Exception ex) { Logger.Log($"Failed to open clipboard path: {ex.Message}"); }
                            HidePopup();
                        }));
                    }
                }

                // Pin / Unpin - pinned uses the solid filled vector pushpin; not-pinned keeps the
                // original Segoe glyph. The tooltip conveys pin vs unpin.
                actions.Children.Add(CreatePopupAction(
                    "",
                    entry.IsPinned ? "Unpin" : "Pin", () =>
                {
                    if (entry.IsPinned)
                    {
                        PowerClipService.Instance.Unpin(entry.Id);
                    }
                    else if (!PowerClipService.Instance.Pin(entry.Id))
                    {
                        ToastService.Show(this, $"Pin limit reached (max {PowerClipService.MaxPinnedEntries})");
                    }
                    HidePopup();
                }, "IconButtonOrangeStyle", entry.IsPinned ? ClipIcons.CreatePushpin() : null));

                // Delete
                actions.Children.Add(CreatePopupAction("\uE74D", "Delete", () =>
                {
                    PowerClipService.Instance.Delete(entry.Id);
                    HidePopup();
                }, "IconButtonRedStyle"));

                // Paste selection (text previews only) — last in the row, collapsed until text is selected.
                if (pasteSelBtn != null)
                    actions.Children.Add(pasteSelBtn);

                panel.Children.Add(actions);
                return panel;
            }
            catch { return null; }
        }

        private Button CreatePopupAction(string icon, string tooltip, Action onClick, string styleName = "IconButtonBlueStyle", FrameworkElement? customContent = null)
        {
            FrameworkElement content;
            if (customContent != null)
            {
                // Vector icon (e.g. the pushpin Path) — used as-is.
                content = customContent;
            }
            else
            {
                var iconBlock = new TextBlock
                {
                    Text = icon,
                    FontSize = 14,
                };
                iconBlock.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");

                var binding = new System.Windows.Data.Binding("Foreground")
                {
                    RelativeSource = new System.Windows.Data.RelativeSource(
                        System.Windows.Data.RelativeSourceMode.FindAncestor, typeof(Button), 1)
                };
                iconBlock.SetBinding(TextBlock.ForegroundProperty, binding);
                content = iconBlock;
            }

            var button = new Button
            {
                ToolTip = tooltip,
                Margin = new Thickness(0, 0, 2, 0),
                Cursor = Cursors.Hand,
                Content = content,
            };
            button.SetResourceReference(Button.StyleProperty, styleName);
            button.Click += (s, e) => onClick();

            return button;
        }

        // Labeled popup action (icon glyph + text) for wider affordances like "Paste selection".
        // CreatePopupAction is icon-only (fixed 24x24 square styles), so this builds a self-contained
        // button that can hold a label. Hover uses a translucent-blue fill + accent foreground that
        // reads well on both light and dark popup cards.
        private Button CreatePopupTextAction(string icon, string label, Action onClick)
        {
            var iconBlock = new TextBlock { Text = icon, FontSize = 13, VerticalAlignment = VerticalAlignment.Center };
            iconBlock.SetResourceReference(TextBlock.FontFamilyProperty, "SegoeFluentIcons");

            var labelBlock = new TextBlock
            {
                Text = label, FontSize = 12,
                Margin = new Thickness(6, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center,
            };

            var row = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(8, 3, 8, 3),
            };
            row.Children.Add(iconBlock);
            row.Children.Add(labelBlock);

            // Border/ContentPresenter template so IsMouseOver drives the hover fill/foreground.
            // Foreground is inherited by both TextBlocks above.
            var border = new FrameworkElementFactory(typeof(Border));
            border.Name = "Bd";
            border.SetValue(Border.BackgroundProperty, System.Windows.Media.Brushes.Transparent);
            border.SetValue(Border.CornerRadiusProperty, new CornerRadius(3));
            border.SetValue(Border.BorderThicknessProperty, new Thickness(1));
            border.SetResourceReference(Border.BorderBrushProperty, "CardStrokeBrush");
            border.SetValue(Border.PaddingProperty, new Thickness(0));
            var presenter = new FrameworkElementFactory(typeof(ContentPresenter));
            presenter.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            presenter.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            border.AppendChild(presenter);

            var template = new ControlTemplate(typeof(Button)) { VisualTree = border };
            var hover = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
            hover.Setters.Add(new Setter(Border.BackgroundProperty,
                new System.Windows.Media.SolidColorBrush(Color.FromArgb(38, 33, 150, 243)), "Bd")); // subtle blue tint
            hover.Setters.Add(new Setter(Control.ForegroundProperty,
                new System.Windows.Media.SolidColorBrush(Color.FromArgb(255, 30, 136, 229)))); // #1E88E5 accent
            template.Triggers.Add(hover);

            var button = new Button
            {
                Cursor = Cursors.Hand,
                Background = System.Windows.Media.Brushes.Transparent,
                BorderThickness = new Thickness(0),
                Template = template,
                Content = row,
            };
            button.SetResourceReference(Button.ForegroundProperty, "TextSecondaryBrush");
            button.Click += (s, e) => onClick();

            return button;
        }

        #endregion

        #region Paste Logic

        private void PasteEntry(ClipboardEntry entry) => PasteEntries(new[] { entry });

        // Paste an arbitrary substring (a selection from the preview) as plain text. Routes through
        // the shared paste pipeline via a synthetic text entry so clipboard-suppression, focus, and
        // the Ctrl+V send behave exactly like a normal paste. RichHtml is left null on purpose — a
        // substring's CF_HTML byte offsets wouldn't align, so plain CF_UNICODETEXT is correct.
        private void PasteSelectedText(string selectedText)
        {
            if (string.IsNullOrEmpty(selectedText)) return;
            PasteEntry(new ClipboardEntry
            {
                Content = selectedText,
                Type = ClipboardEntryType.Text,
            });
        }

        // Place a single entry's content on the clipboard in its native format (text/rich-HTML via
        // ClipboardWriter, images via SetImage / GIF file-drop). Shared by single and multi paste.
        private void SetClipboardForEntry(ClipboardEntry entry)
        {
            if (entry.Type == ClipboardEntryType.Image && File.Exists(entry.Content))
            {
                if (entry.Content.EndsWith(".gif", StringComparison.OrdinalIgnoreCase))
                {
                    var data = new DataObject();
                    data.SetFileDropList(new System.Collections.Specialized.StringCollection { entry.Content });
                    data.SetData("GIF", new MemoryStream(File.ReadAllBytes(entry.Content)));
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.UriSource = new Uri(entry.Content);
                    bitmap.EndInit();
                    data.SetImage(bitmap);
                    Clipboard.SetDataObject(data);
                }
                else
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.UriSource = new Uri(entry.Content);
                    bitmap.EndInit();
                    Clipboard.SetImage(bitmap);
                }
            }
            else
            {
                ClipboardWriter.SetTextEntry(entry);
            }
        }

        // Paste one or more entries sequentially, top-to-bottom, into the still-focused target app.
        // The window hides first (proven single-paste focus behavior), then a timer-driven queue
        // sets the clipboard and sends Ctrl+V for each item, one per ~150ms tick.
        private void PasteEntries(IReadOnlyList<ClipboardEntry> entries)
        {
            if (entries == null || entries.Count == 0) return;
            try
            {
                _isPasting = true;
                Logger.Log($"CompactClipboard: Pasting {entries.Count} entr{(entries.Count == 1 ? "y" : "ies")}");

                // Hide popup then paste into the still-focused target app.
                CloseCleanup();
                Hide();

                int index = 0;
                var timer = new System.Windows.Threading.DispatcherTimer
                {
                    Interval = TimeSpan.FromMilliseconds(MultiPasteIntervalMs)
                };
                timer.Tick += (s, args) =>
                {
                    if (index >= entries.Count)
                    {
                        timer.Stop();
                        Close();
                        return;
                    }

                    var entry = entries[index];
                    index++;
                    try
                    {
                        // Suppress before EVERY set so our own writes aren't re-captured (Risk 2).
                        ClipboardMonitorService.Instance.SuppressNextCapture();
                        SetClipboardForEntry(entry);

                        // In the non-activating model the target app never lost focus, so we must NOT
                        // reactivate anything. Only the activating Browsers-derived path needs a
                        // focus restore, and only once before the first paste.
                        if (index == 1 && !_nonActivating)
                            Services.BrowserFocusHelper.FocusWindow(_previousWindow);

                        System.Windows.Forms.SendKeys.SendWait("^v");
                    }
                    catch (Exception ex)
                    {
                        // Per-item guard (Risk 3): a transient clipboard error on one item must not
                        // abort the rest of the burst.
                        Logger.Log($"CompactClipboard: paste item error: {ex.Message}");
                    }
                };
                timer.Start();
            }
            catch (Exception ex)
            {
                Logger.Log($"CompactClipboard: Paste error: {ex.Message}");
                _isPasting = false;
                Close();
            }
        }

        #endregion

        #region Helpers

        private static TextBlock CreateSourceLabel(ClipboardEntry entry)
        {
            var appName = string.IsNullOrEmpty(entry.SourceDetail)
                ? entry.SourceApp!
                : $"{entry.SourceApp} · {entry.SourceDetail}";

            var label = new TextBlock
            {
                Text = $"from {appName}",
                FontSize = 9,
                Margin = new Thickness(0, 1, 0, 0),
            };
            label.SetResourceReference(TextBlock.ForegroundProperty, "TextTertiaryBrush");
            return label;
        }

        private static string TruncateContent(string content, int maxLength)
        {
            if (string.IsNullOrEmpty(content)) return string.Empty;
            var singleLine = content.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");
            if (singleLine.Length <= maxLength) return singleLine;
            return singleLine.Substring(0, maxLength) + "...";
        }

        private static string FormatTime(DateTime timestamp)
        {
            var diff = DateTime.Now - timestamp;
            if (diff.TotalSeconds < 60) return "now";
            if (diff.TotalMinutes < 60) return $"{(int)diff.TotalMinutes}m";
            if (diff.TotalHours < 24) return $"{(int)diff.TotalHours}h";
            if (diff.TotalDays < 7) return $"{(int)diff.TotalDays}d";
            return timestamp.ToString("MMM d");
        }

        private static string GetTypeIcon(ClipboardEntry entry)
        {
            return entry.Type switch
            {
                ClipboardEntryType.Url => "\uE71B",
                ClipboardEntryType.FilePath => "\uE8B7",
                ClipboardEntryType.Image => "\uEB9F",
                ClipboardEntryType.Text => "\uE8C1",
                _ => "\uE8C1"
            };
        }

        #endregion
    }
}
