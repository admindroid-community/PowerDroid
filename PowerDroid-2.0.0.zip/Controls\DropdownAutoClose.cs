using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PowerDroid.Controls
{
    /// <summary>
    /// Attached behavior that closes any open descendant <see cref="ComboBox"/> dropdown when the
    /// host <see cref="ScrollViewer"/> scrolls or its window is moved / minimized.
    ///
    /// A ComboBox dropdown is a <c>Popup</c> — a separate top-level window positioned once when it
    /// opens. Without this, scrolling the page (or moving/minimizing the window) shifts the ComboBox
    /// but leaves the popup floating in its old spot, so the menu looks detached / misaligned.
    /// Closing the dropdown on those events is the conventional, expected behavior.
    ///
    /// Usage — set on a ScrollViewer:
    /// <code>controls:DropdownAutoClose.Enabled="True"</code>
    /// </summary>
    public static class DropdownAutoClose
    {
        public static readonly DependencyProperty EnabledProperty =
            DependencyProperty.RegisterAttached(
                "Enabled", typeof(bool), typeof(DropdownAutoClose),
                new PropertyMetadata(false, OnEnabledChanged));

        public static bool GetEnabled(DependencyObject obj) => (bool)obj.GetValue(EnabledProperty);
        public static void SetEnabled(DependencyObject obj, bool value) => obj.SetValue(EnabledProperty, value);

        // Remembers the window we hooked so we can unhook it on unload.
        private static readonly DependencyProperty HookedWindowProperty =
            DependencyProperty.RegisterAttached(
                "HookedWindow", typeof(Window), typeof(DropdownAutoClose), new PropertyMetadata(null));

        private static void OnEnabledChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is not ScrollViewer scrollViewer) return;

            if ((bool)e.NewValue)
            {
                scrollViewer.ScrollChanged += OnScrollChanged;
                scrollViewer.Loaded += OnLoaded;
                scrollViewer.Unloaded += OnUnloaded;
            }
            else
            {
                scrollViewer.ScrollChanged -= OnScrollChanged;
                scrollViewer.Loaded -= OnLoaded;
                scrollViewer.Unloaded -= OnUnloaded;
                Unhook(scrollViewer);
            }
        }

        private static void OnScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            // Ignore no-op scroll notifications (e.g. layout passes).
            if (e.VerticalChange == 0 && e.HorizontalChange == 0) return;
            if (sender is DependencyObject root) CloseOpenComboBoxes(root);
        }

        private static void OnLoaded(object sender, RoutedEventArgs e)
        {
            if (sender is not ScrollViewer scrollViewer) return;
            var window = Window.GetWindow(scrollViewer);
            if (window == null) return;

            scrollViewer.SetValue(HookedWindowProperty, window);
            window.LocationChanged += OnWindowChanged; // dragged/moved
            window.StateChanged += OnWindowChanged;    // minimized/maximized/restored
        }

        private static void OnUnloaded(object sender, RoutedEventArgs e)
        {
            if (sender is ScrollViewer scrollViewer) Unhook(scrollViewer);
        }

        private static void Unhook(ScrollViewer scrollViewer)
        {
            if (scrollViewer.GetValue(HookedWindowProperty) is Window window)
            {
                window.LocationChanged -= OnWindowChanged;
                window.StateChanged -= OnWindowChanged;
                scrollViewer.SetValue(HookedWindowProperty, null);
            }
        }

        private static void OnWindowChanged(object? sender, System.EventArgs e)
        {
            if (sender is Window window) CloseOpenComboBoxes(window);
        }

        private static void CloseOpenComboBoxes(DependencyObject root)
        {
            foreach (var comboBox in FindOpenComboBoxes(root))
                comboBox.IsDropDownOpen = false;
        }

        private static IEnumerable<ComboBox> FindOpenComboBoxes(DependencyObject root)
        {
            int count = VisualTreeHelper.GetChildrenCount(root);
            for (int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(root, i);
                if (child is ComboBox { IsDropDownOpen: true } comboBox)
                    yield return comboBox;

                foreach (var nested in FindOpenComboBoxes(child))
                    yield return nested;
            }
        }
    }
}
