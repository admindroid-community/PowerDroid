using System;
using System.IO;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage;
using Windows.Storage.Streams;

namespace PowerDroid.Services
{
    /// <summary>
    /// Extracts text from images using the Windows built-in OCR engine.
    /// Includes image pre-processing (upscale + grayscale + contrast)
    /// to improve accuracy on Windows 10's older OCR model.
    /// </summary>
    public static class OcrService
    {
        // Images smaller than this get upscaled for better OCR accuracy
        private const uint MinDimensionForOcr = 1500;

        /// <summary>
        /// Extracts text from an image file using Windows OCR.
        /// </summary>
        /// <param name="imagePath">Full path to a PNG or GIF image file.</param>
        /// <returns>Extracted text, or null if no text found or OCR unavailable.</returns>
        public static async Task<string?> ExtractTextAsync(string imagePath)
        {
            try
            {
                if (string.IsNullOrEmpty(imagePath) || !File.Exists(imagePath))
                    return null;

                var engine = OcrEngine.TryCreateFromUserProfileLanguages();
                if (engine == null)
                {
                    Logger.Log("OcrService: No OCR engine available");
                    return null;
                }

                var file = await StorageFile.GetFileFromPathAsync(imagePath);
                using var stream = await file.OpenAsync(FileAccessMode.Read);

                var decoder = await BitmapDecoder.CreateAsync(stream);

                // Pre-process: upscale small images for better OCR accuracy
                var bitmap = await GetPreprocessedBitmapAsync(decoder);

                var result = await engine.RecognizeAsync(bitmap);
                var text = result?.Text?.Trim();

                if (string.IsNullOrWhiteSpace(text))
                {
                    Logger.Log("OcrService: No text found in image");
                    return null;
                }

                Logger.Log($"OcrService: Extracted {text.Length} chars from image");
                return text;
            }
            catch (Exception ex)
            {
                Logger.Log($"OcrService: Error extracting text: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Pre-processes the image: upscales if small, converts to grayscale,
        /// and boosts contrast to help the OCR engine.
        /// </summary>
        private static async Task<SoftwareBitmap> GetPreprocessedBitmapAsync(BitmapDecoder decoder)
        {
            uint origWidth = decoder.PixelWidth;
            uint origHeight = decoder.PixelHeight;

            // Calculate scale factor — upscale so the smaller dimension is at least MinDimensionForOcr
            double scale = 1.0;
            uint minDim = Math.Min(origWidth, origHeight);
            if (minDim < MinDimensionForOcr)
                scale = (double)MinDimensionForOcr / minDim;

            // Cap at 4x to avoid excessive memory use
            scale = Math.Min(scale, 4.0);

            uint scaledWidth = (uint)(origWidth * scale);
            uint scaledHeight = (uint)(origHeight * scale);

            // OcrEngine.MaxImageDimension is 2600 on Win10 — ensure we stay within
            // Use a safe max since MaxImageDimension may not be available on all builds
            const uint maxDim = 2560;
            if (scaledWidth > maxDim || scaledHeight > maxDim)
            {
                double downScale = (double)maxDim / Math.Max(scaledWidth, scaledHeight);
                scaledWidth = (uint)(scaledWidth * downScale);
                scaledHeight = (uint)(scaledHeight * downScale);
            }

            var transform = new BitmapTransform
            {
                ScaledWidth = scaledWidth,
                ScaledHeight = scaledHeight,
                InterpolationMode = BitmapInterpolationMode.Fant // high quality
            };

            var pixelData = await decoder.GetPixelDataAsync(
                BitmapPixelFormat.Bgra8,
                BitmapAlphaMode.Premultiplied,
                transform,
                ExifOrientationMode.RespectExifOrientation,
                ColorManagementMode.ColorManageToSRgb);

            var pixels = pixelData.DetachPixelData();

            // Convert to grayscale and boost contrast in-place
            ApplyGrayscaleAndContrast(pixels);

            var bitmap = SoftwareBitmap.CreateCopyFromBuffer(
                pixels.AsBuffer(),
                BitmapPixelFormat.Bgra8,
                (int)scaledWidth,
                (int)scaledHeight,
                BitmapAlphaMode.Premultiplied);

            Logger.Log($"OcrService: Pre-processed {origWidth}x{origHeight} -> {scaledWidth}x{scaledHeight} (scale={scale:F1}x)");

            return bitmap;
        }

        /// <summary>
        /// Converts pixels to grayscale and applies contrast stretching.
        /// Operates on BGRA8 pixel data in-place.
        /// </summary>
        private static void ApplyGrayscaleAndContrast(byte[] pixels)
        {
            // First pass: find min/max luminance for contrast stretching
            byte minLum = 255, maxLum = 0;
            for (int i = 0; i < pixels.Length; i += 4)
            {
                byte b = pixels[i], g = pixels[i + 1], r = pixels[i + 2];
                // ITU-R BT.601 luma
                byte gray = (byte)((r * 77 + g * 150 + b * 29) >> 8);
                if (gray < minLum) minLum = gray;
                if (gray > maxLum) maxLum = gray;
            }

            // Avoid division by zero; skip if image is already high contrast
            int range = maxLum - minLum;
            if (range < 10) range = 255; // nearly uniform image, skip stretching

            // Second pass: apply grayscale + contrast stretch
            for (int i = 0; i < pixels.Length; i += 4)
            {
                byte b = pixels[i], g = pixels[i + 1], r = pixels[i + 2];
                byte gray = (byte)((r * 77 + g * 150 + b * 29) >> 8);

                // Contrast stretch to full 0-255 range
                int stretched = (gray - minLum) * 255 / range;
                byte val = (byte)Math.Clamp(stretched, 0, 255);

                pixels[i] = val;     // B
                pixels[i + 1] = val; // G
                pixels[i + 2] = val; // R
                // Alpha (i+3) unchanged
            }
        }

        // OCR availability can't change without installing a language pack + restart,
        // so probe once and cache (IsAvailable is called per image entry when rendering).
        private static bool? _isAvailable;

        /// <summary>
        /// Returns true if an OCR engine is available on this system. Unavailable on
        /// Windows N/KN editions or systems without an OCR language pack installed.
        /// </summary>
        public static bool IsAvailable()
        {
            if (_isAvailable.HasValue) return _isAvailable.Value;
            try
            {
                _isAvailable = OcrEngine.TryCreateFromUserProfileLanguages() != null;
            }
            catch
            {
                _isAvailable = false;
            }
            return _isAvailable.Value;
        }
    }
}
