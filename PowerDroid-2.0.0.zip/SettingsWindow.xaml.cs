using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PowerDroid
{
    /// <summary>
    /// Settings window with Windows 11 style left navigation
    /// Pages: Home, Manage Rules, Settings, Documentation
    /// </summary>
    public partial class SettingsWindow : Window
    {
        private EventHandler? _navigateToRulesHandler;
        private EventHandler? _testAllRulesHandler;
        private EventHandler? _navigateToClipboardHandler;
        private EventHandler? _navigateToSettingsHandler;
        private EventHandler? _dataChangedHandler;
        private EventHandler? _dataImportedHandler;
        private bool _lastKnownDefaultStatus;
        // Signature of the installed-browser set last seen on activation, used to detect a browser
        // being installed/removed while the window was in the background without paying the cost of
        // re-enumerating profiles every time the window merely regains focus. (#56)
        private string _lastBrowserSignature = string.Empty;

        public SettingsWindow()
        {
            InitializeComponent();

            // Set window size to 70% of screen
            Width = SystemParameters.PrimaryScreenWidth * 0.7;
            Height = SystemParameters.PrimaryScreenHeight * 0.7;
            MinWidth = 900;
            MinHeight = 600;

            // Hide dev-only features in production
            if (!AppConfig.DevMode)
            {
                TestButton.Visibility = Visibility.Collapsed;
            }

            // Auto-import built-in groups if they don't exist (disabled by default)
            UrlGroupManager.EnsureBuiltInGroupsExist();

            // Wire up events from pages
            _navigateToRulesHandler = (s, e) => NavigateToPage("Rules");
            _testAllRulesHandler = (s, e) => OpenTestWindow();
            _navigateToClipboardHandler = (s, e) => NavigateToPage("PowerClip");
            _navigateToSettingsHandler = (s, e) => NavigateToPage("Settings");
            _dataChangedHandler = (s, e) => UpdateRulesCount();
            _dataImportedHandler = (s, e) => OnDataImported();

            HomePageControl.NavigateToRulesRequested += _navigateToRulesHandler;
            HomePageControl.TestAllRulesRequested += _testAllRulesHandler;
            if (BrandConfig.PowerClipEnabled)
                HomePageControl.NavigateToClipboardRequested += _navigateToClipboardHandler;
            HomePageControl.NavigateToSettingsRequested += _navigateToSettingsHandler;
            RulesPageControl.DataChanged += _dataChangedHandler;
            BrowserSettingsPageControl.DataImported += _dataImportedHandler;

            Closing += SettingsWindow_Closing;
            SourceInitialized += (s, e) => ThemeManager.ApplyTitleBarTheme(this);

            // Refresh nav status when theme changes so colors update immediately
            ThemeManager.ThemeChanged += OnThemeChanged;

            // Refresh nav status when monitoring state changes (enable/disable/pause/resume)
            // so the POWER CLIP warning icon updates immediately, from any toggle source.
            Services.TrayIconService.Instance.StateChanged += OnMonitoringStateChanged;

            // Hide Power Clip UI if disabled
            if (!BrandConfig.PowerClipEnabled)
            {
                PowerClipSectionHeader.Visibility = Visibility.Collapsed;
                PowerClipNavItem.Visibility = Visibility.Collapsed;
                ClipSettingsNavItem.Visibility = Visibility.Collapsed;
                WelcomeClipDivider.Visibility = Visibility.Collapsed;
                WelcomeClipFeature.Visibility = Visibility.Collapsed;
            }

            LoadAllData();
            UpdateNavigationStatus();

            _lastKnownDefaultStatus = RegistryHelper.IsSystemDefaultBrowser();
            _lastBrowserSignature = ComputeBrowserSignature();
            Activated += SettingsWindow_Activated;

            // Restore last selected page from settings
            var settings = SettingsManager.LoadSettings();
            var lastPage = settings.LastSelectedPage ?? "Home";

            // If saved page no longer exists or is disabled, redirect to Home
            if (lastPage == "Docs")
                lastPage = "Home";
            if (!BrandConfig.PowerClipEnabled && (lastPage == "PowerClip" || lastPage == "ClipSettings"))
                lastPage = "Home";

            NavigateToPage(lastPage);

            // Check if app was just updated — show "What's New" overlay
            CheckAndShowWhatsNew();

            // Show update notification if already detected
            if (Services.UpdateCheckService.Instance.IsUpdateAvailable)
                ShowUpdateNotification();
        }

        private void SettingsWindow_Activated(object? sender, EventArgs e)
        {
            bool isDefault = RegistryHelper.IsSystemDefaultBrowser();
            bool defaultChanged = isDefault != _lastKnownDefaultStatus;

            // The user may have installed or removed a browser while this window was in the
            // background. Re-detect (cheap — registry + File.Exists, no profile enumeration) and
            // compare against the last seen set so a new browser shows up without restarting. (#56)
            string browserSignature = ComputeBrowserSignature();
            bool browsersChanged = browserSignature != _lastBrowserSignature;
            _lastBrowserSignature = browserSignature;

            if (defaultChanged)
            {
                _lastKnownDefaultStatus = isDefault;
                UpdateNavigationStatus();
            }

            // Nothing relevant changed — skip the costly profile/icon reload of the visible page.
            if (!defaultChanged && !browsersChanged)
                return;

            if (SettingsPageControl.Visibility == Visibility.Visible)
                SettingsPageControl.LoadData();

            if (BrowserSettingsPageControl.Visibility == Visibility.Visible)
                BrowserSettingsPageControl.LoadData();

            if (RulesPageControl.Visibility == Visibility.Visible)
                RulesPageControl.LoadData();

            if (HomePageControl.Visibility == Visibility.Visible)
                HomePageControl.LoadData();

            if (WelcomeOverlay.Visibility == Visibility.Visible)
                UpdateWelcomeDefaultStatus();
        }

        /// <summary>
        /// Clears the browser detection cache and returns a stable signature (sorted executable
        /// paths) of the currently installed browsers. Detection is cheap and does NOT enumerate
        /// profiles, so this is safe to run on every activation; the signature lets the caller pay
        /// for a full reload only when the set of browsers actually changed. (#56)
        /// </summary>
        private static string ComputeBrowserSignature()
        {
            BrowserDetector.ClearCache();
            var paths = BrowserDetector.GetInstalledBrowsers()
                .Select(b => b.ExecutablePath)
                .OrderBy(p => p, StringComparer.OrdinalIgnoreCase);
            return string.Join("|", paths);
        }

        public void ShowWelcomeOverlay()
        {
            WelcomeOverlay.Visibility = Visibility.Visible;
            UpdateWelcomeDefaultStatus();
        }

        private void UpdateWelcomeDefaultStatus()
        {
            bool isDefault = RegistryHelper.IsSystemDefaultBrowser();
            WelcomeSetupCard.Visibility = isDefault ? Visibility.Collapsed : Visibility.Visible;
            WelcomeSetupDoneCard.Visibility = isDefault ? Visibility.Visible : Visibility.Collapsed;
        }

        private void WelcomeSetAsDefault_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!RegistryHelper.IsRegistered())
                {
                    Logger.Log("Welcome: Registering browser before opening Windows Settings");
                    RegistryHelper.RegisterAsDefaultBrowser();
                }

                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = $"ms-settings:defaultapps?registeredAppUser={BrandConfig.RegistryAppId}",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                Logger.Log($"WelcomeSetAsDefault_Click ERROR: {ex.Message}");
            }
        }

        private void WelcomeGetStarted_Click(object sender, RoutedEventArgs e)
        {
            WelcomeOverlay.Visibility = Visibility.Collapsed;

            var settings = SettingsManager.LoadSettings();
            settings.HasSeenWelcome = true;
            SettingsManager.SaveSettings(settings);

            // Refresh all status indicators
            _lastKnownDefaultStatus = RegistryHelper.IsSystemDefaultBrowser();
            UpdateNavigationStatus();
        }

        private void LoadAllData()
        {
            UpdateRulesCount();
        }

        private void UpdateRulesCount()
        {
            try
            {
                var rules = UrlRuleManager.LoadRules();
                var urlGroups = UrlGroupManager.LoadGroups();

                int totalCount = rules.Count + urlGroups.Count;
                RulesCountBadge.Text = totalCount > 0 ? $"({totalCount})" : "";

                // Refresh home page stats if visible
                if (HomePageControl.Visibility == Visibility.Visible)
                {
                    HomePageControl.LoadData();
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateRulesCount ERROR: {ex.Message}");
            }
        }

        private void OnDataImported()
        {
            // Refresh navigation count
            UpdateRulesCount();

            // Refresh rules page if it exists
            RulesPageControl.LoadData();

            Logger.Log("Data imported - refreshed navigation counts and pages");
        }

        /// <summary>
        /// Selects the Settings page programmatically (called after registration)
        /// </summary>
        public void SelectSettingsPage()
        {
            NavigateToPage("Settings");
        }

        /// <summary>
        /// Legacy method for backwards compatibility - redirects to settings page
        /// </summary>
        public void SelectAppTab()
        {
            SelectSettingsPage();
        }

        #region Navigation

        private void NavigationList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (NavigationList.SelectedItem is ListBoxItem selectedItem)
            {
                string? tag = selectedItem.Tag as string;
                if (!string.IsNullOrEmpty(tag))
                {
                    NavigateToPage(tag);
                }
            }
        }

        public void NavigateToPage(string pageName)
        {
            // Guard against calls before pages are initialized
            if (HomePageControl == null || RulesPageControl == null ||
                SettingsPageControl == null)
            {
                return;
            }

            // Hide all pages
            HomePageControl.Visibility = Visibility.Collapsed;
            RulesPageControl.Visibility = Visibility.Collapsed;
            BrowserSettingsPageControl.Visibility = Visibility.Collapsed;
            PowerClipPageControl.Visibility = Visibility.Collapsed;
            ClipSettingsPageControl.Visibility = Visibility.Collapsed;
            SettingsPageControl.Visibility = Visibility.Collapsed;

            // Show selected page and update navigation selection
            switch (pageName)
            {
                case "Home":
                    HomePageControl.Visibility = Visibility.Visible;
                    HomePageControl.LoadData();
                    NavigationList.SelectedItem = HomeNavItem;
                    break;

                case "Rules":
                    RulesPageControl.Visibility = Visibility.Visible;
                    RulesPageControl.LoadData();
                    NavigationList.SelectedItem = RulesNavItem;
                    break;

                case "BrowserSettings":
                    BrowserSettingsPageControl.Visibility = Visibility.Visible;
                    BrowserSettingsPageControl.LoadData();
                    NavigationList.SelectedItem = BrowserSettingsNavItem;
                    break;

                case "PowerClip":
                    if (!BrandConfig.PowerClipEnabled) break;
                    PowerClipPageControl.Visibility = Visibility.Visible;
                    PowerClipPageControl.LoadData();
                    NavigationList.SelectedItem = PowerClipNavItem;
                    break;

                case "ClipSettings":
                    if (!BrandConfig.PowerClipEnabled) break;
                    ClipSettingsPageControl.Visibility = Visibility.Visible;
                    ClipSettingsPageControl.LoadData();
                    NavigationList.SelectedItem = ClipSettingsNavItem;
                    break;

                case "Settings":
                    SettingsPageControl.Visibility = Visibility.Visible;
                    SettingsPageControl.LoadData();
                    NavigationList.SelectedItem = SettingsNavItem;
                    UpdateNavigationStatus();
                    break;

            }

            // Persist the selected page
            try
            {
                var settings = SettingsManager.LoadSettings();
                settings.LastSelectedPage = pageName;
                SettingsManager.SaveSettings(settings);
            }
            catch (Exception ex)
            {
                Logger.Log($"Failed to save last selected page: {ex.Message}");
            }
        }

        /// <summary>
        /// Public method to navigate to the Rules page (used by NotificationHelper)
        /// </summary>
        public void NavigateToRules()
        {
            NavigateToPage("Rules");
        }

        public void NavigateToSettings()
        {
            NavigateToPage("Settings");
        }

        #endregion

        #region Test Automation

        private void TestButton_Click(object sender, RoutedEventArgs e)
        {
            OpenTestWindow();
        }

        private void OpenTestWindow()
        {
            try
            {
                var testWindow = new TestAutomationWindow();
                testWindow.Owner = this;
                testWindow.ShowDialog();

                // Reload data after tests
                UpdateRulesCount();

                // Refresh current page
                if (RulesPageControl.Visibility == Visibility.Visible)
                {
                    RulesPageControl.LoadData();
                }
                else if (HomePageControl.Visibility == Visibility.Visible)
                {
                    HomePageControl.LoadData();
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"OpenTestWindow ERROR: {ex.Message}");
                MessageBox.Show($"Error opening Test window: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #endregion

        #region Status Indicator

        public void UpdateNavigationStatus()
        {
            try
            {
                var settings = SettingsManager.LoadSettings();
                bool isEnabled = settings.IsEnabled;
                bool isDefaultBrowser = RegistryHelper.IsSystemDefaultBrowser();

                if (isEnabled && isDefaultBrowser)
                {
                    // Green - Rules processing enabled AND is default browser
                    var greenBrush = (Brush)FindResource("StatusSuccessFgBrush");
                    StatusDot.Fill = greenBrush;
                    StatusText.Text = "Active";
                    StatusText.Foreground = greenBrush;
                    StatusIndicatorBorder.Background = (Brush)FindResource("StatusSuccessBgBrush");
                    StatusIndicatorBorder.BorderBrush = (Brush)FindResource("StatusSuccessBorderBrush");
                }
                else if (isEnabled && !isDefaultBrowser)
                {
                    // Orange - Rules enabled but not default browser
                    var orangeBrush = (Brush)FindResource("StatusWarningFgBrush");
                    StatusDot.Fill = orangeBrush;
                    StatusText.Text = "Not Default";
                    StatusText.Foreground = orangeBrush;
                    StatusIndicatorBorder.Background = (Brush)FindResource("StatusWarningBgBrush");
                    StatusIndicatorBorder.BorderBrush = (Brush)FindResource("StatusWarningBorderBrush");
                }
                else
                {
                    // Gray - Rules processing disabled
                    var grayBrush = (Brush)FindResource("TextSecondaryBrush");
                    StatusDot.Fill = grayBrush;
                    StatusText.Text = "Paused";
                    StatusText.Foreground = grayBrush;
                    StatusIndicatorBorder.Background = (Brush)FindResource("ControlFillDisabledBrush");
                    StatusIndicatorBorder.BorderBrush = (Brush)FindResource("ControlStrokeSecondaryBrush");
                }

                // Show a warning icon next to the SMART BROWSE nav header when not the default browser
                SmartBrowseWarningIcon.Visibility = isDefaultBrowser ? Visibility.Collapsed : Visibility.Visible;

                // Show a warning icon next to the POWER CLIP nav header when the feature is turned
                // off, or when monitoring isn't capturing (disabled or paused) — mirrors the
                // in-page red warning banner, with a matching tooltip.
                bool powerClipOff = !Services.PowerClipService.Instance.IsEnabled;
                var clip = settings.ClipboardMonitoring;
                bool clipCapturing = !powerClipOff && clip.IsEnabled && !clip.IsPaused;
                PowerClipWarningIcon.Visibility = clipCapturing ? Visibility.Collapsed : Visibility.Visible;
                PowerClipWarningIcon.ToolTip = powerClipOff
                    ? "Power Clip is turned off — clipboard history isn't being captured"
                    : "Clipboard monitoring is off — history isn't being captured";
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateNavigationStatus ERROR: {ex.Message}");
            }
        }

        #endregion

        #region Update Notification

        /// <summary>
        /// Shows the update notification dot on the Settings nav item.
        /// If this is the first time seeing this update, shows the overlay popup too.
        /// </summary>
        public void ShowUpdateNotification()
        {
            var service = Services.UpdateCheckService.Instance;
            if (!service.IsUpdateAvailable) return;

            SettingsUpdateDot.Visibility = Visibility.Visible;

            if (service.ShouldShowPopup)
            {
                UpdateOverlayTitle.Text = "New Version Available";
                UpdateOverlayVersion.Text = !string.IsNullOrWhiteSpace(service.ReleaseTitle)
                    ? $"{service.ReleaseTitle} \u2014 v{service.LatestVersion}"
                    : $"PowerDroid v{service.LatestVersion}";
                UpdateOverlayNotes.Text = !string.IsNullOrWhiteSpace(service.ReleaseNotes)
                    ? service.ReleaseNotes
                    : "A new version is available.";
                UpdateOverlay.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// Hides the update dot (called after user downloads or skips).
        /// </summary>
        public void HideUpdateDot()
        {
            SettingsUpdateDot.Visibility = Visibility.Collapsed;
        }

        private async void UpdateOverlayDownload_Click(object sender, RoutedEventArgs e)
        {
            // Dismiss overlay and navigate to Settings page to show progress
            Services.UpdateCheckService.Instance.MarkPopupSeen();
            UpdateOverlay.Visibility = Visibility.Collapsed;
            NavigateToPage("Settings");

            // Trigger download from the Settings page
            var settingsPage = SettingsPageControl;
            if (settingsPage != null)
            {
                settingsPage.RefreshUpdateStatus();
                // Simulate clicking the download button
                settingsPage.StartDownloadAndInstall();
            }
        }

        private void UpdateOverlayLater_Click(object sender, RoutedEventArgs e)
        {
            Services.UpdateCheckService.Instance.MarkPopupSeen();
            UpdateOverlay.Visibility = Visibility.Collapsed;
            // Dot remains visible
        }

        private void UpdateOverlayBackground_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Clicking outside the card dismisses
            Services.UpdateCheckService.Instance.MarkPopupSeen();
            UpdateOverlay.Visibility = Visibility.Collapsed;
        }

        private void UpdateOverlayCard_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Prevent click-through to background
            e.Handled = true;
        }

        #endregion

        #region What's New Overlay

        /// <summary>
        /// Checks if the app was just updated and shows a "What's New" overlay.
        /// Call this after the window is loaded.
        /// </summary>
        public void CheckAndShowWhatsNew()
        {
            var settings = SettingsManager.LoadSettings();
            var currentVersion = BrandConfig.Version;

            // If PreviousAppVersion is empty, this is a fresh install — just record the version
            // (Welcome overlay is shown separately via ShowWelcomeOverlay from App.xaml.cs)
            if (string.IsNullOrEmpty(settings.PreviousAppVersion))
            {
                settings.PreviousAppVersion = currentVersion;
                SettingsManager.SaveSettings(settings);
                return;
            }

            // If version changed, show What's New (reset HasSeenWhatsNew for manual installs)
            if (settings.PreviousAppVersion != currentVersion)
            {
                var prevVersion = settings.PreviousAppVersion;
                WhatsNewVersionText.Text = $"PowerDroid v{currentVersion}  (was v{prevVersion})";

                // Release-notes source order:
                //  1. Cached notes from a prior online update check (freshest, if present).
                //  2. Otherwise (e.g. a manual install) fetch this version's notes live from GitHub.
                //  3. Otherwise fall back to the bundled CHANGELOG.md section for this version.
                //  4. Otherwise a generic message.
                var cached = settings.LastKnownReleaseNotes;
                if (!string.IsNullOrWhiteSpace(cached))
                {
                    WhatsNewNotesText.Text = Services.UpdateCheckService.StripMarkdown(cached);
                }
                else
                {
                    // Show the bundled changelog immediately so there's real content offline, then
                    // try GitHub — if it has this version's release, prefer that (it can't be empty).
                    var changelog = Services.UpdateCheckService.GetBundledChangelogNotes(currentVersion);
                    WhatsNewNotesText.Text = !string.IsNullOrWhiteSpace(changelog)
                        ? changelog
                        : "This version includes new features and improvements.";
                    _ = LoadWhatsNewFromGitHubAsync(currentVersion);
                }

                WhatsNewOverlay.Visibility = Visibility.Visible;

                // Navigate to Home page
                NavigateToPage("Home");
            }
        }

        /// <summary>
        /// Manual-install fallback: fetch this version's release notes live from GitHub and, if
        /// found, replace the bundled-changelog text already showing in the overlay.
        /// </summary>
        private async Task LoadWhatsNewFromGitHubAsync(string version)
        {
            try
            {
                var notes = await Services.UpdateCheckService.Instance.GetReleaseNotesForVersionAsync(version);
                if (!string.IsNullOrWhiteSpace(notes))
                    Dispatcher.Invoke(() => WhatsNewNotesText.Text = notes);
            }
            catch (Exception ex)
            {
                Logger.Log($"LoadWhatsNewFromGitHubAsync error: {ex.Message}");
            }
        }

        private void WhatsNewGetStarted_Click(object sender, RoutedEventArgs e)
        {
            WhatsNewOverlay.Visibility = Visibility.Collapsed;

            var settings = SettingsManager.LoadSettings();
            settings.PreviousAppVersion = BrandConfig.Version;
            settings.HasSeenWhatsNew = true;
            // Reset update state since we just installed the update
            settings.LastKnownUpdateVersion = string.Empty;
            settings.HasSeenUpdatePopup = false;
            SettingsManager.SaveSettings(settings);
        }

        private void WhatsNewOverlayBackground_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            WhatsNewGetStarted_Click(sender, e);
        }

        private void WhatsNewOverlayCard_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            e.Handled = true;
        }

        #endregion

        #region Cleanup

        private void OnThemeChanged(object? sender, EventArgs e)
        {
            UpdateNavigationStatus();
            ThemeManager.ApplyTitleBarTheme(this);
        }

        private void OnMonitoringStateChanged(object? sender, EventArgs e)
        {
            Dispatcher.Invoke(UpdateNavigationStatus);
        }

        private void SettingsWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            ThemeManager.ThemeChanged -= OnThemeChanged;
            Services.TrayIconService.Instance.StateChanged -= OnMonitoringStateChanged;

            // Unsubscribe from page events to prevent memory leaks
            if (_navigateToRulesHandler != null)
                HomePageControl.NavigateToRulesRequested -= _navigateToRulesHandler;
            if (_testAllRulesHandler != null)
                HomePageControl.TestAllRulesRequested -= _testAllRulesHandler;
            if (_navigateToClipboardHandler != null)
                HomePageControl.NavigateToClipboardRequested -= _navigateToClipboardHandler;
            if (_navigateToSettingsHandler != null)
                HomePageControl.NavigateToSettingsRequested -= _navigateToSettingsHandler;
            if (_dataChangedHandler != null)
                RulesPageControl.DataChanged -= _dataChangedHandler;
            if (_dataImportedHandler != null)
                BrowserSettingsPageControl.DataImported -= _dataImportedHandler;
        }

        #endregion
    }
}
