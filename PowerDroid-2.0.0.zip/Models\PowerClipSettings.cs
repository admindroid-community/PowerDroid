namespace PowerDroid.Models
{
    /// <summary>
    /// Settings for the Power Clip feature.
    /// Stored separately in powerclip-settings.json.
    /// </summary>
    public class PowerClipSettings
    {
        public bool IsEnabled { get; set; } = true;
        public int RetentionDays { get; set; } = 0; // Legacy, no longer used in UI
        public int MaxEntries { get; set; } = 200;
        public bool CaptureUrls { get; set; } = true;
        public bool CaptureText { get; set; } = true;
        public bool CaptureFilePaths { get; set; } = true;
        public bool CaptureImages { get; set; } = true;
        public long MaxImageStorageMB { get; set; } = 200;
    }
}
