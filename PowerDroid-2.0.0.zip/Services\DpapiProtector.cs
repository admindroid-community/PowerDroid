using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace PowerDroid.Services
{
    /// <summary>
    /// Encrypts and decrypts data at rest using the Windows Data Protection API (DPAPI),
    /// scoped to the current user. The encryption key is derived from the user's Windows
    /// login and managed entirely by the OS — the app never sees or stores a key. Blobs
    /// produced here cannot be decrypted by another Windows user, on another machine, or
    /// from an offline copy of the file.
    ///
    /// Implemented via crypt32 P/Invoke (CryptProtectData/CryptUnprotectData) so no extra
    /// NuGet dependency is required. This is the same mechanism the managed
    /// System.Security.Cryptography.ProtectedData wraps.
    /// </summary>
    internal static class DpapiProtector
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct DATA_BLOB
        {
            public int cbData;
            public IntPtr pbData;
        }

        // CRYPTPROTECT_UI_FORBIDDEN — never show a UI prompt; fail instead. Required for a
        // background/service context.
        private const int CRYPTPROTECT_UI_FORBIDDEN = 0x1;

        [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool CryptProtectData(
            ref DATA_BLOB pDataIn, string? szDataDescr, IntPtr pOptionalEntropy,
            IntPtr pvReserved, IntPtr pPromptStruct, int dwFlags, ref DATA_BLOB pDataOut);

        [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool CryptUnprotectData(
            ref DATA_BLOB pDataIn, IntPtr ppszDataDescr, IntPtr pOptionalEntropy,
            IntPtr pvReserved, IntPtr pPromptStruct, int dwFlags, ref DATA_BLOB pDataOut);

        [DllImport("kernel32.dll")]
        private static extern IntPtr LocalFree(IntPtr hMem);

        /// <summary>
        /// Encrypts <paramref name="plaintext"/> for the current user. Throws on failure.
        /// </summary>
        public static byte[] Protect(byte[] plaintext)
        {
            return Transform(plaintext, protect: true);
        }

        /// <summary>
        /// Decrypts a blob previously produced by <see cref="Protect"/>. Throws on failure
        /// (e.g. the blob was produced by a different user or is not a DPAPI blob).
        /// </summary>
        public static byte[] Unprotect(byte[] ciphertext)
        {
            return Transform(ciphertext, protect: false);
        }

        private static byte[] Transform(byte[] input, bool protect)
        {
            var inBlob = new DATA_BLOB();
            var outBlob = new DATA_BLOB();
            try
            {
                inBlob.cbData = input.Length;
                inBlob.pbData = Marshal.AllocHGlobal(Math.Max(1, input.Length));
                if (input.Length > 0)
                    Marshal.Copy(input, 0, inBlob.pbData, input.Length);

                bool ok = protect
                    ? CryptProtectData(ref inBlob, null, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero,
                                       CRYPTPROTECT_UI_FORBIDDEN, ref outBlob)
                    : CryptUnprotectData(ref inBlob, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero,
                                         CRYPTPROTECT_UI_FORBIDDEN, ref outBlob);

                if (!ok)
                    throw new Win32Exception(Marshal.GetLastWin32Error());

                var result = new byte[outBlob.cbData];
                if (outBlob.cbData > 0)
                    Marshal.Copy(outBlob.pbData, result, 0, outBlob.cbData);
                return result;
            }
            finally
            {
                if (inBlob.pbData != IntPtr.Zero) Marshal.FreeHGlobal(inBlob.pbData);
                if (outBlob.pbData != IntPtr.Zero) LocalFree(outBlob.pbData);
            }
        }
    }
}
